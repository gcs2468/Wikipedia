package com.epam.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.epam.ui.base.SeleniumUtils;

public class AirtelPage extends SeleniumUtils {

    @FindBy(id = "number-one")
    private WebElement username;

    @FindBy(id = "pasword")
    private WebElement password;

    @FindBy(id = "loginButtonSpan")
    private WebElement loginButton;

   

    public void enterUserNamePassword(String arg1, String arg2) {

    	username.sendKeys(arg1);
        password.sendKeys(arg2);
    }

    public void clickOnLogin() {
        loginButton.click();
    }

    

}
