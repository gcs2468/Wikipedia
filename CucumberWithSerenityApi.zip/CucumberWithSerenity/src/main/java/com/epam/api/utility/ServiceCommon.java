package com.epam.api.utility;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;

import com.epam.ta.reportportal.ws.model.log.SaveLogRQ.File;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification; 
/**
 * Utility class containing common methods related to restassured.
 */
public final class ServiceCommon {


    /**
     * Private constructor for utility class.
     */
    private ServiceCommon() {
    }

    /**
     * Base URL.
     */
    private static String baseURL;

    /**
     * baseURL getter method.
     *
     * @return - String
     */
    public static String getBaseURL() {
        return baseURL;
    }

    /**
     * baseURL setter method.
     *
     * @param baseUrl - Base url.
     */
    public static void setBaseURI(final String baseUrl) {
        ServiceCommon.baseURL = baseUrl;
    }

    /**
     * Verifies the status code of the response.
     *
     * @param pathToResource - Path to the resource.
     * @param statusCode     - Status code to be checked.
     */
    public static void checkStatusCode(final String pathToResource, final int statusCode) {
        given().when().get(getBaseURL() + pathToResource).then().assertThat().statusCode(statusCode);
    }

    /**
     * Checks the value for a certain key in json.
     *
     * @param pathToResource - Path to resourse.
     * @param jpath          - Jpath to locate the key.
     * @param data           - Value to be verified for that key.
     */
    public static void checkContentInJson(final String pathToResource, final String jpath, final String data) {
        given().header("Accept", "application/json").when().get(getBaseURL() + pathToResource).then().body(jpath,
                equalTo(data));
    }

    /**
     * Checks the value for a certain key in xml.
     *
     * @param pathToResource - Path to resource.
     * @param xmlPath        - xml path to locate the key.
     * @param data           - Value to be verified for that key.
     */
    public static void checkContentInXml(final String pathToResource, final String xmlPath, final String data) {
        given().header("Accept", "application/xml").when().get(getBaseURL() + pathToResource).then().body(xmlPath,
                equalTo(data));
    }

    /**
     * This method verifies a cookie.
     *
     * @param pathToResource - Path to resource.
     * @param cookieKey      - Key value of cookie.
     * @param cookieValue    - Value of that cookie.
     */
    public static void verifyCookies(final String pathToResource, final String cookieKey, final String cookieValue) {
        given().when().get(getBaseURL() + pathToResource).then().assertThat().cookie(cookieKey, cookieValue);
    }

    /**
     * This method verifies header value.
     *
     * @param pathToResource - Path to resource.
     * @param headerKey      - Key of the header.
     * @param headerValue    - Value of the header.
     */
    public static void verifyHeaders(final String pathToResource, final String headerKey, final String headerValue) {
        given().when().get(getBaseURL() + pathToResource).then().assertThat().header(headerKey, headerValue);
    }

    /**
     * This method verifies the content type of the request.
     *
     * @param pathToResource - Path to the resource.
     * @param contentType    - Content type string.
     */
    public static void verifyContentType(final String pathToResource, final String contentType) {
        given().when().get(getBaseURL() + pathToResource).then().assertThat().contentType(contentType);
    }

    /**
     * This method verifies the content type of the request.
     *
     * @param pathToResource - Path to the resource.
     * @param contentType    - Content type.
     */
    public static void verifyContentType(final String pathToResource, final ContentType contentType) {
        given().when().get(getBaseURL() + pathToResource).then().assertThat().contentType(contentType);
    }

    /**
     * This method returns a ValidateResponce object which can be used to perform
     * chain of assertions.
     *
     * @param pathToResource - Path to resource.
     * @return - ValidatableResponce.
     */
    public static ValidatableResponse assertChain(final String pathToResource) {
        return given().when().get(getBaseURL() + pathToResource).then().assertThat();
    }
    /**
     * This method returns a ValidateResponce object 
     * @param properties - properties to resource.
     * @param endPoint - Path to resource.
     * @return - ValidatableResponce.
     */
    public static Response getReponse(String endPoint,Properties properties) {
    	return given().spec(setHeaderParams(properties)).when().get(endPoint);
    }
    /**
     * This method returns a ValidateResponce object
     * @param filePath - filePath. 
     * @param properties - properties to resource.
     * @param endPoint - Path to resource.
     * @return - ValidatableResponce.
     */
    public static Response postReponse(String endPoint,Properties properties, String filePath) throws IOException {   	
    	FileInputStream fs = new FileInputStream(filePath);
        return RestAssured.given().headers("Content-Type","application/json").and().body(IOUtils.toString(fs,"UTF-8")).log().all().when().post("https://petstore.swagger.io/v2/pet");
    	
    }
    /**
     * This method returns a boolean
     * @param Response - response.    
     * @return - ValidatableResponce.
     */
    public static boolean verifyContentType(Response response) {
    	System.out.println("content type-->"+response.getContentType());
		return response.getContentType().equals("application/json");
    	
    }
    /**
     * This method set the Request Parameters and Header Parameters
     * This method returns a RequestSpecification
     * @param properties - Properties.    
     * @return - RequestSpecification.
     */
    public static RequestSpecification setHeaderParams(Properties properties) {
    	 RestAssured.reset();
         Set<String> keys = properties.stringPropertyNames();
         System.out.println(keys);
         for (String key : keys) {
             if (key.endsWith("IP"))
                 RestAssured.baseURI = properties.getProperty(key);
             else if (key.endsWith("PORT"))
                 RestAssured.port = Integer.parseInt(properties.getProperty(key));
             else if (key.endsWith("BASE_PATH"))
                 RestAssured.basePath = properties.getProperty(key);
         }

        return getRequestSpecification(setHeaders());
    }
    public static RequestSpecification getRequestSpecification(Map<String, String> headers) {

        return RestAssured.given().log().all().
               headers(headers).contentType("application/json");
    }
    public static Map<String, String> setHeaders() {

        Map<String, String> headers = new HashMap<String, String>();
           /*headers.put("Authorization", "Bearer " + PostUserLogin.getInstance().getToken());
           System.out.println("Authorizarion token is :"+PostUserLogin.getInstance().getToken());
           System.out.println("Headers are :" + headers);*/
           headers.put("Content-Type","application/json");
           return headers;
       }
   
    public static boolean statusChecks(Response response) {

        if (response.statusCode() == 200) {
            if (response.getTimeIn(TimeUnit.SECONDS) < 60) {
                System.out.println("Response Time is less than 60 i.e: " + response.getTimeIn(TimeUnit.SECONDS) + " Second(s)");
                return true;
            } else {
                System.out.println("Response time is greater than 60 i.e " + response.getTimeIn(TimeUnit.SECONDS) + " Second(s)");
                return false;
            }
        } else if (response.statusCode() == 401) {
            System.out.println("User is Unauthorised" + response.statusCode());
            return false;
        } else if (response.statusCode() == 502) {
            System.out.println("Bad Gateway" + response.statusCode());
            return false;
        }  else if (response.statusCode() == 400){
                System.out.println("Bad Request"+response.statusCode());
            return false;
        } else {
            System.out.println("Unable to Call the API " + response.statusCode());
            return false;
        }
    }


}
