package com.epam.api.base;

public interface APIEndPoints {

    String EMPLOYEE_API = "employees"; //get api
    String EMPLOYEE_CREATION_API = "create" ; //Post api
    
    String Albums_API = "albums";
}
