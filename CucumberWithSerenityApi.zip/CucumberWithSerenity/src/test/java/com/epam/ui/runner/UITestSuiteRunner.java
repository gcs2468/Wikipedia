package com.epam.ui.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;


import com.epam.api.runner.APITestSuiteRunner;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = {"src\\main\\java\\com\\epam\\ui\\features"},
        glue="com.epam.ui.stepDefinitions",
       // tags = {"@uismoke"},
        snippets = SnippetType.CAMELCASE,
        format = {"pretty", "html:test-output"}
)
public class UITestSuiteRunner {

	 private static  Logger logger = LogManager.getLogger(APITestSuiteRunner.class);

    /**
     * Define runtime properties for test execution
     */
    /*@BeforeClass
    public static void setupProperties() {
    	logger.info("This is set logger");
    	
    	System.out.println("************"+System.getProperty("env.value"));

        System.setProperty("ExecutionEnv", "Stage");   // Environment to execute against

        System.setProperty("BrowserEnv", "local");     // "local" or "saucelab"
        
        // Default is FireFox
        System.setProperty("BrowserType", "firefox");  // for "ie" or "firefox" or "chrome" or "edge" or "headless chrome" or "headless firefox"

        System.setProperty("BrowserVersion", "61"); //Firefox version

        logger.info("Environment to execute is :: " + System.getProperty("ExecutionEnv"));

    }
*/

}


