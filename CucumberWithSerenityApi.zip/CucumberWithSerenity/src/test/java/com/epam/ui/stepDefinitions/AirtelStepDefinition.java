package com.epam.ui.stepDefinitions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.api.runner.APITestSuiteRunner;
import com.epam.ui.pages.AirtelPage;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class AirtelStepDefinition {
	 private static  Logger logger = LogManager.getLogger(APITestSuiteRunner.class);
	AirtelPage airtelPage=new AirtelPage();
	@Given("^Navigate to application$")
	public void navigate_to_application(DataTable dt) throws Exception {
		 List<Map<String, String>> list = dt.asMaps(String.class, String.class);
		 logger.info("URL is : "+list.get(0).get("URL"));
		    airtelPage.getUrl(list.get(0).get("URL"));
	}
	
	

@When("^User enters username and password$")
public void user_enters_username_and_password(DataTable dt) throws Exception {
	 List<Map<String, String>> list = dt.asMaps(String.class, String.class);
	 airtelPage.enterUserNamePassword(list.get(0).get("UserName"), list.get(0).get("Password"));
}
@When("^User clicks on signin button$")
public void user_clicks_on_signin_button() throws Exception {
    // Write code here that turns the phrase above into concrete actions
   airtelPage.clickOnLogin();
}}
