package com.epam.api.stepDefinitions;

import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.api.base.APIEndPoints;
import com.epam.api.runner.APITestSuiteRunner;
import com.epam.api.utility.ApplicationConfig;
import com.epam.api.utility.ServiceCommon;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateAlbum {
	   private static  Logger logger = LogManager.getLogger(APITestSuiteRunner.class);
	 public Response albumJson;
	    public String empApi = APIEndPoints.Albums_API;
	    public String path = System.getProperty("user.dir")+"\\src\\main\\resources\\jsonpaylods\\postResource.json";
	
	@Given("^user building a post api with all the parameters$")
	public void user_building_a_post_api_with_all_the_parameters() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		Properties	properties= ApplicationConfig.getAppConfigInstance();
		albumJson= ServiceCommon.postReponse(empApi ,properties,path);
	}

	@When("^user passing pet creation payload$")
	public void user_passing_pet_creation_payload() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		System.out.println(albumJson.getStatusCode());
	}

	@Then("^a new Album should be created$")
	public void a_new_Album_should_be_created() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		albumJson.prettyPrint();
		JsonPath json = new JsonPath(albumJson.asString());
				logger.info("id is : "+json.getString("id"));
	}


}
