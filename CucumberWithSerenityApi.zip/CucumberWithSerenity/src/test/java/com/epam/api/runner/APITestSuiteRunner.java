package com.epam.api.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;


@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = {"src\\main\\java\\com\\epam\\api\\features"},
        glue="com.epam.api.stepDefinitions",
        //tags = {"@smoke"},
        snippets = SnippetType.CAMELCASE,
        format = {"pretty", "html:test-output"}
)
public class APITestSuiteRunner {

    private static  Logger logger = LogManager.getLogger(APITestSuiteRunner.class);

    

}


