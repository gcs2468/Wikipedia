package com.epam.api.stepDefinitions;

public class VlidateUserStepDef  {/*
	 public Response empJsonResponse;

	    
	    @Given("^User provided all the inputs parameters for an api$")
	    public void userProvidedAllTheInputsParametersForAnApi() throws Exception {
	        // Write code here that turns the phrase above into concrete actions
	    	Properties	properties= ApplicationConfig.getAppConfigInstance();
		       empJsonResponse= ServiceCommon.getReponse(APIEndPoints.Albums_API ,properties);
	    }

	    @When("^User hitting an employee get api$")
	    public void userHittingAnEmployeeGetApi() throws Exception {
	        // Write code here that turns the phrase above into concrete actions
	    	 System.out.println("this is response api method");
		        empJsonResponse.prettyPrint();
		  	   // Assert.assertTrue(ServiceCommon.verifyContentType(empJsonResponse));
		        Assert.assertTrue(ServiceCommon.statusChecks(empJsonResponse));
	    }

	    @Then("^User should be able to get all the employee information and response schema also validated$")
	    public void userShouldBeAbleToGetAllTheEmployeeInformationAndResponseSchemaAlsoValidated() throws Exception {
	    	JsonPath json = new JsonPath(empJsonResponse.asString());
		       // empJsonResponse.then().assertThat().body(matchesJsonSchema("C:\\Users\\Sai Ram\\workspace\\ApiAuto\\src\\test\\java\\resources\\EmployeeApis\\GetAllEmployee.json"));
		      System.out.println("Id value-->"+json.get("id").toString());

	    }
*/}
