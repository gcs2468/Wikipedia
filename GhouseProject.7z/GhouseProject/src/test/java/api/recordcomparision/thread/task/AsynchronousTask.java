package api.recordcomparision.thread.task;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * Used for performing asynchronous operation.
 *
 * @param <V> the type expected from the result of the asynchronous operation.
 */
public class AsynchronousTask<V> {

    private Thread thread;
    private FutureTask<V> futureTask;

    public AsynchronousTask(Callable<V> task) {
        this.futureTask = new FutureTask<>(task);
        thread = new Thread(futureTask);
        thread.start();
    }

    /**
     * Waits for the thread to finish execution and returns the return value.
     *
     * @return the expected return value.
     * @throws InterruptedException in case of interruption.
     */
    public V get() throws InterruptedException, ExecutionException {
        thread.join();
        return futureTask.get();
    }

}
