package api.recordcomparision.migration;

import api.recordcomparision.thread.task.AsynchronousTask;
import com.ebsco.api.comparision.CaseComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.CaseCustomVal;
import com.ebsco.api.netsuite.services.retrieval.CaseData;
import com.ebsco.api.salesforce.pojo.Case;
import com.ebsco.api.salesforce.services.CasesAll;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public class CaseMigrationValidation implements Runnable {
    private List<String> recordIDs;
    private NetSuiteConnectionPool pool;
    private Queue<ReportData> reportQueue;

    public CaseMigrationValidation(List<String> recordIDs, NetSuiteConnectionPool pool, Queue<ReportData> reportQueue) {
        this.recordIDs = recordIDs;
        this.pool = pool;
        this.reportQueue = reportQueue;
    }
    @Override
    public void run() {
        try {
            AsynchronousTask<Map<String, Case>> sfRecordRetriever = new AsynchronousTask<>(CasesAll::queryCases);
            AsynchronousTask<Map<String, CaseCustomVal>> nsRecordRetriever =
                    new AsynchronousTask<>(() -> new CaseData().get(recordIDs, pool));
            DataMigration<CaseCustomVal, Case> dataMigration = new CaseMigration(reportQueue, nsRecordRetriever.get(), sfRecordRetriever.get(), new CaseComparator());
            dataMigration.assertMigrationFromNSToSF();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
