package api.recordcomparision.migration;

import api.recordcomparision.thread.task.AsynchronousTask;
import com.ebsco.api.comparision.MessageComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.retrieval.MessageData;
import com.ebsco.api.netsuite.services.pojo.MessageCustomVal;
import com.ebsco.api.salesforce.pojo.Message;
import com.ebsco.api.salesforce.services.MessagesAll;

import java.util.List;
import java.util.Map;
import java.util.Queue;

public class MessageMigrationValidation implements Runnable {
    private List<String> recordIDs;
    private NetSuiteConnectionPool pool;
    private Queue<ReportData> reportQueue;

    public MessageMigrationValidation(List<String> recordIDs, NetSuiteConnectionPool pool, Queue<ReportData> reportQueue) {
        this.recordIDs = recordIDs;
        this.pool = pool;
        this.reportQueue = reportQueue;
    }
    @Override
    public void run() {
        try {
            AsynchronousTask<Map<String, Message>> sfRecordRetriever = new AsynchronousTask<>(MessagesAll::queryMessage);
            AsynchronousTask<Map<String, MessageCustomVal>> nsRecordRetriever =
                    new AsynchronousTask<>(() -> new MessageData().get(recordIDs, pool));
//            System.out.println("*****"+sfRecordRetriever.get().size());
            DataMigration<MessageCustomVal, Message> dataMigration = new MessageMigration(reportQueue, nsRecordRetriever.get(), sfRecordRetriever.get(), new MessageComparator());
            dataMigration.assertMigrationFromNSToSF();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
