package api.recordcomparision.migration;

import com.ebsco.api.comparision.ContactComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.ContactCustomVal;
import com.ebsco.api.netsuite.services.retrieval.ContactData;
import com.ebsco.api.salesforce.pojo.Contact;

import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.stream.Collectors;

public class ContactMigrationValidationSFtoNS implements Runnable {
    private Map<String, Contact> sfRecordIDs;
    private NetSuiteConnectionPool pool;
    private Queue<ReportData> reportQueue;

    public ContactMigrationValidationSFtoNS(Map<String, Contact> recordIDs, NetSuiteConnectionPool pool,
                                            Queue<ReportData> reportQueue) {
        this.pool = pool;
        this.sfRecordIDs = recordIDs;
        this.reportQueue = reportQueue;
    }


    @Override
    public void run() {
        try {
            List<String> nsContactIDs =
                    sfRecordIDs.values().stream().map(Contact::getEISNetsuiteRecordIdC).collect(Collectors.toList());
            Map<String, ContactCustomVal> contacts =
                    new ContactData().get(nsContactIDs, pool);
            DataMigration<ContactCustomVal, Contact> dataMigration =
                    new ContactMigration(reportQueue, contacts, sfRecordIDs, new ContactComparator());
            dataMigration.assertMigrationFromSFToNS();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
