package api.recordcomparision.migration;

import com.ebsco.api.comparision.AbstractRecordComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.pojo.CaseCustomVal;
import com.ebsco.api.salesforce.pojo.Case;
import com.netsuite.suitetalk.proxy.v2017_2.lists.support.SupportCase;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

public class CaseMigration extends DataMigration<CaseCustomVal, Case> {
    CaseMigration(Collection<ReportData> reportQueue, Map<String, CaseCustomVal> netSuiteRecordList, Map<String,Case> salesForceRecordList, AbstractRecordComparator<CaseCustomVal, Case> comparator) {
        super(reportQueue, netSuiteRecordList, salesForceRecordList, comparator);
        System.out.println("size of net suite map"+ netSuiteRecordList.size() +"--size of salesforce map"+salesForceRecordList.size());
    }

    @Override
    Function<Case, String> getNetSuiteRecordId() {
        return Case::getEISNetsuiteRecordIdC;
    }

    @Override
    Function<CaseCustomVal, String> getSalesForceRecordId() {
        return SupportCase::getExternalId ;
    }

    @Override
    Function<CaseCustomVal, String> getInternalIdFromNetsuite() {
        return  SupportCase::getInternalId;
    }

    @Override
    Function<Case, String> getInternalIdFromSalesForce() {
        return com.ebsco.api.salesforce.pojo.Case::getId;
    }
}
