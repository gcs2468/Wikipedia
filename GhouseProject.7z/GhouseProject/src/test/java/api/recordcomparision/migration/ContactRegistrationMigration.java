package api.recordcomparision.migration;

import com.ebsco.api.comparision.AbstractRecordComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.pojo.ContactCustomVal;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

public class ContactRegistrationMigration extends DataMigration<ContactCustomVal, com.ebsco.api.salesforce.pojo.Contact> {


    ContactRegistrationMigration(Collection<ReportData> reportQueue, Map<String, ContactCustomVal> netSuiteRecordList, Map<String, com.ebsco.api.salesforce.pojo.Contact> salesForceRecordList, AbstractRecordComparator<ContactCustomVal, com.ebsco.api.salesforce.pojo.Contact> comparator) {
        super(reportQueue, netSuiteRecordList, salesForceRecordList, comparator);
    }

    @Override
    Function<com.ebsco.api.salesforce.pojo.Contact, String> getNetSuiteRecordId() {
        return com.ebsco.api.salesforce.pojo.Contact::getEISNetsuiteRecordIdC;
    }

    @Override
    Function<ContactCustomVal, String> getSalesForceRecordId() {
        return ContactCustomVal::getExternalId;
    }

    @Override
    Function<ContactCustomVal, String> getInternalIdFromNetsuite() {
        return  ContactCustomVal::getInternalId;
    }

    @Override
    Function<com.ebsco.api.salesforce.pojo.Contact, String> getInternalIdFromSalesForce() {
        return com.ebsco.api.salesforce.pojo.Contact::getId;
    }
}
