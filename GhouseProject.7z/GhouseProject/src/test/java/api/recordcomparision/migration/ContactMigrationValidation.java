package api.recordcomparision.migration;

import api.recordcomparision.thread.task.AsynchronousTask;
import com.ebsco.api.comparision.ContactComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.ContactCustomVal;
import com.ebsco.api.netsuite.services.retrieval.ContactData;
import com.ebsco.api.salesforce.pojo.Contact;
import com.ebsco.api.salesforce.services.ContactsAll;

import java.util.List;
import java.util.Map;
import java.util.Queue;

public class ContactMigrationValidation implements Runnable {

    private List<String> recordIDs;
    private NetSuiteConnectionPool pool;
    private Queue<ReportData> reportQueue;

    public ContactMigrationValidation(List<String> recordIDs, NetSuiteConnectionPool pool, Queue<ReportData> reportQueue) {
        this.recordIDs = recordIDs;
        this.pool = pool;
        this.reportQueue = reportQueue;
    }


    @Override
    public void run() {
        try {
            AsynchronousTask<Map<String, Contact>> sfRecordRetriever = new AsynchronousTask<>(ContactsAll::queryContact);
            AsynchronousTask<Map<String, ContactCustomVal>> nsRecordRetriever =
                    new AsynchronousTask<>(() -> new ContactData().get(recordIDs, pool));
            DataMigration<ContactCustomVal, Contact> dataMigration = new ContactMigration(reportQueue, nsRecordRetriever.get(), sfRecordRetriever.get(), new ContactComparator());
            dataMigration.assertMigrationFromNSToSF();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
