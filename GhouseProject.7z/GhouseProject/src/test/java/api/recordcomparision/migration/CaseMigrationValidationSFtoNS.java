package api.recordcomparision.migration;

import com.ebsco.api.comparision.CaseComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.CaseCustomVal;
import com.ebsco.api.netsuite.services.retrieval.CaseData;
import com.ebsco.api.salesforce.pojo.Case;

import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.stream.Collectors;

public class CaseMigrationValidationSFtoNS implements Runnable {
    private Map<String, Case> sfRecordIDs;
    private NetSuiteConnectionPool pool;
    private Queue<ReportData> reportQueue;

    public CaseMigrationValidationSFtoNS(Map<String, Case> recordIDs, NetSuiteConnectionPool pool,
                                         Queue<ReportData> reportQueue) {
        this.pool = pool;
        this.sfRecordIDs = recordIDs;
        this.reportQueue = reportQueue;
    }


    @Override
    public void run() {
        try {
            List<String> nsCaseIDs =
                    sfRecordIDs.values().stream().map(Case::getEISNetsuiteRecordIdC).collect(Collectors.toList());
            Map<String, CaseCustomVal> cases =
                    new CaseData().get(nsCaseIDs, pool);
            DataMigration<CaseCustomVal, Case> dataMigration =
                    new CaseMigration(reportQueue, cases, sfRecordIDs, new CaseComparator());
            dataMigration.assertMigrationFromSFToNS();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
