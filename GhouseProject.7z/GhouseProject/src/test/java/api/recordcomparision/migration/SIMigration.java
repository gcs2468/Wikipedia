package api.recordcomparision.migration;

import com.ebsco.api.comparision.AbstractRecordComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.api.salesforce.pojo.ServiceIssues;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

public class SIMigration extends DataMigration<ServiceIssue, ServiceIssues> {
    public SIMigration(Collection<ReportData> reportQueue, Map<String, ServiceIssue> netSuiteRecordList, Map<String, ServiceIssues> salesForceRecordList, AbstractRecordComparator<ServiceIssue, ServiceIssues> comparator) {
        super(reportQueue, netSuiteRecordList, salesForceRecordList, comparator);
    }

    @Override
    Function<ServiceIssues, String> getNetSuiteRecordId() {
        return ServiceIssues::getEISNetsuiteRecordIdC;
    }

    @Override
    Function<ServiceIssue, String> getSalesForceRecordId() {
        return ServiceIssue::getSfServiceIssueId ;
    }

    @Override
    Function<ServiceIssue, String> getInternalIdFromNetsuite() {
        return  ServiceIssue::getNetsuiteInternalId;
    }

    @Override
    Function<ServiceIssues, String> getInternalIdFromSalesForce() {
        return ServiceIssues::getId;
    }
}
