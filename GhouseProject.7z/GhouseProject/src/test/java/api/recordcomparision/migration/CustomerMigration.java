package api.recordcomparision.migration;

import com.ebsco.api.comparision.AbstractRecordComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.pojo.CustomerCustomVal;
import com.ebsco.api.salesforce.pojo.Record;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

public class CustomerMigration extends DataMigration<CustomerCustomVal, Record> {


    CustomerMigration(Collection<ReportData> reportQueue, Map<String, CustomerCustomVal> netSuiteRecordList, Map<String, Record> salesForceRecordList, AbstractRecordComparator<CustomerCustomVal, Record> comparator) {
        super(reportQueue, netSuiteRecordList, salesForceRecordList, comparator);
    }

    @Override
    Function<Record, String> getNetSuiteRecordId() {
        return Record::getEISNetsuiteRecordIdC;
    }

    @Override
    Function<CustomerCustomVal, String> getSalesForceRecordId() {
        return CustomerCustomVal::getExternalId;
    }

    @Override
    Function<CustomerCustomVal, String> getInternalIdFromNetsuite() {
        return CustomerCustomVal::getInternalId;
    }

    @Override
    Function<Record, String> getInternalIdFromSalesForce() {
        return Record::getId;
    }

}
