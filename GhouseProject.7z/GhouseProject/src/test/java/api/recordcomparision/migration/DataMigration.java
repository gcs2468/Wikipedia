package api.recordcomparision.migration;


import com.ebsco.api.comparision.AbstractRecordComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.model.report.ReportEntity;
import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import com.netsuite.suitetalk.proxy.v2017_2.platform.core.Record;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.asserts.SoftAssert;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

/**
 * Asserts whether migration has taken place for a particular type of record.
 * This takes care of both single and bulk migration of records.
 * Compares the record from netsuite list with that of salesforce and generates report data for each of these.
 */
public abstract class DataMigration<T extends Record, U> {
    private Logger logger = LogManager.getLogger(DataMigration.class);
    private SoftAssert softAssert;
    private Collection<ReportData> reportQueue;
    private Map<String, U> salesForceRecordList;
    private Map<String, T> netSuiteRecordList;
    private AbstractRecordComparator<T, U> comparator;

    DataMigration(Collection<ReportData> reportQueue, Map<String, T> netSuiteRecordList,
                  Map<String, U> salesForceRecordList, AbstractRecordComparator<T, U> comparator) {
        softAssert = new SoftAssert();
        this.reportQueue = reportQueue;
        this.salesForceRecordList = salesForceRecordList;
        this.netSuiteRecordList = netSuiteRecordList;
        this.comparator = comparator;
        softAssert = new SoftAssert();
    }

    /**
     * Pass the id of a particular record for reporting purpose.
     * @return the id of the record.
     */
    abstract Function<U, String> getNetSuiteRecordId();

    /**
     * Pass the id of a particular record for reporting purpose.
     * @return the id of the record.
     */
    abstract Function<T, String> getSalesForceRecordId();
    /**
     * Pass the id of a particular record for reporting purpose.
     * @return the id of the record.
     */
    abstract Function<T, String> getInternalIdFromNetsuite();

    /**
     * Pass the id of a particular record for reporting purpose.
     * @return the id of the record.
     */
    abstract Function<U, String> getInternalIdFromSalesForce();


    public void assertMigrationFromNSToSF() {

        netSuiteRecordList.forEach((id, record) -> {
            String salesForceRecordId = getSalesForceRecordId().apply(record);
            System.out.println("Looking for "+ salesForceRecordId +" in"+salesForceRecordList.keySet());
            Optional<U> salesForceRecord = Optional.ofNullable(salesForceRecordList.get(salesForceRecordId));
            if (salesForceRecord.isPresent()) {
                compareData(record, salesForceRecord.get(), false);
            } else {
                setReportForNotMigratedData(record);
            }
        });
    }

    //1. All netsuite records must be present in salesforce.
    public void assertMigrationFromSFToNS() {
        salesForceRecordList.forEach((id, record) -> {
            String netSuiteRecordId = getNetSuiteRecordId().apply(record).replaceAll(".0", "");
            Optional<T> netSuiteRecord = Optional.ofNullable(netSuiteRecordList.get(netSuiteRecordId));
            if (netSuiteRecord.isPresent()) {
                compareData(netSuiteRecord.get(), record, true);
            } else {
                setReportForNotMigratedData(record);
            }
        });
    }

    /**
     * Invokes the comparator to check equality of records.
     *
     * @param netSuiteRecord provided.
     * @param sfRecord       provided.
     */
    private void compareData(T netSuiteRecord, U sfRecord, boolean sfToNs) {
        comparator.set(netSuiteRecord, sfRecord);
        softAssert.assertTrue(comparator.areEqual(), "Record fields are not equal.");
        ReportData reportData = comparator.getData();
        if (sfToNs)
            reportData.markTruncatedDataAsNotUpdated();
        ReportEntity entity = new ReportEntity(
                new FieldName("NetSuite Record Id", "SalesForce Record Id"),
                new FieldValue(getNetSuiteRecordId().apply(sfRecord), getSalesForceRecordId().apply(netSuiteRecord)));
        entity.ignoreStatus().ignoreDesc();
        reportData.add(entity);
        reportQueue.add(reportData);
    }


    private void setReportForNotMigratedData(T netSuiteRecord) {
        ReportData reportData = new ReportData();

        ReportEntity entity = new ReportEntity(
                new FieldName("NetSuite Record Id", "SalesForce Record Id"),
                new FieldValue(getInternalIdFromNetsuite().apply(netSuiteRecord), getSalesForceRecordId().apply(netSuiteRecord)));
        entity.containsNotMigratedData();
        reportData.add(entity);
        reportData.setDescription("Record not migrated.");
        reportQueue.add(reportData);
        softAssert.assertTrue(false, "Record not migrated.");
    }

    private void setReportForNotMigratedData(U salesForceRecord) {
        ReportData reportData = new ReportData();

        ReportEntity entity = new ReportEntity(
                new FieldName("NetSuite Record Id", "SalesForce Record Id"),
                new FieldValue(getNetSuiteRecordId().apply(salesForceRecord), getInternalIdFromSalesForce().apply(salesForceRecord)));
        entity.containsNotMigratedData();
        reportData.add(entity);
        reportData.setDescription("Record not migrated.");
        reportQueue.add(reportData);
        softAssert.assertTrue(false, "Record not migrated.");
    }
}
