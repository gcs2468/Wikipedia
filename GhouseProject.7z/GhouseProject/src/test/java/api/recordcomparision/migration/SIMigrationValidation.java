package api.recordcomparision.migration;

import api.recordcomparision.thread.task.AsynchronousTask;
import com.ebsco.api.comparision.SIComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.api.netsuite.services.retrieval.SIData;
import com.ebsco.api.salesforce.pojo.ServiceIssues;
import com.ebsco.api.salesforce.services.SISAll;

import java.util.List;
import java.util.Map;
import java.util.Queue;

public class SIMigrationValidation implements Runnable {
    private List<String> recordIDs;
    private NetSuiteConnectionPool pool;
    private Queue<ReportData> reportQueue;

    public SIMigrationValidation(List<String> recordIDs, NetSuiteConnectionPool pool, Queue<ReportData> reportQueue) {
        this.recordIDs = recordIDs;
        this.pool = pool;
        this.reportQueue = reportQueue;
    }
    @Override
    public void run() {
        try {
            AsynchronousTask<Map<String, ServiceIssues>> sfRecordRetriever = new AsynchronousTask<>(SISAll::querySi);
            AsynchronousTask<Map<String, ServiceIssue>> nsRecordRetriever =
                    new AsynchronousTask<>(() -> new SIData().get(recordIDs, pool));
            System.out.println("&&&&7"+ sfRecordRetriever.get().keySet() );
            DataMigration<ServiceIssue, ServiceIssues> dataMigration = new SIMigration(reportQueue, nsRecordRetriever.get(), sfRecordRetriever.get(), new SIComparator());
           System.out.println("*************"+ reportQueue.size() );
            dataMigration.assertMigrationFromNSToSF();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
