package api.recordcomparision.migration;

import com.ebsco.api.comparision.AbstractRecordComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.pojo.MessageCustomVal;
import com.ebsco.api.salesforce.pojo.Message;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

public class MessageMigration extends DataMigration<MessageCustomVal, Message> {
    MessageMigration(Collection<ReportData> reportQueue, Map<String, MessageCustomVal> netSuiteRecordList, Map<String,Message> salesForceRecordList, AbstractRecordComparator<MessageCustomVal, Message> comparator) {
        super(reportQueue, netSuiteRecordList, salesForceRecordList, comparator);
    }

    @Override
    Function<Message, String> getNetSuiteRecordId() {
        return Message::getEISNetsuiteRecordIdC;
    }

    @Override
    Function<MessageCustomVal, String> getSalesForceRecordId() {
        return MessageCustomVal::getMessageId ;
    }

    @Override
    Function<MessageCustomVal, String> getInternalIdFromNetsuite() {
        return  MessageCustomVal::getMessageId;
    }

    @Override
    Function<Message, String> getInternalIdFromSalesForce() {
        return Message::getId;
    }
}
