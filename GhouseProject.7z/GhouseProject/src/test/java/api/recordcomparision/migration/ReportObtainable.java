package api.recordcomparision.migration;

import com.ebsco.api.model.report.ReportData;

import java.util.Collection;

/**
 * A class capable of generating report must implement this interface.
 */
public interface ReportObtainable {

    /**
     * @return reportQueue set containing ReportData objects.
     */
    Collection<ReportData> getReport();
}
