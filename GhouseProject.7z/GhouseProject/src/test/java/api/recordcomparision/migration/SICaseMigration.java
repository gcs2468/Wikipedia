package api.recordcomparision.migration;

import com.ebsco.api.comparision.AbstractRecordComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.api.salesforce.pojo.SICasesMap;
import com.ebsco.api.salesforce.pojo.ServiceIssues;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

public class SICaseMigration extends DataMigration<ServiceIssue, SICasesMap> {
    public SICaseMigration(Collection<ReportData> reportQueue, Map<String, ServiceIssue> netSuiteRecordList, Map<String, SICasesMap> salesForceRecordList, AbstractRecordComparator<ServiceIssue, SICasesMap> comparator) {
        super(reportQueue, netSuiteRecordList, salesForceRecordList, comparator);
        System.out.println("size ns==="+ netSuiteRecordList.size() );
        System.out.println( "size---"+salesForceRecordList.size() );
    }

    @Override
    Function<SICasesMap, String> getNetSuiteRecordId() {
        return SICasesMap::getEISNetsuiteRecordIdC;
    }

    @Override
    Function<ServiceIssue, String> getSalesForceRecordId() {
        return ServiceIssue::getNetsuiteInternalId ;
    }

    @Override
    Function<ServiceIssue, String> getInternalIdFromNetsuite() {
        return  ServiceIssue::getNetsuiteInternalId;
    }
    @Override
    Function<SICasesMap, String> getInternalIdFromSalesForce() {
        return SICasesMap::getId;
    }
}
