package api.recordcomparision.migration;

import api.recordcomparision.thread.task.AsynchronousTask;
import com.ebsco.api.comparision.SICasesComparator;
import com.ebsco.api.comparision.SIComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.api.netsuite.services.retrieval.SICaseData;
import com.ebsco.api.netsuite.services.retrieval.SICaseDataTemp;
import com.ebsco.api.salesforce.pojo.SICasesMap;
import com.ebsco.api.salesforce.pojo.ServiceIssues;
import com.ebsco.api.salesforce.services.SISAll;
import com.ebsco.api.salesforce.services.SISCasesAll;

import java.util.List;
import java.util.Map;
import java.util.Queue;

public class SICaseMigrationValidation implements Runnable {
    private List<String> recordIDs;
    private NetSuiteConnectionPool pool;
    private Queue<ReportData> reportQueue;

    public SICaseMigrationValidation(List<String> recordIDs, NetSuiteConnectionPool pool, Queue<ReportData> reportQueue) {
        this.recordIDs = recordIDs;
        this.pool = pool;
        this.reportQueue = reportQueue;
    }

    @Override
    public void run() {
        try {
            AsynchronousTask<Map<String, SICasesMap>> sfRecordRetriever = new AsynchronousTask<>( SISCasesAll::querySiCase );
            AsynchronousTask<Map<String, ServiceIssue>> nsRecordRetriever =
                    new AsynchronousTask<>( () -> new SICaseData().get( recordIDs, pool ) );
             Map<String,SICasesMap> sfRetriever= sfRecordRetriever.get(  );
            Map<String,ServiceIssue> nSRetriever= nsRecordRetriever.get(  );
           System.out.println( "----"+nSRetriever.keySet());
                   System.out.println( "**********"+sfRetriever .keySet());
           System.exit( 0 );
            //sfRetriever.values().stream().map( SICasesMap::getCasesR ).forEach( System.out::println ) ;
           // DataMigration<ServiceIssue, SICasesMap> dataMigration = new SICaseMigration( reportQueue, nSRetriever, sfRetriever, new SICasesComparator() );
            //System.out.println( "*************" + reportQueue.size() );
            //dataMigration.assertMigrationFromNSToSF();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
