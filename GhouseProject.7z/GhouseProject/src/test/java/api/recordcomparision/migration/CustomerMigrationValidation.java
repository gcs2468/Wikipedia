package api.recordcomparision.migration;


import api.recordcomparision.thread.task.AsynchronousTask;
import com.ebsco.api.comparision.CustomerComparator;
import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.CustomerCustomVal;
import com.ebsco.api.netsuite.services.retrieval.CustomerData;
import com.ebsco.api.salesforce.pojo.AccountsAll;
import com.ebsco.api.salesforce.pojo.Record;


import java.util.List;
import java.util.Map;
import java.util.Queue;


/**
 * This represents a process for validation of migration of records.
 */
public class CustomerMigrationValidation implements Runnable {

    private List<String> recordIDs;
    private NetSuiteConnectionPool pool;
    private Queue<ReportData> reportQueue;

    public CustomerMigrationValidation(List<String> recordIDs, NetSuiteConnectionPool pool, Queue<ReportData> reportQueue) {
        this.recordIDs = recordIDs;
        this.pool = pool;
        this.reportQueue = reportQueue;
    }


    @Override
    public void run() {
        try {
            AsynchronousTask<Map<String, Record>> sfRecordRetriever = new AsynchronousTask<>(AccountsAll::queryAccount);
            AsynchronousTask<Map<String, CustomerCustomVal>> nsRecordRetriever= new AsynchronousTask<>(() -> new CustomerData().get(recordIDs, pool));
            DataMigration<CustomerCustomVal, Record> dataMigration =
                    new CustomerMigration(reportQueue, nsRecordRetriever.get(), sfRecordRetriever.get(), new CustomerComparator());
            dataMigration.assertMigrationFromNSToSF();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
