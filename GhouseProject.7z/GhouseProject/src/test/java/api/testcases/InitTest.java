package api.testcases;

import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.model.report.ReportEntity;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.utilities.ExcelReport;
import com.ebsco.common.utility.CommonUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static com.ebsco.api.utilities.ExcelReport.attachExcelToAllureReport;
import static com.ebsco.api.utilities.ExcelReport.captureTime;
import static com.ebsco.common.constants.FilePaths.REPORT_FILE;

public class InitTest {


    Logger logger = LogManager.getLogger(this);
    String startTime, endTime;
    static NetSuiteConnectionPool pool;
    private static SoftAssert softAssert;
    public static Queue<ReportData> reportQueue;
    static final int MAX_THREADS_ALLOWED = 10;


    @BeforeSuite
    public void initTestSuite() {
        startTime = captureTime("Start Time", CommonUtils.getTime("dd-MM-YYYY HH:mm:ss"));
        pool = new NetSuiteConnectionPool(MAX_THREADS_ALLOWED + 1);
        pool.initAll();
    }

    @BeforeTest
    public void initClass() {
        reportQueue = new ConcurrentLinkedQueue<>();
        softAssert = new SoftAssert();
    }

    void logReport() throws Exception {
        logger.info("Size of report queue: " + reportQueue.size());
        ExcelReport excelReport = new ExcelReport(REPORT_FILE);
        excelReport.prepareExcel(reportQueue);
        excelReport.commit();
        attachExcelToAllureReport();

        softAssert = new SoftAssert();
        reportQueue.stream()
                .distinct()
                .map(ReportData::getEntities)
                .map(this::dataHasEqualContents)
                .forEach(softAssert::assertTrue);
        reportQueue.clear();
        softAssert.assertAll();

    }

    @AfterSuite
    public void closeTestSuite() {
        pool.destroyAll();
        endTime = captureTime("End Time", CommonUtils.getTime("dd-MM-YYYY HH:mm:ss"));
        captureTime("Execution Time Difference", CommonUtils.timeDifference(startTime, endTime));
        deleteTempFilesInTestDate();
    }


    List<List<String>> partitionData(List<String> dataList, int numOfSets) {
        AtomicInteger counter = new AtomicInteger(0);
        int totalNumOfData = dataList.size();
        //Partition Bulk IDs
        int dataForEachSet = (totalNumOfData > numOfSets) ? totalNumOfData / numOfSets : totalNumOfData;
        final Collection<List<String>> partitioned = dataList.stream()
                .collect(Collectors.groupingBy(it -> counter.getAndIncrement() / dataForEachSet)).values();
        return new LinkedList<>(partitioned);
    }

    <T> List<Map<String, T>> partitionMap(Map<String, T> dataList, int numOfSets) {
        Map<String, T> container = new LinkedHashMap<>(dataList);
        int totalData = dataList.size();
        int dataForEachSet = (totalData > numOfSets) ? totalData / numOfSets : totalData;
        List<String> keys = new LinkedList<>(container.keySet());
        List<T> values = new LinkedList<>(container.values());
        List<Map<String, T>> resultMap = new LinkedList<>();
        while (!values.isEmpty() && !keys.isEmpty()) {
            Map<String, T> partitionedMap = new HashMap<>();
            for (int i = 0; i < dataForEachSet && (!values.isEmpty() && !keys.isEmpty()); i++)
                partitionedMap.put(keys.remove(0), values.remove(0));
            resultMap.add(partitionedMap);

        }
        return resultMap;
    }

    /**
     * Only for assertions.
     */
    private boolean dataHasEqualContents(List<ReportEntity> entities) {
        for (ReportEntity entity : entities) {

            //Since entities displaying only Ids are ignorable, we don't compare them.
            if (entity.isStatusIgnorable()) {
                continue;
            }

            if (entity.containsNotMigratedData() || !entity.getFieldValue().areEqual()) {
                return false;
            }
        }

        return true;
    }


    public static void deleteTempFilesInTestDate() {

        File folder = new File(System.getProperty("user.dir") + "\\src\\main\\resources\\Testdata");
        File[] listOfFiles = folder.listFiles();

        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].getName().contains("Temp"))listOfFiles[i].delete();
        }
    }
}
