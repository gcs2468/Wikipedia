package api.testcases;

import api.recordcomparision.migration.ContactRegistrationValidation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.FilePaths.CONTACT_SYNC_CXP_STATUS_TEMP_FILE_NAME;

public class ContactRegistrationNStoSFTest extends InitTest {

    Logger logger = LogManager.getLogger(this);


    @Test
    public void validateCXPStatus() throws Exception {
        long start = System.currentTimeMillis();
        try {
            List<String> contactList = Files.readAllLines(Paths.get(CONTACT_SYNC_CXP_STATUS_TEMP_FILE_NAME)).stream().distinct().collect(Collectors.toList());
            ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
            List<List<String>> partitionedIDs = partitionData(contactList, MAX_THREADS_ALLOWED);
            partitionedIDs.forEach(partitionedSet -> executor.execute(new ContactRegistrationValidation(partitionedSet, pool, reportQueue)));
            while (executor.getActiveCount() != 0) ; //Wait for all threads to finish.
        } catch (Exception e) {
            e.printStackTrace();
        }

        logReport();
    }
}
