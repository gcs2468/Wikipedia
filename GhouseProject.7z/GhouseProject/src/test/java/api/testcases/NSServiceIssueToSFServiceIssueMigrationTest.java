package api.testcases;

import api.recordcomparision.migration.SICaseMigrationValidation;
import api.recordcomparision.migration.SIMigrationValidation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.FilePaths.SI_ID_BATCH_FILE;
import static com.ebsco.common.constants.FilePaths.SI_SYNC_TEMP_FILE_NAME;


public class NSServiceIssueToSFServiceIssueMigrationTest extends InitTest {
    Logger logger = LogManager.getLogger(this);

    @Test
    public void validateSIMigratedDataInBatch() {
        long start = System.currentTimeMillis();
        try {
            List<String> siList = Files.readAllLines(Paths.get(SI_ID_BATCH_FILE)).stream().distinct().collect(Collectors.toList());
            ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
            List<List<String>> partitionedIDs = partitionData(siList, MAX_THREADS_ALLOWED);
            partitionedIDs.forEach(partitionedSet -> executor.execute(new SIMigrationValidation(partitionedSet, pool, reportQueue)));
            while (executor.getActiveCount() != 0) ; //Wait for all threads to finish.
            logReport();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Test
    public void validateSICaseMigratedDataInBatch() {
        long start = System.currentTimeMillis();
        try {
            List<String> siList = Files.readAllLines(Paths.get(SI_ID_BATCH_FILE)).stream().distinct().collect(Collectors.toList());
            ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
            List<List<String>> partitionedIDs = partitionData(siList, MAX_THREADS_ALLOWED);
            partitionedIDs.forEach(partitionedSet -> executor.execute(new SICaseMigrationValidation(partitionedSet, pool, reportQueue)));
            while (executor.getActiveCount() != 0) ; //Wait for all threads to finish.
            logReport();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    @Test
    public void validateSIMigratedData() throws Exception {
        long start = System.currentTimeMillis();
        try {
            List<String> siList = Files.readAllLines(Paths.get(SI_SYNC_TEMP_FILE_NAME)).stream().distinct().collect(Collectors.toList());
            ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
            List<List<String>> partitionedIDs = partitionData(siList, MAX_THREADS_ALLOWED);
            partitionedIDs.forEach(partitionedSet -> executor.execute(new SIMigrationValidation(partitionedSet, pool, reportQueue)));
            while (executor.getActiveCount() != 0) ; //Wait for all threads to finish.
        } catch (Exception e) {
            e.printStackTrace();
        }

        logReport();
    }
}
