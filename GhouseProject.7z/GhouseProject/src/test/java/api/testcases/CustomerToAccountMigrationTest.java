package api.testcases;

import api.recordcomparision.migration.CustomerMigrationValidation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.FilePaths.CUSTOMER_BATCH_ID_FILE;
import static com.ebsco.common.constants.FilePaths.CUSTOMER_ID_FILE;

public class CustomerToAccountMigrationTest extends InitTest {

    public String startTime,endTime;
    private Logger logger = LogManager.getLogger(CustomerToAccountMigrationTest.class);
    private SoftAssert softAssert;
    public static final int MAX_THREADS_ALLOWED = 10;



    @Test
    public void validateCustomerMigratedData() throws Exception {
        long start = System.currentTimeMillis();
        try {
            List<String> customerList = Files.readAllLines(Paths.get(CUSTOMER_ID_FILE)).stream().distinct().collect(Collectors.toList());

            logger.info(customerList.size() + " is the number of ids.");
            ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
            List<List<String>> partitionedIDs = partitionData(customerList, MAX_THREADS_ALLOWED);
            partitionedIDs.forEach(partitionedSet -> executor.execute(new CustomerMigrationValidation(partitionedSet, pool, reportQueue)));
            while (executor.getActiveCount() != 0) ; //Wait for all threads to finish.
        } catch (Exception e) {
            e.printStackTrace();
        }
    logReport();
    }

    @Test
    public void validateCustomerMigratedDataInBatch() throws Exception {
        long start = System.currentTimeMillis();
        try {
            List<String> customerList = Files.readAllLines(Paths.get(CUSTOMER_BATCH_ID_FILE));
            logger.info(customerList.size() + " is the number of ids.");
            ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
            List<List<String>> partitionedIDs = partitionData(customerList, MAX_THREADS_ALLOWED);
            partitionedIDs.forEach(partitionedSet -> executor.execute(new CustomerMigrationValidation(partitionedSet, pool, reportQueue)));
            while (executor.getActiveCount() != 0) ; //Wait for all threads to finish.
        } catch (Exception e) {
            e.printStackTrace();
        }

        logger.info("Time taken for entire execution: " + (System.currentTimeMillis() - start) + " ms.");
        logReport();
    }
}