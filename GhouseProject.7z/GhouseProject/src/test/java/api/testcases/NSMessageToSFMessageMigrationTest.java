package api.testcases;

import api.recordcomparision.migration.MessageMigrationValidation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.FilePaths.CASE_SYNC_TEMP_FILE_NAME;
import static com.ebsco.common.constants.FilePaths.MESSGAE_ID_BATCH_FILE;


public class NSMessageToSFMessageMigrationTest extends InitTest{
    Logger logger = LogManager.getLogger(this);

    @Test
    public void validateMessageMigratedDataInBatch() throws Exception {
        long start = System.currentTimeMillis();
        try {
            List<String> messageList = Files.readAllLines(Paths.get(MESSGAE_ID_BATCH_FILE)).stream().distinct().collect(Collectors.toList());
            System.out.println("Message List::"+messageList);
            ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
            List<List<String>> partitionedIDs = partitionData(messageList, MAX_THREADS_ALLOWED);
            partitionedIDs.forEach(partitionedSet -> executor.execute(new MessageMigrationValidation(partitionedSet, pool, reportQueue)));
            while (executor.getActiveCount() != 0) ; //Wait for all threads to finish.
        } catch (Exception e) {
            e.printStackTrace();
        }

        logReport();
    }

    @Test
    public void validateMessageMigratedData() throws Exception {
        long start = System.currentTimeMillis();
        try {
            List<String> messageList = Files.readAllLines(Paths.get(CASE_SYNC_TEMP_FILE_NAME)).stream().distinct().collect(Collectors.toList());
            System.out.println("Message List::"+messageList);
            ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
            List<List<String>> partitionedIDs = partitionData(messageList, MAX_THREADS_ALLOWED);
            partitionedIDs.forEach(partitionedSet -> executor.execute(new MessageMigrationValidation(partitionedSet, pool, reportQueue)));
            while (executor.getActiveCount() != 0) ; //Wait for all threads to finish.
        } catch (Exception e) {
            e.printStackTrace();
        }

        logReport();
    }
}
