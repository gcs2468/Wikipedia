package api.testcases;

import api.recordcomparision.migration.ContactMigrationValidationSFtoNS;
import api.recordcomparision.migration.ContactRegistrationValidationSFtoNS;
import com.ebsco.api.salesforce.pojo.Contact;
import com.ebsco.api.salesforce.services.CXPStatusLastModifiedContactsAll;
import com.ebsco.api.salesforce.services.LastModifiedContactsAll;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class SFContactToNSContactMigrationTest extends InitTest {

    Logger logger = LogManager.getLogger(this);

    @Test
    public void validateContactsMigratedData() throws Exception {
        Map<String, Contact> contacts = LastModifiedContactsAll.queryContact();
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
        List<Map<String, Contact>> partitionedMap = partitionMap(contacts, MAX_THREADS_ALLOWED);
        partitionedMap.forEach(partitionedSet -> executor.execute(new ContactMigrationValidationSFtoNS(partitionedSet, pool, reportQueue)));
        executor.awaitTermination(10, TimeUnit.SECONDS);
        logReport();
    }

    @Test
    public void validateCXPStatusSFtoNS() throws Exception {
        Map<String, Contact> contacts = CXPStatusLastModifiedContactsAll.queryContact();
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
        List<Map<String, Contact>> partitionedMap = partitionMap(contacts, MAX_THREADS_ALLOWED);
        partitionedMap.forEach(partitionedSet -> executor.execute(new ContactRegistrationValidationSFtoNS(partitionedSet, pool, reportQueue)));
        executor.awaitTermination(10, TimeUnit.SECONDS);
        logReport();
    }
}
