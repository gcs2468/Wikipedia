package api.testcases;

import api.recordcomparision.migration.CaseMigrationValidationSFtoNS;
import com.ebsco.api.salesforce.pojo.Case;
import com.ebsco.api.salesforce.services.LastModifiedCasesAll;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class SFCaseToNSCaseMigrationTest extends InitTest {

    Logger logger = LogManager.getLogger(this);

    @Test
    public void validateCasesMigratedData() throws Exception {
        Map<String, Case> cases = LastModifiedCasesAll.queryCases();
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
        List<Map<String, Case>> partitionedMap = partitionMap(cases, MAX_THREADS_ALLOWED);
        partitionedMap.forEach(partitionedSet -> executor.execute(new CaseMigrationValidationSFtoNS(partitionedSet, pool, reportQueue)));
        executor.awaitTermination(10, TimeUnit.SECONDS);
        logReport();
    }

}
