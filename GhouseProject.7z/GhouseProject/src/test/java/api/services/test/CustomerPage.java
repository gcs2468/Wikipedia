package api.services.test;

import com.ebsco.api.netsuite.services.utils.services.CustomerOperations;
import com.netsuite.suitetalk.client.v2017_2.WsClient;
import com.netsuite.suitetalk.proxy.v2017_2.lists.relationships.Customer;
import com.netsuite.suitetalk.proxy.v2017_2.platform.messages.ReadResponse;


public class CustomerPage {

    public  Customer getCustomer(final WsClient client,final String internalID) throws Exception {
        ReadResponse response =  new CustomerOperations().getCustomer(client,internalID);
        System.out.println(response.getStatus().isIsSuccess());
        return (Customer)response.getRecord();
    }
}
