package web.testcases;

import com.ebsco.api.model.utility.comparison.Link;
import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.utilities.Links;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class UnAuthLinksValidationTests {

    private Logger logger = LogManager.getLogger(this);
    private SoftAssert softAssert= new SoftAssert();


    @Test
    public void validateHomePageForUnAuth() {
        logger.info("Validating for Unauthenticated homepage.");
        By[] selectors = new By[]{
                By.xpath("//button[contains(@class, 'comm-navigation__sub-menu-trigger')]")};
        WebDriver driver = InvokeInstances.getInvokeInstance().getWebDriverManager().getDriver();
        List<String> linksObtained = Links.getAllLinks(driver, selectors);
        logger.info("Validating " + linksObtained.size() + " links..");
        for (String url : linksObtained)
            softAssert.assertTrue(new Link(url).isValid(), url + " is not valid.");
        logger.info("Validation complete.");
        softAssert.assertAll();
    }
}
