package web.testcases;

import com.ebsco.api.model.utility.comparison.Link;
import com.ebsco.web.utilities.Links;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class LinksValidationTests extends BaseTest {
    private Logger logger = LogManager.getLogger(this);
    private SoftAssert softAssert= new SoftAssert();

    @Test(description = "")
    public void validateHomePageForAuth() {
        logger.info("Validating for authenticated homepage.");
        By[] selectors = new By[]{
                By.xpath("//button[contains(@class, 'comm-navigation__sub-menu-trigger')]"),
                By.xpath("//button[@class='profile-menuTrigger']")
        };
        List<String> linksObtained = Links.getAllLinks(driver, selectors);
        logger.info("Validating " + linksObtained.size() + " links..");
        for (String url : linksObtained)
            softAssert.assertTrue(new Link(url).isValid(), url + " is not valid.");
        softAssert.assertAll();
    }
}
