package web.testcases;

import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.managers.FileReaderManager;
import com.ebsco.web.managers.PageObjectManager;
import com.ebsco.web.managers.WebDriverManager;
import com.ebsco.web.utilities.TestListener;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.util.Map;

import static com.ebsco.common.constants.Constants.API;
import static com.ebsco.common.constants.Constants.CONSORTIA_LOGIN_SHEET;
import static com.ebsco.common.constants.Constants.TESTCASES_SHEET;

@Listeners({TestListener.class})
public class BaseTest extends PageObjectManager{

    InvokeInstances invokeInstances;
    WebDriverManager webDriverManager;
    WebDriver driver;
    private String platformName;
    public static Map<String, Map<String, String>> consortiaLogin;
    public static Map<String, Map<String, String>> testData;
    public String testcaseName;
    public long tcExecCount;

    @BeforeSuite
    public void init(){
        consortiaLogin = FileReaderManager.getInstance().getExcelReader().readMultipleData(CONSORTIA_LOGIN_SHEET);
        testData = FileReaderManager.getInstance().getExcelReader().readMultipleData(TESTCASES_SHEET);
    }


    @BeforeMethod
    public void setupAndLogin(Method methodName) {
        platformName = FileReaderManager.getInstance().getConfigReader().getPlatform();
        invokeInstances = InvokeInstances.getInvokeInstance();
        webDriverManager = invokeInstances.getWebDriverManager();
        driver = webDriverManager.getDriver();
        getAllPageInstances();
        testcaseName = methodName.getName();
        countTestcaseExec();
    }

    private long countTestcaseExec(){
        tcExecCount = 0;
        testData.forEach((k,v) -> tcExecCount += countTestcaseOccurrence(k, testcaseName));
        return tcExecCount;
    }

    //counts number of times testcase(TC) has occurred in testdata map
    private int countTestcaseOccurrence(String actualTCName, String findTCName) {
        return actualTCName.split(findTCName, -1).length - 1;
    }

    @AfterMethod
    public void logoutAndTeardown() {
        if (!platformName.equalsIgnoreCase(API)) {
            webDriverManager.closeDriver();
            invokeInstances.resetInvokeInstances();
        }
    }
}
