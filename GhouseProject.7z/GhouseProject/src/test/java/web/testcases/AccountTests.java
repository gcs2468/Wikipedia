package web.testcases;

import io.qameta.allure.Description;
import org.testng.annotations.Test;

public class AccountTests extends BaseTest {

    @Test(description = "Verify account details")
    @Description("Account details verification")
    public void testAccountDetails()  {
        try{
            accountsPage.setupAccountsTab();
            accountsPage.clickAccountsMenu();
            //data: OAK_VIEW, EBSCO
            accountsPage.searchAccount("EBSCO");
            accountsPage.clickOnSearchAccount();
            accountsPage.viewFields();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
