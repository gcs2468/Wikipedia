package web.testcases;

import com.ebsco.api.utilities.ExcelReport;
import io.qameta.allure.Description;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.Constants.*;

public class CasesTests extends BaseTest {

    private SoftAssert softAssert = new SoftAssert();
    private Logger logger = LogManager.getLogger(this.getClass());

    public List<String> caseNumbers=new ArrayList<>();

    @Test(description = "Create a New case")
    @Description("Create new case and validate case details")
    public void createCaseAndValidateDetails() {
        for(int tcRowNumber = 1; tcRowNumber <=tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName+"_"+ tcRowNumber);
            loginPage.loginToCommunity(excelInputData.get(I_USERNAME),excelInputData.get(I_PASSWORD));
            homePage.goToProfilePage();
            String accountName = globalPage.getAccountName();
            String profileName = globalPage.getProfileName();
            caseNumbers.add(createNewCase(excelInputData.get(I_PRODUCT_NAME),excelInputData.get(I_SUBJECT),excelInputData.get(I_DESCRIPTION)));
            //validate case creation
            casePage.validateCaseCreated(excelInputData, accountName, profileName);
            loginPage.logoutFromCommunity(driver);
        }
    }

    @Test(description = "Verify Independent institute contacts can see all cases of their institute")
    @Description("Verify Independent institute contacts can see all cases of their institute")
    public void independentInstitute() {
        for(int tcRowNumber = 1; tcRowNumber <=tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            loginPage.login(false);
            accountsPage.clickAccountsMenu();
            accountsPage.searchAccount(excelInputData.get(I_ACCOUNT_NAME));
            accountsPage.clickOnSearchAccount();
            int casesCount = Integer.parseInt(accountsPage.getCasesCount());
            accountsPage.clickCases();
            accountsPage.openEachContactAndValidate(accountsPage.getCaseNumbers(), casesCount, consortiaLogin);
        }
    }

    @Test
    public void deleteCases()
    {
        for(int tcRowNumber = 1; tcRowNumber <=tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            if(caseNumbers.isEmpty()) {
                loginPage.loginToCommunity(excelInputData.get(I_USERNAME), excelInputData.get(I_PASSWORD));
                caseNumbers.add(createNewCase(excelInputData.get(I_PRODUCT_NAME), excelInputData.get(I_SUBJECT), excelInputData.get(I_DESCRIPTION)));
                System.out.println(caseNumbers);
                loginPage.logoutFromCommunity(driver);
            }
            loginPage.login(false);
            casesPage.deleteCase_CXPPortal(caseNumbers);
        }
    }

    @Test
    public void updateCase() throws InterruptedException {
        for(int tcRowNumber = 1; tcRowNumber <=tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            loginPage.loginToCommunity(excelInputData.get(I_USERNAME), excelInputData.get(I_PASSWORD));
            List<String> caseNumbers = Arrays.asList("00034015");
            homePage.goToProfilePage();
            String userName = ""/*profilePage.getProfileName()*/;
            for (String caseNumber : caseNumbers) {
                casesPage.selectCasesFromDropDownMenu(driver);
                casesPage.clickCasesListViewDropDwn(driver);
                casesPage.selectAllCasesFromDropDwn(driver);
//                Thread.sleep(2000);
                casesPage.clickOnCaseNum(caseNumber);
                boolean allFieldsAreReadOnly = casePage.allFieldsAreNonEditable();
                softAssert.assertTrue(allFieldsAreReadOnly, FIELDS_NOT_EDITABLE_ERROR_MSG);
//                Thread.sleep(2000);
                casePage.clickAttachmentSection();
                casePage.createNewCaseMessage();
                boolean caseMessageHasBeenCreated = casePage.verifyCreationOfCaseMsg(userName);
                logger.info("Message Created for Case Number : " + caseNumber + "? " + caseMessageHasBeenCreated);
                softAssert.assertTrue(caseMessageHasBeenCreated, CASE_MSG_CREATE_FAILURE);
            }
        }
        softAssert.assertAll();
    }

    public String createNewCase(String productInterfaceName,String subject,String description)
    {
        casesPage.selectCasesFromDropDownMenu(driver);
        casesPage.clickOnNewCase();
        createCasePage.selectProductOrInterface(productInterfaceName);
        createCasePage.enterSubject(subject);
        createCasePage.enterDescription(description);
        //createCasePage.addAttachment(System.getProperty("user.dir") + UPLOAD_TEST_FILE);
        createCasePage.clickSubmit();
        return casePage.getCaseNumber();
    }
}
