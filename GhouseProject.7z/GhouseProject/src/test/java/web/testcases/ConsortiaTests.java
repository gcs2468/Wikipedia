package web.testcases;

import com.ebsco.web.utilities.LogUtil;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.util.Map;

import static com.ebsco.common.constants.Constants.*;

public class ConsortiaTests extends BaseTest {

    private String caseIdsInPrimaryContactInstituteOne,
            caseIdsInSecondaryContactInstituteOne,
            caseIdsInPrimaryContactInstituteTwo,
            caseIdsInSecondaryContactInstituteTwo,
            totalCasesPresentUnderChildInstitutes,
            institutionName = "",
            parentInstituteCaseNumbers;

    private Map<String, String> primaryContactOfChildInsOne,
            primaryContactOfChildInsTwo,
            secondaryContactOfChildInsOne,
            secondaryContactOfChildInsTwo,
            primaryContactOfConsortiaHeadData,
            contactOfConsortiaData,
            primaryContactOfSecondConsortia,
            contactOfSecondConsortia;


    private void initLogins() {
        primaryContactOfChildInsOne = consortiaLogin.get(PRIMARY_CONTACT_OF_CHILD_INS_ONE);
        primaryContactOfChildInsTwo = consortiaLogin.get(PRIMARY_CONTACT_OF_CHILD_INS_TWO);
        secondaryContactOfChildInsOne = consortiaLogin.get(SECOND_CONTACT_OF_CHILD_INS_ONE);
        secondaryContactOfChildInsTwo = consortiaLogin.get(SECOND_CONTACT_OF_CHILD_INS_TWO);
        primaryContactOfConsortiaHeadData = consortiaLogin.get(PRIMARY_CONTACT_OF_CONSORTIA_HEAD);
        contactOfConsortiaData = consortiaLogin.get(CONTACT_OF_CONSORTIA);
        primaryContactOfSecondConsortia = consortiaLogin.get(PRIMARY_CONTACT_OF_SECOND_CONSORTIA);
        contactOfSecondConsortia = consortiaLogin.get(CONTACT_OF_SECOND_CONSORTIA);
    }

    @Test
    public void verifyInstituteCasesFromConsortiaWhenChildInstitutesAreOptedOut() {
        for (int tcRowNumber = 1; tcRowNumber <= tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            initLogins();
            LogUtil.log("Script started for Consortia Head with Child Institutes as Opted Out");
            changeToOptOut(OPT_IN_OPT_OUT_INSTITUTE_NUMBER_ALL);
            getCaseIdsFromChildInstitutes();
            verifyInstituteCasesFromConsortiaByDefaultAsOptOut();
            LogUtil.log("Script ended for Consortia Head with Child Institutes as Opted Out");
        }
    }

    @Test
    public void verifyInstituteCasesFromConsortiaWhenChildInstituteOneOptedIn() {
        for (int tcRowNumber = 1; tcRowNumber <= tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            initLogins();
            LogUtil.log("Script started for Consortia Head with Child Institute One as Opted In");
            changeToOptIn(OPT_IN_OPT_OUT_INSTITUTE_NUMBER_ONE);
            changeToOptOut(OPT_IN_OPT_OUT_INSTITUTE_NUMBER_TWO);
            getCaseIdsFromChildInstitutes();
            verifyInstituteCasesFromConsortiaByInstituteAsOptIn(caseIdsInPrimaryContactInstituteOne, caseIdsInSecondaryContactInstituteOne);
            LogUtil.log("Script ended for Consortia Head with Child Institute One as Opted In");
        }
    }

    @Test
    public void verifyInstituteCasesFromConsortiaWhenChildInstituteTwoOptedIn() {
        for (int tcRowNumber = 1; tcRowNumber <= tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            initLogins();
            LogUtil.log("Script started for Consortia Head with Child Institute Two as Opted In");
            changeToOptOut(OPT_IN_OPT_OUT_INSTITUTE_NUMBER_ONE);
            changeToOptIn(OPT_IN_OPT_OUT_INSTITUTE_NUMBER_TWO);
            getCaseIdsFromChildInstitutes();
            verifyInstituteCasesFromConsortiaByInstituteAsOptIn(caseIdsInPrimaryContactInstituteTwo, caseIdsInSecondaryContactInstituteTwo);
            LogUtil.log("Script ended for Consortia Head with Child Institute Two as Opted In");
        }
    }

    @Test
    public void verifyInstituteCasesFromConsortiaWhenChildInstitutesAreOptedIn() {
        for (int tcRowNumber = 1; tcRowNumber <= tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            initLogins();
            LogUtil.log("Script started for Consortia Head with Child Institutes as Opted In");
            changeToOptIn(OPT_IN_OPT_OUT_INSTITUTE_NUMBER_ALL);
            getCaseIdsFromChildInstitutes();
            verifyInstituteCasesFromConsortiaByChildInstitutesAsOptIn();
            LogUtil.log("Script ended for Consortia Head with Child Institutes as Opted In");
        }
    }

    @Test
    public void verifyParentInstituteCasesUnderChildInstitute() {
        for (int tcRowNumber = 1; tcRowNumber <= tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            initLogins();
            LogUtil.log("Script started to validate the parent consortia cases under child institute");
            loginPage.loginToCommunity(primaryContactOfConsortiaHeadData.get(URL), primaryContactOfConsortiaHeadData.get(USERNAME), primaryContactOfConsortiaHeadData.get(PASSWORD));
            institutionName = accountsPage.getInstitutionNameFromMyAccountsPage();
            casesPage.navigateToAllCasesView(driver);
            parentInstituteCaseNumbers = casesPage.getCaseNumbersBasedOnInstitution(institutionName);
            LogUtil.log("Cases Belong to " + institutionName + " are " + parentInstituteCaseNumbers);
            loginPage.logoutFromCommunity(driver);
            LogUtil.log("Logged in with primary contact of Child Institute One");
            casesPage.verifyParentInstituteCases(primaryContactOfChildInsOne.get(URL), primaryContactOfChildInsOne.get(USERNAME), primaryContactOfChildInsOne.get(PASSWORD), parentInstituteCaseNumbers);
            LogUtil.log("Logged in with primary contact of Child Institute Two");
            casesPage.verifyParentInstituteCases(primaryContactOfChildInsTwo.get(URL), primaryContactOfChildInsTwo.get(USERNAME), primaryContactOfChildInsTwo.get(PASSWORD), parentInstituteCaseNumbers);
            LogUtil.log("Script ended to validate the parent consortia cases under child institute");
        }
    }

    @Test
    public void validateOptInOptOutForChildInstituteBelongsToTwoConsortias()
    {
        for (int tcRowNumber = 1; tcRowNumber <= tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            initLogins();
            LogUtil.log("Script started to validate the common child institute cases presence under parent consortia when Opted Out");
            changeToOptOut(OPT_IN_OPT_OUT_INSTITUTE_NUMBER_TWO);
            caseIdsInPrimaryContactInstituteTwo = casesPage.getCaseIdsFromPrimaryContactChildInstituteTwo(primaryContactOfChildInsTwo.get(URL), primaryContactOfChildInsTwo.get(USERNAME), primaryContactOfChildInsTwo.get(PASSWORD));
            LogUtil.log("Logged in with primary contact of Parent Institute One");
            loginPage.loginToCommunity(primaryContactOfConsortiaHeadData.get(URL), primaryContactOfConsortiaHeadData.get(USERNAME), primaryContactOfConsortiaHeadData.get(PASSWORD));
            casesPage.verifyInstituteCasesFromConsortiaByInstituteAsOptOut(caseIdsInPrimaryContactInstituteTwo);
            LogUtil.log("Logged in with primary contact of Parent Institute Two");
            loginPage.loginToCommunity(primaryContactOfSecondConsortia.get(URL), primaryContactOfSecondConsortia.get(USERNAME), primaryContactOfSecondConsortia.get(PASSWORD));
            casesPage.verifyInstituteCasesFromConsortiaByInstituteAsOptOut(caseIdsInPrimaryContactInstituteTwo);
            changeToOptIn(OPT_IN_OPT_OUT_INSTITUTE_NUMBER_TWO);
            caseIdsInPrimaryContactInstituteTwo = casesPage.getCaseIdsFromPrimaryContactChildInstituteTwo(primaryContactOfChildInsTwo.get(URL), primaryContactOfChildInsTwo.get(USERNAME), primaryContactOfChildInsTwo.get(PASSWORD));
            LogUtil.log("Logged in with primary contact of Parent Institute One");
            loginPage.loginToCommunity(primaryContactOfConsortiaHeadData.get(URL), primaryContactOfConsortiaHeadData.get(USERNAME), primaryContactOfConsortiaHeadData.get(PASSWORD));
            casesPage.verifyInstituteCasesFromConsortiaByInstituteAsOptIn(caseIdsInPrimaryContactInstituteTwo);
            LogUtil.log("Logged in with primary contact of Parent Institute Two");
            loginPage.loginToCommunity(primaryContactOfSecondConsortia.get(URL), primaryContactOfSecondConsortia.get(USERNAME), primaryContactOfSecondConsortia.get(PASSWORD));
            casesPage.verifyInstituteCasesFromConsortiaByInstituteAsOptIn(caseIdsInPrimaryContactInstituteTwo);
            LogUtil.log("Script ended to validate the common child institute cases presence under parent consortia when Opted Out");
        }
    }

    @Test
    public void verifyOptInOptOutStatusWhenPrimaryContactIsChanged() {
        for (int tcRowNumber = 1; tcRowNumber <= tcExecCount; tcRowNumber++) {
            Map<String, String> excelInputData = testData.get(testcaseName + "_" + tcRowNumber);
            initLogins();
            LogUtil.log("Script Started to validate the OptIn/OptOut status when primary contact is changed");
            boolean optedInValueForInitialPrimaryContact;
            loginPage.loginToCommunity(primaryContactOfChildInsTwo.get(URL), primaryContactOfChildInsTwo.get(USERNAME), primaryContactOfChildInsTwo.get(PASSWORD));
            LogUtil.log("Logged in as Primary Contact");
            casesPage.navigateToContactListPage(driver);
            casesPage.clickOnPrimaryContactName(driver);
            LogUtil.log("Clicked on Primary Contact Name");
            if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_OUT_VALUE))
                optedInValueForInitialPrimaryContact = true;
            else
                optedInValueForInitialPrimaryContact = false;
            LogUtil.log("Captured the Opt In value");
            casesPage.navigateToContactListPage(driver);
            casesPage.clickOnSecondaryContactName(driver);
            LogUtil.log("Navigated to Secondary contact name under contacts list");
            casesPage.makePrimaryContact(driver);
            LogUtil.log("Marked secondary conract as Primary Contact");
            loginPage.logoutFromCommunity(driver);
            LogUtil.log("Logged out as Primary Contact");
            loginPage.loginToCommunity(secondaryContactOfChildInsTwo.get(URL), secondaryContactOfChildInsTwo.get(USERNAME), secondaryContactOfChildInsTwo.get(PASSWORD));
            LogUtil.log("Logged in as New Primary Contact");
            casesPage.navigateToContactListPage(driver);
            casesPage.clickOnPrimaryContactName(driver);
            LogUtil.log("Clicked on Primary Contact Name");
            boolean optedInValueAfterChangingPrimaryContact;
            if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_OUT_VALUE))
                optedInValueAfterChangingPrimaryContact = true;
            else
                optedInValueAfterChangingPrimaryContact = false;
            LogUtil.log("Captured the Opt In value");
            if (optedInValueAfterChangingPrimaryContact == optedInValueForInitialPrimaryContact)
                LogUtil.log("Opt In value is same after changing th primary contact");
            else {
                LogUtil.log("Opt In value is not same after changing th primary contact");
                Assert.fail();
            }
            LogUtil.log("Script started to re Assign the Primary Contact to the Old Primary Contact");
            casesPage.navigateToContactListPage(driver);
            casesPage.clickOnSecondaryContactName(driver);
            casesPage.makePrimaryContact(driver);
            LogUtil.log("Script ended to re Assign the Primary Contact to the Old Primary Contact");
        }
    }


    private void verifyInstituteCasesFromConsortiaByDefaultAsOptOut() {

        if ((caseIdsInPrimaryContactInstituteOne.equals(caseIdsInSecondaryContactInstituteOne)) && (caseIdsInPrimaryContactInstituteTwo.equals(caseIdsInSecondaryContactInstituteTwo))) {
            LogUtil.log("Cases from 2 contacts of same institute are same");
            loginPage.loginToCommunity(primaryContactOfConsortiaHeadData.get(URL), primaryContactOfConsortiaHeadData.get(USERNAME), primaryContactOfConsortiaHeadData.get(PASSWORD));
            LogUtil.log("Logged in with Primary Contact of Consortia Head");
            String casesInConsortiaPrimaryContact = casesPage.performCasesCountRetrieval(driver);
            LogUtil.log("Cases Present Under Primary Contact of Consortia::" + casesInConsortiaPrimaryContact);
            String[] caseIdListFromInstitute = totalCasesPresentUnderChildInstitutes.split(" ");
            boolean verifyCaseIdPresenceStatusInPrimaryConsortia = false;
            for (int caseListIndex = 0; caseListIndex < caseIdListFromInstitute.length; caseListIndex++) {
                if (casesInConsortiaPrimaryContact.contains(caseIdListFromInstitute[caseListIndex])) {
                    LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is present");
                    verifyCaseIdPresenceStatusInPrimaryConsortia = true;
                } else {
                    LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is not present");
                    verifyCaseIdPresenceStatusInPrimaryConsortia = false;
                }
            }
            if (!verifyCaseIdPresenceStatusInPrimaryConsortia) {
                LogUtil.log("Institute Cases are not displaying for Primary Consortia for Institute Optout");

                loginPage.loginToCommunity(contactOfConsortiaData.get(URL), contactOfConsortiaData.get(USERNAME), contactOfConsortiaData.get(PASSWORD));
                LogUtil.log("Logged in with Secondary Contact of Consortia");
                String casesInConsortiaContact = casesPage.performCasesCountRetrieval(driver);
                LogUtil.log("Cases Present Under Secondary Contact of Consortia::" + casesInConsortiaContact);
                boolean verifyCaseIdPresenceStatusInConsortia = false;
                for (int caseListIndex = 0; caseListIndex < caseIdListFromInstitute.length; caseListIndex++) {
                    if (casesInConsortiaContact.contains(caseIdListFromInstitute[caseListIndex])) {
                        LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is present");
                        verifyCaseIdPresenceStatusInConsortia = true;
                    } else {
                        LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is not present");
                        verifyCaseIdPresenceStatusInConsortia = false;
                    }
                }
                if (!verifyCaseIdPresenceStatusInConsortia) {
                    LogUtil.log("Institute Cases are not displaying for Secondary Consortia for Child Institutes Optout");
                } else {
                    LogUtil.log("Institute Cases are displaying for Secondary Consortia for Child Institutes Optout");
                    Assert.fail();
                }
            } else {
                LogUtil.log("Institute Cases are displaying for Primary Consortia for Child Institutes Optout");
                Assert.fail();
            }
        } else {
            LogUtil.log("Primary Contact and secondary contact/s cases are not same");
            Assert.fail();
        }
    }

    public void verifyInstituteCasesFromConsortiaByInstituteAsOptIn(String caseIdsInPrimaryContactInstitute, String caseIdsInSecondaryContactInstitute) {
        if (caseIdsInPrimaryContactInstitute.equals(caseIdsInSecondaryContactInstitute)) {
            LogUtil.log("Cases from 2 contacts of same institute are same");
            loginPage.loginToCommunity(primaryContactOfConsortiaHeadData.get(URL), primaryContactOfConsortiaHeadData.get(USERNAME), primaryContactOfConsortiaHeadData.get(PASSWORD));
            LogUtil.log("Logged in with Primary Contact of Consortia");
            String casesInConsortiaPrimaryContact = casesPage.performCasesCountRetrieval(driver);
            LogUtil.log("Cases Present Under Primary Contact of Consortia::" + casesInConsortiaPrimaryContact);
            String[] caseIdListFromInstitute = caseIdsInPrimaryContactInstitute.split(" ");
            boolean verifyCaseIdPresenceStatusInPrimaryConsortia = false;
            for (int caseListIndex = 0; caseListIndex < caseIdListFromInstitute.length; caseListIndex++) {
                if (casesInConsortiaPrimaryContact.contains(caseIdListFromInstitute[caseListIndex])) {
                    LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is present");
                    verifyCaseIdPresenceStatusInPrimaryConsortia = true;
                } else {
                    LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is not present");
                    verifyCaseIdPresenceStatusInPrimaryConsortia = false;
                }
            }
            if (verifyCaseIdPresenceStatusInPrimaryConsortia) {
                LogUtil.log("Institute Cases are displaying for Primary Consortia for Institute OptIn");
                loginPage.loginToCommunity(contactOfConsortiaData.get(URL), contactOfConsortiaData.get(USERNAME), contactOfConsortiaData.get(PASSWORD));
                LogUtil.log("Logged in with Secondary Contact of Consortia");
                String casesInConsortiaContact = casesPage.performCasesCountRetrieval(driver);
                LogUtil.log("Cases Present Under Secondary Contact of Consortia::" + casesInConsortiaContact);
                boolean verifyCaseIdPresenceStatusInConsortia = false;
                for (int caseListIndex = 0; caseListIndex < caseIdListFromInstitute.length; caseListIndex++) {
                    if (casesInConsortiaContact.contains(caseIdListFromInstitute[caseListIndex])) {
                        LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is present");
                        verifyCaseIdPresenceStatusInConsortia = true;
                    } else {
                        LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is not present");
                        verifyCaseIdPresenceStatusInConsortia = false;
                    }
                }
                if (verifyCaseIdPresenceStatusInConsortia) {
                    LogUtil.log("Institute Cases are displaying for Secondary Consortia for Institute OptIn");
                } else {
                    LogUtil.log("Institute Cases are not displaying for Secondary Consortia for Institute OptIn");
                    Assert.fail();
                }
            } else {
                LogUtil.log("Institute Cases are not displaying for Primary Consortia for Institute OptIn");
                Assert.fail();
            }
        } else {
            LogUtil.log("Primary Contact and secondary contact/s cases are not same");
            Assert.fail();
        }
    }

    public void verifyInstituteCasesFromConsortiaByChildInstitutesAsOptIn() {
        if ((caseIdsInPrimaryContactInstituteOne.equals(caseIdsInSecondaryContactInstituteOne)) && (caseIdsInPrimaryContactInstituteTwo.equals(caseIdsInSecondaryContactInstituteTwo))) {
            LogUtil.log("Cases from 2 contacts of same institute are same");
            loginPage.loginToCommunity(primaryContactOfConsortiaHeadData.get(URL), primaryContactOfConsortiaHeadData.get(USERNAME), primaryContactOfConsortiaHeadData.get(PASSWORD));
            LogUtil.log("Logged in with Primary Contact of Consortia");
            String casesSizeInConsortiaPrimaryContact = casesPage.performCasesCountRetrieval(driver);
            LogUtil.log("Cases Present Under Primary Contact of Consortia::" + casesSizeInConsortiaPrimaryContact);
            String[] caseIdListFromInstitute = totalCasesPresentUnderChildInstitutes.split(" ");
            boolean verifyCaseIdPresenceStatusInPrimaryConsortia = false;
            for (int caseListIndex = 0; caseListIndex < caseIdListFromInstitute.length; caseListIndex++) {
                if (casesSizeInConsortiaPrimaryContact.contains(caseIdListFromInstitute[caseListIndex])) {
                    LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is present");
                    verifyCaseIdPresenceStatusInPrimaryConsortia = true;
                } else {
                    LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is not present");
                    verifyCaseIdPresenceStatusInPrimaryConsortia = false;
                }
            }
            if (verifyCaseIdPresenceStatusInPrimaryConsortia) {
                LogUtil.log("Institute Cases are displaying for Primary Consortia for Institute OptIn");
                loginPage.loginToCommunity(contactOfConsortiaData.get(URL), contactOfConsortiaData.get(USERNAME), contactOfConsortiaData.get(PASSWORD));
                LogUtil.log("Logged in with Secondary Contact of Consortia");
                String casesSizeInConsortiaContact = casesPage.performCasesCountRetrieval(driver);
                LogUtil.log("Cases Present Under Secondary Contact of Consortia::" + casesSizeInConsortiaContact);
                boolean verifyCaseIdPresenceStatusInConsortia = false;
                for (int caseListIndex = 0; caseListIndex < caseIdListFromInstitute.length; caseListIndex++) {
                    if (casesSizeInConsortiaContact.contains(caseIdListFromInstitute[caseListIndex])) {
                        LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is present");
                        verifyCaseIdPresenceStatusInConsortia = true;
                    } else {
                        LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is not present");
                        verifyCaseIdPresenceStatusInConsortia = false;
                    }
                }
                if (verifyCaseIdPresenceStatusInConsortia) {
                    LogUtil.log("Institute Cases are displaying for Secondary Consortia for Child Institutes OptIn");
                } else {
                    LogUtil.log("Institute Cases are not displaying for Secondary Consortia for Child Institutes OptIn");
                    Assert.fail();
                }
            } else {
                LogUtil.log("Institute Cases are not displaying for Primary Consortia for Child Institutes OptIn");
                Assert.fail();
            }
        } else {
            LogUtil.log("Primary Contact and secondary contact/s cases are not same");
            Assert.fail();
        }
    }

    public void changeToOptOut(String ChildInstituteNumber) {
        switch (ChildInstituteNumber) {
            case OPT_IN_OPT_OUT_INSTITUTE_NUMBER_ONE:
                loginPage.loginToCommunity(primaryContactOfChildInsOne.get(URL), primaryContactOfChildInsOne.get(USERNAME), primaryContactOfChildInsOne.get(PASSWORD));
                LogUtil.log("Logged in with Primary Contact of Institute One");
                casesPage.navigateToContactListPage(driver);
                casesPage.clickOnPrimaryContactName(driver);
                if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_OUT_VALUE))
                    casesPage.clickOptInOptOut(driver);
                LogUtil.log("Changed the Status to Opt Out");
                loginPage.logoutFromCommunity(driver);
                break;
            case OPT_IN_OPT_OUT_INSTITUTE_NUMBER_TWO:
                loginPage.loginToCommunity(primaryContactOfChildInsTwo.get(URL), primaryContactOfChildInsTwo.get(USERNAME), primaryContactOfChildInsTwo.get(PASSWORD));
                LogUtil.log("Logged in with Primary Contact of Institute Two");
                casesPage.navigateToContactListPage(driver);
                casesPage.clickOnPrimaryContactName(driver);
                if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_OUT_VALUE))
                    casesPage.clickOptInOptOut(driver);
                LogUtil.log("Changed the Status to Opt Out");
                loginPage.logoutFromCommunity(driver);
                break;
            case OPT_IN_OPT_OUT_INSTITUTE_NUMBER_ALL:
                loginPage.loginToCommunity(primaryContactOfChildInsOne.get(URL), primaryContactOfChildInsOne.get(USERNAME), primaryContactOfChildInsOne.get(PASSWORD));
                LogUtil.log("Logged in with Primary Contact of Institute One");
                casesPage.navigateToContactListPage(driver);
                casesPage.clickOnPrimaryContactName(driver);
                if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_OUT_VALUE))
                    casesPage.clickOptInOptOut(driver);
                LogUtil.log("Changed the Status to Opt Out");
                loginPage.logoutFromCommunity(driver);
                loginPage.loginToCommunity(primaryContactOfChildInsTwo.get(URL), primaryContactOfChildInsTwo.get(USERNAME), primaryContactOfChildInsTwo.get(PASSWORD));
                LogUtil.log("Logged in with Primary Contact of Institute Two");
                casesPage.navigateToContactListPage(driver);
                casesPage.clickOnPrimaryContactName(driver);
                if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_OUT_VALUE))
                    casesPage.clickOptInOptOut(driver);
                LogUtil.log("Changed the Status to Opt Out");
                loginPage.logoutFromCommunity(driver);
                break;
        }

    }

    public void changeToOptIn(String ChildInstituteNumber) {

        switch (ChildInstituteNumber) {
            case OPT_IN_OPT_OUT_INSTITUTE_NUMBER_ONE:
                loginPage.loginToCommunity(primaryContactOfChildInsOne.get(URL), primaryContactOfChildInsOne.get(USERNAME), primaryContactOfChildInsOne.get(PASSWORD));
                LogUtil.log("Logged in with Primary Contact of Institute One");
                casesPage.navigateToContactListPage(driver);
                casesPage.clickOnPrimaryContactName(driver);

                if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_IN_VALUE))
                    casesPage.clickOptInOptOut(driver);
                LogUtil.log("Changed the Status to Opt In");
                loginPage.logoutFromCommunity(driver);
                break;
            case OPT_IN_OPT_OUT_INSTITUTE_NUMBER_TWO:
                loginPage.loginToCommunity(primaryContactOfChildInsTwo.get(URL), primaryContactOfChildInsTwo.get(USERNAME), primaryContactOfChildInsTwo.get(PASSWORD));
                LogUtil.log("Logged in with Primary Contact of Institute Two");
                casesPage.navigateToContactListPage(driver);
                casesPage.clickOnPrimaryContactName(driver);
                if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_IN_VALUE))
                    casesPage.clickOptInOptOut(driver);
                LogUtil.log("Changed the Status to Opt In");
                loginPage.logoutFromCommunity(driver);
                break;
            case OPT_IN_OPT_OUT_INSTITUTE_NUMBER_ALL:
                loginPage.loginToCommunity(primaryContactOfChildInsOne.get(URL), primaryContactOfChildInsOne.get(USERNAME), primaryContactOfChildInsOne.get(PASSWORD));
                LogUtil.log("Logged in with Primary Contact of Institute One");
                casesPage.navigateToContactListPage(driver);
                casesPage.clickOnPrimaryContactName(driver);
                if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_IN_VALUE))
                    casesPage.clickOptInOptOut(driver);
                LogUtil.log("Changed the Status to Opt In");
                loginPage.logoutFromCommunity(driver);
                loginPage.loginToCommunity(primaryContactOfChildInsTwo.get(URL), primaryContactOfChildInsTwo.get(USERNAME), primaryContactOfChildInsTwo.get(PASSWORD));
                LogUtil.log("Logged in with Primary Contact of Institute Two");
                casesPage.navigateToContactListPage(driver);
                casesPage.clickOnPrimaryContactName(driver);
                if (casesPage.verifyOptInOptOut(driver).equalsIgnoreCase(OPT_IN_VALUE))
                    casesPage.clickOptInOptOut(driver);
                LogUtil.log("Changed the Status to Opt In");
                loginPage.logoutFromCommunity(driver);
                break;
        }


    }

    public void getCaseIdsFromChildInstitutes() {
        loginPage.loginToCommunity(primaryContactOfChildInsOne.get(URL), primaryContactOfChildInsOne.get(USERNAME), primaryContactOfChildInsOne.get(PASSWORD));
        LogUtil.log("Logged in with Primary Contact of Institute One");
        caseIdsInPrimaryContactInstituteOne = casesPage.performCasesCountRetrieval(driver);
        LogUtil.log("Cases Present Under Institute One Of Primary Contact::" + caseIdsInPrimaryContactInstituteOne);
        loginPage.loginToCommunity(secondaryContactOfChildInsOne.get(URL), secondaryContactOfChildInsOne.get(USERNAME), secondaryContactOfChildInsOne.get(PASSWORD));
        LogUtil.log("Logged in with Secondary Contact of Institute One");
        caseIdsInSecondaryContactInstituteOne = casesPage.performCasesCountRetrieval(driver);
        LogUtil.log("Cases Present Under Institute One Of Secondary Contact::" + caseIdsInSecondaryContactInstituteOne);
        loginPage.loginToCommunity(primaryContactOfChildInsTwo.get(URL), primaryContactOfChildInsTwo.get(USERNAME), primaryContactOfChildInsTwo.get(PASSWORD));
        LogUtil.log("Logged in with Primary Contact of Institute TWO");
        caseIdsInPrimaryContactInstituteTwo = casesPage.performCasesCountRetrieval(driver);
        LogUtil.log("Cases Present Under Institute Two Of Primary Contact::" + caseIdsInPrimaryContactInstituteTwo);
        loginPage.loginToCommunity(secondaryContactOfChildInsTwo.get(URL), secondaryContactOfChildInsTwo.get(USERNAME), secondaryContactOfChildInsTwo.get(PASSWORD));
        LogUtil.log("Logged in with Secondary Contact of Institute TWO");
        caseIdsInSecondaryContactInstituteTwo = casesPage.performCasesCountRetrieval(driver);
        LogUtil.log("Cases Present Under Institute Two Of Secondary Contact::" + caseIdsInSecondaryContactInstituteTwo);
        totalCasesPresentUnderChildInstitutes = caseIdsInPrimaryContactInstituteOne + caseIdsInPrimaryContactInstituteTwo;
    }


}
