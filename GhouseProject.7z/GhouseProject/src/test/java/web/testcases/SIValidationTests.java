package web.testcases;

import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.api.netsuite.services.retrieval.SIData;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class SIValidationTests extends BaseTest {

    private Logger logger = LogManager.getLogger(this.getClass());
    private static final String SF_CASE_NUMBER = "00033634";
    private SoftAssert softAssert = new SoftAssert();


    @Test
    public void validateSI() throws Exception {
        loginPage.login(true);
        List<ServiceIssue> nsServiceIssue = retrieveServiceIssues(Arrays.asList("123000"));
        nsServiceIssue.forEach(si -> {
            String url = "https://qa-ebsco.cs23.force.com/dev1/s/service-issues/" + si.getSfServiceIssueId();
            driver.get(url);
            softAssert.assertTrue(siDetailPage.validateDetails(si));
        });
        softAssert.assertAll();
    }


    private List<ServiceIssue> retrieveServiceIssues(List<String> netsuiteSIIDs) throws Exception {
        return new LinkedList<>(new SIData()
                .get(netsuiteSIIDs, null)
                .values());
    }
}

