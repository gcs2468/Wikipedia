package web.testcases;


import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.pageobjects.home.HomePage;
import com.ebsco.web.pageobjects.home.PasswordResetPage;
import com.ebsco.web.utilities.Email;
import com.ebsco.web.utilities.SeleniumWrappers;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import web.pageobject.ThankYouPage;

import javax.mail.MessagingException;
import javax.mail.Session;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class UserRegistration {
    private SeleniumWrappers fActions = new SeleniumWrappers();

    private static URL extractFirstURLFrom(String mailContents) throws MalformedURLException {

        int urlStartIndex = mailContents.indexOf( "http" );
        if (urlStartIndex < 0)
            throw new NullPointerException( "No URL exists in email." );
        int endIndex;
        int lengthOfContents = mailContents.length();
        for (endIndex = urlStartIndex; ; endIndex++) {
            char character = mailContents.charAt( endIndex );
            if (endIndex >= lengthOfContents || character == '\n' || Character.isWhitespace( character )) {
                break;
            }
        }
        String url = mailContents.substring( urlStartIndex, endIndex );
        return new URL( url );
    }

    @Test
    public void userRegistration() throws IOException, MessagingException {
        SoftAssert softAssert = new SoftAssert();
        Session session = Email.createEmailSessionForReading();
        String invitationEmail = Email.getMostRecentEmail( session );
        URL activationURL = extractFirstURLFrom( invitationEmail );
        WebDriver driver = InvokeInstances.getInvokeInstance().getWebDriverManager().getDriver();
        fActions.openURL( driver, activationURL.toString() );
        softAssert.assertTrue( new ThankYouPage( driver ).hasThankYouMessage(), "Thank you page is not visited." );
        String passwordResetEmail = Email.getMostRecentEmail( session );
        URL passwordResetLink = extractFirstURLFrom( passwordResetEmail );
        driver.get( passwordResetLink.toString() );
        new PasswordResetPage( driver ).enterCredentials();
        softAssert.assertTrue( new HomePage( driver ).contentTitleExists(), "HomePage has not arrived yet." );
        softAssert.assertAll();
    }

}


