package com.ebsco.api.netsuite.services.retrieval;

import com.ebsco.api.netsuite.services.connection.NetSuiteConnection;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.MessageCustomVal;
import com.ebsco.common.utility.AppProperties;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.PropertyNames.MESSAGE_RETRIEVE_SQL_PROPERTY;

public class MessageData extends AbstractRecord<MessageCustomVal> {

    @Override
    public synchronized Map<String, MessageCustomVal> get(List<String> idList, NetSuiteConnectionPool pool) throws Exception {
        NetSuiteConnectionPool nsConnectionPool=new NetSuiteConnectionPool(1);
        NetSuiteConnection connection = nsConnectionPool.acquire();
        Statement statement = connection.getStatement();
        String sql = AppProperties.getValueFor(MESSAGE_RETRIEVE_SQL_PROPERTY);
        sql += listToString(idList);
        System.out.println("SQL Query::"+sql);
        Map<String, MessageCustomVal> messageMap = new HashMap<>();

        try (ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                MessageCustomVal messageCustomVal = new MessageCustomVal();
                messageCustomVal.setCaseId(String.valueOf( new Double( resultSet.getDouble( "case_id" )).longValue()));
                messageCustomVal.setSfCaseId(resultSet.getString("sf_case_id"));
                messageCustomVal.setMessage(resultSet.getString("message"));
                messageCustomVal.setMessageId(String.valueOf( new Double( resultSet.getDouble( "message_id")).longValue()));
                messageCustomVal.setName(resultSet.getString("Name"));;
                messageCustomVal.setEmail(resultSet.getString("Email"));
                messageCustomVal.setCc(resultSet.getString("CC"));
                messageCustomVal.setSubject(resultSet.getString("SUBJECT"));
                messageCustomVal.setBCC(resultSet.getString("BCC"));
                messageCustomVal.setDATE_0(resultSet.getString("DATE_0"));
                messageCustomVal.setIS_EMAILED(resultSet.getString("IS_EMAILED"));
                messageCustomVal.setIS_INCOMING(resultSet.getString("IS_INCOMING"));
                messageCustomVal.setRECIPIENT_ID(resultSet.getString("RECIPIENT_ID"));

                messageMap.put(messageCustomVal.getMessageId(), messageCustomVal);
            }
        }

        pool.free(connection);
//        System.out.println("Values::"+messageMap.values());
        return messageMap;
    }
}
