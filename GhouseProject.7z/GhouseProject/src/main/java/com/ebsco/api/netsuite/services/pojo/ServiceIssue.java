package com.ebsco.api.netsuite.services.pojo;

import com.netsuite.suitetalk.proxy.v2017_2.platform.core.Record;

import java.util.List;

public class ServiceIssue extends Record {

    private String netsuiteInternalId;
    private String synopsis;
    private String product_interface;
    private String status;
    private String issueExperience;
    private String resolution;
    private String dateCreated;
    private String lastmodified;
    private String siDateClosed;
    private String sfServiceIssueId;

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    private String caseId;

    public List<String> getCaseIdList() {
        return caseIdList;
    }

    public void setCaseIdList(List<String> caseIdList) {
        this.caseIdList = caseIdList;
    }

    private List<String> caseIdList;


    public String getNetsuiteInternalId() {
        return netsuiteInternalId;
    }

    public void setNetsuiteInternalId(String netsuiteInternalId) {
        this.netsuiteInternalId = netsuiteInternalId;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public String getProduct_interface() {
        return product_interface;
    }

    public void setProduct_interface(String product_interface) {
        this.product_interface = product_interface;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIssueExperience() {
        return issueExperience;
    }

    public void setIssueExperience(String issueExperience) {
        this.issueExperience = issueExperience;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getLastmodified() {
        return lastmodified;
    }

    public void setLastmodified(String lastmodified) {
        this.lastmodified = lastmodified;
    }

    public String getSiDateClosed() {
        return siDateClosed;
    }

    public void setSiDateClosed(String siDateClosed) {
        this.siDateClosed = siDateClosed;
    }

    public String getSfServiceIssueId() {
        return sfServiceIssueId;
    }

    public void setSfServiceIssueId(String sfServiceIssueId) {
        this.sfServiceIssueId = sfServiceIssueId;
    }
}
