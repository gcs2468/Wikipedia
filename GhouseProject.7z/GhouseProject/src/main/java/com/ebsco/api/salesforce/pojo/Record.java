package com.ebsco.api.salesforce.pojo;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class Record {

    @JsonProperty("attributes")
    private Attributes attributes;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("MasterRecordId")
    private Object masterRecordId;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Type")
    private Object type;
    @JsonProperty("BillingStreet")
    private String billingStreet;
    @JsonProperty("BillingCity")
    private String billingCity;
    @JsonProperty("BillingState")
    private String billingState;
    @JsonProperty("BillingPostalCode")
    private String billingPostalCode;
    @JsonProperty("BillingCountry")
    private String billingCountry;
    @JsonProperty("BillingLatitude")
    private Object billingLatitude;
    @JsonProperty("BillingLongitude")
    private Object billingLongitude;
    @JsonProperty("BillingGeocodeAccuracy")
    private Object billingGeocodeAccuracy;
    /*@JsonProperty("BillingAddress")
    private BillingAddress billingAddress;*/
    @JsonProperty("ShippingStreet")
    private Object shippingStreet;
    @JsonProperty("ShippingCity")
    private Object shippingCity;
    @JsonProperty("ShippingState")
    private Object shippingState;
    @JsonProperty("ShippingPostalCode")
    private Object shippingPostalCode;
    @JsonProperty("ShippingCountry")
    private Object shippingCountry;
    @JsonProperty("ShippingLatitude")
    private Object shippingLatitude;
    @JsonProperty("ShippingLongitude")
    private Object shippingLongitude;
    @JsonProperty("ShippingGeocodeAccuracy")
    private Object shippingGeocodeAccuracy;
    @JsonProperty("ShippingAddress")
    private Object shippingAddress;
    @JsonProperty("Phone")
    private Object phone;
    @JsonProperty("Fax")
    private Object fax;
    @JsonProperty("Website")
    private Object website;
    @JsonProperty("PhotoUrl")
    private String photoUrl;
    @JsonProperty("Industry")
    private Object industry;
    @JsonProperty("NumberOfEmployees")
    private Object numberOfEmployees;
    @JsonProperty("Description")
    private Object description;
    @JsonProperty("OwnerId")
    private String ownerId;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("LastActivityDate")
    private Object lastActivityDate;
    @JsonProperty("LastViewedDate")
    private String lastViewedDate;
    @JsonProperty("LastReferencedDate")
    private String lastReferencedDate;
    @JsonProperty("IsCustomerPortal")
    private Boolean isCustomerPortal;
    @JsonProperty("Jigsaw")
    private Object jigsaw;
    @JsonProperty("JigsawCompanyId")
    private Object jigsawCompanyId;
    @JsonProperty("AccountSource")
    private Object accountSource;
    @JsonProperty("SicDesc")
    private Object sicDesc;
    @JsonProperty("EIS_CAS_Customer_Level__c")
    private Object eISCASCustomerLevelC;
    @JsonProperty("EIS_Customer_Satisfaction__c")
    private Object eISCustomerSatisfactionC;
    @JsonProperty("EIS_Market__c")
    private String eISMarketC;
    @JsonProperty("Opt_In_To_Parent_Visibility__c")
    private Boolean optInToParentVisibilityC;
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    private String eISNetsuiteRecordIdC;
    @JsonProperty("EIS_Segment__c")
    private String eISSegmentC;
    @JsonProperty("EIS_Netsuite_Customer_Id__c")
    private String eISNetsuiteCustomerIdC;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     */
    public Record() {
    }

    /**
     * @param phone
     * @param jigsaw
     * @param createdById
     * @param ownerId
     * @param billingGeocodeAccuracy
     * @param billingLatitude
     * @param type
     * @param billingState
     * @param shippingLatitude
     * @param accountSource
     * @param billingStreet
     * @param id
     *
     * @param shippingState
     * @param billingPostalCode
     * @param description
     * @param systemModstamp
     * @param name
     * @param lastModifiedById
     * @param numberOfEmployees
     * @param billingCity
     * @param shippingLongitude
     * @param billingCountry
     * @param industry
     * @param shippingAddress
     * @param createdDate
     * @param lastViewedDate
     * @param billingLongitude
     * @param lastReferencedDate
     * @param masterRecordId
     * @param website
     * @param shippingGeocodeAccuracy
     * @param lastActivityDate
     * @param shippingPostalCode
     * @param isDeleted
     * @param shippingStreet
     * @param jigsawCompanyId
     * @param sicDesc
     * @param lastModifiedDate
//     * @param billingAddress
     * @param shippingCountry
     * @param attributes
     * @param photoUrl
     * @param shippingCity
     */
    public Record(Attributes attributes, String id, Boolean isDeleted, Object masterRecordId, String name, Object type, String billingStreet, String billingCity, String billingState, String billingPostalCode, String billingCountry, Object billingLatitude, Object billingLongitude, Object billingGeocodeAccuracy, /*BillingAddress billingAddress,*/ Object shippingStreet, Object shippingCity, Object shippingState, Object shippingPostalCode, Object shippingCountry, Object shippingLatitude, Object shippingLongitude, Object shippingGeocodeAccuracy, Object shippingAddress, Object phone, Object fax, Object website, String photoUrl, Object industry, Object numberOfEmployees, Object description, String ownerId, String createdDate, String createdById, String lastModifiedDate, String lastModifiedById, String systemModstamp, Object lastActivityDate, String lastViewedDate, String lastReferencedDate, Boolean isCustomerPortal, Object jigsaw, Object jigsawCompanyId, Object accountSource, Object sicDesc, Object eISCASCustomerLevelC, Object eISCustomerSatisfactionC, String eISMarketC, Boolean optInToParentVisibilityC, String eISNetsuiteRecordIdC, String eISSegmentC, String eISNetsuiteCustomerIdC) {
        super();
        this.attributes = attributes;
        this.id = id;
        this.isDeleted = isDeleted;
        this.masterRecordId = masterRecordId;
        this.name = name;
        this.type = type;
        this.billingStreet = billingStreet;
        this.billingCity = billingCity;
        this.billingState = billingState;
        this.billingPostalCode = billingPostalCode;
        this.billingCountry = billingCountry;
        this.billingLatitude = billingLatitude;
        this.billingLongitude = billingLongitude;
        this.billingGeocodeAccuracy = billingGeocodeAccuracy;
//        this.billingAddress = billingAddress;
        this.shippingStreet = shippingStreet;
        this.shippingCity = shippingCity;
        this.shippingState = shippingState;
        this.shippingPostalCode = shippingPostalCode;
        this.shippingCountry = shippingCountry;
        this.shippingLatitude = shippingLatitude;
        this.shippingLongitude = shippingLongitude;
        this.shippingGeocodeAccuracy = shippingGeocodeAccuracy;
        this.shippingAddress = shippingAddress;
        this.phone = phone;
        this.fax = fax;
        this.website = website;
        this.photoUrl = photoUrl;
        this.industry = industry;
        this.numberOfEmployees = numberOfEmployees;
        this.description = description;
        this.ownerId = ownerId;
        this.createdDate = createdDate;
        this.createdById = createdById;
        this.lastModifiedDate = lastModifiedDate;
        this.lastModifiedById = lastModifiedById;
        this.systemModstamp = systemModstamp;
        this.lastActivityDate = lastActivityDate;
        this.lastViewedDate = lastViewedDate;
        this.lastReferencedDate = lastReferencedDate;
        this.isCustomerPortal = isCustomerPortal;
        this.jigsaw = jigsaw;
        this.jigsawCompanyId = jigsawCompanyId;
        this.accountSource = accountSource;
        this.sicDesc = sicDesc;
        this.eISCASCustomerLevelC = eISCASCustomerLevelC;
        this.eISCustomerSatisfactionC = eISCustomerSatisfactionC;
        this.eISMarketC = eISMarketC;
        this.optInToParentVisibilityC = optInToParentVisibilityC;
        this.eISNetsuiteRecordIdC = eISNetsuiteRecordIdC;
        this.eISSegmentC = eISSegmentC;
        this.eISNetsuiteCustomerIdC = eISNetsuiteCustomerIdC;
    }

    @JsonProperty("attributes")
    public Attributes getAttributes() {
        return attributes;
    }

    @JsonProperty("attributes")
    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("MasterRecordId")
    public Object getMasterRecordId() {
        return masterRecordId;
    }

    @JsonProperty("MasterRecordId")
    public void setMasterRecordId(Object masterRecordId) {
        this.masterRecordId = masterRecordId;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Type")
    public Object getType() {
        return type;
    }

    @JsonProperty("Type")
    public void setType(Object type) {
        this.type = type;
    }

    @JsonProperty("BillingStreet")
    public String getBillingStreet() {
        return billingStreet;
    }

    @JsonProperty("BillingStreet")
    public void setBillingStreet(String billingStreet) {
        this.billingStreet = billingStreet;
    }

    @JsonProperty("BillingCity")
    public String getBillingCity() {
        return billingCity;
    }

    @JsonProperty("BillingCity")
    public void setBillingCity(String billingCity) {
        this.billingCity = billingCity;
    }

    @JsonProperty("BillingState")
    public String getBillingState() {
        return billingState;
    }

    @JsonProperty("BillingState")
    public void setBillingState(String billingState) {
        this.billingState = billingState;
    }

    @JsonProperty("BillingPostalCode")
    public String getBillingPostalCode() {
        return billingPostalCode;
    }

    @JsonProperty("BillingPostalCode")
    public void setBillingPostalCode(String billingPostalCode) {
        this.billingPostalCode = billingPostalCode;
    }

    @JsonProperty("BillingCountry")
    public String getBillingCountry() {
        return billingCountry;
    }

    @JsonProperty("BillingCountry")
    public void setBillingCountry(String billingCountry) {
        this.billingCountry = billingCountry;
    }

    @JsonProperty("BillingLatitude")
    public Object getBillingLatitude() {
        return billingLatitude;
    }

    @JsonProperty("BillingLatitude")
    public void setBillingLatitude(Object billingLatitude) {
        this.billingLatitude = billingLatitude;
    }

    @JsonProperty("BillingLongitude")
    public Object getBillingLongitude() {
        return billingLongitude;
    }

    @JsonProperty("BillingLongitude")
    public void setBillingLongitude(Object billingLongitude) {
        this.billingLongitude = billingLongitude;
    }

    @JsonProperty("BillingGeocodeAccuracy")
    public Object getBillingGeocodeAccuracy() {
        return billingGeocodeAccuracy;
    }

    @JsonProperty("BillingGeocodeAccuracy")
    public void setBillingGeocodeAccuracy(Object billingGeocodeAccuracy) {
        this.billingGeocodeAccuracy = billingGeocodeAccuracy;
    }

    /*@JsonProperty("BillingAddress")
    public BillingAddress getBillingAddress() {
        return billingAddress;
    }

    @JsonProperty("BillingAddress")
    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }
*/
    @JsonProperty("ShippingStreet")
    public Object getShippingStreet() {
        return shippingStreet;
    }

    @JsonProperty("ShippingStreet")
    public void setShippingStreet(Object shippingStreet) {
        this.shippingStreet = shippingStreet;
    }

    @JsonProperty("ShippingCity")
    public Object getShippingCity() {
        return shippingCity;
    }

    @JsonProperty("ShippingCity")
    public void setShippingCity(Object shippingCity) {
        this.shippingCity = shippingCity;
    }

    @JsonProperty("ShippingState")
    public Object getShippingState() {
        return shippingState;
    }

    @JsonProperty("ShippingState")
    public void setShippingState(Object shippingState) {
        this.shippingState = shippingState;
    }

    @JsonProperty("ShippingPostalCode")
    public Object getShippingPostalCode() {
        return shippingPostalCode;
    }

    @JsonProperty("ShippingPostalCode")
    public void setShippingPostalCode(Object shippingPostalCode) {
        this.shippingPostalCode = shippingPostalCode;
    }

    @JsonProperty("ShippingCountry")
    public Object getShippingCountry() {
        return shippingCountry;
    }

    @JsonProperty("ShippingCountry")
    public void setShippingCountry(Object shippingCountry) {
        this.shippingCountry = shippingCountry;
    }

    @JsonProperty("ShippingLatitude")
    public Object getShippingLatitude() {
        return shippingLatitude;
    }

    @JsonProperty("ShippingLatitude")
    public void setShippingLatitude(Object shippingLatitude) {
        this.shippingLatitude = shippingLatitude;
    }

    @JsonProperty("ShippingLongitude")
    public Object getShippingLongitude() {
        return shippingLongitude;
    }

    @JsonProperty("ShippingLongitude")
    public void setShippingLongitude(Object shippingLongitude) {
        this.shippingLongitude = shippingLongitude;
    }

    @JsonProperty("ShippingGeocodeAccuracy")
    public Object getShippingGeocodeAccuracy() {
        return shippingGeocodeAccuracy;
    }

    @JsonProperty("ShippingGeocodeAccuracy")
    public void setShippingGeocodeAccuracy(Object shippingGeocodeAccuracy) {
        this.shippingGeocodeAccuracy = shippingGeocodeAccuracy;
    }

    @JsonProperty("ShippingAddress")
    public Object getShippingAddress() {
        return shippingAddress;
    }

    @JsonProperty("ShippingAddress")
    public void setShippingAddress(Object shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    @JsonProperty("Phone")
    public Object getPhone() {
        return phone;
    }

    @JsonProperty("Phone")
    public void setPhone(Object phone) {
        this.phone = phone;
    }

    @JsonProperty("Fax")
    public Object getFax() {
        return fax;
    }

    @JsonProperty("Fax")
    public void setFax(Object fax) {
        this.fax = fax;
    }

    @JsonProperty("Website")
    public Object getWebsite() {
        return website;
    }

    @JsonProperty("Website")
    public void setWebsite(Object website) {
        this.website = website;
    }

    @JsonProperty("PhotoUrl")
    public String getPhotoUrl() {
        return photoUrl;
    }

    @JsonProperty("PhotoUrl")
    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    @JsonProperty("Industry")
    public Object getIndustry() {
        return industry;
    }

    @JsonProperty("Industry")
    public void setIndustry(Object industry) {
        this.industry = industry;
    }

    @JsonProperty("NumberOfEmployees")
    public Object getNumberOfEmployees() {
        return numberOfEmployees;
    }

    @JsonProperty("NumberOfEmployees")
    public void setNumberOfEmployees(Object numberOfEmployees) {
        this.numberOfEmployees = numberOfEmployees;
    }

    @JsonProperty("Description")
    public Object getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(Object description) {
        this.description = description;
    }

    @JsonProperty("OwnerId")
    public String getOwnerId() {
        return ownerId;
    }

    @JsonProperty("OwnerId")
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("LastActivityDate")
    public Object getLastActivityDate() {
        return lastActivityDate;
    }

    @JsonProperty("LastActivityDate")
    public void setLastActivityDate(Object lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }

    @JsonProperty("LastViewedDate")
    public String getLastViewedDate() {
        return lastViewedDate;
    }

    @JsonProperty("LastViewedDate")
    public void setLastViewedDate(String lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }

    @JsonProperty("LastReferencedDate")
    public String getLastReferencedDate() {
        return lastReferencedDate;
    }

    @JsonProperty("LastReferencedDate")
    public void setLastReferencedDate(String lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }

    @JsonProperty("IsCustomerPortal")
    public Boolean getIsCustomerPortal() {
        return isCustomerPortal;
    }

    @JsonProperty("IsCustomerPortal")
    public void setIsCustomerPortal(Boolean isCustomerPortal) {
        this.isCustomerPortal = isCustomerPortal;
    }

    @JsonProperty("Jigsaw")
    public Object getJigsaw() {
        return jigsaw;
    }

    @JsonProperty("Jigsaw")
    public void setJigsaw(Object jigsaw) {
        this.jigsaw = jigsaw;
    }

    @JsonProperty("JigsawCompanyId")
    public Object getJigsawCompanyId() {
        return jigsawCompanyId;
    }

    @JsonProperty("JigsawCompanyId")
    public void setJigsawCompanyId(Object jigsawCompanyId) {
        this.jigsawCompanyId = jigsawCompanyId;
    }

    @JsonProperty("AccountSource")
    public Object getAccountSource() {
        return accountSource;
    }

    @JsonProperty("AccountSource")
    public void setAccountSource(Object accountSource) {
        this.accountSource = accountSource;
    }

    @JsonProperty("SicDesc")
    public Object getSicDesc() {
        return sicDesc;
    }

    @JsonProperty("SicDesc")
    public void setSicDesc(Object sicDesc) {
        this.sicDesc = sicDesc;
    }

    @JsonProperty("EIS_CAS_Customer_Level__c")
    public Object getEISCASCustomerLevelC() {
        return eISCASCustomerLevelC;
    }

    @JsonProperty("EIS_CAS_Customer_Level__c")
    public void setEISCASCustomerLevelC(Object eISCASCustomerLevelC) {
        this.eISCASCustomerLevelC = eISCASCustomerLevelC;
    }

    @JsonProperty("EIS_Customer_Satisfaction__c")
    public Object getEISCustomerSatisfactionC() {
        return eISCustomerSatisfactionC;
    }

    @JsonProperty("EIS_Customer_Satisfaction__c")
    public void setEISCustomerSatisfactionC(Object eISCustomerSatisfactionC) {
        this.eISCustomerSatisfactionC = eISCustomerSatisfactionC;
    }

    @JsonProperty("EIS_Market__c")
    public String getEISMarketC() {
        return eISMarketC;
    }

    @JsonProperty("EIS_Market__c")
    public void setEISMarketC(String eISMarketC) {
        this.eISMarketC = eISMarketC;
    }

    @JsonProperty("Opt_In_To_Parent_Visibility__c")
    public Boolean getOptInToParentVisibilityC() {
        return optInToParentVisibilityC;
    }

    @JsonProperty("Opt_In_To_Parent_Visibility__c")
    public void setOptInToParentVisibilityC(Boolean optInToParentVisibilityC) {
        this.optInToParentVisibilityC = optInToParentVisibilityC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public String getEISNetsuiteRecordIdC() {
        return eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public void setEISNetsuiteRecordIdC(String eISNetsuiteRecordIdC) {
        this.eISNetsuiteRecordIdC = eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Segment__c")
    public String getEISSegmentC() {
        return eISSegmentC;
    }

    @JsonProperty("EIS_Segment__c")
    public void setEISSegmentC(String eISSegmentC) {
        this.eISSegmentC = eISSegmentC;
    }

    @JsonProperty("EIS_Netsuite_Customer_Id__c")
    public String getEISNetsuiteCustomerIdC() {
        return eISNetsuiteCustomerIdC;
    }

    @JsonProperty("EIS_Netsuite_Customer_Id__c")
    public void setEISNetsuiteCustomerIdC(String eISNetsuiteCustomerIdC) {
        this.eISNetsuiteCustomerIdC = eISNetsuiteCustomerIdC;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("attributes", attributes).append("id", id).append("isDeleted", isDeleted).append("masterRecordId", masterRecordId).append("name", name).append("type", type).append("billingStreet", billingStreet).append("billingCity", billingCity).append("billingState", billingState).append("billingPostalCode", billingPostalCode).append("billingCountry", billingCountry).append("billingLatitude", billingLatitude).append("billingLongitude", billingLongitude).append("billingGeocodeAccuracy", billingGeocodeAccuracy)/*.append("billingAddress", billingAddress)*/.append("shippingStreet", shippingStreet).append("shippingCity", shippingCity).append("shippingState", shippingState).append("shippingPostalCode", shippingPostalCode).append("shippingCountry", shippingCountry).append("shippingLatitude", shippingLatitude).append("shippingLongitude", shippingLongitude).append("shippingGeocodeAccuracy", shippingGeocodeAccuracy).append("shippingAddress", shippingAddress).append("phone", phone).append("fax", fax).append("website", website).append("photoUrl", photoUrl).append("industry", industry).append("numberOfEmployees", numberOfEmployees).append("description", description).append("ownerId", ownerId).append("createdDate", createdDate).append("createdById", createdById).append("lastModifiedDate", lastModifiedDate).append("lastModifiedById", lastModifiedById).append("systemModstamp", systemModstamp).append("lastActivityDate", lastActivityDate).append("lastViewedDate", lastViewedDate).append("lastReferencedDate", lastReferencedDate).append("isCustomerPortal", isCustomerPortal).append("jigsaw", jigsaw).append("jigsawCompanyId", jigsawCompanyId).append("accountSource", accountSource).append("sicDesc", sicDesc).append("eISCASCustomerLevelC", eISCASCustomerLevelC).append("eISCustomerSatisfactionC", eISCustomerSatisfactionC).append("eISMarketC", eISMarketC).append("optInToParentVisibilityC", optInToParentVisibilityC).append("eISNetsuiteRecordIdC", eISNetsuiteRecordIdC).append("eISSegmentC", eISSegmentC).append("eISNetsuiteCustomerIdC", eISNetsuiteCustomerIdC).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(isCustomerPortal).append(phone).append(jigsaw).append(billingGeocodeAccuracy).append(type).append(shippingLatitude).append(shippingState).append(description).append(systemModstamp).append(lastModifiedById).append(industry).append(shippingLongitude).append(createdDate).append(lastViewedDate).append(eISCASCustomerLevelC).append(billingLongitude).append(fax).append(masterRecordId).append(shippingGeocodeAccuracy).append(lastActivityDate).append(shippingPostalCode).append(eISMarketC).append(eISSegmentC).append(shippingStreet).append(additionalProperties).append(jigsawCompanyId).append(sicDesc).append(shippingCountry).append(eISCustomerSatisfactionC).append(createdById).append(ownerId).append(billingLatitude).append(billingState).append(accountSource).append(billingStreet).append(optInToParentVisibilityC).append(id).append(billingPostalCode).append(eISNetsuiteRecordIdC).append(name).append(numberOfEmployees).append(billingCity).append(billingCountry).append(shippingAddress).append(lastReferencedDate).append(website).append(eISNetsuiteCustomerIdC).append(isDeleted).append(lastModifiedDate)/*.append(billingAddress)*/.append(attributes).append(photoUrl).append(shippingCity).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Record) == false) {
            return false;
        }
        Record rhs = ((Record) other);
        return new EqualsBuilder().append(isCustomerPortal, rhs.isCustomerPortal).append(phone, rhs.phone).append(jigsaw, rhs.jigsaw).append(billingGeocodeAccuracy, rhs.billingGeocodeAccuracy).append(type, rhs.type).append(shippingLatitude, rhs.shippingLatitude).append(shippingState, rhs.shippingState).append(description, rhs.description).append(systemModstamp, rhs.systemModstamp).append(lastModifiedById, rhs.lastModifiedById).append(industry, rhs.industry).append(shippingLongitude, rhs.shippingLongitude).append(createdDate, rhs.createdDate).append(lastViewedDate, rhs.lastViewedDate).append(eISCASCustomerLevelC, rhs.eISCASCustomerLevelC).append(billingLongitude, rhs.billingLongitude).append(fax, rhs.fax).append(masterRecordId, rhs.masterRecordId).append(shippingGeocodeAccuracy, rhs.shippingGeocodeAccuracy).append(lastActivityDate, rhs.lastActivityDate).append(shippingPostalCode, rhs.shippingPostalCode).append(eISMarketC, rhs.eISMarketC).append(eISSegmentC, rhs.eISSegmentC).append(shippingStreet, rhs.shippingStreet).append(additionalProperties, rhs.additionalProperties).append(jigsawCompanyId, rhs.jigsawCompanyId).append(sicDesc, rhs.sicDesc).append(shippingCountry, rhs.shippingCountry).append(eISCustomerSatisfactionC, rhs.eISCustomerSatisfactionC).append(createdById, rhs.createdById).append(ownerId, rhs.ownerId).append(billingLatitude, rhs.billingLatitude).append(billingState, rhs.billingState).append(accountSource, rhs.accountSource).append(billingStreet, rhs.billingStreet).append(optInToParentVisibilityC, rhs.optInToParentVisibilityC).append(id, rhs.id).append(billingPostalCode, rhs.billingPostalCode).append(eISNetsuiteRecordIdC, rhs.eISNetsuiteRecordIdC).append(name, rhs.name).append(numberOfEmployees, rhs.numberOfEmployees).append(billingCity, rhs.billingCity).append(billingCountry, rhs.billingCountry).append(shippingAddress, rhs.shippingAddress).append(lastReferencedDate, rhs.lastReferencedDate).append(website, rhs.website).append(eISNetsuiteCustomerIdC, rhs.eISNetsuiteCustomerIdC).append(isDeleted, rhs.isDeleted).append(lastModifiedDate, rhs.lastModifiedDate)/*.append(billingAddress, rhs.billingAddress)*/.append(attributes, rhs.attributes).append(photoUrl, rhs.photoUrl).append(shippingCity, rhs.shippingCity).isEquals();
    }
}
