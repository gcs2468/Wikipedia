package com.ebsco.api.model.utility.comparison;

public class Country extends com.netsuite.suitetalk.proxy.v2017_2.platform.common.types.Country {
    public Country(String value) {
        super( value );
    }
}
