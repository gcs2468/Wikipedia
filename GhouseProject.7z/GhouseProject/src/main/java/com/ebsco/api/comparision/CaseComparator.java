package com.ebsco.api.comparision;

import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import com.ebsco.api.netsuite.services.pojo.CaseCustomVal;
import com.ebsco.api.salesforce.pojo.Case;
import com.ebsco.api.utilities.CaseStatusMapper;
import com.ebsco.common.utility.CommonUtils;

import java.util.HashMap;
import java.util.Map;

import static com.ebsco.common.constants.Constants.SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss;


public class CaseComparator extends AbstractRecordComparator<CaseCustomVal, Case> {
    @Override
    public void applyMappings() {
try{
        map.put( new FieldName( "NetSuite Internal Id", "Netsuite Record Id" ),
                new FieldValue( netSuiteRecord.getInternalId(), salesForceRecord.getEISNetsuiteRecordIdC() ) );

        map.put( new FieldName( "Case Number", "Netsuite Case Number" ),
                new FieldValue( netSuiteRecord.getCaseNumber(), salesForceRecord.getEISNetsuiteCaseNumberC() ) );

        map.put( new FieldName( "Subject", "Subject" ),
                new FieldValue( netSuiteRecord.getTitle(), salesForceRecord.getSubject() ) );

        map.put( new FieldName( "Product/Interface", "Product/Interface" ),
                new FieldValue( netSuiteRecord.getProductInterface(), salesForceRecord.getEISProductInterfaceC() ) );

        map.put( new FieldName( "Area of Support", "Area of Support" ),
                new FieldValue( netSuiteRecord.getAreOfSupport(), salesForceRecord.getEISAreaOfSupportC() ) );

        map.put( new FieldName( "Category", "Category" ),
                new FieldValue( netSuiteRecord.getCaseCategory(), salesForceRecord.getEISCategoryC() ) );


        map.put( new FieldName( "Institution", "Institution" ),
                new FieldValue( netSuiteRecord.getInstitution(), salesForceRecord.getAccountId() ) );

        map.put( new FieldName( "Contact", "Contact" ),
                new FieldValue( netSuiteRecord.getCaseContact(), salesForceRecord.getContactId() ) );

//        map.put(new FieldName("Contact","Original Contact"),
//                new FieldValue(netSuiteRecord.getCustomFieldList().getCustomField( 7 ), salesForceRecord.getContactId()));

        map.put( new FieldName( "Assigned To", "NetCRM Assigned To" ),
                new FieldValue( netSuiteRecord.getAssignedTo(), salesForceRecord.getEISNetCRMAssignedToC() ) );

        map.put( new FieldName( "SF Case Id", "Salesforce Record Id" ),
                new FieldValue( netSuiteRecord.getExternalId(), salesForceRecord.getId() ) );

    map.put( new FieldName( "Created Date", "Original Created Date" ),
            new FieldValue( netSuiteRecord.getCaseCreatedDate(), salesForceRecord.getEISOriginalCreatedDateC().replace( ".000+0000", "" ).replaceAll( "T", " " ) ,CommonUtils.convertSFTimeToNSTime( salesForceRecord.getEISOriginalCreatedDateC().replace( ".000+0000", "" ).replaceAll( "T", " " ),SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss,4,30 ),true) );

    map.put( new FieldName( "Last Modified Date", "Original Last Modified Date" ),
            new FieldValue( netSuiteRecord.getCaseLastModifiedDate(), salesForceRecord.getEISOriginalLastModifiedDateC().replace( ".000+0000", "" ).replaceAll( "T", " " ) ,CommonUtils.convertSFTimeToNSTime( salesForceRecord.getEISOriginalLastModifiedDateC().replace( ".000+0000", "" ).replaceAll( "T", " " ),SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss,4,30 ),true) );

       /* map.put(new FieldName("Last Message Date","Original Last Messaged Date"),
                new FieldValue(netSuiteRecord.getCustomFieldList().getCustomField( 10 ), salesForceRecord.getEISOriginalLastMessagedDateC()));
*/
    map.put( new FieldName( "Closed Date", "Original Closed Date" ),
            new FieldValue( netSuiteRecord.getCaseClosedDate(), salesForceRecord.getEISOriginalClosedDateC()));

    map.put( new FieldName( "Status", "Status" ),
            new FieldValue(  netSuiteRecord.getCaseStatus() , salesForceRecord.getStatus()));
//        map.put(new FieldName("Origin","Salesforce Record Id"),
//                new FieldValue(netSuiteRecord.getExternalId(), salesForceRecord.getId()));
}catch(Exception e){
    e.printStackTrace();
}

    }

    private String getStatus(String netSuiteStatus) {
        Map<String, String> status = new HashMap<>();
        if (netSuiteStatus.equalsIgnoreCase( "Open" ) || netSuiteStatus.equalsIgnoreCase( "In Progress" ) || netSuiteStatus.equalsIgnoreCase( "Awaiting Reply" ) || netSuiteStatus.equalsIgnoreCase( "Re-Opened" ) || netSuiteStatus.equalsIgnoreCase( "Not Started" )) {
            status.put( netSuiteStatus, "New" );
        }
        return status.get( netSuiteStatus );

    }
}
