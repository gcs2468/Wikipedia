package com.ebsco.api.model.utility.comparison;

@FunctionalInterface
public interface Description {
    public String getDesc();
}
