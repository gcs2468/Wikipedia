package com.ebsco.api.salesforce.services;

import com.ebsco.api.salesforce.pojo.AccountAll;
import com.ebsco.api.salesforce.pojo.Record;
import com.ebsco.common.utility.AppProperties;
import com.ebsco.api.utilities.BaseURI;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import java.util.Map;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.PropertyNames.ACCOUNT_QUERY_FILE;


/**
 * A thread-safe class which retrieves all records from salesforce end.
 * For any number of threads the retrieval occurs only once.
 * The same set of salesforce records are used by threads for access.
 */
public class AccountsAll {

    private static Map<String, Record> records;

    public static Map<String, Record> retrieveAccounts() {
        String loginURL = BaseURI.get() + "/query/?q=" + AppProperties.getValueFor(ACCOUNT_QUERY_FILE);
        RequestSpecification request = RestAssured.given().auth().oauth2(BaseURI.getAccessToken());
        Response response = request.get(loginURL);
        ResponseBody body = response.getBody();
        AccountAll responseAccount = body.as(AccountAll.class);
        records = responseAccount.getRecords().stream().collect(Collectors.toMap(Record::getId, record -> record));
        System.out.println("size:::"+ responseAccount.getRecords().size() );
        System.exit( 0 );
        return records;
    }

    public static Map<String, Record> queryAccount() {
        synchronized (AccountsAll.class) {
            if (records == null) {
                records = retrieveAccounts();
            }
        }
        return records;
    }

}
