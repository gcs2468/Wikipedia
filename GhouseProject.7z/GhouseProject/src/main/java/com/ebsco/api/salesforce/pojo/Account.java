
package com.ebsco.api.salesforce.pojo;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

public class Account {

    @JsonProperty("AccountNumber")
    private String accountNumber;
    @JsonProperty("Active__c")
    private String activeC;
    @JsonProperty("AnnualRevenue")
    private Double annualRevenue;
    @JsonProperty("BillingCity")
    private String billingCity;
    @JsonProperty("BillingCountry")
    private Object billingCountry;
    @JsonProperty("BillingPostalCode")
    private Object billingPostalCode;
    @JsonProperty("BillingState")
    private String billingState;
    @JsonProperty("BillingStreet")
    private String billingStreet;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("CustomerPriority__c")
    private String customerPriorityC;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("Fax")
    private String fax;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("Industry")
    private String industry;
    @JsonProperty("IsCustomerPortal")
    private Boolean isCustomerPortal;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("IsPartner")
    private Boolean isPartner;
    @JsonProperty("LastActivityDate")
    private String lastActivityDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("MasterRecordId")
    private Object masterRecordId;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("NumberOfEmployees")
    private Integer numberOfEmployees;
    @JsonProperty("NumberofLocations__c")
    private Integer numberofLocationsC;
    @JsonProperty("OwnerId")
    private String ownerId;
    @JsonProperty("Ownership")
    private String ownership;
    @JsonProperty("ParentId")
    private Object parentId;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("Rating")
    private String rating;
    @JsonProperty("SLAExpirationDate__c")
    private String sLAExpirationDateC;
    @JsonProperty("SLASerialNumber__c")
    private String sLASerialNumberC;
    @JsonProperty("SLA__c")
    private String sLAC;
    @JsonProperty("ShippingCity")
    private Object shippingCity;
    @JsonProperty("ShippingCountry")
    private Object shippingCountry;
    @JsonProperty("ShippingPostalCode")
    private Object shippingPostalCode;
    @JsonProperty("ShippingState")
    private Object shippingState;
    @JsonProperty("ShippingStreet")
    private String shippingStreet;
    @JsonProperty("Sic")
    private String sic;
    @JsonProperty("Site")
    private Object site;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("TickerSymbol")
    private String tickerSymbol;
    @JsonProperty("Type")
    private String type;
    @JsonProperty("UpsellOpportunity__c")
    private String upsellOpportunityC;
    @JsonProperty("Website")
    private String website;
    @JsonProperty("attributes")
    private Attributes attributes;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     *
     */
    public Account() {
    }

    /**
     *
     * @param isCustomerPortal
     * @param phone
     * @param createdById
     * @param ownerId
     * @param type
     * @param customerPriorityC
     * @param billingState
     * @param billingStreet
     * @param id
     * @param parentId
     * @param accountNumber
     * @param shippingState
     * @param sLAExpirationDateC
     * @param billingPostalCode
     * @param description
     * @param systemModstamp
     * @param lastModifiedById
     * @param name
     * @param billingCity
     * @param numberOfEmployees
     * @param billingCountry
     * @param industry
     * @param createdDate
     * @param site
     * @param sic
     * @param numberofLocationsC
     * @param fax
     * @param sLAC
     * @param masterRecordId
     * @param website
     * @param isPartner
     * @param lastActivityDate
     * @param shippingPostalCode
     * @param isDeleted
     * @param shippingStreet
     * @param tickerSymbol
     * @param ownership
     * @param annualRevenue
     * @param sLASerialNumberC
     * @param lastModifiedDate
     * @param upsellOpportunityC
     * @param attributes
     * @param shippingCountry
     * @param rating
     * @param shippingCity
     * @param activeC
     */
    public Account(String accountNumber, String activeC, Double annualRevenue, String billingCity, Object billingCountry, Object billingPostalCode, String billingState, String billingStreet, String createdById, String createdDate, String customerPriorityC, String description, String fax, String id, String industry, Boolean isCustomerPortal, Boolean isDeleted, Boolean isPartner, String lastActivityDate, String lastModifiedById, String lastModifiedDate, Object masterRecordId, String name, Integer numberOfEmployees, Integer numberofLocationsC, String ownerId, String ownership, Object parentId, String phone, String rating, String sLAExpirationDateC, String sLASerialNumberC, String sLAC, Object shippingCity, Object shippingCountry, Object shippingPostalCode, Object shippingState, String shippingStreet, String sic, Object site, String systemModstamp, String tickerSymbol, String type, String upsellOpportunityC, String website, Attributes attributes) {
        super();
        this.accountNumber = accountNumber;
        this.activeC = activeC;
        this.annualRevenue = annualRevenue;
        this.billingCity = billingCity;
        this.billingCountry = billingCountry;
        this.billingPostalCode = billingPostalCode;
        this.billingState = billingState;
        this.billingStreet = billingStreet;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.customerPriorityC = customerPriorityC;
        this.description = description;
        this.fax = fax;
        this.id = id;
        this.industry = industry;
        this.isCustomerPortal = isCustomerPortal;
        this.isDeleted = isDeleted;
        this.isPartner = isPartner;
        this.lastActivityDate = lastActivityDate;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.masterRecordId = masterRecordId;
        this.name = name;
        this.numberOfEmployees = numberOfEmployees;
        this.numberofLocationsC = numberofLocationsC;
        this.ownerId = ownerId;
        this.ownership = ownership;
        this.parentId = parentId;
        this.phone = phone;
        this.rating = rating;
        this.sLAExpirationDateC = sLAExpirationDateC;
        this.sLASerialNumberC = sLASerialNumberC;
        this.sLAC = sLAC;
        this.shippingCity = shippingCity;
        this.shippingCountry = shippingCountry;
        this.shippingPostalCode = shippingPostalCode;
        this.shippingState = shippingState;
        this.shippingStreet = shippingStreet;
        this.sic = sic;
        this.site = site;
        this.systemModstamp = systemModstamp;
        this.tickerSymbol = tickerSymbol;
        this.type = type;
        this.upsellOpportunityC = upsellOpportunityC;
        this.website = website;
        this.attributes = attributes;
    }

    @JsonProperty("AccountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("AccountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    @JsonProperty("Active__c")
    public String getActiveC() {
        return activeC;
    }

    @JsonProperty("Active__c")
    public void setActiveC(String activeC) {
        this.activeC = activeC;
    }

    @JsonProperty("AnnualRevenue")
    public Double getAnnualRevenue() {
        return annualRevenue;
    }

    @JsonProperty("AnnualRevenue")
    public void setAnnualRevenue(Double annualRevenue) {
        this.annualRevenue = annualRevenue;
    }

    @JsonProperty("BillingCity")
    public String getBillingCity() {
        return billingCity;
    }

    @JsonProperty("BillingCity")
    public void setBillingCity(String billingCity) {
        this.billingCity = billingCity;
    }

    @JsonProperty("BillingCountry")
    public Object getBillingCountry() {
        return billingCountry;
    }

    @JsonProperty("BillingCountry")
    public void setBillingCountry(Object billingCountry) {
        this.billingCountry = billingCountry;
    }

    @JsonProperty("BillingPostalCode")
    public Object getBillingPostalCode() {
        return billingPostalCode;
    }

    @JsonProperty("BillingPostalCode")
    public void setBillingPostalCode(Object billingPostalCode) {
        this.billingPostalCode = billingPostalCode;
    }

    @JsonProperty("BillingState")
    public String getBillingState() {
        return billingState;
    }

    @JsonProperty("BillingState")
    public void setBillingState(String billingState) {
        this.billingState = billingState;
    }

    @JsonProperty("BillingStreet")
    public String getBillingStreet() {
        return billingStreet;
    }

    @JsonProperty("BillingStreet")
    public void setBillingStreet(String billingStreet) {
        this.billingStreet = billingStreet;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("CustomerPriority__c")
    public String getCustomerPriorityC() {
        return customerPriorityC;
    }

    @JsonProperty("CustomerPriority__c")
    public void setCustomerPriorityC(String customerPriorityC) {
        this.customerPriorityC = customerPriorityC;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("Fax")
    public String getFax() {
        return fax;
    }

    @JsonProperty("Fax")
    public void setFax(String fax) {
        this.fax = fax;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("Industry")
    public String getIndustry() {
        return industry;
    }

    @JsonProperty("Industry")
    public void setIndustry(String industry) {
        this.industry = industry;
    }

    @JsonProperty("IsCustomerPortal")
    public Boolean getIsCustomerPortal() {
        return isCustomerPortal;
    }

    @JsonProperty("IsCustomerPortal")
    public void setIsCustomerPortal(Boolean isCustomerPortal) {
        this.isCustomerPortal = isCustomerPortal;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("IsPartner")
    public Boolean getIsPartner() {
        return isPartner;
    }

    @JsonProperty("IsPartner")
    public void setIsPartner(Boolean isPartner) {
        this.isPartner = isPartner;
    }

    @JsonProperty("LastActivityDate")
    public String getLastActivityDate() {
        return lastActivityDate;
    }

    @JsonProperty("LastActivityDate")
    public void setLastActivityDate(String lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("MasterRecordId")
    public Object getMasterRecordId() {
        return masterRecordId;
    }

    @JsonProperty("MasterRecordId")
    public void setMasterRecordId(Object masterRecordId) {
        this.masterRecordId = masterRecordId;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("NumberOfEmployees")
    public Integer getNumberOfEmployees() {
        return numberOfEmployees;
    }

    @JsonProperty("NumberOfEmployees")
    public void setNumberOfEmployees(Integer numberOfEmployees) {
        this.numberOfEmployees = numberOfEmployees;
    }

    @JsonProperty("NumberofLocations__c")
    public Integer getNumberofLocationsC() {
        return numberofLocationsC;
    }

    @JsonProperty("NumberofLocations__c")
    public void setNumberofLocationsC(Integer numberofLocationsC) {
        this.numberofLocationsC = numberofLocationsC;
    }

    @JsonProperty("OwnerId")
    public String getOwnerId() {
        return ownerId;
    }

    @JsonProperty("OwnerId")
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @JsonProperty("Ownership")
    public String getOwnership() {
        return ownership;
    }

    @JsonProperty("Ownership")
    public void setOwnership(String ownership) {
        this.ownership = ownership;
    }

    @JsonProperty("ParentId")
    public Object getParentId() {
        return parentId;
    }

    @JsonProperty("ParentId")
    public void setParentId(Object parentId) {
        this.parentId = parentId;
    }

    @JsonProperty("Phone")
    public String getPhone() {
        return phone;
    }

    @JsonProperty("Phone")
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JsonProperty("Rating")
    public String getRating() {
        return rating;
    }

    @JsonProperty("Rating")
    public void setRating(String rating) {
        this.rating = rating;
    }

    @JsonProperty("SLAExpirationDate__c")
    public String getSLAExpirationDateC() {
        return sLAExpirationDateC;
    }

    @JsonProperty("SLAExpirationDate__c")
    public void setSLAExpirationDateC(String sLAExpirationDateC) {
        this.sLAExpirationDateC = sLAExpirationDateC;
    }

    @JsonProperty("SLASerialNumber__c")
    public String getSLASerialNumberC() {
        return sLASerialNumberC;
    }

    @JsonProperty("SLASerialNumber__c")
    public void setSLASerialNumberC(String sLASerialNumberC) {
        this.sLASerialNumberC = sLASerialNumberC;
    }

    @JsonProperty("SLA__c")
    public String getSLAC() {
        return sLAC;
    }

    @JsonProperty("SLA__c")
    public void setSLAC(String sLAC) {
        this.sLAC = sLAC;
    }

    @JsonProperty("ShippingCity")
    public Object getShippingCity() {
        return shippingCity;
    }

    @JsonProperty("ShippingCity")
    public void setShippingCity(Object shippingCity) {
        this.shippingCity = shippingCity;
    }

    @JsonProperty("ShippingCountry")
    public Object getShippingCountry() {
        return shippingCountry;
    }

    @JsonProperty("ShippingCountry")
    public void setShippingCountry(Object shippingCountry) {
        this.shippingCountry = shippingCountry;
    }

    @JsonProperty("ShippingPostalCode")
    public Object getShippingPostalCode() {
        return shippingPostalCode;
    }

    @JsonProperty("ShippingPostalCode")
    public void setShippingPostalCode(Object shippingPostalCode) {
        this.shippingPostalCode = shippingPostalCode;
    }

    @JsonProperty("ShippingState")
    public Object getShippingState() {
        return shippingState;
    }

    @JsonProperty("ShippingState")
    public void setShippingState(Object shippingState) {
        this.shippingState = shippingState;
    }

    @JsonProperty("ShippingStreet")
    public String getShippingStreet() {
        return shippingStreet;
    }

    @JsonProperty("ShippingStreet")
    public void setShippingStreet(String shippingStreet) {
        this.shippingStreet = shippingStreet;
    }

    @JsonProperty("Sic")
    public String getSic() {
        return sic;
    }

    @JsonProperty("Sic")
    public void setSic(String sic) {
        this.sic = sic;
    }

    @JsonProperty("Site")
    public Object getSite() {
        return site;
    }

    @JsonProperty("Site")
    public void setSite(Object site) {
        this.site = site;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("TickerSymbol")
    public String getTickerSymbol() {
        return tickerSymbol;
    }

    @JsonProperty("TickerSymbol")
    public void setTickerSymbol(String tickerSymbol) {
        this.tickerSymbol = tickerSymbol;
    }

    @JsonProperty("Type")
    public String getType() {
        return type;
    }

    @JsonProperty("Type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("UpsellOpportunity__c")
    public String getUpsellOpportunityC() {
        return upsellOpportunityC;
    }

    @JsonProperty("UpsellOpportunity__c")
    public void setUpsellOpportunityC(String upsellOpportunityC) {
        this.upsellOpportunityC = upsellOpportunityC;
    }

    @JsonProperty("Website")
    public String getWebsite() {
        return website;
    }

    @JsonProperty("Website")
    public void setWebsite(String website) {
        this.website = website;
    }

    @JsonProperty("attributes")
    public Attributes getAttributes() {
        return attributes;
    }

    @JsonProperty("attributes")
    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("accountNumber", accountNumber).append("activeC", activeC).append("annualRevenue", annualRevenue).append("billingCity", billingCity).append("billingCountry", billingCountry).append("billingPostalCode", billingPostalCode).append("billingState", billingState).append("billingStreet", billingStreet).append("createdById", createdById).append("createdDate", createdDate).append("customerPriorityC", customerPriorityC).append("description", description).append("fax", fax).append("id", id).append("industry", industry).append("isCustomerPortal", isCustomerPortal).append("isDeleted", isDeleted).append("isPartner", isPartner).append("lastActivityDate", lastActivityDate).append("lastModifiedById", lastModifiedById).append("lastModifiedDate", lastModifiedDate).append("masterRecordId", masterRecordId).append("name", name).append("numberOfEmployees", numberOfEmployees).append("numberofLocationsC", numberofLocationsC).append("ownerId", ownerId).append("ownership", ownership).append("parentId", parentId).append("phone", phone).append("rating", rating).append("sLAExpirationDateC", sLAExpirationDateC).append("sLASerialNumberC", sLASerialNumberC).append("sLAC", sLAC).append("shippingCity", shippingCity).append("shippingCountry", shippingCountry).append("shippingPostalCode", shippingPostalCode).append("shippingState", shippingState).append("shippingStreet", shippingStreet).append("sic", sic).append("site", site).append("systemModstamp", systemModstamp).append("tickerSymbol", tickerSymbol).append("type", type).append("upsellOpportunityC", upsellOpportunityC).append("website", website).append("attributes", attributes).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(isCustomerPortal).append(phone).append(createdById).append(ownerId).append(type).append(customerPriorityC).append(billingState).append(billingStreet).append(id).append(parentId).append(accountNumber).append(shippingState).append(sLAExpirationDateC).append(billingPostalCode).append(description).append(systemModstamp).append(name).append(lastModifiedById).append(numberOfEmployees).append(billingCity).append(industry).append(billingCountry).append(createdDate).append(site).append(sic).append(numberofLocationsC).append(fax).append(sLAC).append(masterRecordId).append(website).append(isPartner).append(lastActivityDate).append(shippingPostalCode).append(isDeleted).append(shippingStreet).append(tickerSymbol).append(ownership).append(annualRevenue).append(additionalProperties).append(sLASerialNumberC).append(lastModifiedDate).append(upsellOpportunityC).append(attributes).append(shippingCountry).append(rating).append(shippingCity).append(activeC).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Account) == false) {
            return false;
        }
        Account rhs = ((Account) other);
        return new EqualsBuilder().append(isCustomerPortal, rhs.isCustomerPortal).append(phone, rhs.phone).append(createdById, rhs.createdById).append(ownerId, rhs.ownerId).append(type, rhs.type).append(customerPriorityC, rhs.customerPriorityC).append(billingState, rhs.billingState).append(billingStreet, rhs.billingStreet).append(id, rhs.id).append(parentId, rhs.parentId).append(accountNumber, rhs.accountNumber).append(shippingState, rhs.shippingState).append(sLAExpirationDateC, rhs.sLAExpirationDateC).append(billingPostalCode, rhs.billingPostalCode).append(description, rhs.description).append(systemModstamp, rhs.systemModstamp).append(name, rhs.name).append(lastModifiedById, rhs.lastModifiedById).append(numberOfEmployees, rhs.numberOfEmployees).append(billingCity, rhs.billingCity).append(industry, rhs.industry).append(billingCountry, rhs.billingCountry).append(createdDate, rhs.createdDate).append(site, rhs.site).append(sic, rhs.sic).append(numberofLocationsC, rhs.numberofLocationsC).append(fax, rhs.fax).append(sLAC, rhs.sLAC).append(masterRecordId, rhs.masterRecordId).append(website, rhs.website).append(isPartner, rhs.isPartner).append(lastActivityDate, rhs.lastActivityDate).append(shippingPostalCode, rhs.shippingPostalCode).append(isDeleted, rhs.isDeleted).append(shippingStreet, rhs.shippingStreet).append(tickerSymbol, rhs.tickerSymbol).append(ownership, rhs.ownership).append(annualRevenue, rhs.annualRevenue).append(additionalProperties, rhs.additionalProperties).append(sLASerialNumberC, rhs.sLASerialNumberC).append(lastModifiedDate, rhs.lastModifiedDate).append(upsellOpportunityC, rhs.upsellOpportunityC).append(attributes, rhs.attributes).append(shippingCountry, rhs.shippingCountry).append(rating, rhs.rating).append(shippingCity, rhs.shippingCity).append(activeC, rhs.activeC).isEquals();
    }

}
