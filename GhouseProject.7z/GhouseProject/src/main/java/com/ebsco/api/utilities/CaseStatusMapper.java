package com.ebsco.api.utilities;

import java.util.LinkedHashMap;
import java.util.Map;

public class CaseStatusMapper {
    private static Map<String, String> caseStatus = new LinkedHashMap<>();
    static {
        caseStatus.put("Not Started", "New");
        caseStatus.put("Awaiting Reply", "Awaiting Reply");
        caseStatus.put("In Progress", "Working");
        caseStatus.put("New", "Working");
        caseStatus.put("On Hold", "Working");
        caseStatus.put("Escalated", "Working");
        caseStatus.put("To Review", "Working");
        caseStatus.put("Re-Opened", "Re-Opened");

    }

    public static String getStatuMappedToSF(String status) {
        return caseStatus.get(status);
    }

    public static Map<String, String> getMap() {
        return caseStatus;
    }
}
