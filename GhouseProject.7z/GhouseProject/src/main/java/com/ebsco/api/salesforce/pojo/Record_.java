
package com.ebsco.api.salesforce.pojo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "attributes",
    "Id"
})
public class Record_ {

    @JsonProperty("attributes")
    private Attributes_ attributes;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public String getEIS_Netsuite_Record_Id__c() {
        return EIS_Netsuite_Record_Id__c;
    }
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public void setEIS_Netsuite_Record_Id__c(String EIS_Netsuite_Record_Id__c) {
        this.EIS_Netsuite_Record_Id__c = EIS_Netsuite_Record_Id__c;
    }
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    private String EIS_Netsuite_Record_Id__c;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("attributes")
    public Attributes_ getAttributes() {
        return attributes;
    }

    @JsonProperty("attributes")
    public void setAttributes(Attributes_ attributes) {
        this.attributes = attributes;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
