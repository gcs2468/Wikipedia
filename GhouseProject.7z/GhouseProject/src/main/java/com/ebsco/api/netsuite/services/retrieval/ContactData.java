package com.ebsco.api.netsuite.services.retrieval;

import com.ebsco.api.netsuite.services.connection.NetSuiteConnection;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.ContactCustomVal;
import com.ebsco.common.utility.AppProperties;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.PropertyNames.CONTACTS_RETRIEVE_SQL_PROPERTY;


public class ContactData extends AbstractRecord<ContactCustomVal> {

    @Override
    public Map<String, ContactCustomVal> get(List<String> idList, NetSuiteConnectionPool pool) throws Exception {
        NetSuiteConnection connection = new NetSuiteConnectionPool( 1 ).acquire()/*pool.acquire()*/;
        Statement statement = connection.getStatement();
        String sql = AppProperties.getValueFor( CONTACTS_RETRIEVE_SQL_PROPERTY );
        sql += listToString( idList );
        Map<String, ContactCustomVal> contactMap = new HashMap<>();
        try (ResultSet resultSet = statement.executeQuery( sql )) {
            while (resultSet.next()) {
                ContactCustomVal contact = new ContactCustomVal();
                //SELECT CONTACT_ID,  CUSTOMERS.COMPANYNAME,  FIRSTNAME, MIDDLENAME,  LASTNAME,  EMAIL,  PHONE,  TITLE, SF_CONTACT_ID ,
                // JOB_ROLES.LIST_ITEM_NAME ,CONTACT_ORIGIN.LIST_ITEM_NAME,BUSINESS_INTEREST_TYPE.LIST_ITEM_NAME
                contact.setInternalId( resultSet.getString( "CONTACT_ID" ).replaceAll( ".0", "" ) );
                contact.setCompanyName( resultSet.getString( "COMPANYNAME" ) );
                contact.setFirstName( resultSet.getString( "FIRSTNAME" ) );
                contact.setMiddleName( resultSet.getString( "MIDDLENAME" ) );
                contact.setLastName( resultSet.getString( "LASTNAME" ) );
                contact.setEmail( resultSet.getString( "EMAIL" ) );
                contact.setPhone( resultSet.getString( "PHONE" ) );
                contact.setTitle( resultSet.getString( "TITLE" ) );
                contact.setExternalId( resultSet.getString( "SF_CONTACT_ID" ) );
                contact.setJobRole( resultSet.getString( "LIST_ITEM_NAME" ) );
                contact.setContactOrigin( resultSet.getString( "LIST_ITEM_NAME" ) );
                contact.setLegitimateBusinessInterest( resultSet.getString( "LIST_ITEM_NAME" ) );
                contact.setInactive( resultSet.getString( "ISINACTIVE" ) );
                contact.setOptInToParentVisibility( resultSet.getString( "CXP_OPT_IN_TO_PARENT_VISIBILI" ) );
                contactMap.put( contact.getInternalId(), contact );
            }
        }
//        pool.free(connection);
        return contactMap;
    }

}
