package com.ebsco.api.netsuite.services.retrieval;

import com.ebsco.api.netsuite.services.connection.NetSuiteConnection;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.CaseCustomVal;
import com.ebsco.common.utility.AppProperties;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.PropertyNames.CASE_RETRIEVE_SQL_PROPERTY;

public class CaseData extends AbstractRecord<CaseCustomVal> {

    @Override
    public synchronized Map<String, CaseCustomVal> get(List<String> idList, NetSuiteConnectionPool pool) throws Exception {
        NetSuiteConnectionPool nsConnectionPool = new NetSuiteConnectionPool( 1 );
        NetSuiteConnection connection = nsConnectionPool.acquire();
        Statement statement = connection.getStatement();
        String sql = AppProperties.getValueFor( CASE_RETRIEVE_SQL_PROPERTY );
        sql += listToString( idList );
        Map<String, CaseCustomVal> caseMap = new HashMap<>();
        try (ResultSet resultSet = statement.executeQuery( sql )) {
            while (resultSet.next()) {
                CaseCustomVal caseCustomVal = new CaseCustomVal();
                caseCustomVal.setInternalId( String.valueOf( new Double( resultSet.getDouble( "case_id" ) ).longValue() ) );
                caseCustomVal.setCaseNumber( resultSet.getString( "case_number" ).replaceAll( ".0", "" ) );
                caseCustomVal.setTitle( resultSet.getString( "title" ) );
                caseCustomVal.setProductInterface( resultSet.getString( "DDE_PRODUCTINTERFACE_NAME" ) );
                caseCustomVal.setAreOfSupport( resultSet.getString( "DDE_AREA_OF_SUPPORT_NAME" ) );
                caseCustomVal.setCaseCategory( resultSet.getString( "category" ) );
                caseCustomVal.setCaseStatus( resultSet.getString( "status" ) );
                caseCustomVal.setInstitution( resultSet.getString( "company" ) );
                caseCustomVal.setCaseContact( resultSet.getString( "contact" ) );
                caseCustomVal.setCaseCreatedDate( resultSet.getString( "create_date" ) );
                caseCustomVal.setCaseLastModifiedDate( resultSet.getString( "date_last_modified" ) );
                caseCustomVal.setCaseClosedDate( resultSet.getString( "date_closed" ) );
                caseCustomVal.setAssignedTo( resultSet.getString( "NAME" ) );
                caseCustomVal.setExternalId( resultSet.getString( "sf_case_id" ) );
//                caseCustomVal.setCaseOrigin(resultSet.getString(15));
//                caseCustomVal.setSupportCase( supportCase );
                caseMap.put( caseCustomVal.getInternalId(), caseCustomVal );
            }
        }

        pool.free( connection );
        return caseMap;
    }
}
