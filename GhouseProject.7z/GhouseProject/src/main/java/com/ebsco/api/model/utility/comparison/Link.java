package com.ebsco.api.model.utility.comparison;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import static java.net.HttpURLConnection.HTTP_BAD_REQUEST;

public class Link {

    private final String link;

    public Link(String link) {
        this.link = link;
    }

    public boolean isValid() {
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL( link ).openConnection();
            connection.connect();
            int actualResponseCode = connection.getResponseCode();
            return actualResponseCode < HTTP_BAD_REQUEST;
        } catch (IOException e) {
            return false;
        }
    }
}
