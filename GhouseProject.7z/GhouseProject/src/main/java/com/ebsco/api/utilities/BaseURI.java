package com.ebsco.api.utilities;

import com.ebsco.web.appconfig.ConfigFileReader;
import com.ebsco.web.managers.FileReaderManager;
import io.restassured.path.json.JsonPath;


import static com.ebsco.common.constants.Constants.*;
import static io.restassured.RestAssured.given;

public class BaseURI {

    private static String baseUri;
    private static String instanceUrl;
    private static String accessToken;

    private static void init() {
        ConfigFileReader cfr = FileReaderManager.getInstance().getConfigReader();
        String loginURL = cfr.getCxpURL() +
                GRANTSERVICE + "&access_token=offline" + "&client_id=" + CLIENTID + "&client_secret=" + CLIENTSECRET + "&username=" + cfr.getCxpUsername() + "&password=" + cfr.getCxpPassword();
        String response = given().post(loginURL).asString();
        JsonPath jsonPath = new JsonPath(response);
        accessToken = jsonPath.get("access_token");
        instanceUrl = jsonPath.getString("instance_url");
    }


    public static String get() {
        if (baseUri == null) {
            init();
            baseUri = instanceUrl + REST_ENDPOINT + API_VERSION;
        }
        return baseUri;
    }

    public static String getAccessToken() {
        if (accessToken == null) {
            init();
        }
        return accessToken;
    }

    public static String getInstanceUrl() {
        return instanceUrl;
    }
}