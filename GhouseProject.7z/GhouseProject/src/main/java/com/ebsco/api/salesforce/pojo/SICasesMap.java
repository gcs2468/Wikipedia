
package com.ebsco.api.salesforce.pojo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "attributes",
    "Id",
    "Cases__r"
})
public class SICasesMap {

    @JsonProperty("attributes")
    private Attributes attributes;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("Cases__r")
    private CasesR casesR;
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    private String eISNetsuiteRecordIdC;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("attributes")
    public Attributes getAttributes() {
        return attributes;
    }

    @JsonProperty("attributes")
    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("Cases__r")
    public CasesR getCasesR() {
        return casesR;
    }

    @JsonProperty("Cases__r")
    public void setCasesR(CasesR casesR) {
        this.casesR = casesR;
    }
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public String getEISNetsuiteRecordIdC() {
        return eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public void setEISNetsuiteRecordIdC(String eISNetsuiteRecordIdC) {
        this.eISNetsuiteRecordIdC = eISNetsuiteRecordIdC;
    }
    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
