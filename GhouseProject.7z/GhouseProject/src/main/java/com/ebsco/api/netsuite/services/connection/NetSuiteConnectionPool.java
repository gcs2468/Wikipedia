package com.ebsco.api.netsuite.services.connection;

import com.ebsco.api.model.pool.Pool;

public class NetSuiteConnectionPool extends Pool<NetSuiteConnection> {

    public NetSuiteConnectionPool(int poolSize) {
        super();
        for (int i = 0; i < poolSize; i++)
            addNew( new NetSuiteConnection() );
        initAll();
    }
}
