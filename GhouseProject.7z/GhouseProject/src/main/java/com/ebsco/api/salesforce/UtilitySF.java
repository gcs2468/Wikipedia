package com.ebsco.api.salesforce;

import com.ebsco.api.utilities.BaseURI;
import com.ebsco.common.constants.Constants;
import com.ebsco.common.utility.AppProperties;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.util.List;

public class UtilitySF {

    private static Logger logger = LogManager.getLogger( UtilitySF.class );

    public static ResponseBody getResponseBody(String queryFile) {
        String loginURL = BaseURI.get() + Constants.QUERY_STRING + AppProperties.getValueFor( queryFile );
        logger.info( loginURL );
        return makeRestCall(loginURL);
    }
    public static ResponseBody getResponseBody(String queryFile,List<String> ids) {
        String loginURL = BaseURI.get() + Constants.QUERY_STRING + AppProperties.getValueFor( queryFile )+listToString(ids);
        logger.info( loginURL );
        return makeRestCall(loginURL);
    }

    public static ResponseBody makeRestCall(String url) {
        RequestSpecification request = RestAssured.given().auth().oauth2( BaseURI.getAccessToken() );
        Response response = request.get( url );
        return response.getBody();
    }

    private static String listToString(List<String> idList) {
        StringBuilder sb = new StringBuilder("(");
        int size = idList.size();
        int i = 0;
        for (; i < size - 1; i++)
            sb.append("'" + idList.get(i).replace("\"", " ").trim() + "', ");
        sb.append("'" + idList.get(i).replace("\"", " ").trim() + "')");
        return sb.toString();
    }
}
