package com.ebsco.api.salesforce.pojo;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "attributes",
        "Attachment_Id__c",
        "Attach_To__c",
        "Author_Email__c",
        "Author__c",
        "Bcc__c",
        "Case__c",
        "Cc__c",
        "CreatedById",
        "CreatedDate",
        "DateTime__c",
        "EIS_Netsuite_Record_Id__c",
        "Emailed__c",
        "Email_Message__c",
        "Feeditem_ID__c",
        "Id",
        "Incoming__c",
        "Internal_Only__c",
        "IsDeleted",
        "LastActivityDate",
        "LastModifiedById",
        "LastModifiedDate",
        "LastReferencedDate",
        "LastViewedDate",
        "messageDate__c",
        "Name",
        "Subject__c",
        "SystemModstamp"
})
public class Message {

    @JsonProperty("attributes")
    private Attributes attributes;
    @JsonProperty("Attachment_Id__c")
    private Object attachmentIdC;
    @JsonProperty("Attach_To__c")
    private String attachToC;
    @JsonProperty("Author_Email__c")
    private Object authorEmailC;
    @JsonProperty("Author__c")
    private String authorC;
    @JsonProperty("Bcc__c")
    private Object bccC;
    @JsonProperty("Case__c")
    private String caseC;
    @JsonProperty("Cc__c")
    private Object ccC;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("DateTime__c")
    private Object dateTimeC;
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    private String eISNetsuiteRecordIdC;
    @JsonProperty("Emailed__c")
    private Boolean emailedC;
    @JsonProperty("Email_Message__c")
    private String emailMessageC;
    @JsonProperty("Feeditem_ID__c")
    private Object feeditemIDC;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("Incoming__c")
    private Boolean incomingC;
    @JsonProperty("Internal_Only__c")
    private Boolean internalOnlyC;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("LastActivityDate")
    private Object lastActivityDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("LastReferencedDate")
    private Object lastReferencedDate;
    @JsonProperty("LastViewedDate")
    private Object lastViewedDate;
    @JsonProperty("messageDate__c")
    private String messageDateC;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Subject__c")
    private Object subjectC;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     *
     */
    public Message() {
    }

    /**
     *
     * @param messageDateC
     * @param emailMessageC
     * @param internalOnlyC
     * @param authorC
     * @param createdById
     * @param subjectC
     * @param id
     * @param dateTimeC
     * @param bccC
     * @param attachmentIdC
     * @param eISNetsuiteRecordIdC
     * @param systemModstamp
     * @param name
     * @param lastModifiedById
     * @param feeditemIDC
     * @param createdDate
     * @param lastViewedDate
     * @param attachToC
     * @param lastReferencedDate
     * @param lastActivityDate
     * @param incomingC
     * @param authorEmailC
     * @param isDeleted
     * @param emailedC
     * @param caseC
     * @param ccC
     * @param lastModifiedDate
     * @param attributes
     */
    public Message(Attributes attributes, Object attachmentIdC, String attachToC, Object authorEmailC, String authorC, Object bccC, String caseC, Object ccC, String createdById, String createdDate, Object dateTimeC, String eISNetsuiteRecordIdC, Boolean emailedC, String emailMessageC, Object feeditemIDC, String id, Boolean incomingC, Boolean internalOnlyC, Boolean isDeleted, Object lastActivityDate, String lastModifiedById, String lastModifiedDate, Object lastReferencedDate, Object lastViewedDate, String messageDateC, String name, Object subjectC, String systemModstamp) {
        super();
        this.attributes = attributes;
        this.attachmentIdC = attachmentIdC;
        this.attachToC = attachToC;
        this.authorEmailC = authorEmailC;
        this.authorC = authorC;
        this.bccC = bccC;
        this.caseC = caseC;
        this.ccC = ccC;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.dateTimeC = dateTimeC;
        this.eISNetsuiteRecordIdC = eISNetsuiteRecordIdC;
        this.emailedC = emailedC;
        this.emailMessageC = emailMessageC;
        this.feeditemIDC = feeditemIDC;
        this.id = id;
        this.incomingC = incomingC;
        this.internalOnlyC = internalOnlyC;
        this.isDeleted = isDeleted;
        this.lastActivityDate = lastActivityDate;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lastReferencedDate = lastReferencedDate;
        this.lastViewedDate = lastViewedDate;
        this.messageDateC = messageDateC;
        this.name = name;
        this.subjectC = subjectC;
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("attributes")
    public Attributes getAttributes() {
        return attributes;
    }

    @JsonProperty("attributes")
    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    @JsonProperty("Attachment_Id__c")
    public Object getAttachmentIdC() {
        return attachmentIdC;
    }

    @JsonProperty("Attachment_Id__c")
    public void setAttachmentIdC(Object attachmentIdC) {
        this.attachmentIdC = attachmentIdC;
    }

    @JsonProperty("Attach_To__c")
    public String getAttachToC() {
        return attachToC;
    }

    @JsonProperty("Attach_To__c")
    public void setAttachToC(String attachToC) {
        this.attachToC = attachToC;
    }

    @JsonProperty("Author_Email__c")
    public Object getAuthorEmailC() {
        return authorEmailC;
    }

    @JsonProperty("Author_Email__c")
    public void setAuthorEmailC(Object authorEmailC) {
        this.authorEmailC = authorEmailC;
    }

    @JsonProperty("Author__c")
    public String getAuthorC() {
        return authorC;
    }

    @JsonProperty("Author__c")
    public void setAuthorC(String authorC) {
        this.authorC = authorC;
    }

    @JsonProperty("Bcc__c")
    public Object getBccC() {
        return bccC;
    }

    @JsonProperty("Bcc__c")
    public void setBccC(Object bccC) {
        this.bccC = bccC;
    }

    @JsonProperty("Case__c")
    public String getCaseC() {
        return caseC;
    }

    @JsonProperty("Case__c")
    public void setCaseC(String caseC) {
        this.caseC = caseC;
    }

    @JsonProperty("Cc__c")
    public Object getCcC() {
        return ccC;
    }

    @JsonProperty("Cc__c")
    public void setCcC(Object ccC) {
        this.ccC = ccC;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("DateTime__c")
    public Object getDateTimeC() {
        return dateTimeC;
    }

    @JsonProperty("DateTime__c")
    public void setDateTimeC(Object dateTimeC) {
        this.dateTimeC = dateTimeC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public String getEISNetsuiteRecordIdC() {
        return eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public void setEISNetsuiteRecordIdC(String eISNetsuiteRecordIdC) {
        this.eISNetsuiteRecordIdC = eISNetsuiteRecordIdC;
    }

    @JsonProperty("Emailed__c")
    public Boolean getEmailedC() {
        return emailedC;
    }

    @JsonProperty("Emailed__c")
    public void setEmailedC(Boolean emailedC) {
        this.emailedC = emailedC;
    }

    @JsonProperty("Email_Message__c")
    public String getEmailMessageC() {
        return emailMessageC;
    }

    @JsonProperty("Email_Message__c")
    public void setEmailMessageC(String emailMessageC) {
        this.emailMessageC = emailMessageC;
    }

    @JsonProperty("Feeditem_ID__c")
    public Object getFeeditemIDC() {
        return feeditemIDC;
    }

    @JsonProperty("Feeditem_ID__c")
    public void setFeeditemIDC(Object feeditemIDC) {
        this.feeditemIDC = feeditemIDC;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("Incoming__c")
    public Boolean getIncomingC() {
        return incomingC;
    }

    @JsonProperty("Incoming__c")
    public void setIncomingC(Boolean incomingC) {
        this.incomingC = incomingC;
    }

    @JsonProperty("Internal_Only__c")
    public Boolean getInternalOnlyC() {
        return internalOnlyC;
    }

    @JsonProperty("Internal_Only__c")
    public void setInternalOnlyC(Boolean internalOnlyC) {
        this.internalOnlyC = internalOnlyC;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("LastActivityDate")
    public Object getLastActivityDate() {
        return lastActivityDate;
    }

    @JsonProperty("LastActivityDate")
    public void setLastActivityDate(Object lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("LastReferencedDate")
    public Object getLastReferencedDate() {
        return lastReferencedDate;
    }

    @JsonProperty("LastReferencedDate")
    public void setLastReferencedDate(Object lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }

    @JsonProperty("LastViewedDate")
    public Object getLastViewedDate() {
        return lastViewedDate;
    }

    @JsonProperty("LastViewedDate")
    public void setLastViewedDate(Object lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }

    @JsonProperty("messageDate__c")
    public String getMessageDateC() {
        return messageDateC;
    }

    @JsonProperty("messageDate__c")
    public void setMessageDateC(String messageDateC) {
        this.messageDateC = messageDateC;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Subject__c")
    public Object getSubjectC() {
        return subjectC;
    }

    @JsonProperty("Subject__c")
    public void setSubjectC(Object subjectC) {
        this.subjectC = subjectC;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("attributes", attributes).append("attachmentIdC", attachmentIdC).append("attachToC", attachToC).append("authorEmailC", authorEmailC).append("authorC", authorC).append("bccC", bccC).append("caseC", caseC).append("ccC", ccC).append("createdById", createdById).append("createdDate", createdDate).append("dateTimeC", dateTimeC).append("eISNetsuiteRecordIdC", eISNetsuiteRecordIdC).append("emailedC", emailedC).append("emailMessageC", emailMessageC).append("feeditemIDC", feeditemIDC).append("id", id).append("incomingC", incomingC).append("internalOnlyC", internalOnlyC).append("isDeleted", isDeleted).append("lastActivityDate", lastActivityDate).append("lastModifiedById", lastModifiedById).append("lastModifiedDate", lastModifiedDate).append("lastReferencedDate", lastReferencedDate).append("lastViewedDate", lastViewedDate).append("messageDateC", messageDateC).append("name", name).append("subjectC", subjectC).append("systemModstamp", systemModstamp).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(messageDateC).append(emailMessageC).append(internalOnlyC).append(authorC).append(createdById).append(subjectC).append(id).append(dateTimeC).append(bccC).append(attachmentIdC).append(eISNetsuiteRecordIdC).append(systemModstamp).append(name).append(lastModifiedById).append(feeditemIDC).append(createdDate).append(lastViewedDate).append(lastReferencedDate).append(attachToC).append(lastActivityDate).append(incomingC).append(authorEmailC).append(isDeleted).append(emailedC).append(caseC).append(ccC).append(additionalProperties).append(lastModifiedDate).append(attributes).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Message) == false) {
            return false;
        }
        Message rhs = ((Message) other);
        return new EqualsBuilder().append(messageDateC, rhs.messageDateC).append(emailMessageC, rhs.emailMessageC).append(internalOnlyC, rhs.internalOnlyC).append(authorC, rhs.authorC).append(createdById, rhs.createdById).append(subjectC, rhs.subjectC).append(id, rhs.id).append(dateTimeC, rhs.dateTimeC).append(bccC, rhs.bccC).append(attachmentIdC, rhs.attachmentIdC).append(eISNetsuiteRecordIdC, rhs.eISNetsuiteRecordIdC).append(systemModstamp, rhs.systemModstamp).append(name, rhs.name).append(lastModifiedById, rhs.lastModifiedById).append(feeditemIDC, rhs.feeditemIDC).append(createdDate, rhs.createdDate).append(lastViewedDate, rhs.lastViewedDate).append(lastReferencedDate, rhs.lastReferencedDate).append(attachToC, rhs.attachToC).append(lastActivityDate, rhs.lastActivityDate).append(incomingC, rhs.incomingC).append(authorEmailC, rhs.authorEmailC).append(isDeleted, rhs.isDeleted).append(emailedC, rhs.emailedC).append(caseC, rhs.caseC).append(ccC, rhs.ccC).append(additionalProperties, rhs.additionalProperties).append(lastModifiedDate, rhs.lastModifiedDate).append(attributes, rhs.attributes).isEquals();
    }

}