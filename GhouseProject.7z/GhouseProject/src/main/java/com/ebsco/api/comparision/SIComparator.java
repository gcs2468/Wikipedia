package com.ebsco.api.comparision;

import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.api.salesforce.pojo.ServiceIssues;
import com.ebsco.common.utility.CommonUtils;

import java.util.HashMap;
import java.util.Map;

import static com.ebsco.common.constants.Constants.SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss;


public class SIComparator extends AbstractRecordComparator<ServiceIssue, ServiceIssues> {
    private static Map<String, String> statusMap = new HashMap<>();

    static {
        statusMap.put("Not Started", "Submitted");
        statusMap.put("PM Review", "Under Review");
        statusMap.put("Closed Unresolved", "Closed");
        statusMap.put("Assigned to Triage", "Under Review");
        statusMap.put("Deferred", "Under Review");
        statusMap.put("In Progress", "In Progress");
        statusMap.put("Information Needed", "Under Review");
        statusMap.put("Resolved", "Resolved");
        statusMap.put("Scheduled", "Scheduled");
    }


    private String transformStatus(String netSuiteStatus) {
        return statusMap.getOrDefault(netSuiteStatus, netSuiteStatus);
    }
    @Override
    public void applyMappings() {
try {
    map.put( new FieldName( "NetSuite Internal Id", "Netsuite Record Id" ),
            new FieldValue( netSuiteRecord.getNetsuiteInternalId(), salesForceRecord.getEISNetsuiteRecordIdC() ) );

    map.put( new FieldName( "Synopsis", "Synopsis" ),
            new FieldValue( netSuiteRecord.getSynopsis(), salesForceRecord.getEISSynopsisC() ) );


    map.put( new FieldName( "Product/Interface", "Product/Interface" ),
            new FieldValue( netSuiteRecord.getProduct_interface(), salesForceRecord.getEISProductInterfaceC() ) );


    map.put( new FieldName( "Status", "Status" ),
            new FieldValue( netSuiteRecord.getStatus(), salesForceRecord.getEISStatusC(), transformStatus( netSuiteRecord.getStatus() ) ) );

    map.put( new FieldName( "Issue Experienced ", "Issue Experienced " ),
            new FieldValue( netSuiteRecord.getIssueExperience(), salesForceRecord.getEISIssueExperiencedC() ) );

    map.put( new FieldName( "Resolution", "Resolution" ),
            new FieldValue( netSuiteRecord.getResolution(), salesForceRecord.getEISResolutionC() ) );

    map.put( new FieldName( "Date Created", "Original Date Created" ),
            new FieldValue( netSuiteRecord.getDateCreated(), salesForceRecord.getEISOriginalDateCreatedC().replace( ".000+0000", "" ).replaceAll( "T", " " ), CommonUtils.convertSFTimeToNSTime( salesForceRecord.getEISOriginalDateCreatedC().replaceAll( "T", " " ), SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss, 4, 30 ), true ) );
    map.put( new FieldName( "Last Modified Date", "Original Last Modified" ),
            new FieldValue( netSuiteRecord.getLastmodified(), salesForceRecord.getEISOriginalLastModifiedC().replace( ".000+0000", "" ).replaceAll( "T", " " ) ,CommonUtils.convertSFTimeToNSTime( salesForceRecord.getEISOriginalLastModifiedC().replaceAll( "T", " " ), SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss, 4, 30 ), true ) );

    map.put( new FieldName( "SI Date Closed", "SI Date Closed" ),
            new FieldValue( netSuiteRecord.getSiDateClosed(), salesForceRecord.getEISSIDateClosedC()));


    map.put( new FieldName( "SF Case Id", "Salesforce Record Id" ),
            new FieldValue( netSuiteRecord.getSfServiceIssueId(), salesForceRecord.getId() ) );
}catch (Exception e){
    e.printStackTrace();
}

    }

  /*  private String getStatus(String netSuiteStatus){
        Map<String,String> status = new HashMap<>(  );
        if(netSuiteStatus.equalsIgnoreCase( "Open" )||netSuiteStatus.equalsIgnoreCase( "In Progress" )||netSuiteStatus.equalsIgnoreCase( "Awaiting Reply" )||netSuiteStatus.equalsIgnoreCase( "Re-Opened" )||netSuiteStatus.equalsIgnoreCase( "Not Started" )) {
            status.put( netSuiteStatus, "New" );}
            return status.get( netSuiteStatus );

    }*/
}
