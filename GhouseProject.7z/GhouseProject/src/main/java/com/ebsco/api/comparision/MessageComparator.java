package com.ebsco.api.comparision;

import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import com.ebsco.api.netsuite.services.pojo.MessageCustomVal;
import com.ebsco.api.salesforce.pojo.Message;


public class MessageComparator extends AbstractRecordComparator<MessageCustomVal, Message> {
    @Override
    public void applyMappings() {
//
        map.put(new FieldName("NetSuite Internal Id", "Netsuite Case Id"),
                new FieldValue(netSuiteRecord.getSfCaseId(), salesForceRecord.getCaseC()));

        map.put(new FieldName("Message", "Message"),
                new FieldValue(netSuiteRecord.getMessage(), salesForceRecord.getEmailMessageC()));

        map.put(new FieldName("Author Name", "Author Name"),
                new FieldValue(netSuiteRecord.getName(), salesForceRecord.getAuthorC()));

        map.put(new FieldName("Author Email", "Author Email"),
                new FieldValue(netSuiteRecord.getEmail(), salesForceRecord.getAuthorEmailC()));

        map.put(new FieldName("CC", "CC"),
                new FieldValue(netSuiteRecord.getCc(), salesForceRecord.getCcC()));

        map.put(new FieldName("SUBJECT", "SUBJECT"),
                new FieldValue(netSuiteRecord.getSubject(), salesForceRecord.getSubjectC()));

        map.put(new FieldName("BCC", "BCC"),
                new FieldValue(netSuiteRecord.getBCC(), salesForceRecord.getBccC()));

        map.put(new FieldName("DATE_0", "DATE_0"),
                new FieldValue(netSuiteRecord.getDATE_0(), salesForceRecord.getCreatedDate()));

        map.put(new FieldName("IS_EMAILED", "IS_EMAILED"),
                new FieldValue(netSuiteRecord.getIS_EMAILED(), salesForceRecord.getEmailedC()));

        map.put(new FieldName("IS_INCOMING", "IS_INCOMING"),
                new FieldValue(netSuiteRecord.getIS_INCOMING(), salesForceRecord.getIncomingC()));

        map.put(new FieldName("RECIPIENT_ID", "RECIPIENT_ID"),
                new FieldValue(netSuiteRecord.getRECIPIENT_ID(), salesForceRecord.getAttachToC()));


    }

}
