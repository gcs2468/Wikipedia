
package com.ebsco.api.salesforce.pojo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "attributes",
    "AccountId",
    "ContactId",
    "EIS_Area_of_Support__c",
    "EIS_Category__c",
    "EIS_NetCRM_Assigned_To__c",
    "EIS_Netsuite_Case_Number__c",
    "EIS_Netsuite_Record_Id__c",
    "EIS_Original_Closed_Date__c",
    "EIS_Original_Created_Date__c",
    "EIS_Original_Last_Messaged_Date__c",
    "EIS_Original_Last_Modified_Date__c",
    "EIS_Product_Interface__c",
    "EIS_SI_Number__c",
    "Status",
    "Subject"
})
public class Case {

    @JsonProperty("Id")
    private String id;
    @JsonProperty("attributes")
    private Attributes attributes;
    @JsonProperty("AccountId")
    private String accountId;
    @JsonProperty("ContactId")
    private String contactId;
    @JsonProperty("EIS_Area_of_Support__c")
    private String eISAreaOfSupportC;
    @JsonProperty("EIS_Category__c")
    private String eISCategoryC;
    @JsonProperty("EIS_NetCRM_Assigned_To__c")
    private String eISNetCRMAssignedToC;
    @JsonProperty("EIS_Netsuite_Case_Number__c")
    private String eISNetsuiteCaseNumberC;
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    private String eISNetsuiteRecordIdC;
    @JsonProperty("EIS_Original_Closed_Date__c")
    private Object eISOriginalClosedDateC;
    @JsonProperty("EIS_Original_Created_Date__c")
    private String eISOriginalCreatedDateC;
    @JsonProperty("EIS_Original_Last_Messaged_Date__c")
    private Object eISOriginalLastMessagedDateC;
    @JsonProperty("EIS_Original_Last_Modified_Date__c")
    private String eISOriginalLastModifiedDateC;
    @JsonProperty("EIS_Product_Interface__c")
    private String eISProductInterfaceC;
    @JsonProperty("EIS_SI_Number__c")
    private Object eISSINumberC;
    @JsonProperty("Status")
    private String status;
    @JsonProperty("Subject")
    private String subject;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("attributes")
    public Attributes getAttributes() {
        return attributes;
    }

    @JsonProperty("attributes")
    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    @JsonProperty("AccountId")
    public String getAccountId() {
        return accountId;
    }

    @JsonProperty("AccountId")
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    @JsonProperty("ContactId")
    public String getContactId() {
        return contactId;
    }

    @JsonProperty("ContactId")
    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    @JsonProperty("EIS_Area_of_Support__c")
    public String getEISAreaOfSupportC() {
        return eISAreaOfSupportC;
    }

    @JsonProperty("EIS_Area_of_Support__c")
    public void setEISAreaOfSupportC(String eISAreaOfSupportC) {
        this.eISAreaOfSupportC = eISAreaOfSupportC;
    }

    @JsonProperty("EIS_Category__c")
    public String getEISCategoryC() {
        return eISCategoryC;
    }

    @JsonProperty("EIS_Category__c")
    public void setEISCategoryC(String eISCategoryC) {
        this.eISCategoryC = eISCategoryC;
    }

    @JsonProperty("EIS_NetCRM_Assigned_To__c")
    public String getEISNetCRMAssignedToC() {
        return eISNetCRMAssignedToC;
    }

    @JsonProperty("EIS_NetCRM_Assigned_To__c")
    public void setEISNetCRMAssignedToC(String eISNetCRMAssignedToC) {
        this.eISNetCRMAssignedToC = eISNetCRMAssignedToC;
    }

    @JsonProperty("EIS_Netsuite_Case_Number__c")
    public String getEISNetsuiteCaseNumberC() {
        return eISNetsuiteCaseNumberC;
    }

    @JsonProperty("EIS_Netsuite_Case_Number__c")
    public void setEISNetsuiteCaseNumberC(String eISNetsuiteCaseNumberC) {
        this.eISNetsuiteCaseNumberC = eISNetsuiteCaseNumberC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public String getEISNetsuiteRecordIdC() {
        return eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public void setEISNetsuiteRecordIdC(String eISNetsuiteRecordIdC) {
        this.eISNetsuiteRecordIdC = eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Original_Closed_Date__c")
    public Object getEISOriginalClosedDateC() {
        return eISOriginalClosedDateC;
    }

    @JsonProperty("EIS_Original_Closed_Date__c")
    public void setEISOriginalClosedDateC(Object eISOriginalClosedDateC) {
        this.eISOriginalClosedDateC = eISOriginalClosedDateC;
    }

    @JsonProperty("EIS_Original_Created_Date__c")
    public String getEISOriginalCreatedDateC() {
        return eISOriginalCreatedDateC;
    }

    @JsonProperty("EIS_Original_Created_Date__c")
    public void setEISOriginalCreatedDateC(String eISOriginalCreatedDateC) {
        this.eISOriginalCreatedDateC = eISOriginalCreatedDateC;
    }

    @JsonProperty("EIS_Original_Last_Messaged_Date__c")
    public Object getEISOriginalLastMessagedDateC() {
        return eISOriginalLastMessagedDateC;
    }

    @JsonProperty("EIS_Original_Last_Messaged_Date__c")
    public void setEISOriginalLastMessagedDateC(Object eISOriginalLastMessagedDateC) {
        this.eISOriginalLastMessagedDateC = eISOriginalLastMessagedDateC;
    }

    @JsonProperty("EIS_Original_Last_Modified_Date__c")
    public String getEISOriginalLastModifiedDateC() {
        return eISOriginalLastModifiedDateC;
    }

    @JsonProperty("EIS_Original_Last_Modified_Date__c")
    public void setEISOriginalLastModifiedDateC(String eISOriginalLastModifiedDateC) {
        this.eISOriginalLastModifiedDateC = eISOriginalLastModifiedDateC;
    }

    @JsonProperty("EIS_Product_Interface__c")
    public String getEISProductInterfaceC() {
        return eISProductInterfaceC;
    }

    @JsonProperty("EIS_Product_Interface__c")
    public void setEISProductInterfaceC(String eISProductInterfaceC) {
        this.eISProductInterfaceC = eISProductInterfaceC;
    }

    @JsonProperty("EIS_SI_Number__c")
    public Object getEISSINumberC() {
        return eISSINumberC;
    }

    @JsonProperty("EIS_SI_Number__c")
    public void setEISSINumberC(Object eISSINumberC) {
        this.eISSINumberC = eISSINumberC;
    }

    @JsonProperty("Status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("Subject")
    public String getSubject() {
        return subject;
    }

    @JsonProperty("Subject")
    public void setSubject(String subject) {
        this.subject = subject;
    }
    @JsonProperty("Id")
    public String getId() {
        return id;
    }
    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }
    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }


}
