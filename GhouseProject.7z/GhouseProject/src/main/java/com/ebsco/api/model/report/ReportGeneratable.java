package com.ebsco.api.model.report;


/**
 * A class which contains sufficient data to form a report must implement this interface.
 */
@FunctionalInterface
public interface ReportGeneratable {
    ReportData getData();
}