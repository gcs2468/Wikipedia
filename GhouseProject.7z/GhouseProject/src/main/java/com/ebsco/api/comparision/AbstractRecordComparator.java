package com.ebsco.api.comparision;

import com.ebsco.api.model.report.ReportData;
import com.ebsco.api.model.report.ReportGeneratable;
import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import com.netsuite.suitetalk.proxy.v2017_2.platform.core.Record;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Base class for those comparators which compare records.
 * These records can be Customers, Contacts, Cases, etc.
 *
 * @param <T> represents the Record from NetSuite CRM
 * @param <E> represents the Record from Salesforce
 */
public abstract class AbstractRecordComparator<T extends Record, E> implements FieldMapper, ReportGeneratable {

    protected Map<FieldName, FieldValue> map = new LinkedHashMap<>();
    protected T netSuiteRecord;
    protected E salesForceRecord;

    /**
     * Checks if POJOs of NetSuiteRecord and SalesForce Record are equal or not.
     *
     * @return true if records are equal in both NetSuite and SalesForce.
     */
    public boolean areEqual() {
        return map.values().stream().map( FieldValue::areEqual ).allMatch( value -> true );
    }

    /**
     * Report is prepared for a particular record containing the status for each of it's fields.
     *
     * @return the ReportData associated with this comparator.
     */
    @Override
    public ReportData getData() {
        ReportData reportData = new ReportData();
        map.forEach( reportData::add );
        return reportData;
    }

    /**
     * Set the records which are to be compared.
     * It's essential to invoke this method to compare every new records.
     *
     * @param netSuiteRecord   to set.
     * @param salesForceRecord to set.
     */
    public void set(T netSuiteRecord, E salesForceRecord) {
        this.netSuiteRecord = netSuiteRecord;
        this.salesForceRecord = salesForceRecord;
        map.clear();
        this.applyMappings();
    }

}
