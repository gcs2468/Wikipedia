package com.ebsco.api.salesforce.services;

import com.ebsco.api.salesforce.pojo.Account;
import com.ebsco.api.utilities.BaseURI;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import static com.ebsco.common.constants.Constants.ACCOUNTS_URI;

public class Accounts {
    public static Account queryAccount(String accountId) {

        String loginURL =BaseURI.get()+ ACCOUNTS_URI+accountId;
        System.out.println(loginURL);
        RequestSpecification request = RestAssured.given().auth().oauth2(BaseURI.getAccessToken());
        Response response = request.get(loginURL);
        ResponseBody body = response.getBody();
        Account responseAccount = body.as(Account.class);
        return responseAccount;
    }


}
