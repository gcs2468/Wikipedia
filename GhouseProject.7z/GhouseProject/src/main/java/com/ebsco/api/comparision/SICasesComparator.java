package com.ebsco.api.comparision;

import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.api.salesforce.pojo.Record_;
import com.ebsco.api.salesforce.pojo.SICasesMap;
import com.ebsco.api.salesforce.pojo.ServiceIssuesCases;


public class SICasesComparator extends AbstractRecordComparator<ServiceIssue, SICasesMap> {
    @Override
    public void applyMappings() {

        map.put( new FieldName( "NetSuite Internal Id", "Netsuite Record Id" ),
                new FieldValue( netSuiteRecord.getNetsuiteInternalId(), salesForceRecord.getEISNetsuiteRecordIdC() ) );

        map.put( new FieldName( "Cases NS", "Cases SF" ),
                new FieldValue( netSuiteRecord.getCaseId(), salesForceRecord.getEISNetsuiteRecordIdC()));

        map.put( new FieldName( "SF Case Id", "Salesforce Record Id" ),
                new FieldValue( netSuiteRecord.getSfServiceIssueId(), salesForceRecord.getId() ) );

        System.out.println( "salesForceRecord---"+salesForceRecord.getId() );


    }

 }
