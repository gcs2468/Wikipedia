package com.ebsco.api.model.report;

import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Objects;

/**
 * An entity encapsulates a FieldName and FieldValue object.
 * Example:
 *
 * @<code> new ReportEntity(new FieldName("Country","Billing Country"), new FieldValue("United States", "India"));
 * </code>
 * <p>
 * The above code illustrates the usage of ReportEntity.
 * ReportEntity objects make up a ReportData. In other words, a report entity represents a row in a ReportData object
 * which exists in table format.
 */
public class ReportEntity {

    private FieldName fieldName;
    private FieldValue fieldValue;
    private boolean ignoreStatus;
    private boolean ignoreDesc;
    private boolean containsNotMigratedData;
    private Logger logger = LogManager.getLogger( ReportEntity.class );

    public ReportEntity(FieldName fieldName, FieldValue fieldValue) {
        this.fieldName = fieldName;
        this.fieldValue = fieldValue;
    }

    public FieldValue getFieldValue() {
        return fieldValue;
    }

    public FieldName getFieldName() {
        return fieldName;
    }

    public ReportEntity ignoreStatus() {
        ignoreStatus = true;
        return this;
    }

    public ReportEntity ignoreDesc() {
        ignoreDesc = true;
        return this;
    }

    public boolean isStatusIgnorable() {
        return this.ignoreStatus;
    }

    public boolean isDescIgnorable() {
        return this.ignoreDesc;
    }

    public boolean containsNotMigratedData() {
        return this.containsNotMigratedData;
    }

    @Override
    public int hashCode() {
        return Objects.hash( fieldValue.getNetSuiteFieldVal(), fieldValue.getSalesForceFieldVal() );
    }

    @Override
    public boolean equals(Object obj) {
        ReportEntity otherEntity = (ReportEntity) obj;
        return (otherEntity != null)
                && Objects.equals( fieldValue.getSalesForceFieldVal(), otherEntity.fieldValue.getSalesForceFieldVal() )
                && Objects.equals( fieldValue.getNetSuiteFieldVal(), otherEntity.fieldValue.getNetSuiteFieldVal() );
    }
}
