package com.ebsco.api.netsuite.services.pojo;

import com.netsuite.suitetalk.proxy.v2017_2.general.communication.Message;

public class MessageCustomVal extends Message {



    private String caseId;

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    private String sfCaseId;
    private String messageId;

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getSfCaseId() {
        return sfCaseId;
    }

    public void setSfCaseId(String sfCaseId) {
        this.sfCaseId = sfCaseId;
    }

    @Override
    public String getMessage() {
        return message;
    }

    @Override
    public void setMessage(String message) {
        this.message = message;
    }

    private String message;

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    private String email;

    private String BCC;

    public String getBCC() {
        return BCC;
    }

    public void setBCC(String BCC) {
        this.BCC = BCC;
    }

    public String getDATE_0() {
        return DATE_0;
    }

    public void setDATE_0(String DATE_0) {
        this.DATE_0 = DATE_0;
    }

    public String getIS_EMAILED() {
        return IS_EMAILED;
    }

    public void setIS_EMAILED(String IS_EMAILED) {
        this.IS_EMAILED = IS_EMAILED;
    }

    public String getIS_INCOMING() {
        return IS_INCOMING;
    }

    public void setIS_INCOMING(String IS_INCOMING) {
        this.IS_INCOMING = IS_INCOMING;
    }

    public String getRECIPIENT_ID() {
        return RECIPIENT_ID;
    }

    public void setRECIPIENT_ID(String RECIPIENT_ID) {
        this.RECIPIENT_ID = RECIPIENT_ID;
    }

    private String DATE_0;
    private String IS_EMAILED;
    private String IS_INCOMING;
    private String RECIPIENT_ID;
}
