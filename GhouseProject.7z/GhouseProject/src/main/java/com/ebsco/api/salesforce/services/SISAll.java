package com.ebsco.api.salesforce.services;


import com.ebsco.api.salesforce.UtilitySF;
import com.ebsco.api.salesforce.pojo.SIAll;
import com.ebsco.api.salesforce.pojo.ServiceIssues;
import com.ebsco.api.utilities.BaseURI;
import com.ebsco.common.utility.AppProperties;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.PropertyNames.SI_QUERY_FILE;


public class SISAll {

    private static Map<String, ServiceIssues> records;
    public static Map<String, ServiceIssues> retrieveSI() {
        ResponseBody body = UtilitySF.getResponseBody(SI_QUERY_FILE);
        SIAll responseSi = body.as(SIAll.class);
        System.out.println("Size::"+responseSi.getRecords().size());
        List<ServiceIssues> totalRecords = new LinkedList<>();
        totalRecords.addAll(responseSi.getRecords());
        while (!responseSi.getDone()) {
            String restURL = BaseURI.getInstanceUrl() + responseSi.getNextRecordsUrl();
            ResponseBody newBody = UtilitySF.makeRestCall( restURL );
            responseSi = newBody.as( SIAll.class );
            totalRecords.addAll( responseSi.getRecords() );        }

        records = totalRecords
                .stream()
                .collect( Collectors.toMap( ServiceIssues::getId,
                        record -> record, (record, record2) -> record2 ) );
        return records;
    }

    public static Map<String, ServiceIssues> querySi() {
        synchronized (SIAll.class) {
            if (records == null) {
                records = retrieveSI();
            }        }
        return records;
    }
}
