package com.ebsco.api.model.pool;

/**
 * The init method which is to be invoked when the pool is created.
 */
public interface PoolInitializable {
    void init();
}
