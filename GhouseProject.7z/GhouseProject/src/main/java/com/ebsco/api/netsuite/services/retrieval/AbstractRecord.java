package com.ebsco.api.netsuite.services.retrieval;


import java.util.List;

/**
 * Represents a base class for each of the type of record which can be
 * retrieved.
 *
 * @param <T> Represents the type of Record.
 */
public abstract class AbstractRecord<T> implements Retrievable<T> {

    /**
     * Converts the list of Strings i.e contact ids into a single String
     * which is compatible with SQL statement.
     * If Arrays.asList("1", "2", "3") is passed as parameter, then
     * "('1', '2', '3')" would be returned.
     *
     * @param idList to convert.
     * @return String
     */

    protected String listToString(List<String> idList) {
        StringBuilder sb = new StringBuilder( "(" );
        int size = idList.size();
        int i = 0;
        for (; i < size - 1; i++) {
            sb.append( "'" + idList.get( i ).replace( "\"", " " ).trim() + "', " );
        }
        sb.append( "'" + idList.get( i ).replace( "\"", " " ).trim() + "')" );
        return sb.toString();
    }


}