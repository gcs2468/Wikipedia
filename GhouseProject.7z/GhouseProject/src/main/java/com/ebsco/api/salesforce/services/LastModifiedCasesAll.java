package com.ebsco.api.salesforce.services;

import com.ebsco.api.salesforce.pojo.Case;
import com.ebsco.api.salesforce.pojo.CaseAll;
import com.ebsco.api.utilities.BaseURI;
import com.ebsco.common.utility.AppProperties;
import com.ebsco.common.utility.CommonUtils;
import com.ebsco.web.managers.FileReaderManager;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import java.util.Map;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.Constants.SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss;
import static com.ebsco.common.constants.PropertyNames.CASE_QUERY_FILE_LAST_MODIFIED;

public class LastModifiedCasesAll {


    private static Map<String, Case> records;
    public static Map<String, Case> retrieveCases() {
        String startTime,gmtStartTime,endTime,gmtEndTime,sql;
        String replacedQueryFile = "";
        int hoursToAdd=FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
        int hoursToSub=FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();
        try {
            startTime = CommonUtils.getTimeWithHoursAdd(hoursToSub) + "+0000";
            gmtStartTime = CommonUtils.getGMTTime(startTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            endTime = CommonUtils.getTimeWithHoursAdd(hoursToAdd) + "+0000";
            gmtEndTime = CommonUtils.getGMTTime(endTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
        replacedQueryFile=AppProperties.getValueFor(CASE_QUERY_FILE_LAST_MODIFIED).
                replace("START_TIME",gmtStartTime.replace(" ","T")).
                replace("END_TIME",gmtEndTime.replace(" ","T"));
        }
        catch (Exception e){
        }
            String loginURL = BaseURI.get() + "/query/?q=" + replacedQueryFile;
            System.out.println(loginURL);

        RequestSpecification request = RestAssured.given().auth().oauth2(BaseURI.getAccessToken());
        Response response = request.get(loginURL);
        ResponseBody body = response.getBody();

        CaseAll responseCase = body.as(CaseAll.class);
        System.out.println("Size::"+responseCase.getRecords().size());

        return responseCase.getRecords()
                .stream()
                .collect(Collectors.toMap(Case::getId, record -> record));
    }

    public static Map<String, Case> queryCases() {
        synchronized (LastModifiedCasesAll.class) {
            if (records == null) {
                records = retrieveCases();
            }
        }
        return records;
    }

}
