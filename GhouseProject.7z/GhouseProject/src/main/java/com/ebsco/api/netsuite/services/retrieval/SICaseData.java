package com.ebsco.api.netsuite.services.retrieval;

import com.ebsco.api.netsuite.services.connection.NetSuiteConnection;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.common.utility.AppProperties;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.PropertyNames.SI_CASE_RETRIEVE_SQL_PROPERTY;
import static com.ebsco.common.constants.PropertyNames.SI_RETRIEVE_SQL_PROPERTY;

public class SICaseData extends AbstractRecord<ServiceIssue> {

    @Override
    public synchronized Map<String, ServiceIssue> get(List<String> idList, NetSuiteConnectionPool pool) throws Exception {
        NetSuiteConnectionPool nsConnectionPool = new NetSuiteConnectionPool( 1 );
        NetSuiteConnection connection = nsConnectionPool.acquire();
        Statement statement = connection.getStatement();
        String sql = AppProperties.getValueFor( SI_CASE_RETRIEVE_SQL_PROPERTY );
        sql += listToString( idList );
        //Service_Issue_ID,Case_ID,Service_Issue.SF_SERVICE_ISSUE_ID
        Map<String, ServiceIssue> siCaseMap = new HashMap<>();
        System.out.println( "query::"+sql );
        try (ResultSet resultSet = statement.executeQuery( sql )) {
            while (resultSet.next()) {
                ServiceIssue serviceIssue = new ServiceIssue();
                serviceIssue.setNetsuiteInternalId( resultSet.getString( "Service_Issue_ID" ).replace( ".0", "" ) );
                serviceIssue.setCaseId( resultSet.getString( "Case_ID" ) );
                serviceIssue.setSfServiceIssueId( resultSet.getString( "SF_SERVICE_ISSUE_ID" ) );
                siCaseMap.put( serviceIssue.getCaseId(), serviceIssue );
            }
        }
        pool.free( connection );
        return siCaseMap;
    }
}
