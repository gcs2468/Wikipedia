package com.ebsco.api.model.utility.comparison;

import java.util.Objects;

/**
 * Encapsulates the values of the fields present in records of Salesforce and NetSuite CRM.
 */
public class FieldValue implements Description {

    private String netSuiteFieldVal;
    private String salesForceFieldVal;
    private static final String FIELDS_EQUAL_DESCRIPTION = "Data Equal";
    private final String fieldsUnequalDescription;
    private static final String NO_DATA = "null";
    private static final String DATA_TRUNCATED = "Data is truncated.";
    private boolean isTruncated;
    private String netSuiteCompareVal;

    public FieldValue(Object netSuiteFieldVal, Object salesForceFieldVal) {
        this.netSuiteFieldVal = Objects.toString( netSuiteFieldVal, NO_DATA ).replaceAll( "[\r\n]","" );
        this.salesForceFieldVal = Objects.toString( salesForceFieldVal, NO_DATA ).replaceAll( "[\r\n]","" );
        netSuiteCompareVal = this.netSuiteFieldVal;
        fieldsUnequalDescription = String.format( "%s and %s are not equal.", netSuiteFieldVal, salesForceFieldVal );
    }

    public FieldValue(Object netSuiteFieldVal, Object salesForceFieldVal, String netSuiteCompareVal) {
        this( netSuiteCompareVal, salesForceFieldVal );
        this.netSuiteCompareVal = netSuiteCompareVal;
    }

    public FieldValue(Object netSuiteFieldVal, Object salesForceFieldVal, String salesforceCompareVal,boolean Sf) {
        this( salesforceCompareVal, salesForceFieldVal );
        this.salesForceFieldVal = salesforceCompareVal;
    }

    public FieldValue(Object netSuiteFieldVal, Object salesForceFieldVal, boolean isTruncated) {
        this( netSuiteFieldVal, salesForceFieldVal );
        this.isTruncated = isTruncated;
    }

    public String getSalesForceFieldVal() {
        return salesForceFieldVal;
    }

    public String getNetSuiteFieldVal() {
        return netSuiteFieldVal;
    }

    public boolean areEqual() {
               return Objects.equals( netSuiteCompareVal, salesForceFieldVal );
    }


    @Override
    public String getDesc() {

        boolean fieldsAreEqual = areEqual();
        if (fieldsAreEqual) {
            return FIELDS_EQUAL_DESCRIPTION;
        }

        if (netSuiteFieldVal.length() <= salesForceFieldVal.length()) {
            if (salesForceFieldVal.contains( netSuiteFieldVal )) return DATA_TRUNCATED;
        } else {
            if (netSuiteFieldVal.contains( salesForceFieldVal )) return DATA_TRUNCATED;
        }


        return fieldsUnequalDescription;
    }
}
