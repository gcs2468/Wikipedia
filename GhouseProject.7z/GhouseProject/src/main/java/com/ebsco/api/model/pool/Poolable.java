package com.ebsco.api.model.pool;

public interface Poolable extends PoolInitializable, Closeable {}
