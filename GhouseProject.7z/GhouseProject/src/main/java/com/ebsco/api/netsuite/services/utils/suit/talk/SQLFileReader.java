package com.ebsco.api.netsuite.services.utils.suit.talk;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class SQLFileReader {

    public static String getSqlFrom(String sqlFilePath) {
        List<String> lines = null;
        try {
            lines = Files.readAllLines( Paths.get( sqlFilePath ) );
        } catch (IOException e) {
            e.printStackTrace();
        }
        StringBuilder sqlQuery = lines.stream()
                .map( line -> line.concat( " " ) )
                .collect( StringBuilder::new, StringBuilder::append,
                        StringBuilder::append );
        return sqlQuery.toString();
    }
}
