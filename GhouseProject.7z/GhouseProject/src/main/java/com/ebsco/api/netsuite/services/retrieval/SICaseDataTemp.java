package com.ebsco.api.netsuite.services.retrieval;

import com.ebsco.api.netsuite.services.connection.NetSuiteConnection;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.api.salesforce.pojo.SICasesMap;
import com.ebsco.common.utility.AppProperties;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.PropertyNames.SI_CASE_RETRIEVE_SQL_PROPERTY;

public class SICaseDataTemp extends AbstractRecord<ServiceIssue> {

    @Override
    public synchronized Map<String, ServiceIssue> get(List<String> idList, NetSuiteConnectionPool pool) throws Exception {
        NetSuiteConnectionPool nsConnectionPool = new NetSuiteConnectionPool( 1 );
        NetSuiteConnection connection = nsConnectionPool.acquire();
        Statement statement = connection.getStatement();
        String sql = AppProperties.getValueFor( SI_CASE_RETRIEVE_SQL_PROPERTY );
        sql += listToString( idList );
        //Service_Issue_ID,Case_ID,Service_Issue.SF_SERVICE_ISSUE_ID
        Map<String, ServiceIssue> siCaseMap = new HashMap<>();
        List<String> ids= new ArrayList<>(  );
        try (ResultSet resultSet = statement.executeQuery( sql )) {
            while (resultSet.next()) {
                ServiceIssue serviceIssue = new ServiceIssue();
                if(siCaseMap.containsKey(resultSet.getString( "Service_Issue_ID" ).replace( ".0", "" ))) {
                    ids.add(resultSet.getString( "Case_ID" )   );
                }
                else{
                    ids.add(resultSet.getString( "Case_ID" )   );
                }
                serviceIssue.setNetsuiteInternalId( resultSet.getString( "Service_Issue_ID" ).replace( ".0", "" ) );
                serviceIssue.setCaseIdList(ids );
                serviceIssue.setSfServiceIssueId( resultSet.getString( "SF_SERVICE_ISSUE_ID" ) );

                siCaseMap.put( serviceIssue.getNetsuiteInternalId(), serviceIssue );

            }
        }
        System.out.println( "1234" );
         siCaseMap.values().stream().forEach( p->p.getCaseIdList() );
        System.exit( 0 );
        pool.free( connection );
        return siCaseMap;
    }
}
