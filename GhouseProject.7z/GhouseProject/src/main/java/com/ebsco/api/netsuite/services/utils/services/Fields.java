package com.ebsco.api.netsuite.services.utils.services;

import com.netsuite.suitetalk.proxy.v2017_2.lists.relationships.Customer;
import com.netsuite.suitetalk.proxy.v2017_2.platform.core.RecordRef;
import com.netsuite.suitetalk.proxy.v2017_2.platform.messages.WriteResponse;
import com.netsuite.suitetalk.proxy.v2017_2.setup.customization.CustomRecord;
import com.netsuite.suitetalk.proxy.v2017_2.transactions.sales.SalesOrder;
import com.netsuite.suitetalk.proxy.v2017_2.transactions.sales.SalesOrderItem;

import java.util.LinkedHashMap;
import java.util.Map;


/**
 * <p>This is type of map which converts particular objects to map of the fields. It can be simply printed
 * using {@link (Map)} method.</p>
 * <p>© 2017 NetSuite Inc. All rights reserved.</p>
 */

public class Fields extends LinkedHashMap<String, String> {

    public Fields() {
        super();
    }

    public Fields(String internalId) {
        super();
        put( Messages.INTERNAL_ID, internalId );
    }

    public Fields(String internalId, String errorMessage) {
        this( internalId );
        put( Messages.ERROR, errorMessage );
    }

    public Fields(Customer customer) {
        super();
        put( Messages.INTERNAL_ID, customer.getInternalId() );
        put( Messages.EXTERNAL_ID, customer.getExternalId() );
        put( Messages.ENTITY_ID, customer.getEntityId() );
        put( Messages.COMPANY_NAME, customer.getCompanyName() );
        put( Messages.EMAIL, customer.getEmail() );
        put( Messages.PHONE, customer.getPhone() );
        //put(ENTITY_STATUS, customer.getEntityStatus().getName());
        put( Messages.IS_INACTIVE, String.valueOf( customer.getIsInactive() ) );
        put( Messages.DATE_CREATED, customer.getDateCreated().getTime().toString() );
    }

    public Fields(WriteResponse response, Customer customer) {
        super();
        put( Messages.INTERNAL_ID, ((RecordRef) response.getBaseRef()).getInternalId() );
        put( Messages.EXTERNAL_ID, ((RecordRef) response.getBaseRef()).getExternalId() );
        put( Messages.ENTITY_ID, customer.getEntityId() );
        put( Messages.COMPANY_NAME, customer.getCompanyName() );
        put( Messages.EMAIL, customer.getEmail() );
        put( Messages.STATUS_INTERNAL_ID, getStatusKey( customer ) );
        put( Messages.ADDRESS_BOOK_LABEL, getAddressBookLabel( customer ) );
    }

    public Fields(SalesOrder salesOrder, boolean isEntityId) {
        super();
        put( Messages.INTERNAL_ID, salesOrder.getInternalId() );
        put( Messages.TRANSACTION_ID, salesOrder.getTranId() );
        if (isEntityId) {
            put( Messages.ENTITY_ID, salesOrder.getEntity().getInternalId() );
        } else {
            put( Messages.CUSTOMER_NAME, salesOrder.getEntity().getName() );
        }
        put( Messages.TOTAL_AMOUNT, String.valueOf( salesOrder.getTotal() ) );
        put( Messages.DATE_CREATED, salesOrder.getCreatedDate().getTime().toString() );
    }

    public Fields(SalesOrderItem item) {
        super();
        put( Messages.ITEM_NAME, item.getItem().getName() );
        put( Messages.QUANTITY, String.valueOf( item.getQuantity() ) );
    }

    public Fields(CustomRecord customRecord) {
        super();
        put( Messages.CUSTOM_RECORD_TYPE_ID, customRecord.getRecType().getInternalId() );
        put( Messages.INTERNAL_ID, customRecord.getInternalId() );
        put( Messages.NAME, customRecord.getName() );
    }

    private static String getStatusKey(Customer customer) {
        if (customer.getEntityStatus() == null) {
            return null;
        }
        return customer.getEntityStatus().getInternalId();
    }

    private static String getAddressBookLabel(Customer customer) {
        final int i = 0;
        if (customer.getAddressbookList() == null || customer.getAddressbookList().getAddressbook() == null
                || customer.getAddressbookList().getAddressbook()[i] == null) {
            return null;
        }
        return customer.getAddressbookList().getAddressbook()[i].getLabel();
    }
}
