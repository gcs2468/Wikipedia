package com.ebsco.api.comparision;

import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import com.ebsco.api.netsuite.services.pojo.ContactCustomVal;
import com.ebsco.api.salesforce.pojo.Contact;


public class ContactComparator extends AbstractRecordComparator<ContactCustomVal, Contact> {

    @Override
    public void applyMappings() {

        map.put( new FieldName( "Institution Name", "Account Name" ),
                new FieldValue( netSuiteRecord.getCompanyName(), salesForceRecord.getAccount().getName() ) );

        map.put( new FieldName( "First Name", "First Name" ),
                new FieldValue( netSuiteRecord.getFirstName(), salesForceRecord.getFirstName() ) );

        map.put( new FieldName( "Last Name", "Last Name" ),
                new FieldValue( netSuiteRecord.getLastName(), salesForceRecord.getLastName() ) );

        map.put( new FieldName( "Email", "Email" ),
                new FieldValue( netSuiteRecord.getEmail(), salesForceRecord.getEmail() ) );

        map.put( new FieldName( "Phone", "Phone" ),
                new FieldValue( netSuiteRecord.getPhone(), salesForceRecord.getPhone() ) );

        map.put( new FieldName( "Job Role", "Job Role" ),
                new FieldValue( netSuiteRecord.getJobRole(), salesForceRecord.getEISJobRoleC() ) );

        map.put( new FieldName( "Title", "Title" ),
                new FieldValue( netSuiteRecord.getTitle(), salesForceRecord.getTitle() ) );

        map.put( new FieldName( "Inactive", "Inactive" ),
                new FieldValue( transformInActive( netSuiteRecord.getInactive() ), salesForceRecord.getEISInactiveC() ) );

        map.put( new FieldName( "Opt In To Parent Visibility", "Opt In To Parent Visibility" ),
                new FieldValue( netSuiteRecord.getOptInToParentVisibility(), salesForceRecord.getEISOptInToParentVisibilityC() ) );

        map.put( new FieldName( "SF Contact Id", "Salesforce Record Id" ),
                new FieldValue( netSuiteRecord.getExternalId(), salesForceRecord.getId() ) );

        map.put( new FieldName( "Portal User Status", "Portal User Status" ),
                new FieldValue( getUserStatus( netSuiteRecord ), salesForceRecord.getEISPortalUserStatusC() ) );

    }

    private String getUserStatus(com.netsuite.suitetalk.proxy.v2017_2.lists.relationships.Contact contact) {
       String contacts="";
        if(contact.getIsInactive() !=null) {
            contacts= contact.getIsInactive() ? "User InActive" : " User Active";
        }else{
            contacts="null";
        }
        return contacts;
    }


    public boolean transformInActive(String inactiveStatus) {
        switch (inactiveStatus.toLowerCase()) {
            case "no":
                return false;
            default:
                return true;
        }
    }

}
