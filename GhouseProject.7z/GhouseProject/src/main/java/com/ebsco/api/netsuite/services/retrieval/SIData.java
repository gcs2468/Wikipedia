package com.ebsco.api.netsuite.services.retrieval;

import com.ebsco.api.netsuite.services.connection.NetSuiteConnection;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.common.utility.AppProperties;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.PropertyNames.SI_RETRIEVE_SQL_PROPERTY;

public class SIData extends AbstractRecord<ServiceIssue> {

    @Override
    public synchronized Map<String, ServiceIssue> get(List<String> idList, NetSuiteConnectionPool pool) throws Exception {
        NetSuiteConnectionPool nsConnectionPool = new NetSuiteConnectionPool( 1 );
        NetSuiteConnection connection = nsConnectionPool.acquire();
        Statement statement = connection.getStatement();
        String sql = AppProperties.getValueFor( SI_RETRIEVE_SQL_PROPERTY );
        sql += "IN " + listToString( idList );
        Map<String, ServiceIssue> siMap = new HashMap<>();
        try (ResultSet resultSet = statement.executeQuery( sql )) {
            while (resultSet.next()) {
                ServiceIssue serviceIssue = new ServiceIssue();
                //serviceIssue.setNetsuiteInternalId( resultSet.getString( "SERVICE_ISSUE_ID" ).replace( ".0", "" ) );
                serviceIssue.setNetsuiteInternalId( String.valueOf( new Double( resultSet.getDouble( "SERVICE_ISSUE_ID" ) ).longValue() ) );
                serviceIssue.setSynopsis( resultSet.getString( "SYNOPSIS" ) );
                serviceIssue.setIssueExperience( resultSet.getString( "ISSUE_EXPERIENCED" ) );
                serviceIssue.setResolution( resultSet.getString( "COMPANY_LINE" ) );
                serviceIssue.setDateCreated( resultSet.getString( "DATE_CREATED" ) );
                serviceIssue.setLastmodified( resultSet.getString( "LAST_MODIFIED_DATE" ) );
                serviceIssue.setSiDateClosed( resultSet.getString( "DATE_CLOSED" ) );
                serviceIssue.setSfServiceIssueId( resultSet.getString("SF_SERVICE_ISSUE_ID" ) );
                serviceIssue.setStatus( resultSet.getString( "LIST_ITEM_NAME" ) );
                serviceIssue.setProduct_interface( resultSet.getString( "PRODUCTS_SERVICE_ISSUE_NAME" ) );
                siMap.put( serviceIssue.getNetsuiteInternalId(), serviceIssue );
            }
        }
        nsConnectionPool.free( connection );
        return siMap;
    }
}
