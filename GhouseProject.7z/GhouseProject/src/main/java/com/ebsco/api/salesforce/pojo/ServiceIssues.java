
package com.ebsco.api.salesforce.pojo;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "attributes",
    "Id",
    "OwnerId",
    "IsDeleted",
    "Name",
    "CreatedDate",
    "CreatedById",
    "LastModifiedDate",
    "LastModifiedById",
    "SystemModstamp",
    "LastViewedDate",
    "LastReferencedDate",
    "EIS_Issue_Experienced__c",
    "EIS_Netsuite_Record_Id__c",
    "EIS_Original_Date_Created__c",
    "EIS_Original_Last_Modified__c",
    "EIS_Resolution__c",
    "EIS_SI_Date_Closed__c",
    "EIS_Status__c",
    "EIS_Synopsis__c",
    "EIS_Product_Interface__c"
})
public class ServiceIssues {

    @JsonProperty("attributes")
    private Attributes attributes;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("OwnerId")
    private String ownerId;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("LastViewedDate")
    private String lastViewedDate;
    @JsonProperty("LastReferencedDate")
    private String lastReferencedDate;
    @JsonProperty("EIS_Issue_Experienced__c")
    private String eISIssueExperiencedC;
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    private String eISNetsuiteRecordIdC;
    @JsonProperty("EIS_Original_Date_Created__c")
    private String eISOriginalDateCreatedC;
    @JsonProperty("EIS_Original_Last_Modified__c")
    private String eISOriginalLastModifiedC;
    @JsonProperty("EIS_Resolution__c")
    private Object eISResolutionC;
    @JsonProperty("EIS_SI_Date_Closed__c")
    private Object eISSIDateClosedC;
    @JsonProperty("EIS_Status__c")
    private String eISStatusC;
    @JsonProperty("EIS_Synopsis__c")
    private String eISSynopsisC;
    @JsonProperty("EIS_Product_Interface__c")
    private String eISProductInterfaceC;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("attributes")
    public Attributes getAttributes() {
        return attributes;
    }

    @JsonProperty("attributes")
    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("OwnerId")
    public String getOwnerId() {
        return ownerId;
    }

    @JsonProperty("OwnerId")
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("LastViewedDate")
    public String getLastViewedDate() {
        return lastViewedDate;
    }

    @JsonProperty("LastViewedDate")
    public void setLastViewedDate(String lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }

    @JsonProperty("LastReferencedDate")
    public String getLastReferencedDate() {
        return lastReferencedDate;
    }

    @JsonProperty("LastReferencedDate")
    public void setLastReferencedDate(String lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }

    @JsonProperty("EIS_Issue_Experienced__c")
    public String getEISIssueExperiencedC() {
        return eISIssueExperiencedC;
    }

    @JsonProperty("EIS_Issue_Experienced__c")
    public void setEISIssueExperiencedC(String eISIssueExperiencedC) {
        this.eISIssueExperiencedC = eISIssueExperiencedC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public String getEISNetsuiteRecordIdC() {
        return eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public void setEISNetsuiteRecordIdC(String eISNetsuiteRecordIdC) {
        this.eISNetsuiteRecordIdC = eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Original_Date_Created__c")
    public String getEISOriginalDateCreatedC() {
        return eISOriginalDateCreatedC;
    }

    @JsonProperty("EIS_Original_Date_Created__c")
    public void setEISOriginalDateCreatedC(String eISOriginalDateCreatedC) {
        this.eISOriginalDateCreatedC = eISOriginalDateCreatedC;
    }

    @JsonProperty("EIS_Original_Last_Modified__c")
    public String getEISOriginalLastModifiedC() {
        return eISOriginalLastModifiedC;
    }

    @JsonProperty("EIS_Original_Last_Modified__c")
    public void setEISOriginalLastModifiedC(String eISOriginalLastModifiedC) {
        this.eISOriginalLastModifiedC = eISOriginalLastModifiedC;
    }

    @JsonProperty("EIS_Resolution__c")
    public Object getEISResolutionC() {
        return eISResolutionC;
    }

    @JsonProperty("EIS_Resolution__c")
    public void setEISResolutionC(Object eISResolutionC) {
        this.eISResolutionC = eISResolutionC;
    }

    @JsonProperty("EIS_SI_Date_Closed__c")
    public Object getEISSIDateClosedC() {
        return eISSIDateClosedC;
    }

    @JsonProperty("EIS_SI_Date_Closed__c")
    public void setEISSIDateClosedC(Object eISSIDateClosedC) {
        this.eISSIDateClosedC = eISSIDateClosedC;
    }

    @JsonProperty("EIS_Status__c")
    public String getEISStatusC() {
        return eISStatusC;
    }

    @JsonProperty("EIS_Status__c")
    public void setEISStatusC(String eISStatusC) {
        this.eISStatusC = eISStatusC;
    }

    @JsonProperty("EIS_Synopsis__c")
    public String getEISSynopsisC() {
        return eISSynopsisC;
    }

    @JsonProperty("EIS_Synopsis__c")
    public void setEISSynopsisC(String eISSynopsisC) {
        this.eISSynopsisC = eISSynopsisC;
    }

    @JsonProperty("EIS_Product_Interface__c")
    public String getEISProductInterfaceC() {
        return eISProductInterfaceC;
    }

    @JsonProperty("EIS_Product_Interface__c")
    public void setEISProductInterfaceC(String eISProductInterfaceC) {
        this.eISProductInterfaceC = eISProductInterfaceC;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
