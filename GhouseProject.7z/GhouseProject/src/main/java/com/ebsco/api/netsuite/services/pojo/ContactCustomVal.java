package com.ebsco.api.netsuite.services.pojo;

import com.netsuite.suitetalk.proxy.v2017_2.lists.relationships.Contact;

public class ContactCustomVal extends Contact {
    private String companyName;
    private String JobRole;
    private String ContactOrigin;
    private String LegitimateBusinessInterest;
    private String inactive;
    private String OptInToParentVisibility;

    public String getInactive() {
        return inactive;
    }


    public void setInactive(String inactive) {
        this.inactive = inactive;
    }

    public String getOptInToParentVisibility() {
        return OptInToParentVisibility;
    }

    public void setOptInToParentVisibility(String optInToParentVisibility) {
        OptInToParentVisibility = optInToParentVisibility;
    }


    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getJobRole() {
        return JobRole;
    }

    public void setJobRole(String jobRole) {
        JobRole = jobRole;
    }

    public String getContactOrigin() {
        return ContactOrigin;
    }

    public void setContactOrigin(String contactOrigin) {
        ContactOrigin = contactOrigin;
    }

    public String getLegitimateBusinessInterest() {
        return LegitimateBusinessInterest;
    }

    public void setLegitimateBusinessInterest(String legitimateBusinessInterest) {
        LegitimateBusinessInterest = legitimateBusinessInterest;
    }


}
