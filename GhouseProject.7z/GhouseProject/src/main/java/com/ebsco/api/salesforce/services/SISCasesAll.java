package com.ebsco.api.salesforce.services;


import com.ebsco.api.salesforce.pojo.*;
import com.ebsco.api.utilities.BaseURI;
import com.ebsco.common.utility.AppProperties;
import groovyjarjarantlr.collections.impl.LList;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import java.security.cert.CollectionCertStoreParameters;
import java.util.*;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.PropertyNames.SI_CASE_QUERY_FILE;
import static com.ebsco.common.constants.PropertyNames.SI_QUERY_FILE;


public class SISCasesAll {

    private static Map<String, SICasesMap> records;
    private static Map<String,SICasesMap> casesiMap;
    public static Map<String, SICasesMap> retrieveSICase() {
        String loginURL = BaseURI.get() + "/query/?q=" + AppProperties.getValueFor(SI_CASE_QUERY_FILE);
        System.out.println(loginURL);
        RequestSpecification request = RestAssured.given().auth().oauth2(BaseURI.getAccessToken());
        Response response = request.get(loginURL);
        ResponseBody body = response.getBody();
       //System.out.println("body===="+ body.prettyPrint() );
        ServiceIssueCase responseSiCase = body.as(ServiceIssueCase.class);
        System.out.println("Size::"+responseSiCase.getRecords().size());

        return responseSiCase.getRecords().stream().filter( p->p.getCasesR()!=null ).collect( Collectors.toMap( SICasesMap::getId,records->records ) );

    }

    public static Map<String, SICasesMap> querySiCase() {
      casesiMap = new LinkedHashMap<>(  );
        synchronized (ServiceIssueCase.class) {
            if (records == null) {
                records = retrieveSICase();

                Iterator<Map.Entry<String, SICasesMap>> itr = records.entrySet().iterator();
                List<String> totallist = new LinkedList<>(  );
                while(itr.hasNext())
                {
                    Map.Entry<String, SICasesMap> entry = itr.next();
                    if(entry.getValue().getCasesR()!=null) {
                        totallist = entry.getValue().getCasesR().getRecords()
                                .stream().map( x -> x.getEIS_Netsuite_Record_Id__c() ).collect( Collectors.toList() );

                    }

                     for (int i=0;i<totallist.size();i++)  {
                        casesiMap.put( totallist.get( i ) ,entry.getValue());
                     }

                      }

            }
        }
       /* Iterator<Map.Entry<String, SICasesMap>> iterator = casesiMap.entrySet().iterator();
        while(iterator.hasNext()) {
            Map.Entry<String, SICasesMap> entry = iterator.next();
            System.out.println( "Key = " + entry.getKey() +
                    ", Value = " + entry.getValue().getId() );
        }*/


        return casesiMap;
    }
}
