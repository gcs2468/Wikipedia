package com.ebsco.api.netsuite.services.retrieval;


import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;

import java.util.List;
import java.util.Map;

public interface Retrievable<T> {
    Map<String, T> get(List<String> idList, NetSuiteConnectionPool pool) throws Exception;
}