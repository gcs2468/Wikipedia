package com.ebsco.api.salesforce.services;


import com.ebsco.api.salesforce.UtilitySF;
import com.ebsco.api.salesforce.pojo.Case;
import com.ebsco.api.salesforce.pojo.CaseAll;
import com.ebsco.common.utility.AppProperties;
import com.ebsco.api.utilities.BaseURI;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.PropertyNames.CASE_QUERY_FILE;


public class CasesAll {

    private static Map<String, Case> records;
    public static Map<String, Case> retrieveCases() {
        ResponseBody body = UtilitySF.getResponseBody(CASE_QUERY_FILE);
        CaseAll responseCase = body.as(CaseAll.class);


        List<Case> totalRecords = new LinkedList<>();
        totalRecords.addAll( responseCase.getRecords() );
        while (!responseCase.getDone()) {
            String restURL = BaseURI.getInstanceUrl() + responseCase.getNextRecordsUrl();
            ResponseBody newBody = UtilitySF.makeRestCall( restURL );
            responseCase = newBody.as( CaseAll.class );
            totalRecords.addAll( responseCase.getRecords() );        }
        System.out.println("Size::"+totalRecords.size());

        records = totalRecords
                .stream()
                .collect( Collectors.toMap( Case::getId,
                        record -> record, (record, recordTwo) -> recordTwo ) );
        //System.out.println("data Size::"+records.keySet().size());
       // System.out.println("Size::"+records.keySet());
       // System.exit( 0 );
        return records;
    }

    public static Map<String, Case> queryCases() {
        synchronized (CasesAll.class) {
            if (records == null) {
                records = retrieveCases();
            }        }
        return records;
    }
}
