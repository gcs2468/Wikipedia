package com.ebsco.api.salesforce.services;

import com.ebsco.api.salesforce.pojo.Contact;
import com.ebsco.api.salesforce.pojo.ContactAll;
import com.ebsco.common.utility.AppProperties;
import com.ebsco.api.utilities.BaseURI;
import com.ebsco.common.utility.CommonUtils;
import com.ebsco.web.managers.FileReaderManager;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import java.util.Map;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.Constants.SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss;
import static com.ebsco.common.constants.PropertyNames.CONTACT_QUERY_FILE_CXP_STATUS;

public class CXPStatusLastModifiedContactsAll {


    private static Map<String, Contact> records;
    public static Map<String, Contact> retrieveAccounts() {
        String startTime,gmtStartTime,endTime,gmtEndTime,sql;
        String replacedQueryFile = "";
        int hoursToAdd=FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
        int hoursToSub=FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();
        try {
            startTime = CommonUtils.getTimeWithHoursAdd(hoursToSub) + "+0000";
            gmtStartTime = CommonUtils.getGMTTime(startTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            endTime = CommonUtils.getTimeWithHoursAdd(hoursToAdd) + "+0000";
            gmtEndTime = CommonUtils.getGMTTime(endTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
        replacedQueryFile=AppProperties.getValueFor(CONTACT_QUERY_FILE_CXP_STATUS).
                replace("START_TIME",gmtStartTime.replace(" ","T")).
                replace("END_TIME",gmtEndTime.replace(" ","T"));
        }
        catch (Exception e){
        }
            String loginURL = BaseURI.get() + "/query/?q=" + replacedQueryFile;
            System.out.println(loginURL);

        RequestSpecification request = RestAssured.given().auth().oauth2(BaseURI.getAccessToken());
        Response response = request.get(loginURL);
        ResponseBody body = response.getBody();

        ContactAll responseContact = body.as(ContactAll.class);
        System.out.println("Size::"+responseContact.getRecords().size());

        return responseContact.getRecords()
                .stream()
                .collect(Collectors.toMap(Contact::getId, record -> record));
    }

    public static Map<String, Contact> queryContact() {
        synchronized (CXPStatusLastModifiedContactsAll.class) {
            if (records == null) {
                records = retrieveAccounts();
            }
        }
        return records;
    }

}
