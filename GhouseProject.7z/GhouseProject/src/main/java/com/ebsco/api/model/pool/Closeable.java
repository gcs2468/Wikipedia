package com.ebsco.api.model.pool;

/**
 * Shut down method for the objects which are pooled.
 */
public interface Closeable {
    void close();
}
