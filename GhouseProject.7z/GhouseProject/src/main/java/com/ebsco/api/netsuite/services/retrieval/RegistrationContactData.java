package com.ebsco.api.netsuite.services.retrieval;

import com.ebsco.api.netsuite.services.connection.NetSuiteConnection;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.common.utility.AppProperties;
import com.ebsco.api.netsuite.services.pojo.ContactCustomVal;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.PropertyNames.CONTACT_CXP_STATUS_QUERY_FILE;


public class RegistrationContactData extends AbstractRecord<ContactCustomVal> {

    @Override
    public synchronized Map<String, ContactCustomVal> get(List<String> idList, NetSuiteConnectionPool pool) throws Exception {
        NetSuiteConnectionPool nsConnectionPool = new NetSuiteConnectionPool(1);
        NetSuiteConnection connection = nsConnectionPool.acquire();
        Statement statement = connection.getStatement();
        String sql = AppProperties.getValueFor(CONTACT_CXP_STATUS_QUERY_FILE);
        sql += listToString(idList);
        Map<String, ContactCustomVal> contactMap = new HashMap<>();
        try (ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                ContactCustomVal contact = new ContactCustomVal();
                contact.setInternalId( resultSet.getString( "CONTACT_ID" ).replaceAll( ".0", "" ) );
                contact.setFirstName( resultSet.getString( "FIRSTNAME" ) );
                contact.setMiddleName( resultSet.getString( "MIDDLENAME" ) );
                contact.setLastName( resultSet.getString( "LASTNAME" ) );
                contact.setEmail( resultSet.getString( "EMAIL" ) );
                contact.setPhone( resultSet.getString( "PHONE" ) );
                contact.setTitle( resultSet.getString( "TITLE" ) );
                contact.setExternalId( resultSet.getString( "SF_CONTACT_ID" ) );
                contact.setComments(resultSet.getString("CXP_OPT_IN_TO_PARENT_VISIBILI"));//Using Comments field for CXP Portal User Status
                contactMap.put(contact.getInternalId(), contact);
            }
        }

        pool.free(connection);
        return contactMap;
    }

}
