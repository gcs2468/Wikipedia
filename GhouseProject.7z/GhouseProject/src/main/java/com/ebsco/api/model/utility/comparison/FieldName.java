package com.ebsco.api.model.utility.comparison;


/**
 * Encapsulates the names of the fields of both salesforce end as well as
 * NetSuite end.
 */
public class FieldName {

    private String netSuiteFieldName;
    private String salesForceFieldName;

    public FieldName(String netSuiteFieldName, String salesForceFieldName) {
        this.netSuiteFieldName = netSuiteFieldName;
        this.salesForceFieldName = salesForceFieldName;
    }

    public String getNetSuiteFieldName() {
        return netSuiteFieldName;
    }

    public String getSalesForceFieldName() {
        return salesForceFieldName;
    }
}