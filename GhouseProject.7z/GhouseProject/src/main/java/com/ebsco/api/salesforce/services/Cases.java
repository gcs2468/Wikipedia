package com.ebsco.api.salesforce.services;

import com.ebsco.api.salesforce.pojo.Case;
import com.ebsco.api.utilities.BaseURI;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import static com.ebsco.common.constants.Constants.CASES_URI;

public class Cases {
    public static Case queryCase(String caseId) {
    
    	String loginURL = BaseURI.get()+CASES_URI+caseId;
    	System.out.println(loginURL);
		RequestSpecification request = RestAssured.given().auth().oauth2(BaseURI.getAccessToken());
		Response response = request.get(loginURL);
		ResponseBody body = response.getBody();
		Case responseCase = body.as(Case.class);
		return responseCase;
    
    }


}
