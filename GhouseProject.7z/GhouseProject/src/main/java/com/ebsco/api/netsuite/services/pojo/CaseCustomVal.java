package com.ebsco.api.netsuite.services.pojo;

import com.netsuite.suitetalk.proxy.v2017_2.lists.support.SupportCase;

public class CaseCustomVal extends SupportCase {


    private String productInterface;
    private String areOfSupport;
    private String caseCategory;
    private String caseStatus;
    private String institution;
    private String caseContact;
    private String caseCreatedDate;
    private String caseLastModifiedDate;
    private String lastMessageDate;
    private String caseClosedDate;
    private String assignedTo;
    private String caseOrigin;

    public String getAreOfSupport() {
        return areOfSupport;
    }

    public void setAreOfSupport(String areOfSupport) {
        this.areOfSupport = areOfSupport;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public String getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }

    public String getProductInterface() {
        return productInterface;
    }

    public void setProductInterface(String productInterface) {
        this.productInterface = productInterface;
    }

    public String getCaseCategory() {
        return caseCategory;
    }

    public void setCaseCategory(String caseCategory) {
        this.caseCategory = caseCategory;
    }

    public String getCaseStatus() {
        return caseStatus;
    }

    public void setCaseStatus(String caseStatus) {
        this.caseStatus = caseStatus;
    }

//    @Override
//    public String getLastMessageDate() {
//        return lastMessageDate;
//    }

    public String getCaseContact() {
        return caseContact;
    }

    public void setCaseContact(String caseContact) {
        this.caseContact = caseContact;
    }

    public String getCaseCreatedDate() {
        return caseCreatedDate;
    }

    public void setCaseCreatedDate(String caseCreatedDate) {
        this.caseCreatedDate = caseCreatedDate;
    }

    public String getCaseLastModifiedDate() {
        return caseLastModifiedDate;
    }

    public void setCaseLastModifiedDate(String caseLastModifiedDate) {
        this.caseLastModifiedDate = caseLastModifiedDate;
    }

    public void setLastMessageDate(String lastMessageDate) {
        this.lastMessageDate = lastMessageDate;
    }

    public String getCaseClosedDate() {
        return caseClosedDate;
    }

    public void setCaseClosedDate(String caseClosedDate) {
        this.caseClosedDate = caseClosedDate;
    }

    public String getCaseOrigin() {
        return caseOrigin;
    }

    public void setCaseOrigin(String caseOrigin) {
        this.caseOrigin = caseOrigin;
    }

    public void setStatus(String string) {
    }
}
