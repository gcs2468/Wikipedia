package com.ebsco.api.salesforce.services;

import com.ebsco.api.salesforce.UtilitySF;
import com.ebsco.api.salesforce.pojo.Message;
import com.ebsco.api.salesforce.pojo.MessageAll;
import com.ebsco.api.utilities.BaseURI;
import com.ebsco.common.utility.AppProperties;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.PropertyNames.MESSAGES_QUERY_FILE;

public class MessagesAll {


    private static Map<String, Message> records;
    public static Map<String, Message> retrieveMessages() {
        ResponseBody body = UtilitySF.getResponseBody(MESSAGES_QUERY_FILE);

        MessageAll responseMessage = body.as(MessageAll.class);
        List<Message> totalRecords = new LinkedList<>();
        totalRecords.addAll( responseMessage.getRecords() );

        while (!responseMessage.getDone()) {
            String restURL = BaseURI.getInstanceUrl() + responseMessage.getNextRecordsUrl();
            ResponseBody newBody = UtilitySF.makeRestCall( restURL );
            responseMessage = newBody.as( MessageAll.class );
            totalRecords.addAll( responseMessage.getRecords() );        }

        records = totalRecords
                .stream()
                .collect( Collectors.toMap( Message::getEISNetsuiteRecordIdC,
                        record -> record, (record, record2) -> record2 ) );
        return records;
    }

    public static Map<String, Message> queryMessage() {
        synchronized (MessagesAll.class) {
            if (records == null) {
                records = retrieveMessages();
            }
        }
        return records;
    }

}
