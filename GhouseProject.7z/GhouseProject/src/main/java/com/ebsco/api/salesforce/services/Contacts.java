package com.ebsco.api.salesforce.services;



import com.ebsco.api.utilities.BaseURI;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import com.ebsco.api.salesforce.pojo.Contact;

import static com.ebsco.common.constants.Constants.CONTACTS_URI;

public class Contacts {
    public static Contact queryContact(String contactId) {
    	
    	String loginURL = BaseURI.get()+CONTACTS_URI+contactId;
    	System.out.println(loginURL);
		RequestSpecification request = RestAssured.given().auth().oauth2(BaseURI.getAccessToken());
		Response response = request.get(loginURL);
		ResponseBody body = response.getBody();
		Contact responseContact = body.as(Contact.class);
		return responseContact;
    
    }


}
