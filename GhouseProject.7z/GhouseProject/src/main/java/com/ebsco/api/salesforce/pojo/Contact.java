package com.ebsco.api.salesforce.pojo;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

public class Contact {

    @JsonProperty("attributes")
    private Attributes attributes;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("MasterRecordId")
    private Object masterRecordId;
    @JsonProperty("AccountId")
    private String accountId;
    @JsonProperty("LastName")
    private String lastName;
    @JsonProperty("FirstName")
    private String firstName;
    @JsonProperty("Salutation")
    private Object salutation;
    @JsonProperty("MiddleName")
    private Object middleName;
    @JsonProperty("Suffix")
    private Object suffix;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OtherStreet")
    private Object otherStreet;
    @JsonProperty("OtherCity")
    private Object otherCity;
    @JsonProperty("OtherState")
    private Object otherState;
    @JsonProperty("OtherPostalCode")
    private Object otherPostalCode;
    @JsonProperty("OtherCountry")
    private Object otherCountry;
    @JsonProperty("OtherLatitude")
    private Object otherLatitude;
    @JsonProperty("OtherLongitude")
    private Object otherLongitude;
    @JsonProperty("OtherGeocodeAccuracy")
    private Object otherGeocodeAccuracy;
    @JsonProperty("OtherAddress")
    private Object otherAddress;
    @JsonProperty("MailingStreet")
    private Object mailingStreet;
    @JsonProperty("MailingCity")
    private Object mailingCity;
    @JsonProperty("MailingState")
    private Object mailingState;
    @JsonProperty("MailingPostalCode")
    private Object mailingPostalCode;
    @JsonProperty("MailingCountry")
    private Object mailingCountry;
    @JsonProperty("MailingLatitude")
    private Object mailingLatitude;
    @JsonProperty("MailingLongitude")
    private Object mailingLongitude;
    @JsonProperty("MailingGeocodeAccuracy")
    private Object mailingGeocodeAccuracy;
    @JsonProperty("MailingAddress")
    private Object mailingAddress;
    @JsonProperty("Phone")
    private Object phone;
    @JsonProperty("Fax")
    private Object fax;
    @JsonProperty("MobilePhone")
    private Object mobilePhone;
    @JsonProperty("ReportsToId")
    private Object reportsToId;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("Title")
    private String title;
    @JsonProperty("Department")
    private Object department;
    @JsonProperty("OwnerId")
    private String ownerId;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("LastActivityDate")
    private Object lastActivityDate;
    @JsonProperty("LastCURequestDate")
    private Object lastCURequestDate;
    @JsonProperty("LastCUUpdateDate")
    private Object lastCUUpdateDate;
    @JsonProperty("LastViewedDate")
    private String lastViewedDate;
    @JsonProperty("LastReferencedDate")
    private String lastReferencedDate;
    @JsonProperty("EmailBouncedReason")
    private Object emailBouncedReason;
    @JsonProperty("EmailBouncedDate")
    private Object emailBouncedDate;
    @JsonProperty("IsEmailBounced")
    private Boolean isEmailBounced;
    @JsonProperty("PhotoUrl")
    private String photoUrl;
    @JsonProperty("Jigsaw")
    private Object jigsaw;
    @JsonProperty("JigsawContactId")
    private Object jigsawContactId;
    @JsonProperty("EIS_Inactive__c")
    private Boolean eISInactiveC;
    @JsonProperty("EIS_Netsuite_Record_Id__c")
    private String eISNetsuiteRecordIdC;
    @JsonProperty("EIS_Opt_In_To_Parent_Visibility__c")
    private Boolean eISOptInToParentVisibilityC;
    @JsonProperty("EIS_Portal_User_Status__c")
    private Object eISPortalUserStatusC;
    @JsonProperty("Invitation_Sent_Date__c")
    private Object invitationSentDateC;
    @JsonProperty("Org_URL__c")
    private String orgURLC;
    @JsonProperty("Flag__c")
    private Boolean flagC;
    @JsonProperty("EIS_Job_Role__c")
    private Object eISJobRoleC;
    @JsonProperty("Account")
    private Account account;


    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     */
    public Contact() {
    }

    /**
     * @param phone
     * @param emailBouncedReason
     * @param lastCUUpdateDate
     * @param accountId
     * @param mailingCountry
     * @param jigsaw
     * @param createdById
     * @param ownerId
     * @param department
     * @param emailBouncedDate
     * @param reportsToId
     * @param id
     * @param mailingCity
     * @param title
     * @param mailingLongitude
     * @param lastCURequestDate
     * @param systemModstamp
     * @param lastModifiedById
     * @param name
     * @param mailingState
     * @param mailingStreet
     * @param firstName
     * @param createdDate
     * @param lastViewedDate
     * @param isEmailBounced
     * @param middleName
     * @param lastName
     * @param lastReferencedDate
     * @param fax
     * @param masterRecordId
     * @param lastActivityDate
     * @param mailingLatitude
     * @param isDeleted
     * @param suffix
     * @param mailingPostalCode
     * @param mobilePhone
     * @param jigsawContactId
     * @param email
     * @param lastModifiedDate
     * @param mailingGeocodeAccuracy
     * @param attributes
     * @param photoUrl
     * @param salutation
     * @param mailingAddress
     */
    public Contact(Attributes attributes, String id, Boolean isDeleted, Object masterRecordId, String accountId, String lastName, String firstName, Object salutation, Object middleName, Object suffix, String name, Object otherStreet, Object otherCity, Object otherState, Object otherPostalCode, Object otherCountry, Object otherLatitude, Object otherLongitude, Object otherGeocodeAccuracy, Object otherAddress, Object mailingStreet, Object mailingCity, Object mailingState, Object mailingPostalCode, Object mailingCountry, Object mailingLatitude, Object mailingLongitude, Object mailingGeocodeAccuracy, Object mailingAddress, Object phone, Object fax, Object mobilePhone, Object reportsToId, String email, String title, Object department, String ownerId, String createdDate, String createdById, String lastModifiedDate, String lastModifiedById, String systemModstamp, Object lastActivityDate, Object lastCURequestDate, Object lastCUUpdateDate, String lastViewedDate, String lastReferencedDate, Object emailBouncedReason, Object emailBouncedDate, Boolean isEmailBounced, String photoUrl, Object jigsaw, Object jigsawContactId, Boolean eISInactiveC, String eISNetsuiteRecordIdC, Boolean eISOptInToParentVisibilityC, Object eISPortalUserStatusC, Object invitationSentDateC, String orgURLC, Boolean flagC, Object eISJobRoleC, Account account) {
        super();
        this.attributes = attributes;
        this.id = id;
        this.isDeleted = isDeleted;
        this.masterRecordId = masterRecordId;
        this.accountId = accountId;
        this.lastName = lastName;
        this.firstName = firstName;
        this.salutation = salutation;
        this.middleName = middleName;
        this.suffix = suffix;
        this.name = name;
        this.otherStreet = otherStreet;
        this.otherCity = otherCity;
        this.otherState = otherState;
        this.otherPostalCode = otherPostalCode;
        this.otherCountry = otherCountry;
        this.otherLatitude = otherLatitude;
        this.otherLongitude = otherLongitude;
        this.otherGeocodeAccuracy = otherGeocodeAccuracy;
        this.otherAddress = otherAddress;
        this.mailingStreet = mailingStreet;
        this.mailingCity = mailingCity;
        this.mailingState = mailingState;
        this.mailingPostalCode = mailingPostalCode;
        this.mailingCountry = mailingCountry;
        this.mailingLatitude = mailingLatitude;
        this.mailingLongitude = mailingLongitude;
        this.mailingGeocodeAccuracy = mailingGeocodeAccuracy;
        this.mailingAddress = mailingAddress;
        this.phone = phone;
        this.fax = fax;
        this.mobilePhone = mobilePhone;
        this.reportsToId = reportsToId;
        this.email = email;
        this.title = title;
        this.department = department;
        this.ownerId = ownerId;
        this.createdDate = createdDate;
        this.createdById = createdById;
        this.lastModifiedDate = lastModifiedDate;
        this.lastModifiedById = lastModifiedById;
        this.systemModstamp = systemModstamp;
        this.lastActivityDate = lastActivityDate;
        this.lastCURequestDate = lastCURequestDate;
        this.lastCUUpdateDate = lastCUUpdateDate;
        this.lastViewedDate = lastViewedDate;
        this.lastReferencedDate = lastReferencedDate;
        this.emailBouncedReason = emailBouncedReason;
        this.emailBouncedDate = emailBouncedDate;
        this.isEmailBounced = isEmailBounced;
        this.photoUrl = photoUrl;
        this.jigsaw = jigsaw;
        this.jigsawContactId = jigsawContactId;
        this.eISInactiveC = eISInactiveC;
        this.eISNetsuiteRecordIdC = eISNetsuiteRecordIdC;
        this.eISOptInToParentVisibilityC = eISOptInToParentVisibilityC;
        this.eISPortalUserStatusC = eISPortalUserStatusC;
        this.invitationSentDateC = invitationSentDateC;
        this.orgURLC = orgURLC;
        this.flagC = flagC;
        this.eISJobRoleC = eISJobRoleC;
        this.account = account;
    }

    @JsonProperty("attributes")
    public Attributes getAttributes() {
        return attributes;
    }

    @JsonProperty("attributes")
    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("MasterRecordId")
    public Object getMasterRecordId() {
        return masterRecordId;
    }

    @JsonProperty("MasterRecordId")
    public void setMasterRecordId(Object masterRecordId) {
        this.masterRecordId = masterRecordId;
    }

    @JsonProperty("AccountId")
    public String getAccountId() {
        return accountId;
    }

    @JsonProperty("AccountId")
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    @JsonProperty("LastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("LastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("FirstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("FirstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("Salutation")
    public Object getSalutation() {
        return salutation;
    }

    @JsonProperty("Salutation")
    public void setSalutation(Object salutation) {
        this.salutation = salutation;
    }

    @JsonProperty("MiddleName")
    public Object getMiddleName() {
        return middleName;
    }

    @JsonProperty("MiddleName")
    public void setMiddleName(Object middleName) {
        this.middleName = middleName;
    }

    @JsonProperty("Suffix")
    public Object getSuffix() {
        return suffix;
    }

    @JsonProperty("Suffix")
    public void setSuffix(Object suffix) {
        this.suffix = suffix;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("OtherStreet")
    public Object getOtherStreet() {
        return otherStreet;
    }

    @JsonProperty("OtherStreet")
    public void setOtherStreet(Object otherStreet) {
        this.otherStreet = otherStreet;
    }

    @JsonProperty("OtherCity")
    public Object getOtherCity() {
        return otherCity;
    }

    @JsonProperty("OtherCity")
    public void setOtherCity(Object otherCity) {
        this.otherCity = otherCity;
    }

    @JsonProperty("OtherState")
    public Object getOtherState() {
        return otherState;
    }

    @JsonProperty("OtherState")
    public void setOtherState(Object otherState) {
        this.otherState = otherState;
    }

    @JsonProperty("OtherPostalCode")
    public Object getOtherPostalCode() {
        return otherPostalCode;
    }

    @JsonProperty("OtherPostalCode")
    public void setOtherPostalCode(Object otherPostalCode) {
        this.otherPostalCode = otherPostalCode;
    }

    @JsonProperty("OtherCountry")
    public Object getOtherCountry() {
        return otherCountry;
    }

    @JsonProperty("OtherCountry")
    public void setOtherCountry(Object otherCountry) {
        this.otherCountry = otherCountry;
    }

    @JsonProperty("OtherLatitude")
    public Object getOtherLatitude() {
        return otherLatitude;
    }

    @JsonProperty("OtherLatitude")
    public void setOtherLatitude(Object otherLatitude) {
        this.otherLatitude = otherLatitude;
    }

    @JsonProperty("OtherLongitude")
    public Object getOtherLongitude() {
        return otherLongitude;
    }

    @JsonProperty("OtherLongitude")
    public void setOtherLongitude(Object otherLongitude) {
        this.otherLongitude = otherLongitude;
    }

    @JsonProperty("OtherGeocodeAccuracy")
    public Object getOtherGeocodeAccuracy() {
        return otherGeocodeAccuracy;
    }

    @JsonProperty("OtherGeocodeAccuracy")
    public void setOtherGeocodeAccuracy(Object otherGeocodeAccuracy) {
        this.otherGeocodeAccuracy = otherGeocodeAccuracy;
    }

    @JsonProperty("OtherAddress")
    public Object getOtherAddress() {
        return otherAddress;
    }

    @JsonProperty("OtherAddress")
    public void setOtherAddress(Object otherAddress) {
        this.otherAddress = otherAddress;
    }

    @JsonProperty("MailingStreet")
    public Object getMailingStreet() {
        return mailingStreet;
    }

    @JsonProperty("MailingStreet")
    public void setMailingStreet(Object mailingStreet) {
        this.mailingStreet = mailingStreet;
    }

    @JsonProperty("MailingCity")
    public Object getMailingCity() {
        return mailingCity;
    }

    @JsonProperty("MailingCity")
    public void setMailingCity(Object mailingCity) {
        this.mailingCity = mailingCity;
    }

    @JsonProperty("MailingState")
    public Object getMailingState() {
        return mailingState;
    }

    @JsonProperty("MailingState")
    public void setMailingState(Object mailingState) {
        this.mailingState = mailingState;
    }

    @JsonProperty("MailingPostalCode")
    public Object getMailingPostalCode() {
        return mailingPostalCode;
    }

    @JsonProperty("MailingPostalCode")
    public void setMailingPostalCode(Object mailingPostalCode) {
        this.mailingPostalCode = mailingPostalCode;
    }

    @JsonProperty("MailingCountry")
    public Object getMailingCountry() {
        return mailingCountry;
    }

    @JsonProperty("MailingCountry")
    public void setMailingCountry(Object mailingCountry) {
        this.mailingCountry = mailingCountry;
    }

    @JsonProperty("MailingLatitude")
    public Object getMailingLatitude() {
        return mailingLatitude;
    }

    @JsonProperty("MailingLatitude")
    public void setMailingLatitude(Object mailingLatitude) {
        this.mailingLatitude = mailingLatitude;
    }

    @JsonProperty("MailingLongitude")
    public Object getMailingLongitude() {
        return mailingLongitude;
    }

    @JsonProperty("MailingLongitude")
    public void setMailingLongitude(Object mailingLongitude) {
        this.mailingLongitude = mailingLongitude;
    }

    @JsonProperty("MailingGeocodeAccuracy")
    public Object getMailingGeocodeAccuracy() {
        return mailingGeocodeAccuracy;
    }

    @JsonProperty("MailingGeocodeAccuracy")
    public void setMailingGeocodeAccuracy(Object mailingGeocodeAccuracy) {
        this.mailingGeocodeAccuracy = mailingGeocodeAccuracy;
    }

    @JsonProperty("MailingAddress")
    public Object getMailingAddress() {
        return mailingAddress;
    }

    @JsonProperty("MailingAddress")
    public void setMailingAddress(Object mailingAddress) {
        this.mailingAddress = mailingAddress;
    }

    @JsonProperty("Phone")
    public Object getPhone() {
        return phone;
    }

    @JsonProperty("Phone")
    public void setPhone(Object phone) {
        this.phone = phone;
    }

    @JsonProperty("Fax")
    public Object getFax() {
        return fax;
    }

    @JsonProperty("Fax")
    public void setFax(Object fax) {
        this.fax = fax;
    }

    @JsonProperty("MobilePhone")
    public Object getMobilePhone() {
        return mobilePhone;
    }

    @JsonProperty("MobilePhone")
    public void setMobilePhone(Object mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    @JsonProperty("ReportsToId")
    public Object getReportsToId() {
        return reportsToId;
    }

    @JsonProperty("ReportsToId")
    public void setReportsToId(Object reportsToId) {
        this.reportsToId = reportsToId;
    }

    @JsonProperty("Email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("Email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("Title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("Title")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("Department")
    public Object getDepartment() {
        return department;
    }

    @JsonProperty("Department")
    public void setDepartment(Object department) {
        this.department = department;
    }

    @JsonProperty("OwnerId")
    public String getOwnerId() {
        return ownerId;
    }

    @JsonProperty("OwnerId")
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("LastActivityDate")
    public Object getLastActivityDate() {
        return lastActivityDate;
    }

    @JsonProperty("LastActivityDate")
    public void setLastActivityDate(Object lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }

    @JsonProperty("LastCURequestDate")
    public Object getLastCURequestDate() {
        return lastCURequestDate;
    }

    @JsonProperty("LastCURequestDate")
    public void setLastCURequestDate(Object lastCURequestDate) {
        this.lastCURequestDate = lastCURequestDate;
    }

    @JsonProperty("LastCUUpdateDate")
    public Object getLastCUUpdateDate() {
        return lastCUUpdateDate;
    }

    @JsonProperty("LastCUUpdateDate")
    public void setLastCUUpdateDate(Object lastCUUpdateDate) {
        this.lastCUUpdateDate = lastCUUpdateDate;
    }

    @JsonProperty("LastViewedDate")
    public String getLastViewedDate() {
        return lastViewedDate;
    }

    @JsonProperty("LastViewedDate")
    public void setLastViewedDate(String lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }

    @JsonProperty("LastReferencedDate")
    public String getLastReferencedDate() {
        return lastReferencedDate;
    }

    @JsonProperty("LastReferencedDate")
    public void setLastReferencedDate(String lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }

    @JsonProperty("EmailBouncedReason")
    public Object getEmailBouncedReason() {
        return emailBouncedReason;
    }

    @JsonProperty("EmailBouncedReason")
    public void setEmailBouncedReason(Object emailBouncedReason) {
        this.emailBouncedReason = emailBouncedReason;
    }

    @JsonProperty("EmailBouncedDate")
    public Object getEmailBouncedDate() {
        return emailBouncedDate;
    }

    @JsonProperty("EmailBouncedDate")
    public void setEmailBouncedDate(Object emailBouncedDate) {
        this.emailBouncedDate = emailBouncedDate;
    }

    @JsonProperty("IsEmailBounced")
    public Boolean getIsEmailBounced() {
        return isEmailBounced;
    }

    @JsonProperty("IsEmailBounced")
    public void setIsEmailBounced(Boolean isEmailBounced) {
        this.isEmailBounced = isEmailBounced;
    }

    @JsonProperty("PhotoUrl")
    public String getPhotoUrl() {
        return photoUrl;
    }

    @JsonProperty("PhotoUrl")
    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    @JsonProperty("Jigsaw")
    public Object getJigsaw() {
        return jigsaw;
    }

    @JsonProperty("Jigsaw")
    public void setJigsaw(Object jigsaw) {
        this.jigsaw = jigsaw;
    }

    @JsonProperty("JigsawContactId")
    public Object getJigsawContactId() {
        return jigsawContactId;
    }

    @JsonProperty("JigsawContactId")
    public void setJigsawContactId(Object jigsawContactId) {
        this.jigsawContactId = jigsawContactId;
    }

    @JsonProperty("EIS_Inactive__c")
    public Boolean getEISInactiveC() {
        return eISInactiveC;
    }

    @JsonProperty("EIS_Inactive__c")
    public void setEISInactiveC(Boolean eISInactiveC) {
        this.eISInactiveC = eISInactiveC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public String getEISNetsuiteRecordIdC() {
        return eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Netsuite_Record_Id__c")
    public void setEISNetsuiteRecordIdC(String eISNetsuiteRecordIdC) {
        this.eISNetsuiteRecordIdC = eISNetsuiteRecordIdC;
    }

    @JsonProperty("EIS_Opt_In_To_Parent_Visibility__c")
    public Boolean getEISOptInToParentVisibilityC() {
        return eISOptInToParentVisibilityC;
    }

    @JsonProperty("EIS_Opt_In_To_Parent_Visibility__c")
    public void setEISOptInToParentVisibilityC(Boolean eISOptInToParentVisibilityC) {
        this.eISOptInToParentVisibilityC = eISOptInToParentVisibilityC;
    }

    @JsonProperty("EIS_Portal_User_Status__c")
    public Object getEISPortalUserStatusC() {
        return eISPortalUserStatusC;
    }

    @JsonProperty("EIS_Portal_User_Status__c")
    public void setEISPortalUserStatusC(Object eISPortalUserStatusC) {
        this.eISPortalUserStatusC = eISPortalUserStatusC;
    }

    @JsonProperty("Invitation_Sent_Date__c")
    public Object getInvitationSentDateC() {
        return invitationSentDateC;
    }

    @JsonProperty("Invitation_Sent_Date__c")
    public void setInvitationSentDateC(Object invitationSentDateC) {
        this.invitationSentDateC = invitationSentDateC;
    }

    @JsonProperty("Org_URL__c")
    public String getOrgURLC() {
        return orgURLC;
    }

    @JsonProperty("Org_URL__c")
    public void setOrgURLC(String orgURLC) {
        this.orgURLC = orgURLC;
    }

    @JsonProperty("Flag__c")
    public Boolean getFlagC() {
        return flagC;
    }

    @JsonProperty("Flag__c")
    public void setFlagC(Boolean flagC) {
        this.flagC = flagC;
    }

    @JsonProperty("EIS_Job_Role__c")
    public Object getEISJobRoleC() {
        return eISJobRoleC;
    }

    @JsonProperty("EIS_Job_Role__c")
    public void setEISJobRoleC(Object eISJobRoleC) {
        this.eISJobRoleC = eISJobRoleC;
    }

    @JsonProperty("Account")
    public Account getAccount() {
        return account;
    }

    @JsonProperty("Account")
    public void setAccount(Account account) {
        this.account = account;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("attributes", attributes).append("id", id).append("isDeleted", isDeleted).append("masterRecordId", masterRecordId).append("accountId", accountId).append("lastName", lastName).append("firstName", firstName).append("salutation", salutation).append("middleName", middleName).append("suffix", suffix).append("name", name).append("otherStreet", otherStreet).append("otherCity", otherCity).append("otherState", otherState).append("otherPostalCode", otherPostalCode).append("otherCountry", otherCountry).append("otherLatitude", otherLatitude).append("otherLongitude", otherLongitude).append("otherGeocodeAccuracy", otherGeocodeAccuracy).append("otherAddress", otherAddress).append("mailingStreet", mailingStreet).append("mailingCity", mailingCity).append("mailingState", mailingState).append("mailingPostalCode", mailingPostalCode).append("mailingCountry", mailingCountry).append("mailingLatitude", mailingLatitude).append("mailingLongitude", mailingLongitude).append("mailingGeocodeAccuracy", mailingGeocodeAccuracy).append("mailingAddress", mailingAddress).append("phone", phone).append("fax", fax).append("mobilePhone", mobilePhone).append("reportsToId", reportsToId).append("email", email).append("title", title).append("department", department).append("ownerId", ownerId).append("createdDate", createdDate).append("createdById", createdById).append("lastModifiedDate", lastModifiedDate).append("lastModifiedById", lastModifiedById).append("systemModstamp", systemModstamp).append("lastActivityDate", lastActivityDate).append("lastCURequestDate", lastCURequestDate).append("lastCUUpdateDate", lastCUUpdateDate).append("lastViewedDate", lastViewedDate).append("lastReferencedDate", lastReferencedDate).append("emailBouncedReason", emailBouncedReason).append("emailBouncedDate", emailBouncedDate).append("isEmailBounced", isEmailBounced).append("photoUrl", photoUrl).append("jigsaw", jigsaw).append("jigsawContactId", jigsawContactId).append("eISInactiveC", eISInactiveC).append("eISNetsuiteRecordIdC", eISNetsuiteRecordIdC).append("eISOptInToParentVisibilityC", eISOptInToParentVisibilityC).append("eISPortalUserStatusC", eISPortalUserStatusC).append("invitationSentDateC", invitationSentDateC).append("orgURLC", orgURLC).append("flagC", flagC).append("eISJobRoleC", eISJobRoleC).append("account", account).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(phone).append(mailingCountry).append(eISJobRoleC).append(jigsaw).append(invitationSentDateC).append(emailBouncedDate).append(otherLongitude).append(mailingCity).append(otherState).append(eISOptInToParentVisibilityC).append(systemModstamp).append(lastModifiedById).append(mailingState).append(createdDate).append(lastViewedDate).append(isEmailBounced).append(otherGeocodeAccuracy).append(middleName).append(lastName).append(fax).append(masterRecordId).append(lastActivityDate).append(mailingLatitude).append(mobilePhone).append(jigsawContactId).append(email).append(otherCity).append(additionalProperties).append(otherAddress).append(mailingAddress).append(flagC).append(emailBouncedReason).append(lastCUUpdateDate).append(accountId).append(createdById).append(ownerId).append(department).append(otherCountry).append(reportsToId).append(id).append(eISInactiveC).append(title).append(mailingLongitude).append(lastCURequestDate).append(eISNetsuiteRecordIdC).append(name).append(mailingStreet).append(firstName).append(eISPortalUserStatusC).append(lastReferencedDate).append(otherStreet).append(orgURLC).append(otherPostalCode).append(isDeleted).append(suffix).append(mailingPostalCode).append(otherLatitude).append(lastModifiedDate).append(mailingGeocodeAccuracy).append(attributes).append(photoUrl).append(salutation).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Contact) == false) {
            return false;
        }
        Contact rhs = ((Contact) other);
        return new EqualsBuilder().append(phone, rhs.phone).append(mailingCountry, rhs.mailingCountry).append(eISJobRoleC, rhs.eISJobRoleC).append(jigsaw, rhs.jigsaw).append(invitationSentDateC, rhs.invitationSentDateC).append(emailBouncedDate, rhs.emailBouncedDate).append(otherLongitude, rhs.otherLongitude).append(mailingCity, rhs.mailingCity).append(otherState, rhs.otherState).append(eISOptInToParentVisibilityC, rhs.eISOptInToParentVisibilityC).append(systemModstamp, rhs.systemModstamp).append(lastModifiedById, rhs.lastModifiedById).append(mailingState, rhs.mailingState).append(createdDate, rhs.createdDate).append(lastViewedDate, rhs.lastViewedDate).append(isEmailBounced, rhs.isEmailBounced).append(otherGeocodeAccuracy, rhs.otherGeocodeAccuracy).append(middleName, rhs.middleName).append(lastName, rhs.lastName).append(fax, rhs.fax).append(masterRecordId, rhs.masterRecordId).append(lastActivityDate, rhs.lastActivityDate).append(mailingLatitude, rhs.mailingLatitude).append(mobilePhone, rhs.mobilePhone).append(jigsawContactId, rhs.jigsawContactId).append(email, rhs.email).append(otherCity, rhs.otherCity).append(additionalProperties, rhs.additionalProperties).append(otherAddress, rhs.otherAddress).append(mailingAddress, rhs.mailingAddress).append(flagC, rhs.flagC).append(emailBouncedReason, rhs.emailBouncedReason).append(lastCUUpdateDate, rhs.lastCUUpdateDate).append(accountId, rhs.accountId).append(createdById, rhs.createdById).append(ownerId, rhs.ownerId).append(department, rhs.department).append(otherCountry, rhs.otherCountry).append(reportsToId, rhs.reportsToId).append(id, rhs.id).append(eISInactiveC, rhs.eISInactiveC).append(title, rhs.title).append(mailingLongitude, rhs.mailingLongitude).append(lastCURequestDate, rhs.lastCURequestDate).append(eISNetsuiteRecordIdC, rhs.eISNetsuiteRecordIdC).append(name, rhs.name).append(mailingStreet, rhs.mailingStreet).append(firstName, rhs.firstName).append(eISPortalUserStatusC, rhs.eISPortalUserStatusC).append(lastReferencedDate, rhs.lastReferencedDate).append(otherStreet, rhs.otherStreet).append(orgURLC, rhs.orgURLC).append(otherPostalCode, rhs.otherPostalCode).append(isDeleted, rhs.isDeleted).append(suffix, rhs.suffix).append(mailingPostalCode, rhs.mailingPostalCode).append(otherLatitude, rhs.otherLatitude).append(lastModifiedDate, rhs.lastModifiedDate).append(mailingGeocodeAccuracy, rhs.mailingGeocodeAccuracy).append(attributes, rhs.attributes).append(photoUrl, rhs.photoUrl).append(salutation, rhs.salutation).isEquals();
    }

}