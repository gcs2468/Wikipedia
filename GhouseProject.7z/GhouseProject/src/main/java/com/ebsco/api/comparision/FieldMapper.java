package com.ebsco.api.comparision;


@FunctionalInterface
/**
 * Applies mappings which define the equality of two records.
 */
public interface FieldMapper {
    void applyMappings();
}