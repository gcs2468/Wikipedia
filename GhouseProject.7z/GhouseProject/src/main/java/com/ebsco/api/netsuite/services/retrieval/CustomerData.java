package com.ebsco.api.netsuite.services.retrieval;

import com.ebsco.api.model.utility.comparison.Country;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnection;
import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.api.netsuite.services.pojo.CustomerCustomVal;
import com.ebsco.common.utility.AppProperties;
import com.netsuite.suitetalk.proxy.v2017_2.lists.relationships.CustomerAddressbook;
import com.netsuite.suitetalk.proxy.v2017_2.lists.relationships.CustomerAddressbookList;
import com.netsuite.suitetalk.proxy.v2017_2.platform.common.Address;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.PropertyNames.CUSTOMERS_RETRIEVE_SQL_PROPERTY;

public class CustomerData extends AbstractRecord<CustomerCustomVal> {

    @Override
    public Map<String, CustomerCustomVal> get(List<String> idList, NetSuiteConnectionPool pool) throws Exception {

        String sql = AppProperties.getValueFor( CUSTOMERS_RETRIEVE_SQL_PROPERTY );
        sql += listToString( idList );
        NetSuiteConnection connection = pool.acquire();
        Statement statement = connection.getStatement();
        Map<String, CustomerCustomVal> customerMap = new HashMap<>();
        try (ResultSet resultSet = statement.executeQuery( sql )) {
            while (resultSet.next()) {
                CustomerCustomVal customerCustomVal = new CustomerCustomVal();
                customerCustomVal.setInternalId( resultSet.getString( "CUSTOMER_ID" ).replaceAll( ".0","" ) );
                customerCustomVal.setEntityId( resultSet.getString( "FULL_NAME" ) );
                customerCustomVal.setCompanyName( resultSet.getString( "COMPANYNAME" ) );
                Address address = new Address();
                address.setAddr1( resultSet.getString( "BILLADDRESS" ).replace( "\n", "" ) );//BillAddress
                address.setState( resultSet.getString( "STATE" ) );
                address.setCountry( new Country( resultSet.getString( "COUNTRY" ) ) );
                address.setZip( resultSet.getString( "ZIPCODE" ) );
                CustomerAddressbook addressbook = new CustomerAddressbook();
                addressbook.setAddressbookAddress( address );
                CustomerAddressbook[] addressBookArr = {addressbook};
                CustomerAddressbookList addrList = new CustomerAddressbookList();
                addrList.setAddressbook( addressBookArr );
                customerCustomVal.setAddressbookList( addrList );
                customerCustomVal.setExternalId( resultSet.getString( "SF_ACCOUNT_ID" ) );
                customerCustomVal.setCustomerSatisfaction( resultSet.getString( "NAME" ) );
                customerCustomVal.setMarket( resultSet.getString( "MARKET_NAME" ) );
                customerCustomVal.setSegment( resultSet.getString( "SEGMENT1_NAME" ) );
                customerCustomVal.setOptInToParentVisibility( resultSet.getString( "CXP_OPT_IN_TO_PARENT_VISIBILI" ) );
                customerCustomVal.setCasCustomerLevel( resultSet.getString( "LIST_ITEM_NAME" ) );
                customerMap.put( customerCustomVal.getInternalId(), customerCustomVal );
            }
        }
        pool.free( connection );
        return customerMap;
    }

}