package com.ebsco.api.salesforce.services;

import com.ebsco.api.salesforce.UtilitySF;
import com.ebsco.api.salesforce.pojo.Contact;
import com.ebsco.api.salesforce.pojo.ContactAll;
import com.ebsco.api.salesforce.pojo.Record;
import com.ebsco.common.utility.AppProperties;
import com.ebsco.api.utilities.BaseURI;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.PropertyNames.CONTACT_QUERY_FILE;

public class ContactsAll {


    private static Map<String, Contact> records;
    public static Map<String, Contact> retrieveAccounts() {

        ResponseBody body = UtilitySF.getResponseBody( CONTACT_QUERY_FILE );
        ContactAll responseContact = body.as( ContactAll.class );

        //First time
        List<Contact> totalRecords = new LinkedList<>();
        totalRecords.addAll( responseContact.getRecords() );

        while (!responseContact.getDone()) {
            String restURL = BaseURI.getInstanceUrl() + responseContact.getNextRecordsUrl();
            ResponseBody newBody = UtilitySF.makeRestCall( restURL );
            responseContact = newBody.as( ContactAll.class );
            totalRecords.addAll( responseContact.getRecords() );        }

        records = totalRecords
                .stream()
                .collect( Collectors.toMap( Contact::getId,
                        record -> record, (record, record2) -> record2 ) );
        return records;
    }

    public static Map<String, Contact> queryContact() {
        synchronized (ContactsAll.class) {
            if (records == null) {
                records = retrieveAccounts();
            }
        }
        return records;
    }

}
