package com.ebsco.api.netsuite.services.connection;

import com.ebsco.api.model.pool.Poolable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import static com.ebsco.common.utility.AppProperties.getValueFor;

public class NetSuiteConnection implements Poolable {
    private final String USER_NAME = getValueFor( "email" );
    private final String PASSWORD = getValueFor( "password" );
    private final String NETSUITE_DRIVER = getValueFor( "netsuite.driver.class" );
    private final String CONNECTION_URL = getValueFor( "db.url" )
            + getValueFor( "account" ) +
            ";RoleID=" + getValueFor( "roleId" ) + ")";
    private Logger logger = LogManager.getLogger( NetSuiteConnection.class );
    private Connection connection;

    @Override
    public void init() {
        if (isOpened()) return;
        try {
            logger.info( "Connecting.." );
            Class.forName( NETSUITE_DRIVER );
            connection = DriverManager.getConnection( CONNECTION_URL, USER_NAME, PASSWORD );
            logger.info( "Connection to NetSuite established." );
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void close() {
        if (!isOpened()) return;

        try {
            logger.info( "Closing connection...do not abort program." );
            connection.close();
            connection = null;
            logger.info( "Connection successfully closed." );
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Statement getStatement() throws SQLException {
        if (!isOpened()) init();
        return connection.createStatement();
    }

    private boolean isOpened() {
        return connection != null;
    }
}
