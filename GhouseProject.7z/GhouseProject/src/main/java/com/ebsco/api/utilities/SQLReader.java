package com.ebsco.api.utilities;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static com.ebsco.common.constants.FilePaths.SQL_PROPERTY_FILE_PATH;

/**
 * Reads SQL Queries from SQL Property file.
 */
public class SQLReader {
    private static Properties sqlQueries;

    static {
        sqlQueries = new Properties();
        try {
            sqlQueries.load(new FileInputStream(new File(SQL_PROPERTY_FILE_PATH)));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getSql(String sqlPropertyName) {
        return sqlQueries.getProperty(sqlPropertyName);
    }
}
