package com.ebsco.api.netsuite.services.utils.services;

import com.netsuite.suitetalk.client.v2017_2.WsClient;
import com.netsuite.suitetalk.proxy.v2017_2.platform.core.types.RecordType;
import com.netsuite.suitetalk.proxy.v2017_2.platform.messages.ReadResponse;

import static com.netsuite.suitetalk.client.v2017_2.utils.Utils.createRecordRef;

public class CustomerOperations {
    public ReadResponse getCustomer(final WsClient client, final String internalId) throws Exception {
        ReadResponse response = client.callGetRecord( createRecordRef( internalId, RecordType.customer ) );
        return response;
    }

    public ReadResponse getContact(final WsClient client, final String internalId) throws Exception {
        ReadResponse response = client.callGetRecord( createRecordRef( internalId, RecordType.contact ) );
        return response;
    }


}
