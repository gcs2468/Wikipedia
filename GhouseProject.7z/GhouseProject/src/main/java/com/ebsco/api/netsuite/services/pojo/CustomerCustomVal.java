package com.ebsco.api.netsuite.services.pojo;

import com.netsuite.suitetalk.proxy.v2017_2.lists.relationships.Customer;

public class CustomerCustomVal extends Customer {


    private String CustomerSatisfaction;
    private String casCustomerLevel;
    private String market;
    private String segment;
    private String optInToParentVisibility;

    public String getOptInToParentVisibility() {
        return optInToParentVisibility;
    }

    public void setOptInToParentVisibility(String optInToParentVisibility) {
        this.optInToParentVisibility = optInToParentVisibility;
    }

    public String getCasCustomerLevel() {
        return casCustomerLevel;
    }

    public void setCasCustomerLevel(String casCustomerLevel) {
        this.casCustomerLevel = casCustomerLevel;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getCustomerSatisfaction() {
        return CustomerSatisfaction;
    }

    public void setCustomerSatisfaction(String customerSatisfaction) {
        CustomerSatisfaction = customerSatisfaction;
    }

}
