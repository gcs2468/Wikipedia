package com.ebsco.api.netsuite.services.utils.suit.talk;

import com.ebsco.api.netsuite.services.utils.services.Messages;
import com.netsuite.suitetalk.proxy.v2017_2.platform.core.RecordRef;
import com.netsuite.suitetalk.proxy.v2017_2.platform.core.SearchResult;
import com.netsuite.suitetalk.proxy.v2017_2.platform.core.StatusDetail;
import com.netsuite.suitetalk.proxy.v2017_2.platform.messages.ReadResponse;
import com.netsuite.suitetalk.proxy.v2017_2.platform.messages.WriteResponse;


/**
 * <p>Utils class containing some convenient methods for parsing information from SOAP responses.</p>
 * <p>© 2017 NetSuite Inc. All rights reserved.</p>
 */
public final class ParsingUtils {

    private ParsingUtils() {
    }

    public static String getInternalId(WriteResponse response) {
        if (response == null || response.getBaseRef() == null) {
            return Messages.NOT_AVAILABLE;
        }
        return ((RecordRef) response.getBaseRef()).getInternalId();
    }

    public static String getErrorMessage(ReadResponse response) {
        if (response == null || response.getStatus() == null) {
            return Messages.NOT_AVAILABLE;
        }
        return getErrorMessage( response.getStatus().getStatusDetail() );
    }

    public static String getErrorMessage(WriteResponse response) {
        if (response == null || response.getStatus() == null) {
            return Messages.NOT_AVAILABLE;
        }
        return getErrorMessage( response.getStatus().getStatusDetail() );
    }

    public static String getErrorMessage(SearchResult searchResult) {
        if (searchResult == null || searchResult.getStatus() == null) {
            return Messages.NOT_AVAILABLE;
        }
        return getErrorMessage( searchResult.getStatus().getStatusDetail() );
    }

    public static String getErrorMessage(StatusDetail[] statusDetails) {
        if (statusDetails == null || statusDetails.length == 0) {
            return Messages.NOT_AVAILABLE;
        }
        String errorMessage = statusDetails[0].getMessage();
        return errorMessage == null ? Messages.NOT_AVAILABLE : errorMessage;
    }
}
