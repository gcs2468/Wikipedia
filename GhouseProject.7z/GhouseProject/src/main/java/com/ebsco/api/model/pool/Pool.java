package com.ebsco.api.model.pool;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public abstract class Pool<T extends Poolable> {

    private Logger logger = LogManager.getLogger(this);
    protected Queue<T> freeObjects;
    protected Queue<T> occupiedObjects;

    public Pool()  {
        freeObjects = new ConcurrentLinkedQueue<>();
        occupiedObjects = new ConcurrentLinkedQueue<>();
    }

    public synchronized void free(T obj) {
        occupiedObjects.remove(obj);
        freeObjects.add(obj);
        logger.info("Freeing an object.");
    }

    public synchronized T acquire() {
        logger.info("Acquiring an object.");
        T occupiedObj = freeObjects.remove();
        occupiedObjects.add(occupiedObj);
        return occupiedObj;
    }

    public void initAll() {
        logger.info("Initializing objects in pool. ");
        freeObjects.parallelStream().forEach(Poolable::init);
    }

    protected void addNew(T obj) {
        freeObjects.add(obj);
    }

    public synchronized void destroyAll() {
        occupiedObjects.forEach(this::free);
        freeObjects.parallelStream().forEach(Closeable::close);
    }
}

