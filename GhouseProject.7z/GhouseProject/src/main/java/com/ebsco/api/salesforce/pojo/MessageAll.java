package com.ebsco.api.salesforce.pojo;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "totalSize",
        "done",
        "records"
})
public class MessageAll {

    @JsonProperty("totalSize")
    private Integer totalSize;
    @JsonProperty("done")
    private Boolean done;
    @JsonProperty("records")
    private List<Message> records = null;

    public String getNextRecordsUrl() {
        return nextRecordsUrl;
    }

    public void setNextRecordsUrl(String nextRecordsUrl) {
        this.nextRecordsUrl = nextRecordsUrl;
    }

    @JsonProperty("nextRecordsUrl")
    private String nextRecordsUrl;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     *
     */
    public MessageAll() {
    }

    /**
     *
     * @param done
     * @param records
     * @param totalSize
     */
    public MessageAll(Integer totalSize, Boolean done, List<Message> records) {
        super();
        this.totalSize = totalSize;
        this.done = done;
        this.records = records;
    }

    @JsonProperty("totalSize")
    public Integer getTotalSize() {
        return totalSize;
    }

    @JsonProperty("totalSize")
    public void setTotalSize(Integer totalSize) {
        this.totalSize = totalSize;
    }

    @JsonProperty("done")
    public Boolean getDone() {
        return done;
    }

    @JsonProperty("done")
    public void setDone(Boolean done) {
        this.done = done;
    }

    @JsonProperty("records")
    public List<Message> getRecords() {
        return records;
    }

    @JsonProperty("records")
    public void setRecords(List<Message> records) {
        this.records = records;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("totalSize", totalSize).append("done", done).append("records", records).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(additionalProperties).append(done).append(records).append(totalSize).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MessageAll) == false) {
            return false;
        }
        MessageAll rhs = ((MessageAll) other);
        return new EqualsBuilder().append(additionalProperties, rhs.additionalProperties).append(done, rhs.done).append(records, rhs.records).append(totalSize, rhs.totalSize).isEquals();
    }

}
