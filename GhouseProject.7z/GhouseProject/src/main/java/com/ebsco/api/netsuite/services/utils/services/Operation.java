package com.ebsco.api.netsuite.services.utils.services;

import java.rmi.RemoteException;

/**
 * <p>Functional interface for storing sample operation into option included in {@code OptionList}.</p>
 * <p>© 2017 NetSuite Inc. All rights reserved.</p>
 */
@FunctionalInterface
public interface Operation {
    void performOperation() throws RemoteException;
}
