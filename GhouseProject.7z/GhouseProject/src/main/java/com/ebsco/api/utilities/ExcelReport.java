package com.ebsco.api.utilities;

import com.ebsco.api.model.report.ReportData;
import com.ebsco.common.constants.FilePaths;
import io.qameta.allure.Attachment;
import io.qameta.allure.Step;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Queue;

/**
 * Utility class to write data to Excel sheet.
 */
public class ExcelReport {

    private StringBuilder reportData;
    private String destFile;
    private Logger logger = LogManager.getLogger(this.getClass());

    public ExcelReport(String destFile) {
        reportData = new StringBuilder("");
        this.destFile = destFile;
    }

    /**
     * Prepare data to be committed to the file.
     *
     * @param dataAsTable  consisting of data where values in first row are treated as headings for columns.
     * @param printHeading skips the first row of reportData if false, otherwise writes to file.
     */
    public void prepareExcelData(String[][] dataAsTable, boolean printHeading) {
        int colSize = dataAsTable[0].length;
        int rowSize = dataAsTable.length;
        int startRow = (printHeading) ? 0 : 1;

        for (int i = startRow; i < rowSize; i++) {
            for (int j = 0; j < colSize; j++) {
                String cellData = dataAsTable[i][j].replaceAll(",", "");
                cellData = cellData.replaceAll("[\r\n]", "");
                reportData.append(cellData);
                if (j != colSize - 1) {
                    reportData.append(", ");
                }
            }
            reportData.append(System.lineSeparator());
        }

        //One line space between excel records.
        //Eases filtration of customer records.
        for (int i = 0; i < colSize; i++) {
            reportData.append((i == colSize - 1) ? (" " + System.lineSeparator()) : (","));
        }
    }

    /**
     * Writes the data to the file.
     * After committing, no data which is already written persists i.e, for the next commit the data used for
     * previous commit is not committed again.
     *
     * @throws IOException if I/O error occurs.
     */
    public void commit() throws IOException {
        if (!Files.exists(Paths.get(destFile))) {
            Files.createFile(Paths.get(destFile));
        }
System.out.println("Total no of records ::"+reportData.toString().split(System.lineSeparator() ).length  );
        Files.write(Paths.get(destFile), "".getBytes(), StandardOpenOption.TRUNCATE_EXISTING);
        Files.write(Paths.get(destFile), reportData.toString().getBytes(), StandardOpenOption.APPEND);
        reportData = new StringBuilder("");
    }

    /**
     * Attaches the excel file to allure report.
     *
     * @throws Exception in case of error.
     */

    /**
     * Prepares excel data for the queue. Headings only for the first ReportData is written.
     *
     * @param reportData set containing Reportdata objects.
     */
    public void prepareExcel(Queue<ReportData> reportData) {
        //Make column for the first report data.
        prepareExcelData(reportData.peek().getDataAsTable(), true);
        reportData.stream()
                .distinct()
                .skip(1)
                .map(ReportData::getDataAsTable)
                .forEach(report -> this.prepareExcelData(report, false));
//        logger.info("Size of the reportdata set is " + reportData.size());
    }

    public static void attachExcelToAllureReport() throws Exception {
        saveXlsxAttachment(FilePaths.REPORT_FILE);
    }


    @Attachment(value = "Comparision Report Sheet", type = "text/csv", fileExtension = ".csv")
    public static byte[] saveXlsxAttachment(String filePath) throws Exception {
        return getSampleFile(filePath);
    }

    @Attachment(value="{0},{1}", type = "text/csv", fileExtension = ".csv")
    public static byte[] test(String test,String filePath) throws Exception {
//        return getSampleFile(filePath);
        return new byte[0];
    }

    private static byte[] getSampleFile(String fileName) throws Exception {
        File file = new File(fileName);
        return Files.readAllBytes(Paths.get(file.getAbsolutePath()));
    }



    @Step("{0}:{1}")
    public static String captureTime(String message, String value)
    {
        return value;
    }

}
