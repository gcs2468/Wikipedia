package com.ebsco.api.netsuite.services.client;

import com.ebsco.api.netsuite.services.utils.services.Properties;
import com.ebsco.api.netsuite.services.utils.services.WsClientFactory;
import com.netsuite.suitetalk.client.v2017_2.WsClient;

import java.io.IOException;

public class NetSuiteClient {

    private static NetSuiteClient netSuiteClient;

    private static WsClient wsClient;
    private NetSuiteClient() {}

    public static NetSuiteClient getInstance() {
        if (netSuiteClient == null) {
            netSuiteClient = new NetSuiteClient();
        }
        return netSuiteClient;
    }

    public static WsClient getWsClient() {
        if (wsClient == null) {
            try {
                wsClient = WsClientFactory.getWsClient(new Properties());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return wsClient;
    }
}