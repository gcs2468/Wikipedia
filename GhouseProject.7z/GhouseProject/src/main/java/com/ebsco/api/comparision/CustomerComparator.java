package com.ebsco.api.comparision;

import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import com.ebsco.api.netsuite.services.pojo.CustomerCustomVal;
import com.ebsco.api.salesforce.pojo.Record;
import com.ebsco.api.utilities.CountryMapper;
import com.netsuite.suitetalk.proxy.v2017_2.platform.common.Address;

import java.util.Objects;

public class CustomerComparator extends AbstractRecordComparator<CustomerCustomVal, Record> {

    /**
     * Applies mapping in such a way that:
     * 1. Key: NetSuiteField name
     * 2. Value: FieldRecord consisting corresponding netsuite field value and
     * the salesforce field value.
     * It's sufficient to invoke this method once to register the mappings.
     */
    @Override
    public void applyMappings() {
        Address customerAddr = netSuiteRecord.getAddressbookList().getAddressbook()[0].getAddressbookAddress();
        salesForceRecord.setBillingStreet( salesForceRecord.getBillingStreet().replaceAll( "\n", "" ) );
        map.put( new FieldName( "NetSuite Internal Id", "Netsuite Record Id" ),
                new FieldValue( netSuiteRecord.getInternalId(), salesForceRecord.getEISNetsuiteRecordIdC() ) );

        map.put( new FieldName( "Customer Id", "Netsuite Customer Id" ),
                new FieldValue( netSuiteRecord.getEntityId(), salesForceRecord.getEISNetsuiteCustomerIdC() ) );

        map.put( new FieldName( "Customer Site Name", "Account Name" ),
                new FieldValue( netSuiteRecord.getCompanyName(), salesForceRecord.getName() ) );

        String partOfMainAddr1 = Objects.toString(netSuiteRecord.getCompanyName(), "");
        String partOfMainAddr2 = Objects.toString(customerAddr.getAddr1(), "");
        String partOfMainAddr3 = Objects.toString(customerAddr.getAddr2(), "");
        String mainAddress = partOfMainAddr1 + partOfMainAddr2 + partOfMainAddr3;
        map.put(new FieldName("Main Address", "Billing Street"),
                new FieldValue(mainAddress, salesForceRecord.getBillingStreet()));

        map.put(new FieldName("State", "Billing State"),
                new FieldValue(customerAddr.getState(), salesForceRecord.getBillingState()));

        map.put(new FieldName("Country", "Billing Country"),
                new FieldValue(CountryMapper.getFullCountryName(customerAddr.getCountry().toString()), salesForceRecord.getBillingCountry()));

        map.put(new FieldName("Zip", "Billing Postal Code"),
                new FieldValue(customerAddr.getZip(), salesForceRecord.getBillingPostalCode()));

        map.put( new FieldName( "Customer Satisfaction", "Customer Satisfaction" ),
                new FieldValue( netSuiteRecord.getCustomerSatisfaction(), salesForceRecord.getEISCustomerSatisfactionC() ) );

        map.put( new FieldName( "CAS Customer Level", "CAS Customer Level" ),
                new FieldValue( netSuiteRecord.getCasCustomerLevel(), salesForceRecord.getEISCASCustomerLevelC() ) );

        map.put( new FieldName( "Market", "Market" ),
                new FieldValue( netSuiteRecord.getMarket(), salesForceRecord.getEISMarketC() ) );

        map.put( new FieldName( "Segment", "Segment" ),
                new FieldValue( netSuiteRecord.getSegment(), salesForceRecord.getEISSegmentC() ) );

        map.put( new FieldName( "Opt In To Parent Visibility", "Opt In To Parent Visibility" ),
                new FieldValue( netSuiteRecord.getOptInToParentVisibility(), salesForceRecord.getOptInToParentVisibilityC(),transformParentVisibility( netSuiteRecord.getOptInToParentVisibility() ) ) );

    }

    public String transformParentVisibility(String isVisible) {
    return String.valueOf(isVisible.equalsIgnoreCase("t"));
    }

}
