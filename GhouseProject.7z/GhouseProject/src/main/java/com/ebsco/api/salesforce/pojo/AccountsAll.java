package com.ebsco.api.salesforce.pojo;

import com.ebsco.api.salesforce.UtilitySF;
import com.ebsco.api.utilities.BaseURI;
import io.restassured.response.ResponseBody;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ebsco.common.constants.PropertyNames.ACCOUNT_QUERY_FILE;

public class AccountsAll {

    private static Map<String, Record> records;

    private static Map<String, Record> retrieveAccounts() {
        ResponseBody body = UtilitySF.getResponseBody( ACCOUNT_QUERY_FILE );
        AccountAll responseAccount = body.as( AccountAll.class );

        //First time
        List<Record> totalRecords = new LinkedList<>();
        totalRecords.addAll( responseAccount.getRecords() );

        while (!responseAccount.getDone()) {
            String restURL = BaseURI.getInstanceUrl() + responseAccount.getNextRecordsUrl();
            ResponseBody newBody = UtilitySF.makeRestCall( restURL );
            responseAccount = newBody.as( AccountAll.class );
            totalRecords.addAll( responseAccount.getRecords() );
        }

        records = totalRecords
                .stream()
                .collect( Collectors.toMap( Record::getId,
                        record -> record, (record, record2) -> record2 ) );
        return records;
    }

    public static Map<String, Record> queryAccount() {
        synchronized (AccountsAll.class) {
            if (records == null) {
                records = retrieveAccounts();
            }
        }
        return records;
    }

}
