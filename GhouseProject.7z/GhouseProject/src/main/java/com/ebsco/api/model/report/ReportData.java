package com.ebsco.api.model.report;

import com.ebsco.api.model.utility.comparison.FieldName;
import com.ebsco.api.model.utility.comparison.FieldValue;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

/**
 * Represents a report showing comparision between two records.
 */
public class ReportData {

    private Logger logger = LogManager.getLogger( this );
    private List<ReportEntity> entities;

    public ReportData() {
        entities = new LinkedList<>();
    }

    private String description;
    private boolean truncatedDataShouldBeAsNotUpdated;

    public void add(FieldName fieldName, FieldValue fieldValue) {
        add( new ReportEntity( fieldName, fieldValue ) );
    }

    public void add(ReportEntity reportEntity) {
        entities.add( reportEntity );
    }

    /**
     * Converts the entities into a two-dimensional array where the first row will be the field tags and the rows
     * following it will be the values.
     *
     * @return a two-dimensional array which represents a table.
     */
    public String[][] getDataAsTable() {
        String[] columnNames = {
                "NetSuite Field Name",
                "SalesForce Field Name",
                "NetSuite Field Value",
                "SalesForce Field Value",
                "Status",
                "Description"
        };

        int size = entities.size();
        String[][] table = new String[size + 1][columnNames.length];

        table[0] = columnNames;
        int rowIndex = 1;
        for (ReportEntity reportEntity : entities) {
            FieldName fieldName = reportEntity.getFieldName();
            FieldValue fieldValue = reportEntity.getFieldValue();

            table[rowIndex][0] = fieldName.getNetSuiteFieldName();
            table[rowIndex][1] = fieldName.getSalesForceFieldName();
            table[rowIndex][2] = fieldValue.getNetSuiteFieldVal();
            table[rowIndex][3] = fieldValue.getSalesForceFieldVal();
            table[rowIndex][4] = (
                    (reportEntity.isStatusIgnorable()) ? "" : fieldValue.areEqual() ? "Matched" : "Mismatched");

            String reportDesc = Objects.toString( description, fieldValue.getDesc() );
            if (truncatedDataShouldBeAsNotUpdated && reportDesc.contains( "Data is truncated." )) {
                reportDesc = "Data not updated.";
            }
            table[rowIndex][5] = (
                    (reportEntity.isDescIgnorable()) ? "" : reportDesc);
            rowIndex++;
        }
        return table;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * For assertions in test case.
     */
    public List<ReportEntity> getEntities() {
        return entities;
    }

    @Override
    public int hashCode() {
        return Objects.hash( entities );
    }

    @Override
    public boolean equals(Object obj) {
        ReportData otherReport = (ReportData) obj;
        return otherReport != null && Objects.equals( entities, otherReport.entities );
    }

    public void markTruncatedDataAsNotUpdated() {
        truncatedDataShouldBeAsNotUpdated = true;
    }
}


