package com.ebsco;

import com.ebsco.api.netsuite.services.connection.NetSuiteConnection;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.api.netsuite.services.retrieval.SIData;
import com.ebsco.common.utility.AppProperties;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DeleteThis {

    public static void main(String[] args) throws Exception {
        NetSuiteConnection conn = new NetSuiteConnection();
        conn.init();
        Statement statement = conn.getStatement();
        ResultSet rs = statement.executeQuery(AppProperties.getValueFor("nssi.retrieve") +
                "BETWEEN 10 AND 150000 AND ROWNUM <= 10 AND SF_SERVICE_ISSUE_ID IS NOT NULL");

        List<String> nsCaseIds = new LinkedList<>();
        while (rs.next()) {
            int cols = rs.getMetaData().getColumnCount();

                System.out.println(rs.getMetaData().getColumnName(1) + " -> " + rs.getString(1));
                nsCaseIds.add(rs.getString(1));

            System.out.println("\n\n\n\n\n");
        }


        System.out.println("All IDS: " + nsCaseIds);
        nsCaseIds = nsCaseIds
                .stream()
                .map(val -> val.replaceAll(".0", ""))
                .collect(Collectors.toList());

        Map<String, ServiceIssue> stringCaseCustomValMap = new SIData().get(nsCaseIds,null);
        stringCaseCustomValMap.forEach((x, y) -> System.out.println(x + "-> " + y.getStatus()));
    }






    }







