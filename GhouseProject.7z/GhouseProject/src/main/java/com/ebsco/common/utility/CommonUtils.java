package com.ebsco.common.utility;

import com.ebsco.common.constants.FilePaths;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.testng.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import static com.ebsco.common.constants.Constants.*;


public class CommonUtils {

    public static String getTime() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HHmmssddMMyy");
        String dt = sdf.format(cal.getTime());
        return dt;
    }

    public static String getTime(String pattern) {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        String dt = sdf.format(cal.getTime());
        return dt;
    }

    public static String convertSFTimeToNSTime (String dateTime,String format,int hoursToAdd,int minutesToAdd)throws Exception
    { Calendar cal= Calendar.getInstance();
        if(dateTime!=null) {
            Date date1 = new SimpleDateFormat( format ).parse( dateTime );
            cal.setTime( date1 );
            cal.add( Calendar.HOUR, hoursToAdd );
            cal.add( Calendar.MINUTE, minutesToAdd );
        }
        return cal.getTime().toString();
    }

    public Map<String, Map<String, String>> readMultipleData(String sheetName) {
        String sKey;
        String sValue;
        Map<String, Map<String, String>> data = new HashMap<>();
        Map<String, String> objMap;
        try {
            HSSFWorkbook objWorkbook = new HSSFWorkbook(new FileInputStream(new File(System.getProperty("user.dir") + FilePaths.DATA_WB)));
            HSSFSheet objSheet = objWorkbook.getSheet(sheetName);
            HSSFRow headerRow = objSheet.getRow(0);

            int iRowCount = objSheet.getLastRowNum();
            int iColCount = objSheet.getRow(0).getLastCellNum();
            for (int iRowCounter = 1; iRowCounter <= iRowCount; iRowCounter++) {
                String firstColVal = objSheet.getRow(iRowCounter).getCell(0).getStringCellValue();
                String secondColVal = objSheet.getRow(iRowCounter).getCell(1).getStringCellValue();
                objMap = new HashMap<>();
                HSSFRow currentRow = objSheet.getRow(iRowCounter);
                for (int iColCounter = 0; iColCounter < iColCount; iColCounter++) {
                    sKey = headerRow.getCell(iColCounter).getStringCellValue();
                    try {
                        sValue = currentRow.getCell(iColCounter).getStringCellValue();
                    } catch (NullPointerException e) {
                        sValue = "";
                    }
                    sValue = sValue.trim();
                    if ((!sValue.equalsIgnoreCase("Null")) && (sValue.trim().length() != 0)) {
                        objMap.put(sKey, sValue);
                    } else {
                        objMap.put(sKey, "");
                    }
                }
                data.put(firstColVal, objMap);
            }
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
        return data;
    }





    public static String timeDifference(String startTime,String endTime)
    {
        SimpleDateFormat format = new SimpleDateFormat(SQL_DATE_FORMAT_dd_MM_YYYY_HH_mm_ss);

        Date d1 = null;
        Date d2 = null;
        try {
            d1 = format.parse(startTime);
            d2 = format.parse(endTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // Get msec from each, and subtract.
        long diff = d2.getTime() - d1.getTime();
        long diffSeconds = diff / 1000 % 60;
        long diffMinutes = diff / (60 * 1000) % 60;
        long diffHours = diff / (60 * 60 * 1000);
//        System.out.println(diffSeconds + "s");
//        System.out.println(diffMinutes + "m");
//        System.out.println( diffHours + "h");

        String totalTimeDiff=diffHours + "h:"+diffMinutes + "m:"+diffSeconds + "s";

        return totalTimeDiff;
    }

    public static String getGMTTime (String dateTime,String format)throws Exception
    {

        SimpleDateFormat localFormat = new SimpleDateFormat(format);
        localFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = localFormat.parse(dateTime);
        SimpleDateFormat gmtFormat = new SimpleDateFormat(format);
        Date time= gmtFormat.parse(localFormat.format(date));
//        dateTime.getTime();
        gmtFormat.format(time);
//        System.out.println(localFormat.format(time));
        String outputTime=localFormat.format(time);

        return outputTime;
//        System.out.println(sdf.format(date));
    }

    public static String getTimeWithHoursAdd(int hoursToAdd)
    {
        SimpleDateFormat localFormat = new SimpleDateFormat(SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
        Calendar cal=Calendar.getInstance();
        cal.add(Calendar.HOUR,hoursToAdd);
//        System.out.println(localFormat.format(cal.getTime()));
        String addedHours=localFormat.format(cal.getTime()).toString();
        return addedHours;
    }
}
