package com.ebsco.common.constants;

public class PropertyNames {

    /* This section is for api properties names */
    public static final String CUSTOMERS_RETRIEVE_SQL_PROPERTY = "nscustomers.retrieve";
    public static final String CONTACTS_RETRIEVE_SQL_PROPERTY = "nscontacts.retrieve";
    public static final String ACCOUNT_QUERY_FILE = "sfaccounts.retrieve";
    public static final String CONTACT_QUERY_FILE = "sfcontacts.retrieve";
    public static final String CUSTOMER_BATCH_INPUT_QUERY_FILE="nscustomers.batchretrieve";
    public static final String CASE_BATCH_INPUT_QUERY_FILE="nscase.batchretrieve";
    public static final String CASE_BATCH_TEMP_INPUT_QUERY_FILE="nscase.batchtempretrieve";
    public static final String CASE_SYNC_INPUT_QUERY_FILE="nscase.syncretrieve";
    public static final String CASE_SYNC_TEMP_INPUT_QUERY_FILE="nscase.synctempretrieve";
    public static final String CUSTOMER_INPUT_QUERY_FILE="nscustomers.syncretrieve";
    public static final String CONTACT_BATCH_INPUT_QUERY_FILE="nscontacts.batchretrieve";
    public static final String CONTACT_INPUT_QUERY_FILE="nscontacts.syncretrieve";
    public static final String CUSTOMER_BATCH_INPUT_QUERY_TEMP_FILE="nscustomers.batchtempretrieve";
    public static final String CUSTOMER_INPUT_QUERY_TEMP_FILE="nscustomers.synctempretrieve";
    public static final String CONTACT_BATCH_INPUT_QUERY_TEMP_FILE="nscontacts.batchtempretrieve";
    public static final String CONTACT_INPUT_QUERY_TEMP_FILE="nscontacts.synctempretrieve";
    public static final String CONTACT_QUERY_FILE_LAST_MODIFIED="sfcontacts.retrieve.lastmodified";
    public static final String CONTACT_SYNC_CXP_STATUS_TEMP_QUERY_FILE="nscontacts.synctempretrieve.cxp.status";
    public static final String CONTACT_SYNC_CXP_STATUS_QUERY_FILE="nscontacts.syncretrieve.cxp.status";
    public static final String CONTACT_CXP_STATUS_QUERY_FILE="nscontacts.retrieve.cxp.status";
    public static final String CONTACT_QUERY_FILE_CXP_STATUS="sfcontacts.retrieve.cxp.status";
    public static final String CASE_RETRIEVE_SQL_PROPERTY = "nscase.retrieve";
    public static final String CASE_QUERY_FILE = "sfcase.retrieve";
    public static final String CASE_QUERY_FILE_LAST_MODIFIED="sfcase.retrieve.lastmodified";
    public static final String NS_DIFF_TIME_ADD ="ns.query.sql.difftime.to.add";
    public static final String NS_DIFF_TIME_SUB ="ns.query.sql.difftime.to.sub";
    public static final String SI_RETRIEVE_SQL_PROPERTY ="nssi.retrieve";
    public static final String SI_CASE_RETRIEVE_SQL_PROPERTY ="nssi.case.retrieve";
    public static final String SI_QUERY_FILE = "sfsi.retrieve";
    public static final String SI_CASE_QUERY_FILE = "sfsi.case.retrieve";
    public static final String SI_BATCH_TEMP_INPUT_QUERY_FILE="nssi.batchtempretrieve";
    public static final String SI_BATCH_INPUT_QUERY_FILE="nssi.batchretrieve";
    public static final String MESSAGES_QUERY_FILE="sfmessages.retrieve";
    public static final String MESSAGE_RETRIEVE_SQL_PROPERTY="nsmessages.retrieve";
    public static final String SI_SYNC_TEMP_INPUT_QUERY_FILE="nssi.synctempretrieve";
    public static final String SI_SYNC_INPUT_QUERY_FILE="nssi.syncretrieve";

    /* This section is for web properties names */
    public static final String DEFAULT_WEBELEMENT_TIMEOUT="default.webelement.timeout";
    public static final String PLATFORM_TYPE= "platform.type";
    public static final String DESKTOP_OS_NAME="desktop.os";
    public static final String BROWSER_NAME = "browser.name";
    public static final String EXEC_ENV="exec.env";
    public static final String MOBILE_OS_NAME ="mobile.os";
    public static final String MOBILE_OS_VERSION="mobile.os.version";
    public static final String SAUCE_ACCESS_KEY="saucelabs.accesskey";
    public static final String SAUCE_USERNAME="saucelabs.username";
    public static final String MOBILE_DEVICE_NAME="mobile.device.name";
    public static final String MOBILE_DEVICE_TYPE="mobile.device.type";
    public static final String APPIUM_VERSION="appium.version";

    /* This section is for login properties names */
    public static final String COMM_URL="community.url";
    public static final String COMM_USERNAME="community.username";
    public static final String COMM_PASSWORD="community.password";

    public static final String CXP_URL="cxp.url";
    public static final String CXP_USERNAME="cxp.username";
    public static final String CXP_PASSWORD="cxp.password";

}
