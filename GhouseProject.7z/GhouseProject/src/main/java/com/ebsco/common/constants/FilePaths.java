package com.ebsco.common.constants;


/**
 * Utilities class which contains the list of files as constants.
 */
public class FilePaths {
    public static final String CUSTOMER_ID_FILE = "src/main/resources/Testdata/TempCustomer.csv";
    public static final String CUSTOMER_BATCH_ID_FILE = "src/main/resources/Testdata/TempBatchCustomer.csv";
    public static final String REPORT_FILE = "src/main/resources/Report.csv";
    public static final String SQL_PROPERTY_FILE_PATH = "src/main/resources/configs/sql.properties";
    public static final String CONTACT_ID_FILE = "src/main/resources/Testdata/TempContact.csv";
    public static final String BATCH_CONTACT_ID_FILE = "src/main/resources/Testdata/TempBatchContact.csv";
    public static final String CONFIGURATIONS_FILE = "src/main/resources/configs/configuration.properties";
    public static final String CUSTOMER_FILE_NAME = "src/main/resources/Testdata/Customer.csv";
    public static final String CONTACT_FILE_NAME = "src/main/resources/Testdata/Contact.csv";
    public static final String CUSTOMER_BATCH_FILE_NAME = "src/main/resources/Testdata/BatchCustomer.csv";
    public static final String CONTACT_BATCH_FILE_NAME = "src/main/resources/Testdata/BatchContact.csv";
    public static final String CUSTOMER_TEMP_FILE_NAME="src/main/resources/Testdata/TempCustomer.csv";
    public static final String CUSTOMER_BATCH_TEMP_FILE_NAME="src/main/resources/Testdata/TempBatchCustomer.csv";
    public static final String CONTACT_TEMP_FILE_NAME="src/main/resources/Testdata/TempContact.csv";
    public static final String CONTACT_BATCH_TEMP_FILE_NAME="src/main/resources/Testdata/TempBatchContact.csv";
    public static final String CONTACT_SYNC_SF_NS_TEMP_FILE_NAME="src/main/resources/Testdata/TempSyncContactSFtoNS.csv";
    public static final String CONTACT_SYNC_SF_NS_FILE_NAME="src/main/resources/Testdata/SyncContactSFtoNS.csv";
    public static final String UPLOAD_TEST_FILE = "\\src\\main\\resources\\test.txt";
    public static final String DATA_WB = "/src/main/resources/Testdata/Data.xls";
    public static final String CONTACT_SYNC_CXP_STATUS_FILE_NAME="src/main/resources/Testdata/SyncContactCXPStatus.csv";
    public static final String CONTACT_SYNC_CXP_STATUS_TEMP_FILE_NAME="src/main/resources/Testdata/TempSyncContactCXPStatus.csv";
    public static final String CASE_ID_BATCH_FILE = "src\\main\\resources\\Testdata\\TempBatchCase.csv";
    public static final String CASE_BATCH_NS_SF_FILE_NAME="src/main/resources/Testdata/BatchCaseNStoSF.csv";
    public static final String CASE_SYNC_FILE_NAME="src/main/resources/Testdata/CaseSync.csv";
    public static final String CASE_SYNC_TEMP_FILE_NAME="src/main/resources/Testdata/TempCaseSync.csv";
    public static final String SI_ID_BATCH_FILE = "src\\main\\resources\\Testdata\\TempBatchSI.csv";
    public static final String SI_BATCH_NS_SF_FILE_NAME="src/main/resources/Testdata/BatchSINStoSF.csv";
    public static final String MESSGAE_ID_BATCH_FILE="src/main/resources/Testdata/TempMessagesBatch.csv";
    public static final String SI_SYNC_TEMP_FILE_NAME="src/main/resources/Testdata/TempSISync.csv";
    public static final String SI_SYNC_FILE_NAME="src/main/resources/Testdata/SiSync.csv";

}
