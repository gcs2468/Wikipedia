package com.ebsco.common.utility;

import com.ebsco.api.netsuite.services.connection.NetSuiteConnectionPool;
import com.ebsco.web.managers.FileReaderManager;
import com.opencsv.CSVWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.Statement;

import static com.ebsco.common.constants.FilePaths.*;
import static com.ebsco.common.constants.Constants.SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss;
import static com.ebsco.common.constants.PropertyNames.*;
import static com.ebsco.common.constants.PropertyNames.SI_SYNC_INPUT_QUERY_FILE;
import static com.ebsco.common.constants.PropertyNames.SI_SYNC_TEMP_INPUT_QUERY_FILE;

/**
 * Utility to fetch test data from source system
 */
public class FetchInputdata {

    /*private static Logger logger;

    {
        logger = LogManager.getLogger(this);
    }
*/
    private static String startTime, gmtStartTime, endTime, gmtEndTime, sql;
    private static Statement statement = null;
    ;

    public static void main(String[] args) throws Exception {
        CSVWriter writer = null;

        NetSuiteConnectionPool nsConnectionPool = new NetSuiteConnectionPool(1);
        try {
            statement = nsConnectionPool.acquire().getStatement();
            //fetchSourcedataForCustomers(writer, (CUSTOMER_FILE_NAME).toString());
            //fetchSourcedataForContacts(writer, Paths.get(CONTACT_FILE_NAME).toString());
            //fetchSourcedataForCustomersForBatch(writer, Paths.get(CUSTOMER_BATCH_FILE_NAME).toString());
            //fetchSourcedataForContactsForBatch(writer, Paths.get(CONTACT_BATCH_FILE_NAME).toString());
            //fetchSourcedataForContactsFromSalesforce(writer, CONTACT_SYNC_SF_NS_FILE_NAME);
            //fetchSourcedata_CXPStatusForContacts(writer, CONTACT_SYNC_CXP_STATUS_FILE_NAME);
            //fetchSourcedataForCasesForBatch(writer, CASE_BATCH_NS_SF_FILE_NAME);
           // fetchSourcedataForCases(writer,CASE_SYNC_FILE_NAME);
            fetchSourcedataForServiceIssueBatch(writer,SI_BATCH_NS_SF_FILE_NAME);
           // fetchSourcedataForServiceIssue(writer,SI_SYNC_FILE_NAME);
        } catch (Exception e) {

        } finally {
            if (writer != null)
                writer.close();
            nsConnectionPool.destroyAll();
        }
    }

    private static void fetchSourcedataForCustomers(CSVWriter writer, String fileName) throws IOException {
//        NetSuiteConnectionPool nsConnectionPool=new NetSuiteConnectionPool(1);
        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();
            writer = new CSVWriter(new FileWriter(fileName));

//            Statement statement = nsConnectionPool.acquire().getStatement();
            startTime = CommonUtils.getTimeWithHoursAdd(hoursToSub);
            gmtStartTime = CommonUtils.getGMTTime(startTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            endTime = CommonUtils.getTimeWithHoursAdd(hoursToAdd);
            gmtEndTime = CommonUtils.getGMTTime(endTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            sql = AppProperties.getValueFor(CUSTOMER_INPUT_QUERY_FILE);
//            logger.info("Sql::"+sql);
            ResultSet resultSet = statement.executeQuery(sql.
                    replace("START_TIME", gmtStartTime).
                    replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(Paths.get(CUSTOMER_TEMP_FILE_NAME).toString()));
            sql = AppProperties.getValueFor(CUSTOMER_INPUT_QUERY_TEMP_FILE);
            resultSet = statement.executeQuery(sql.replace("START_TIME", gmtStartTime).replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, false);
            writer.close();
        } catch (Exception e) {

        }
    }

    private static void fetchSourcedataForCustomersForBatch(CSVWriter writer, String fileName) throws IOException {
//        NetSuiteConnectionPool nsConnectionPool=new NetSuiteConnectionPool(1);
        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();

            writer = new CSVWriter(new FileWriter(fileName));

//            Statement statement = nsConnectionPool.acquire().getStatement();
            sql = AppProperties.getValueFor(CUSTOMER_BATCH_INPUT_QUERY_FILE);
//            logger.info("Sql::"+sql);
            ResultSet resultSet = statement.executeQuery(sql);
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(Paths.get(CUSTOMER_BATCH_TEMP_FILE_NAME).toString()));
            sql = AppProperties.getValueFor(CUSTOMER_BATCH_INPUT_QUERY_TEMP_FILE);
            resultSet = statement.executeQuery(sql);
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, false);
            writer.close();
        } catch (Exception e) {

        }
    }

    private static void fetchSourcedataForContacts(CSVWriter writer, String fileName) throws IOException {
//        NetSuiteConnectionPool nsConnectionPool=new NetSuiteConnectionPool(1);
        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();

            writer = new CSVWriter(new FileWriter(fileName));
//            Statement statement = nsConnectionPool.acquire().getStatement();
            startTime = CommonUtils.getTimeWithHoursAdd(hoursToSub);
            gmtStartTime = CommonUtils.getGMTTime(startTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            endTime = CommonUtils.getTimeWithHoursAdd(hoursToAdd);
            gmtEndTime = CommonUtils.getGMTTime(endTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            sql = AppProperties.getValueFor(CONTACT_INPUT_QUERY_FILE);
//            logger.info("Sql::"+sql);
            ResultSet resultSet = statement.executeQuery(sql.
                    replace("START_TIME", gmtStartTime).
                    replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(Paths.get(CONTACT_TEMP_FILE_NAME).toString()));
            sql = AppProperties.getValueFor(CONTACT_INPUT_QUERY_TEMP_FILE);
            resultSet = statement.executeQuery(sql.replace("START_TIME", gmtStartTime).replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, false);
            writer.close();
        } catch (Exception e) {
        }
    }

    private static void fetchSourcedataForContactsForBatch(CSVWriter writer, String fileName) throws IOException {
//        NetSuiteConnectionPool nsConnectionPool=new NetSuiteConnectionPool(1);
        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();

            writer = new CSVWriter(new FileWriter(fileName));
            sql = AppProperties.getValueFor(CONTACT_BATCH_INPUT_QUERY_FILE);
//            logger.info("Sql::"+sql);
            ResultSet resultSet = statement.executeQuery(sql);
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(CONTACT_BATCH_TEMP_FILE_NAME));
            sql = AppProperties.getValueFor(CONTACT_BATCH_INPUT_QUERY_TEMP_FILE);
            resultSet = statement.executeQuery(sql);
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, false);
            writer.close();
        } catch (Exception e) {
        }
    }

    private static void fetchSourcedataForContactsFromSalesforce(CSVWriter writer, String fileName) throws IOException {
        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();

            writer = new CSVWriter(new FileWriter(fileName));
            startTime = CommonUtils.getTimeWithHoursAdd(hoursToSub);
            gmtStartTime = CommonUtils.getGMTTime(startTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            endTime = CommonUtils.getTimeWithHoursAdd(hoursToAdd);
            gmtEndTime = CommonUtils.getGMTTime(endTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            sql = AppProperties.getValueFor(CONTACT_INPUT_QUERY_FILE);
            ResultSet resultSet = statement.executeQuery(sql.
                    replace("START_TIME", gmtStartTime).
                    replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(CONTACT_SYNC_SF_NS_TEMP_FILE_NAME));
            sql = AppProperties.getValueFor(CONTACT_INPUT_QUERY_TEMP_FILE);
            resultSet = statement.executeQuery(sql.replace("START_TIME", gmtStartTime).replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, false);
            writer.close();
        } catch (Exception e) {

        }
    }

    private static void fetchSourcedata_CXPStatusForContacts(CSVWriter writer, String fileName) throws IOException {
//        NetSuiteConnectionPool nsConnectionPool=new NetSuiteConnectionPool(1);
        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();
            writer = new CSVWriter(new FileWriter(fileName));

//            Statement statement = nsConnectionPool.acquire().getStatement();
            startTime = CommonUtils.getTimeWithHoursAdd(hoursToSub);
            gmtStartTime = CommonUtils.getGMTTime(startTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            endTime = CommonUtils.getTimeWithHoursAdd(hoursToAdd);
            gmtEndTime = CommonUtils.getGMTTime(endTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            sql = AppProperties.getValueFor(CONTACT_SYNC_CXP_STATUS_QUERY_FILE);
//            logger.info("Sql::"+sql);
            ResultSet resultSet = statement.executeQuery(sql.
                    replace("START_TIME", gmtStartTime).
                    replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(Paths.get(CONTACT_SYNC_CXP_STATUS_TEMP_FILE_NAME).toString()));
            sql = AppProperties.getValueFor(CONTACT_SYNC_CXP_STATUS_TEMP_QUERY_FILE);
            resultSet = statement.executeQuery(sql.replace("START_TIME", gmtStartTime).replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, false);
            writer.close();
        } catch (Exception e) {

        }
    }

    private static void fetchSourcedataForCasesForBatch(CSVWriter writer, String fileName) throws IOException {

        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();
            writer = new CSVWriter(new FileWriter(fileName));
            sql = AppProperties.getValueFor(CASE_BATCH_INPUT_QUERY_FILE);
            ResultSet resultSet = statement.executeQuery(sql);
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(Paths.get(CASE_ID_BATCH_FILE).toString()));
            sql = AppProperties.getValueFor(CASE_BATCH_TEMP_INPUT_QUERY_FILE);
            resultSet = statement.executeQuery(sql);
            writer.writeAll(resultSet, false);
            writer.close();

        } catch (Exception e) {

        }
    }

    private static void fetchSourcedataForCases(CSVWriter writer, String fileName) throws IOException {
//        NetSuiteConnectionPool nsConnectionPool=new NetSuiteConnectionPool(1);
        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();

            writer = new CSVWriter(new FileWriter(fileName));
//            Statement statement = nsConnectionPool.acquire().getStatement();
            startTime = CommonUtils.getTimeWithHoursAdd(hoursToSub);
            gmtStartTime = CommonUtils.getGMTTime(startTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            endTime = CommonUtils.getTimeWithHoursAdd(hoursToAdd);
            gmtEndTime = CommonUtils.getGMTTime(endTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            sql = AppProperties.getValueFor(CASE_SYNC_INPUT_QUERY_FILE);
//            logger.info("Sql::"+sql);
            ResultSet resultSet = statement.executeQuery(sql.
                    replace("START_TIME", gmtStartTime).
                    replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(Paths.get(CASE_SYNC_TEMP_FILE_NAME).toString()));
            sql = AppProperties.getValueFor(CASE_SYNC_TEMP_INPUT_QUERY_FILE);
            resultSet = statement.executeQuery(sql.replace("START_TIME", gmtStartTime).replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, false);
            writer.close();
        } catch (Exception e) {
        }
    }

    private static void fetchSourcedataForServiceIssueBatch(CSVWriter writer, String fileName) throws IOException {

        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();
            writer = new CSVWriter(new FileWriter(fileName));
            sql = AppProperties.getValueFor(SI_BATCH_INPUT_QUERY_FILE);
            ResultSet resultSet = statement.executeQuery(sql);
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(Paths.get(SI_ID_BATCH_FILE).toString()));
            sql = AppProperties.getValueFor(SI_BATCH_TEMP_INPUT_QUERY_FILE);
            resultSet = statement.executeQuery(sql);
            writer.writeAll(resultSet, false);
            writer.close();
        } catch (Exception e) {

        }
    }
    private static void fetchSourcedataForServiceIssue(CSVWriter writer, String fileName) throws IOException {
//        NetSuiteConnectionPool nsConnectionPool=new NetSuiteConnectionPool(1);
        try {
            int hoursToAdd = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToAdd();
            int hoursToSub = FileReaderManager.getInstance().getConfigReader().getNsQuerySqlDiffTimeToSub();

            writer = new CSVWriter(new FileWriter(fileName));
//            Statement statement = nsConnectionPool.acquire().getStatement();
            startTime = CommonUtils.getTimeWithHoursAdd(hoursToSub);
            gmtStartTime = CommonUtils.getGMTTime(startTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            endTime = CommonUtils.getTimeWithHoursAdd(hoursToAdd);
            gmtEndTime = CommonUtils.getGMTTime(endTime, SQL_DATE_FORMAT_YYYY_MM_DD_HH_mm_ss);
            sql = AppProperties.getValueFor(SI_SYNC_INPUT_QUERY_FILE);
//            logger.info("Sql::"+sql);
            ResultSet resultSet = statement.executeQuery(sql.
                    replace("START_TIME", gmtStartTime).
                    replace("END_TIME", gmtEndTime));
            System.out.println("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, true);
            writer.close();
            writer = new CSVWriter(new FileWriter(Paths.get(SI_SYNC_TEMP_FILE_NAME).toString()));
            sql = AppProperties.getValueFor(SI_SYNC_TEMP_INPUT_QUERY_FILE);
            resultSet = statement.executeQuery(sql.replace("START_TIME", gmtStartTime).replace("END_TIME", gmtEndTime));
//            logger.info("Sql::"+sql.replace("START_TIME",gmtStartTime).replace("END_TIME",gmtEndTime));
            writer.writeAll(resultSet, false);
            writer.close();
        } catch (Exception e) {
        }
    }
}