package com.ebsco.common.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class jdbcConn {


    public static void main(String[] args) throws Exception {
        Connection connection = null;
        Statement statement = null;
        try {

/*int RoleID=3;
String roleValue ="RoleID= "+RoleID;

String customProp= "(AccountID= 392875_SB1;"+roleValue+")";
System.out.println(customProp);
              OpenAccessDataSource sds = new OpenAccessDataSource();
              sds.setServerDataSource(" NetSuite.com");
              sds.setServerName(" odbcserver.netsuite.com");
              sds.setPortNumber( 1708);
              sds.setCipherSuites("TLS_RSA_WITH_AES_128_CBC_SHA");
              sds.setCustomProperties(customProp);
             // sds.setCustomProperties(roleValue);
              sds.setEncrypted( 1);
              connection = sds.getConnection("Gopalakrishnan_Kovilur@epam.com", "EPAM2018");*/
            Class.forName("com.netsuite.jdbc.openaccess.OpenAccessDriver");
            String connectionURL = "jdbc:ns:// odbcserver.netsuite.com: 1708;" +
                    "ServerDataSource=NetSuite.com;" +
                    "Encrypted=1;" +
                    "CipherSuites=TLS_RSA_WITH_AES_128_CBC_SHA;" +
                    "CustomProperties=(AccountID=392875_SB1;RoleID=3)";
            System.out.println( connectionURL );
            connection = DriverManager.getConnection(connectionURL, "v-sgudavalli2@ebsco.com", "EPAM2018");
            System.out.println("Connection success");
            System.out.println( connectionURL );
            statement = connection.createStatement();


         /* String  sql =  "Select BILLADDRESS from Customers LEFT JOIN EMPLOYEES on Customers.CUSTOMER_SATISFACTION_ID=EMPLOYEES.EMPLOYEE_ID LEFT JOIN MARKET on Customers.MARKET_ID=MARKET.MARKET_ID LEFT JOIN SEGMENT1 on Customers.SEGMENT_ID=SEGMENT1.SEGMENT1_ID LEFT JOIN CAS_LEVELS on Customers.CAS_COVERAGE_ID=CAS_LEVELS.LIST_ID where Customer_id in (1770988," +
                    "1770419," +
                    "1652562," +
                    "1652557," +
                    "1652574," +
                    "1652636," +
                    "1652564)";*/

         //String sql = "select SERVICE_ISSUE_ID,SYNOPSIS,PRODUCT_SI_ID,STATUS_ID,ISSUE_EXPERIENCED,RESOLUTION,DATE_CREATED,LAST_MODIFIED_DATE,DATE_CLOSED,SF_SERVICE_ISSUE_ID from Service_Issue where rownum<=1";
        //   String sql = "SELECT CONTACT_ID,  CUSTOMERS.COMPANYNAME,  FIRSTNAME, MIDDLENAME,  LASTNAME,  EMAIL,  PHONE,  TITLE, SF_CONTACT_ID ,JOB_ROLES.LIST_ITEM_NAME ,CONTACT_ORIGIN.LIST_ITEM_NAME,BUSINESS_INTEREST_TYPE.LIST_ITEM_NAME ,ISINACTIVE, CXP_OPT_IN_TO_PARENT_VISIBILI FROM Contacts  LEFT JOIN CUSTOMERS on Contacts.COMPANY_ID = CUSTOMERS.CUSTOMER_ID  LEFT JOIN JOB_ROLES on Contacts.JOB_ROLE_ID=JOB_ROLES.LIST_ID  LEFT JOIN CONTACT_ORIGIN on Contacts.CONTACT_ORIGIN_ID= CONTACT_ORIGIN.LIST_ID LEFT JOIN BUSINESS_INTEREST_TYPE on Contacts.LEGITIMATE_BUSINESS_INTERES_ID= BUSINESS_INTEREST_TYPE.LIST_ID where SF_CONTACT_ID='CREATE NEW'";
            String sql = "select * from Contacts where COntact_id=650316";
            System.out.println(sql);
            ResultSet rs = statement.executeQuery(sql);
//68569961
            while (rs.next()) {
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    System.out.println(rs.getMetaData().getColumnName(i) + "==>" + rs.getString(i));
                }
            }

            System.out.println("completed");
        } finally {
            if (connection != null)
                connection.close();
        }
    }
}


