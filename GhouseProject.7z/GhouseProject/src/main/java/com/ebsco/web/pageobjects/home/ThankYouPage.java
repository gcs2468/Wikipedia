package web.pageobject;


import com.ebsco.web.utilities.SeleniumWrappers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Wait;

public class ThankYouPage {
    private static final By thankYouMessageSelector = By.xpath("//h1[@title='Link']");
    private static final String EXPECTED_THANK_YOU_MESSAGE =
            "Thank You for Opting Salesforce Experience, You Will get a Separate Email verifying Community Access";
    private final WebDriver webDriver;
    private SeleniumWrappers fActions = new SeleniumWrappers();

    public ThankYouPage(WebDriver webDriver) {
        this.webDriver = webDriver;
    }

    private String getThankYouMessage() {
        fActions.waitForElementVisible(webDriver, thankYouMessageSelector, 10);
        return webDriver.findElement(thankYouMessageSelector).getText();
    }

    public boolean hasThankYouMessage() {
        return getThankYouMessage().equals(EXPECTED_THANK_YOU_MESSAGE);
    }
}
