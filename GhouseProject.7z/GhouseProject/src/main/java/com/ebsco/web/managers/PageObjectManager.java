package com.ebsco.web.managers;

import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.pageobjects.accounts.AccountsPage;
import com.ebsco.web.pageobjects.cases.CasePage;
import com.ebsco.web.pageobjects.cases.CasesPage;
import com.ebsco.web.pageobjects.cases.CreateCasePage;
import com.ebsco.web.pageobjects.cases.SIDetailPage;
import com.ebsco.web.pageobjects.common.GlobalPage;
import com.ebsco.web.pageobjects.common.ProfilePage;
import com.ebsco.web.pageobjects.contacts.ContactPage;
import com.ebsco.web.pageobjects.contacts.ContactsPage;
import com.ebsco.web.pageobjects.home.HomePage;
import com.ebsco.web.pageobjects.home.SearchResultsPage;
import com.ebsco.web.pageobjects.home.UnAuthHomePage;
import com.ebsco.web.pageobjects.login.LoginPage;
import org.openqa.selenium.WebDriver;


public class PageObjectManager {

    public WebDriver driver;

    protected GlobalPage globalPage;
    protected AccountsPage accountsPage;
    protected LoginPage loginPage;
    protected ContactsPage contactsPage;
    protected UnAuthHomePage unAuthHomePage;
    protected CasesPage casesPage;
    protected CasePage casePage;
    protected HomePage homePage;
    protected CreateCasePage createCasePage;
    protected SearchResultsPage searchResultsPage;
    protected ContactPage contactPage;
    protected SIDetailPage siDetailPage;
    protected ProfilePage profilePage;


    public PageObjectManager() {
    }

    public PageObjectManager(WebDriver driver) {
        this.driver = driver;
    }

    public void getAllPageInstances(){
        PageObjectManager pom = InvokeInstances.getInvokeInstance().getPageObjectManager();
        globalPage = pom.getGlobalPage();
        loginPage = pom.getLoginPage();
        accountsPage = pom.getAccountsPage();
        contactsPage = pom.getContactsPage();
        contactPage = pom.getContactPage();
        unAuthHomePage = pom.getUnAuthHomePage();
        homePage = pom.getHomePage();
        searchResultsPage = pom.getSearchResultsPage();
        casesPage = pom.getCasesPage();
        casePage = pom.getCasePage();
        createCasePage = pom.getCreateCasePage();
    }

    public GlobalPage getGlobalPage(){
        return (globalPage == null) ? globalPage = new GlobalPage(driver) : globalPage;
    }

    public AccountsPage getAccountsPage() {
        return (accountsPage == null) ? accountsPage = new AccountsPage(driver) : accountsPage;
    }

    public ContactsPage getContactsPage() {
        return (contactsPage == null) ? contactsPage = new ContactsPage(driver) : contactsPage;
    }

    public ContactPage getContactPage() {
        return (contactPage == null) ? contactPage = new ContactPage(driver) : contactPage;
    }

    public LoginPage getLoginPage() {
        return (loginPage == null) ? loginPage = new LoginPage(driver) : loginPage;
    }

    public UnAuthHomePage getUnAuthHomePage() {
        return (unAuthHomePage == null) ? unAuthHomePage = new UnAuthHomePage(driver) : unAuthHomePage;
    }

    public HomePage getHomePage() {
        return (homePage == null) ? homePage = new HomePage(driver) : homePage;
    }

    public SearchResultsPage getSearchResultsPage() {
        return (searchResultsPage == null) ? searchResultsPage = new SearchResultsPage(driver) : searchResultsPage;
    }

    public CasesPage getCasesPage() {
        return (casesPage == null) ? casesPage = new CasesPage(driver) : casesPage;
    }

    public CasePage getCasePage() {
        return (casePage == null) ? casePage = new CasePage(driver) : casePage;
    }

    public CreateCasePage getCreateCasePage() {
        return (createCasePage == null) ? createCasePage = new CreateCasePage(driver) : createCasePage;
    }




}
