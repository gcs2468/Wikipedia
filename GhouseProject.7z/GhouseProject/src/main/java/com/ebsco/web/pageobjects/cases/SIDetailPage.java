package com.ebsco.web.pageobjects.cases;

import com.ebsco.api.model.utility.comparison.Link;
import com.ebsco.api.netsuite.services.pojo.ServiceIssue;
import com.ebsco.web.utilities.SeleniumWrappers;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class SIDetailPage {

    private By siIdSelector = By.xpath("//h1/span");
    private By issueSelector = By.xpath("(//span[@class='uiOutputTextArea'])[1]");
    private By resolutionSelector = By.xpath("(//span[@class='uiOutputTextArea'])[2]");
    private By interfaceSelector =
            By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[8]");
    private By mobileInterfaceSelector =
            By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[7]");

    private By dateCreatedSelector =
            By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[5]");
    private By mobileDateCreatedSelector =
            By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[4]");


    private By dateModifiedSelector =
            By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[6]");
    private By mobileDateModifiedSelector =
            By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[5]");


    private By statusSelector =
            By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[10]");
    private By mobileStatusSelector =
            By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[9]");
    private By serviceIssueTitleLabel =
            By.xpath("//li/span[text()='Service Issues']");
    private SeleniumWrappers fActions = new SeleniumWrappers();
    private WebDriver driver;
    private Logger logger = LogManager.getLogger(this.getClass());

    public SIDetailPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean validateDetails(ServiceIssue nsServiceIssue) {
        waitUntilSIPageHasArrived();
        return idIsValid(nsServiceIssue) &&
                interfaceIsValid(nsServiceIssue) &&
                issueIsValid(nsServiceIssue) &&
                resolutionIsValid(nsServiceIssue) &&
                statusIsValid(nsServiceIssue) &&
                dateCreatedIsValid(nsServiceIssue) &&
                dateModifiedIsValid(nsServiceIssue);
    }

    private void waitUntilSIPageHasArrived() {
        String keyword = "service-issues";
        while (!driver.getCurrentUrl().contains(keyword));
    }


    private boolean idIsValid(ServiceIssue nsServiceIssue) {
        String url = "https://qa-ebsco.cs23.force.com/dev1/s/service-issues/" + nsServiceIssue.getSfServiceIssueId();
        boolean isValid = new Link(url).isValid();
        logger.info("Id is valid : " + isValid);
        return isValid;
    }

    private boolean issueIsValid(ServiceIssue nsServiceIssue) {
        String uiText = fActions.getText(driver, issueSelector);
        return dataAreEqual(uiText, nsServiceIssue.getIssueExperience());
    }

    private boolean resolutionIsValid(ServiceIssue nsServiceIssue) {
        String uiText = fActions.getText(driver, resolutionSelector);
        return dataAreEqual(uiText, nsServiceIssue.getResolution());
    }

    private boolean interfaceIsValid(ServiceIssue nsServiceIssue) {
        String uiText = getTextDependingOnDevice(interfaceSelector, mobileInterfaceSelector);
        return dataAreEqual(uiText, nsServiceIssue.getProduct_interface());
    }

    private boolean statusIsValid(ServiceIssue nsServiceIssue) {
        String uiText = getTextDependingOnDevice(statusSelector, mobileStatusSelector);
        return dataAreEqual(uiText, nsServiceIssue.getStatus());
    }

    private boolean dateCreatedIsValid(ServiceIssue nsServiceIssue) {
        String uiText = getTextDependingOnDevice(dateCreatedSelector, mobileDateCreatedSelector);
        return datesAreEqual(uiText, nsServiceIssue.getDateCreated());
    }

    private boolean dateModifiedIsValid(ServiceIssue nsServiceIssue) {
        String uiText = getTextDependingOnDevice(dateModifiedSelector, mobileDateModifiedSelector);
        return datesAreEqual(uiText, nsServiceIssue.getLastmodified());
    }

    private boolean datesAreEqual(String uiDate, String apiDate) {
        LocalDateTime netsuiteDate =
                LocalDateTime.parse(apiDate, DateTimeFormatter.ofPattern("y-M-d H:m:s"));
        LocalDateTime salesforceDate =
                LocalDateTime.parse(uiDate, DateTimeFormatter.ofPattern("M/d/y h:m a"));

        return netsuiteDate.getDayOfMonth() == salesforceDate.getDayOfMonth() &&
                netsuiteDate.getMonth() == salesforceDate.getMonth() &&
                netsuiteDate.getYear() == salesforceDate.getYear() &&
                netsuiteDate.getHour() == salesforceDate.getHour() &&
                netsuiteDate.getMinute() == salesforceDate.getMinute();
    }

    private String getTextDependingOnDevice(By desktopSelector, By mobileSelector) {
        if (fActions.deviceIsDesktop(driver))
            return fActions.getText(driver, desktopSelector);
        else
            return fActions.getText(driver, mobileSelector);
    }

    private boolean dataAreEqual(String uiText, String apiText) {
        uiText = Objects.toString(uiText, "");
        apiText = Objects.toString(apiText, "");
        logger.info("UI: " + uiText + " API: " + apiText);
        return uiText.equals(apiText);
    }

    /**
     * SI ID done
     Status done
     Issue Experienced done
     Resolution done
     Date Created done
     Date last modified done
     Date closed
     */
}
