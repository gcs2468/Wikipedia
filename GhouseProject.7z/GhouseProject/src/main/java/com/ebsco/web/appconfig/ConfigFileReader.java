package com.ebsco.web.appconfig;

import com.ebsco.common.utility.AppProperties;

import static com.ebsco.common.constants.PropertyNames.*;

public class ConfigFileReader {

    public long getImplicitlyWait() {
        return Long.parseLong(AppProperties.getValueFor(DEFAULT_WEBELEMENT_TIMEOUT));
    }

    public String getBrowser() {
        return AppProperties.getValueFor(BROWSER_NAME);
    }

    public String getEnvironment() {
        return AppProperties.getValueFor(EXEC_ENV);
    }

    public String getPlatform() {
        return AppProperties.getValueFor(PLATFORM_TYPE);
    }

    public String getMobileOs() {
        return AppProperties.getValueFor(MOBILE_OS_NAME);
    }

    public String getDesktopOs() {
        return AppProperties.getValueFor(DESKTOP_OS_NAME);
    }

    public String getMobileOsVersion() {
        return AppProperties.getValueFor(MOBILE_OS_VERSION);
    }

    public String getSauceAccessKey() {
        return AppProperties.getValueFor(SAUCE_ACCESS_KEY);
    }

    public String getSauceUsername() {
        return AppProperties.getValueFor(SAUCE_USERNAME);
    }

    public String getMobileDeviceName() { return AppProperties.getValueFor(MOBILE_DEVICE_NAME); }

    public String getMobileDeviceType() {return AppProperties.getValueFor(MOBILE_DEVICE_TYPE);}

    public int getNsQuerySqlDiffTimeToAdd() { return Integer.parseInt(AppProperties.getValueFor(NS_DIFF_TIME_ADD)); }

    public int getNsQuerySqlDiffTimeToSub() { return Integer.parseInt(AppProperties.getValueFor(NS_DIFF_TIME_SUB)); }

    public String getAppiumVersion() { return AppProperties.getValueFor(APPIUM_VERSION); }

    public String getCommunityURL(){return AppProperties.getValueFor(COMM_URL); }

    public String getCommunityUsername(){return AppProperties.getValueFor(COMM_USERNAME); }

    public String getCommunityPassword(){return AppProperties.getValueFor(COMM_PASSWORD); }

    public String getCxpURL(){return AppProperties.getValueFor(CXP_URL); }

    public String getCxpUsername(){return AppProperties.getValueFor(CXP_USERNAME); }

    public String getCxpPassword(){return AppProperties.getValueFor(CXP_PASSWORD); }


}
