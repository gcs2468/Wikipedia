package com.ebsco.web.utilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.*;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import static com.ebsco.common.constants.Constants.DEFAULT_MILLI_SECONDS;
import static com.ebsco.common.constants.Constants.DESKTOP_WEB;

public class SeleniumWrappers {

    /**
     * Waits until given element is displayed.
     */
    private boolean waitForElement(WebDriver driver, By objLocator, int timeOut) {
        try {
            Wait<WebDriver> wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(timeOut))
                    .pollingEvery(Duration.ofSeconds(1))
                    .ignoring(NoSuchElementException.class);
            return wait.until((element) -> element.findElements(objLocator).size() > 0);
        } catch (TimeoutException e) {
            return false;
        }
    }

    public void waitForElementVisible(WebDriver driver, By objLocator, int timeOut) {
        if (!waitForElement(driver, objLocator, timeOut))
            throw new NoSuchElementException(String.format("%s unable to find the element on page", objLocator));
    }

    public void waitForElementInvisible(WebDriver driver, By objLocator, int timeOut) {
        boolean waitForNotVisible = new WebDriverWait(driver, timeOut).until(
                ExpectedConditions.invisibilityOfElementLocated(objLocator));
        if (!waitForNotVisible)
            throw new NoSuchElementException(String.format("%s able to see on the element", objLocator));
    }

    public WebElement getWebElement(WebDriver driver, By objLocator) {
        if (waitForElement(driver, objLocator, 10)) {
            return driver.findElement(objLocator);
        }
        throw new NoSuchElementException(String.format("Unable to find the element ->  %s.", objLocator));
    }

    public List<WebElement> getWebElements(WebDriver driver, By objLocator) {
        List<WebElement> listOfEle;
        if (waitForElement(driver, objLocator, 10))
            listOfEle = new ArrayList<>(driver.findElements(objLocator));
        else
            listOfEle = new ArrayList<>();
        return listOfEle;
    }

    public void enterText(WebDriver driver, By objLocator, String text) throws NoSuchElementException {
        WebElement element = getWebElement(driver, objLocator);
        element.clear();
        element.sendKeys(text);
    }

    public void openURL(WebDriver driver, String url) {
        driver.get(url);
    }

    public void clickElement(WebDriver driver, By objLocator) {
        getWebElement(driver, objLocator).click();
    }

    public void moveBack(WebDriver driver) {
        driver.navigate().back();
    }

    public void moveForward(WebDriver driver) {
        driver.navigate().forward();
    }

    public void clickElementUsingJse(WebDriver driver, By objLocator) {
        WebElement ele = getWebElement(driver, objLocator);
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click()", ele);
    }

    public Actions moveOnToElement(WebDriver driver, By objLocator) {
        Actions actions = new Actions(driver);
        return actions.moveToElement(getWebElement(driver, objLocator));
    }

    public Actions moveOnToElement(WebDriver driver, WebElement element) {
        Actions actions = new Actions(driver);
        return actions.moveToElement(element);
    }

    public void moveAndClick(WebDriver driver, By objLocator) {
        moveOnToElement(driver, objLocator).click().build().perform();
    }

    public void moveAndClick(WebDriver driver, WebElement element) {
        moveOnToElement(driver, element).click().build().perform();
    }

    public void moveAndDoubleClick(WebDriver driver, By objLocator) {
        moveOnToElement(driver, objLocator).doubleClick().build().perform();
    }

    public void moveAndDoubleClick(WebDriver driver, WebElement element) {
        moveOnToElement(driver, element).doubleClick().build().perform();
    }

    public void switchToWindow(WebDriver driver, String windowName) {
        driver.switchTo().window(windowName);
    }


    public void openElementInNewTab(WebDriver driver, WebElement element) {
        moveOnToElement(driver, element).keyDown(Keys.SHIFT).click(element).keyUp(Keys.SHIFT).build().perform();
    }

    public String getWindowName(WebDriver driver) {
        return driver.getWindowHandle();
    }

    public List<String> getWindowNames(WebDriver driver) {
        return new ArrayList<>(driver.getWindowHandles());
    }

    public void closeVisibleWindow(WebDriver driver) {
        driver.close();
    }

    public void closeAllWindows(WebDriver driver) {
        driver.quit();
    }


    public int getXpathCount(WebDriver wDriver, By objLocator) {
        return getWebElements(wDriver, objLocator).size();
    }

    public void fileUpload(WebDriver driver, By objLocator, String filePath) throws Exception {
        WebElement element = getWebElement(driver, objLocator);
        element.click();
        StringSelection stringSelection = new StringSelection(filePath);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
        Robot robot = new Robot();
        robot.delay(2000);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.delay(1000 * 2);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.delay(1000 * 4);

    }

    public void fileUpload(WebDriver driver, By objLocator, String filePath, String platformName) throws Exception {
        switch (platformName) {
            case DESKTOP_WEB:
                uploadFileInDesktop(driver, objLocator, filePath);
                break;
            default:
                return;
        }
    }

    public void uploadFileInDesktop(WebDriver driver, By objLocator, String filePath) throws AWTException {
        ((RemoteWebDriver) driver).setFileDetector(new LocalFileDetector());
        driver.findElement(objLocator).sendKeys(filePath);
        WebElement element = getWebElement(driver, objLocator);
        element.click();
        if (true) return;
        Robot robot = new Robot();
        robot.delay(1000);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(1000);
        robot.delay(1000);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        System.out.println(System.getProperty("user.dir"));
        robot.delay(1000);
        for (int i = 1; i <= 8; i++) {
            robot.keyPress(KeyEvent.VK_TAB);//To select the open area.
            robot.keyRelease(KeyEvent.VK_TAB);
            robot.delay(200);
        }

        robot.delay(1000);
        keyPressAndRelease(robot, KeyEvent.VK_CONTEXT_MENU);
        robot.delay(1000);
        //Go to New > Section
        keyPressAndRelease(robot, KeyEvent.VK_UP);
        robot.delay(1000);
        //Open the drop down
        keyPressAndRelease(robot, KeyEvent.VK_RIGHT);

        //Select Text Document
        for (int i = 1; i <= 3; i++) {
            keyPressAndRelease(robot, KeyEvent.VK_UP);
        }

        keyPressAndRelease(robot, KeyEvent.VK_ENTER);
        StringSelection stringSelection = new StringSelection(filePath);
        System.out.println(filePath);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_A);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyRelease(KeyEvent.VK_A);
        robot.delay(1000 * 2);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_C);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyRelease(KeyEvent.VK_C);
        robot.delay(1000 * 2);
        keyPressAndRelease(robot, KeyEvent.VK_ENTER);
        robot.delay(100);
        keyPressAndRelease(robot, KeyEvent.VK_CONTEXT_MENU);
        robot.delay(100);

        //Go to edit button
        keyPressAndRelease(robot, KeyEvent.VK_E);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(3000);
        //Type some text into this file.
        for (int i = 1; i <= 4; i++) {
            //Type some text
            robot.keyPress(KeyEvent.VK_S);
            robot.keyRelease(KeyEvent.VK_S);
            robot.delay(100);
        }

        keyPressAndRelease(robot, KeyEvent.VK_ENTER);
        robot.delay(1000);
        //Save
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(1000);
        robot.keyPress(KeyEvent.VK_ALT);
        robot.keyPress(KeyEvent.VK_F);
        robot.keyRelease(KeyEvent.VK_ALT);
        robot.keyRelease(KeyEvent.VK_F);
        robot.delay(2000);
        keyPressAndRelease(robot, KeyEvent.VK_S);
        robot.delay(1000);
        keyPressAndRelease(robot, KeyEvent.VK_S);
        robot.delay(1000);
        //Close the notepad
        robot.keyPress(KeyEvent.VK_ALT);
        robot.keyPress(KeyEvent.VK_F);
        robot.keyRelease(KeyEvent.VK_ALT);
        robot.keyRelease(KeyEvent.VK_F);
        robot.delay(100);
        keyPressAndRelease(robot, KeyEvent.VK_X);
        keyPressAndRelease(robot, KeyEvent.VK_S);
        robot.delay(1000);

        //Paste the text in input field.
        keyPressAndRelease(robot, KeyEvent.VK_TAB);
        robot.delay(100);
        keyPressAndRelease(robot, KeyEvent.VK_ENTER);
        System.out.println("Done uploading..");
    }

    public void keyPressAndRelease(Robot robot, int keyCode) {
        robot.keyPress(keyCode);
        robot.keyRelease(keyCode);
    }

    public void selectByValueFromDropDown(WebDriver driver, By objLocator, String value) {
        Select selectFromDropDown = new Select(getWebElement(driver, objLocator));
        selectFromDropDown.selectByValue(value);
    }


    public void selectOptionByVisibleText(WebDriver driver, By objLocator, String value) {
        Select selectFromDropDown = new Select(getWebElement(driver, objLocator));
        selectFromDropDown.selectByVisibleText(value);
    }

    public void selectByIndexFromDropDown(WebDriver driver, By objLocator, int index) {
        Select selectFromDropDown = new Select(getWebElement(driver, objLocator));
        selectFromDropDown.selectByIndex(index);
    }

    public String getText(WebDriver driver, By objLocator) {
        return getWebElement(driver, objLocator).getText();
    }

    public boolean deviceIsDesktop(WebDriver webDriver) {
        return !deviceIsMobile(webDriver);
    }

    public boolean deviceIsMobile(WebDriver webDriver) {
        return webDriver instanceof AndroidDriver || webDriver instanceof IOSDriver;
    }

    public void waitInSeconds(int timeToWait) throws InterruptedException {
        Thread.sleep(timeToWait * DEFAULT_MILLI_SECONDS);
    }

    public void executeOnMobile(WebDriver driver, Consumer<WebDriver> mobileScript) {
        if (deviceIsDesktop(driver)) return;
        mobileScript.accept(driver);
    }

    public void executeOnDesktop(WebDriver driver, Consumer<WebDriver> desktopScript) {
        if (deviceIsMobile(driver)) return;
        desktopScript.accept(driver);
    }

    public void moveMouseByOffSet(WebDriver driver,int xAxis,int yAxis)
    {
        Actions actions = new Actions(driver);
        actions.moveByOffset(100,100);
    }
}
