package com.ebsco.web.pageobjects.cases;

import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.managers.FileReaderManager;
import com.ebsco.web.pageobjects.common.GlobalPage;
import com.ebsco.web.pageobjects.login.LoginPage;
import com.ebsco.web.utilities.LogUtil;
import com.ebsco.web.utilities.Reusable;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static com.ebsco.common.constants.Constants.*;
import static com.ebsco.common.constants.Constants.PASSWORD;
import static com.ebsco.common.constants.Constants.USERNAME;

public class CasesPage extends GlobalPage {

    private WebDriver driver;
    private Reusable reusable = new Reusable();

    private final By newCaseElement = By.xpath("//a[text()='New Case']");
    private final By descriptionElement = By.xpath("//textarea");
    private final By caseEle = By.xpath("//a[@role and @title='Cases']");
    private final By casesViewDrpDwn = By.xpath("//*[@class='triggerLinkText selectedListView uiOutputText']");
    private final By allCasesView = By.xpath("//*[@class=' virtualAutocompleteOptionText' and text()='All Cases']");
    private final By casesIdLink = By.xpath("//*[@data-aura-class='uiVirtualDataTable']/tbody/tr/th[1]");
    private final By lastCaseNumSelector = By.xpath("//table/tbody/descendant::a[last()]");
    private final By primaryContactCb = By.xpath("//tbody/tr/td[6]/span/span/img");
    private final String contactNameLink = "//tbody/tr[rowNum]/th[1]/span/a";
    private final By optInOptOutButton = By.xpath("//*[@class='slds-button slds-button_brand slds-align_absolute-center']");
    private final By contactListLink = By.xpath("//a[@role and @title='Contacts List']");
    private final By institutionNameLinkInCasesPage = By.xpath("//tbody/tr/td[6]/span");
    private final String caseNumberLink = "//tbody/tr[rowNum]/th/span/a";
    private By searchField = By.xpath("//h2/ancestor::div[contains(@class, 'page-header')]/following-sibling::div//table[contains(@class, 'VirtualDataTable')]/tbody/tr/td[1]/following-sibling::th//a");
    private final By deleteButton=By.xpath("//a[@title='Delete']");
    private final By confirmDeleteButton=By.xpath("//button[@title='Delete']");
    private final By makePrimaryContactButton=By.xpath(".//*[@title='Make Primary Contact']");

    public CasesPage(WebDriver driver) {
        this.driver = driver;
        platformName = FileReaderManager.getInstance().getConfigReader().getPlatform();
    }

    @Step("Select Cases from dropdown menu")
    public void selectCasesFromDropDownMenu(WebDriver driver) {
        clickMenuItem(driver, "Cases");
        fActions.clickElement(driver, caseEle);
    }

    @Step("Navigate to newcase page")
    public void clickOnNewCase() throws NoSuchElementException {
        fActions.clickElement(driver, newCaseElement);
        fActions.waitForElementVisible(driver, descriptionElement, 15);
    }

    public String getInstituionName(int rowNum) {
        try {
            int headerPos;
            headerPos = reusable.getTableHeaderNamePosition(driver, "Institution");
            if (headerPos == -1) {
                return "Unable to find the header name mentioned";
            } else if (headerPos == 0) {
                return "Unable to find table";
            }
            long count = getAllCaseRows();
            for (int i = 1; i <= count; i++) {
                if (i == (rowNum + 1)) {
                    WebElement element = fActions.getWebElement(driver, By.xpath("//tbody/tr[" + i + "]" + "/td[" + headerPos + "]//a"));
                    fActions.moveOnToElement(driver, element).build().perform();
                    return element.getText();
                }
            }
            return "";

        } catch (Exception e) {
            return "Got exception: " + e.getMessage();
        }
    }

    private long getAllCaseRows() {
        Actions actions = new Actions(driver);
        boolean flag = true;
        int count = 0;
        while (flag) {
            try {
                actions.moveToElement(driver.findElement(By.xpath("//table//tbody/tr[last()]"))).perform();
                int currentVal = fActions.getXpathCount(driver, By.xpath("//table//tbody/tr"));
                Thread.sleep(1000);
                actions.moveToElement(driver.findElement(By.xpath("//table//tbody/tr[last()]"))).perform();
                int nextIterationVal = fActions.getXpathCount(driver, By.xpath("//table//tbody/tr"));
                if (currentVal == nextIterationVal) {
                    flag = false;
                    count = currentVal;
                }
            } catch (Exception e) {
                flag = false;
            }
        }
        return count;
    }

    public List<String> getAllCaseNumbers() {
        List<String> rowList = new ArrayList<>();
        try {
            clickCasesListViewDropDwn(driver);
            selectAllCasesFromDropDwn(driver);
            long count = getAllCaseRows();
            if (count == 0) return rowList;
            for (int i = 1; i <= count; i++) {
                WebElement element = driver.findElement(By.xpath("//tbody/tr[" + i + "]" + "/th//a"));
                fActions.moveOnToElement(driver, element).build().perform();
                rowList.add(element.getText());
            }

        } catch (Exception e) {
        }
        return rowList;
    }

    public String getLastCaseNum() {
        return fActions.getText(driver, lastCaseNumSelector);
    }

    @Step("Perform Case Ids count In Cases Page")
    public String performCasesCountRetrieval(WebDriver driver) {
        String caseIds = "";
        try {
            selectCasesFromDropDownMenu(driver);
            //fActions.waitInSeconds(TIME_SECONDS_TWO);
            clickCasesListViewDropDwn(driver);
            //fActions.waitInSeconds(TIME_SECONDS_TWO);
            selectAllCasesFromDropDwn(driver);
            //fActions.waitInSeconds(TIME_SECONDS_TWO);
            caseIds = getCaseIdsInAllCasesView(driver);
            //fActions.waitInSeconds(TIME_SECONDS_TWO);
            InvokeInstances.getInvokeInstance().getPageObjectManager().getLoginPage().logoutFromCommunity(driver);
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
        return caseIds;
    }

    public void clickCasesListViewDropDwn(WebDriver driver) {
        fActions.clickElement(driver, casesViewDrpDwn);
    }

    public void selectAllCasesFromDropDwn(WebDriver driver) {
        fActions.clickElement(driver, allCasesView);
    }

    @Step("Fetching the case ids from All Cases View")
    public String getCaseIdsInAllCasesView(WebDriver driver) {
        String caseIds = "";
        try {
            List<WebElement> caseIdsList = fActions.getWebElements(driver, casesIdLink);
            int casesSize = getCasesSize(driver);

            for (int caseIndex = 0; caseIndex < casesSize; caseIndex++)
                caseIds = caseIds + caseIdsList.get(caseIndex).getText() + " ";
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
        return caseIds;
    }

    private int getCasesSize(WebDriver driver) {
        return fActions.getXpathCount(driver, casesIdLink);
    }

    @Step("Navigate to Contact List Page")
    public void navigateToContactListPage(WebDriver driver) {
        try {
            clickMenuItem(driver, MENU_ITEM_MORE);
            fActions.clickElement(driver, contactListLink);
            //fActions.waitInSeconds(TIME_SECONDS_TWO);
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    @Step("Clicking on Primary Contact Name")
    public void clickOnPrimaryContactName(WebDriver driver) {
        try {
            int contactCbCount = fActions.getXpathCount(driver, primaryContactCb);
            List<WebElement> contactCbsList = fActions.getWebElements(driver, primaryContactCb);
            for (int contactNumber = 0; contactNumber < contactCbCount; contactNumber++) {
                if (contactCbsList.get(contactNumber).getAttribute("alt").equals("True")) {
                    fActions.clickElement(driver, By.xpath(contactNameLink.replace("rowNum", String.valueOf(contactNumber + 1))));
                    break;
                }
            }
            fActions.waitInSeconds(TIME_SECONDS_FOUR);
//            fActions.moveMouseByOffSet(driver,100,100);
            clickMenuItem(driver, MENU_ITEM_MORE);
            clickMenuItem(driver, MENU_ITEM_MORE);
//            fActions.waitInSeconds(TIME_SECONDS_FOUR);

        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    @Step("Clicking on Secondary Contact Name")
    public void clickOnSecondaryContactName(WebDriver driver) {
        try {
            int contactCbCount = fActions.getXpathCount(driver, primaryContactCb);
            List<WebElement> contactCbsList = fActions.getWebElements(driver, primaryContactCb);
            for (int contactNumber = 0; contactNumber < contactCbCount; contactNumber++) {
                if (contactCbsList.get(contactNumber).getAttribute("alt").equals("False")) {
                    fActions.clickElement(driver, By.xpath(contactNameLink.replace("rowNum", String.valueOf(contactNumber + 1))));
                    break;
                }
            }
            //fActions.waitInSeconds(TIME_SECONDS_FOUR);
            clickMenuItem(driver, MENU_ITEM_MORE);
            clickMenuItem(driver, MENU_ITEM_MORE);
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    @Step("Verifying value for OptIn/Opt out Button")
    public String verifyOptInOptOut(WebDriver driver) {
        return fActions.getText(driver, optInOptOutButton);
    }

    @Step("Clicking on OptIn/OptOut Button")
    public void clickOptInOptOut(WebDriver driver) {
        try {
            fActions.clickElement(driver, optInOptOutButton);
            //fActions.waitInSeconds(TIME_SECONDS_FOUR);
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    public String getCaseNumbersBasedOnInstitution(String institutionName) {
        String caseIds = "";
        int institutionNamesListCount = fActions.getXpathCount(driver, institutionNameLinkInCasesPage);
        for (int institutionNameIndex = 0; institutionNameIndex < institutionNamesListCount; institutionNameIndex++) {
            List<WebElement> institutionNamesList = fActions.getWebElements(driver, institutionNameLinkInCasesPage);
            if (institutionNamesList.get(institutionNameIndex).getText().equalsIgnoreCase(institutionName)) {
                String caseNumber;
                caseNumber = fActions.getText(driver, By.xpath(caseNumberLink.replace("rowNum", String.valueOf(institutionNameIndex + 1))));
                caseIds = caseIds + caseNumber + " ";
            }
        }
        return caseIds;
    }

    public void navigateToAllCasesView(WebDriver driver) {
        try {
            selectCasesFromDropDownMenu(driver);
            //fActions.waitInSeconds(TIME_SECONDS_TWO);
            clickCasesListViewDropDwn(driver);
            //fActions.waitInSeconds(TIME_SECONDS_TWO);
            selectAllCasesFromDropDwn(driver);
            //fActions.waitInSeconds(TIME_SECONDS_TWO);
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    public void verifyParentInstituteCases(String url, String userName, String password, String parentInstituteCaseNumbers) {
        LoginPage loginPage = InvokeInstances.getInvokeInstance().getPageObjectManager().getLoginPage();
        loginPage.loginToCommunity(url, userName, password);
        selectCasesFromDropDownMenu(driver);
        String casesInChildInstitute = performCasesCountRetrieval(driver);
        String[] caseIdListFromParentInstitute = parentInstituteCaseNumbers.split(" ");
        boolean verifyCaseIdPresenceStatusInChildInstitute = false;
        for (int caseListIndex = 0; caseListIndex < caseIdListFromParentInstitute.length; caseListIndex++) {
            if (casesInChildInstitute.contains(caseIdListFromParentInstitute[caseListIndex])) {
                LogUtil.log(caseIdListFromParentInstitute[caseListIndex] + " is present in child institute");
                verifyCaseIdPresenceStatusInChildInstitute = true;
            } else {
                LogUtil.log(caseIdListFromParentInstitute[caseListIndex] + " is not present in child institute");
                verifyCaseIdPresenceStatusInChildInstitute = false;
            }
        }
        if (!verifyCaseIdPresenceStatusInChildInstitute)
            LogUtil.log("Parent Institute cases are not present in Child institute cases view");
        else {
            LogUtil.log("Parent Institute cases are present in Child institute cases view");
            org.junit.Assert.fail();
        }
    }

    public void verifyInstituteCasesFromConsortiaByInstituteAsOptIn(String caseIdsInPrimaryContactInstitute) {
        String casesInConsortiaPrimaryContact = performCasesCountRetrieval(driver);
        LogUtil.log("Cases Present Under Consortia::" + casesInConsortiaPrimaryContact);
        String[] caseIdListFromInstitute = caseIdsInPrimaryContactInstitute.split(" ");
        boolean verifyCaseIdPresenceStatusInPrimaryConsortia = false;
        for (int caseListIndex = 0; caseListIndex < caseIdListFromInstitute.length; caseListIndex++) {
            if (casesInConsortiaPrimaryContact.contains(caseIdListFromInstitute[caseListIndex])) {
                LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is present");
                verifyCaseIdPresenceStatusInPrimaryConsortia = true;
            } else {
                LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is not present");
                verifyCaseIdPresenceStatusInPrimaryConsortia = false;
            }
        }
        if (verifyCaseIdPresenceStatusInPrimaryConsortia) {
            LogUtil.log("Institute Cases are displaying for Consortia for Institute OptIn");
        } else {
            LogUtil.log("Institute Cases are not displaying for Consortia for Institute OptIn");
            Assert.fail();
        }
    }

    public void verifyInstituteCasesFromConsortiaByInstituteAsOptOut(String caseIdsInPrimaryContactInstitute) {
        String casesInConsortiaPrimaryContact = performCasesCountRetrieval(driver);
        LogUtil.log("Cases Present Under Consortia::" + casesInConsortiaPrimaryContact);
        String[] caseIdListFromInstitute = caseIdsInPrimaryContactInstitute.split(" ");
        boolean verifyCaseIdPresenceStatusInPrimaryConsortia = false;
        for (int caseListIndex = 0; caseListIndex < caseIdListFromInstitute.length; caseListIndex++) {
            if (casesInConsortiaPrimaryContact.contains(caseIdListFromInstitute[caseListIndex])) {
                LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is present");
                verifyCaseIdPresenceStatusInPrimaryConsortia = true;
            } else {
                LogUtil.log(caseIdListFromInstitute[caseListIndex] + " is not present");
                verifyCaseIdPresenceStatusInPrimaryConsortia = false;
            }
        }
        if (verifyCaseIdPresenceStatusInPrimaryConsortia) {
            LogUtil.log("Institute Cases are displaying for Consortia for Institute OptIn");
            Assert.fail();
        } else {
            LogUtil.log("Institute Cases are not displaying for Consortia for Institute OptIn");
        }
    }

    public String getCaseIdsFromPrimaryContactChildInstituteTwo(String url, String userName, String password) {
        LoginPage loginPage = InvokeInstances.getInvokeInstance().getPageObjectManager().getLoginPage();
        loginPage.loginToCommunity(url, userName, password);
        LogUtil.log("Logged in with Primary Contact of Institute TWO");
        String caseIdsInPrimaryContactInstituteTwo = performCasesCountRetrieval(driver);
        LogUtil.log("Cases Present Under Institute Two Of Primary Contact::" + caseIdsInPrimaryContactInstituteTwo);
        return caseIdsInPrimaryContactInstituteTwo;
    }

    public void deleteCase_CXPPortal(List<String> caseNumbers) {

        Iterator<String> caseNumberIterator = caseNumbers.iterator();
        for(int caseNumber = 0; caseNumberIterator.hasNext(); caseNumber++)
        {
            searchCase(caseNumbers.get(caseNumber));
            clickOnSearchCase();
            fActions.clickElement(driver,deleteButton);
            fActions.clickElement(driver,confirmDeleteButton);
            System.out.println(caseNumberIterator.next());
        }

    }

    public void searchCase(String caseNumber) {
        try {
            if (platformName.equalsIgnoreCase(DESKTOP_WEB))
                selectSearchItem(driver, CXP_CASES_MENU);
            searchText(driver, caseNumber);
//            LogUtil.log("Institution search successfully");
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    public void clickOnSearchCase() {
        try {
            fActions.waitForElementVisible(driver, searchField, 30);
            fActions.clickElement(driver, searchField);
//            LogUtil.log("Successfully click on the institution name");
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    public void clickCasesListViewDropDwn() {
        fActions.executeOnDesktop(driver, webDriver -> fActions.clickElement(driver, casesViewDrpDwn));
    }

    public void selectAllCasesFromDropDwn() {
        fActions.executeOnDesktop(driver, webDriver -> fActions.clickElement(driver, allCasesView));
    }

    public void clickOnCaseNum(String caseNum) {
        By targetCaseNum = null;
        if (fActions.deviceIsDesktop(driver))
            targetCaseNum = By.xpath("//a[@title='" + caseNum + "']");
        else
            targetCaseNum = By.xpath("//p[text()='" + caseNum + "']");
        fActions.waitForElementVisible(driver, targetCaseNum, 10);
        fActions.clickElement(driver, targetCaseNum);
    }

    public void makePrimaryContact(WebDriver driver)
    {
        fActions.clickElement(driver,makePrimaryContactButton);
        try {
            fActions.waitInSeconds(TIME_SECONDS_THREE);
            fActions.waitInSeconds(TIME_SECONDS_THREE);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
