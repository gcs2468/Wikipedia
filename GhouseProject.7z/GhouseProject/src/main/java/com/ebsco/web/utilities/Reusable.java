package com.ebsco.web.utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

public class Reusable {
    private SeleniumWrappers wrappers = new SeleniumWrappers();

    public int getTableHeaderNamePosition(WebDriver driver, String headerName) {
        try { wrappers.waitForElementVisible(driver, By.xpath("//table"), 20);
        }catch (Exception e){return 0;}
        WebElement tHead = driver.findElement(By.tagName("thead"));
        WebElement tr = tHead.findElement(By.tagName("tr"));
        List<WebElement> th = tr.findElements(By.tagName("th"));
        int count = 0;
        Actions actions =new Actions(driver);
        actions.moveToElement(th.get(0)).perform();
        for (WebElement e : th) {
            if (e.getText().toLowerCase().contains(headerName.toLowerCase())) return count;
            count++;
        }
        return -1;
    }


    public String getTableRowText(WebDriver driver, String headerName){
        int pos = getTableHeaderNamePosition(driver, headerName);
        if(pos == -1){
            return  "Unable to find the header name mentioned";
        }else if(pos == 0){
            return "Unable to find table";
        }
        WebElement tBody = driver.findElement(By.tagName("tbody"));
        List<WebElement> rowList = tBody.findElements(By.tagName("tr"));
        for (WebElement row: rowList){
            List<WebElement> dataList = row.findElements(By.tagName("td"));
            for(int i=0; i<dataList.size(); i++){
                if(i == pos){
                    return  dataList.get(i).getText();
                }
            }
        }
        return  null;
    }
}
