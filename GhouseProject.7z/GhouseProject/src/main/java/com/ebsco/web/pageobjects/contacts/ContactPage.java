package com.ebsco.web.pageobjects.contacts;

import com.ebsco.web.pageobjects.common.GlobalPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ContactPage extends GlobalPage {

    private WebDriver driver;
    public ContactPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickOnLoginToCommunity(){
        fActions.clickElement(driver, By.xpath("//div[@title='Log in to Community as User']"));
    }

}
