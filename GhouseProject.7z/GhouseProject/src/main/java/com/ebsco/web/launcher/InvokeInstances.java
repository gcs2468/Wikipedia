package com.ebsco.web.launcher;

import com.ebsco.web.managers.FileReaderManager;
import com.ebsco.web.managers.PageObjectManager;
import com.ebsco.web.managers.WebDriverManager;

import static com.ebsco.common.constants.Constants.API;

public class InvokeInstances {
    private WebDriverManager webDriverManager;
    private PageObjectManager pageObjectManager;
    public  static InvokeInstances invoke;

    private InvokeInstances(){
        if(!FileReaderManager.getInstance().getConfigReader().getPlatform().equalsIgnoreCase(API)) {
            webDriverManager = new WebDriverManager();
            pageObjectManager = new PageObjectManager(webDriverManager.getDriver());
        }
    }

    public static InvokeInstances getInvokeInstance(){ return (invoke == null) ? invoke = new InvokeInstances(): invoke; }

    public WebDriverManager getWebDriverManager() { return webDriverManager; }

    public PageObjectManager getPageObjectManager() { return pageObjectManager; }

    public synchronized void resetInvokeInstances(){
        invoke = null;
    }
}
