package com.ebsco.web.pageobjects.home;

import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.pageobjects.common.GlobalPage;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends GlobalPage {
    private WebDriver driver;
    private By inputBox = By.xpath("//div[@class='search-box']/input");
    private By searchBtn = By.xpath("//div[@class='search-box']/button");
    private By profileDropDownSelector = By.xpath("//button[@class='profile-menuTrigger']");
    private By profileMenuItemSelector = By.xpath("//li[@class='profile-menuItem profile uiMenuItem']/a");
    SearchResultsPage searchResultsPage = InvokeInstances.getInvokeInstance().getPageObjectManager().getSearchResultsPage();
    private By contentTitle = By.xpath("//h1[@class='contentTitle']");
    private static final String TITLE_CONTENT = "How Can we Help?";

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    @Step("Search Item from search box")
    public void searchItem(String searchItem) {
        fActions.enterText(driver, inputBox, searchItem);
        fActions.clickElement(driver, searchBtn);
        searchResultsPage.getSearchItemStatus();
    }

    public void goToProfilePage() {
        fActions.waitForElementVisible(driver, profileDropDownSelector, 10);
        fActions.clickElement(driver, profileDropDownSelector);
        fActions.waitForElementVisible(driver, profileMenuItemSelector, 10);
        fActions.clickElement(driver, profileMenuItemSelector);
    }

    public boolean contentTitleExists() {
        fActions.waitForElementVisible(driver, contentTitle, 10);
        return driver.findElement(contentTitle).getText().equalsIgnoreCase(TITLE_CONTENT);
    }}
