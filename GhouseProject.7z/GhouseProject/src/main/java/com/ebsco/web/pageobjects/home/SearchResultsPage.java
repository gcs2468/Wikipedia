package com.ebsco.web.pageobjects.home;

import com.ebsco.web.pageobjects.common.GlobalPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static com.ebsco.common.constants.Constants.*;

public class SearchResultsPage extends GlobalPage {

    private WebDriver driver;
    private By mobileSearchItemStatEle = By.xpath("//ul[contains(@class, 'itemRows')]//li//div[@title='Status:']/following-sibling::div/span");


    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    public String getSearchItemStatus() {
        if (platformName.equalsIgnoreCase(MOBILE_WEB) && deviceType.equalsIgnoreCase(PHONE)) {
            return fActions.getText(driver, mobileSearchItemStatEle);
        } else {
            return reusable.getTableRowText(driver, STATUS);
        }
    }
}
