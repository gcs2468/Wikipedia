package com.ebsco.web.pageobjects.contacts;

import com.ebsco.web.pageobjects.common.GlobalPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class ContactsPage extends GlobalPage {
	private WebDriver driver;
	public ContactsPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clickMenuBar() {
		fActions.clickElement(driver, By.xpath("//*[@title='Toggle SideBar']"));
	}
	
	public void clickContactsMenu() {
		fActions.clickElement(driver, By.xpath("//*[@class='title truncate'][text()='Contacts']"));
	}
	
	public void clickNewButton() {
		fActions.clickElement(driver, By.xpath("//*[@title='New']"));
	}
	
	public void selectTitle(String titleName) {
		fActions.selectOptionByVisibleText(driver, By.xpath("//*[contains(@class,'salutation')]"), titleName);

	}
	
	public void enterFirstName(String fName) {
		fActions.enterText(driver, By.xpath("//*[contains(@class,'firstName')]"), fName);
	}
	
	/*public String enterMiddleName(String mName) {
		fieldActions.enterText(driver, By.xpath("//*[contains(@class,'middleName')]"), mName);
		return "";
	}*/
	
	public void enterLastName(String lName) {
		fActions.enterText(driver, By.xpath("//*[contains(@class,'lastName')]"), lName);
	}
	
	public String selectAccount() {
		fActions.clickElement(driver, By.xpath("(//*[contains(@class,'text input')])[1]"));
		fActions.clickElement(driver, By.xpath("//*[contains(@class,'default slds-text-body')][text()='testAccountName1234']"));
		return "";
	}
	
	public void clickSave() {
		fActions.clickElement(driver, By.xpath("//*[text()='Save']"));
	}
	
	
	
	
	
}
