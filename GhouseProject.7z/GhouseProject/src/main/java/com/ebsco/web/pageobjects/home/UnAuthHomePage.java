package com.ebsco.web.pageobjects.home;

import com.ebsco.web.pageobjects.common.GlobalPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class UnAuthHomePage extends GlobalPage {
    private WebDriver driver;
    private By signInBtn = By.xpath("//a[@title='Sign In']");

    public UnAuthHomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickOnSignInButton() {
        fActions.clickElement(driver, signInBtn);
    }
}
