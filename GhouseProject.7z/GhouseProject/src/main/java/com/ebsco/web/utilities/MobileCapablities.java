package com.ebsco.web.utilities;

import com.ebsco.web.appconfig.ConfigFileReader;
import com.ebsco.web.managers.FileReaderManager;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileBrowserType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;
import io.github.bonigarcia.wdm.ChromeDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.URL;

import static com.ebsco.common.constants.Constants.*;

public class MobileCapablities {

    WebDriver setMobileCapablities(String browserName) {
        WebDriver wDriver = null;
        DesiredCapabilities caps;
        String environmentType = FileReaderManager.getInstance().getConfigReader().getEnvironment();
        String mobileOs = FileReaderManager.getInstance().getConfigReader().getMobileOs();
        try {
            switch (environmentType.toLowerCase()) {
                case LOCAL_ENV_TYPE:
                    switch (mobileOs.toLowerCase()) {
                        case ANDROID_PLATFORM:
                            switch (browserName.toLowerCase()) {
                                case CHROME_BROWSER:
                                    ChromeDriverManager.getInstance().setup();
                                    caps = new DesiredCapabilities();
                                    caps.setCapability(MobileCapabilityType.BROWSER_NAME, MobileBrowserType.CHROME);
                                    caps.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
                                    caps.setCapability(MobileCapabilityType.DEVICE_NAME, LOCAL_MOBILE_DEVICE_NAME);
                                    wDriver = new AppiumDriver<>(new URL(LOCAL_MOBILE_URL), caps);
                                    break;
                                default:
                                    throw new Exception("Local only supporting chrome browser i,e for Android platform");
                            }
                            break;
                        default:
                            throw new Exception("Local only supports Android platform");
                    }
                    break;
                case REMOTE_ENV_TYPE:
                    switch (mobileOs.toLowerCase()) {
                        case IOS_PLATFORM:
                            switch (browserName.toLowerCase()) {
                                case SAFARI_BROWSER:
                                    ConfigFileReader configFileReader = FileReaderManager.getInstance().getConfigReader();
                                    caps = DesiredCapabilities.iphone();
                                    caps.setCapability(MobileCapabilityType.APPIUM_VERSION, configFileReader.getAppiumVersion());
                                    caps.setCapability(MobileCapabilityType.DEVICE_NAME, configFileReader.getMobileDeviceName());
                                    caps.setCapability("deviceOrientation", MOBILE_DEVICE_ORIENTATION);
                                    caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, configFileReader.getMobileOsVersion());
                                    caps.setCapability(MobileCapabilityType.PLATFORM_NAME, configFileReader.getMobileOs());
                                    caps.setCapability(MobileCapabilityType.BROWSER_NAME, configFileReader.getBrowser());
                                    String accessKey = FileReaderManager.getInstance().getConfigReader().getSauceAccessKey();
                                    String sauceUsername = FileReaderManager.getInstance().getConfigReader().getSauceUsername();
                                    String SAUCE_LABS_URL = "http://" + sauceUsername + ":" + accessKey + "@ondemand.saucelabs.com:80/wd/hub";
                                    wDriver = new IOSDriver<>(new URL(SAUCE_LABS_URL), caps);
                                    break;
                                default:
                                    throw new Exception("Framework supports only safari browser for iOS platform");
                            }
                            break;
                        case ANDROID_PLATFORM:
                            switch (browserName.toLowerCase()) {
                                case CHROME_BROWSER:
                                    ConfigFileReader configFileReader = FileReaderManager.getInstance().getConfigReader();
                                    caps = DesiredCapabilities.android();
                                    caps.setCapability(MobileCapabilityType.APPIUM_VERSION, configFileReader.getAppiumVersion());
                                    caps.setCapability(MobileCapabilityType.DEVICE_NAME, configFileReader.getMobileDeviceName());
                                    caps.setCapability("deviceOrientation", MOBILE_DEVICE_ORIENTATION);
                                    caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, configFileReader.getMobileOsVersion());
                                    caps.setCapability(MobileCapabilityType.PLATFORM_NAME, configFileReader.getMobileOs());
                                    caps.setCapability(MobileCapabilityType.BROWSER_NAME, configFileReader.getBrowser());
                                    String accessKey = FileReaderManager.getInstance().getConfigReader().getSauceAccessKey();
                                    String sauceUsername = FileReaderManager.getInstance().getConfigReader().getSauceUsername();
                                    String SAUCE_LABS_URL = "http://" + sauceUsername + ":" + accessKey + "@ondemand.saucelabs.com:80/wd/hub";
                                    wDriver = new AndroidDriver<>(new URL(SAUCE_LABS_URL), caps);
                                    break;
                                default:
                                    throw new Exception("Framework supports only chrome browser for Android platform");
                            }
                            break;
                    }
                    break;
                default:
                    throw new Exception("Please mention local or remote label as env variable");
            }
            return wDriver;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
