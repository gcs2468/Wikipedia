package com.ebsco.web.utilities;

import com.ebsco.web.launcher.InvokeInstances;
import io.qameta.allure.Attachment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import java.util.List;

public class TestListener implements ITestListener {


    @Override
    public void onTestStart(ITestResult result) {

    }

    @Override
    public void onTestSuccess(ITestResult result) {
        WebDriver driver = InvokeInstances.getInvokeInstance().getWebDriverManager().getDriver();
        saveScreenShotPNG(driver);
        Reporter.log(logOutput(Reporter.getOutput(result)), true);
    }

    @Override
    public void onTestFailure(ITestResult result) {
        WebDriver driver = InvokeInstances.getInvokeInstance().getWebDriverManager().getDriver();
        saveScreenShotPNG(driver);
        Reporter.log(logOutput(Reporter.getOutput(result)), true);
    }

    @Override
    public void onTestSkipped(ITestResult result) {

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

    }

    @Override
    public void onStart(ITestContext context) {

    }

    @Override
    public void onFinish(ITestContext context) {

    }

    @Attachment
    public byte[] saveScreenShotPNG(WebDriver driver){
        return ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
    }

    @Attachment
    public String logOutput(List<String> outputList) {
        String output = "";
        for (String o : outputList)
            output += o + " ";
        return output;
    }
}
