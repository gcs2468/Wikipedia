package com.ebsco.web.pageobjects.cases;

import com.ebsco.common.constants.Constants;
import com.ebsco.common.utility.AppProperties;
import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.managers.PageObjectManager;
import com.ebsco.web.pageobjects.common.GlobalPage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.apache.log4j.LogManager;

import java.util.Map;

import static com.ebsco.common.constants.Constants.COMMUNITY_PROFILE_NAME;
import static com.ebsco.common.constants.Constants.TIME_SECONDS_FOUR;
import static com.ebsco.common.constants.Constants.TIME_SECONDS_TWO;

public class CasePage extends GlobalPage {

    private Logger logger = LogManager.getLogger(this.getClass());
    private WebDriver webDriver;
    private By caseTitleSelector = By.xpath("//h1/span[@class='uiOutputText']");
    private By caseStatusSelector = By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[5]");
    private By mobileCaseStatusSelector =
            By.xpath("//ul[@class='slds-list--horizontal slds-has-dividers--left']/li[position()=1]/span");
    private By caseOwnerSelector = By.xpath("//div[@class='ownerName']//a");
    private By instituteNameSelector =
            By.xpath("(//div[@class='outputLookupContainer forceOutputLookupWithPreview']/a)[1]");
    private By mobileInstituteNameSelector =
            By.xpath("(//a[contains(@class, 'outputLookupLink ')])[1]");
    private By subjectSelector =
            By.xpath("(//span[@class='uiOutputText'])[4]");
    private By descriptionSelector =
            By.xpath(".//span[@class='uiOutputTextArea']");
    private By interfaceSelector =
            By.xpath("(.//*[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only'])[8]");
    private By relatedTabSelector = By.xpath("//li[contains(@class, 'uiTabItem')]/a[@title='ATTACHMENTS']");
    private By attachmentNameSelector =
            By.xpath("//span[@class='cuf-auxBodyTitle uiOutputText']");
    private By caseNumSelector = By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only']/span[@class='uiOutputText'])[1]");
    private By mobileCaseNumSelector =
            By.xpath("//ul[@class='slds-list--horizontal slds-has-dividers--left']/li[position()=2]/span");
    private By homePageSelector = By.xpath("//a[contains(@class, 'comm-navigation__home-link')]");
    private By burgerSelector = By.xpath("//div[@class='themeNavTrigger comm-navigation__mobile-trigger']");
    private By siNumSelector = By.xpath("(//a[contains(@class, 'outputLookupLink')])[1]");
    private By attachmentTabSelector = By.xpath("//a[@title='ATTACHMENTS']/parent::li");
    private By editSectionFieldSelectors =
            By.xpath("//div[contains(@class, 'forcePageBlockSectionEdit')]//span[contains(@class, 'uiOutputText')]");
    private By editSectionDropDownSelector =
            By.xpath("//div[contains(@class, 'forcePageBlockSectionEdit')]//*[contains(@class, 'select')]");
    private By newMessageBtnSelector = By.xpath("//button[text()='New']");
    private By subjectInputFieldSelector = By.xpath("//input[contains(@class, 'slds-input')]");
    private By textAreaSelector = By.xpath("//div[contains(@class, 'ql-editor')]");
    private By latestCaseFromMsgSelector = By.xpath("(//span[@class='slds-form-element__static'])[1]");
    private By latestCaseSubjectMsgSelector = By.xpath("(//span[@class='slds-form-element__static'])[2]");
    private By createMsgBtnSelector =
            By.xpath("//footer[@class='cCreateNewSFMessageModal']/button[contains(@class, 'slds-button_brand')]");
    private By editBtnSelector = By.xpath("//a[@title='Edit']");
    private By mobileEditBtnSelector = By.xpath("(//button[contains(@class, 'slds-p-around--none')])[1]");
    private By caseEditCancelBtnSelector = By.xpath("//button[@title='Cancel']");

    public CasePage(WebDriver webDriver) {
        this.webDriver = webDriver;
    }

    public String getCaseTitle() {
        try {
            Thread.sleep(TIME_SECONDS_FOUR);
            fActions.waitForElementVisible(webDriver, caseTitleSelector, 10);
            return webDriver.findElement(caseTitleSelector).getText();
        }catch (Exception e){
            return e.getMessage();
        }
    }

    public String getAttachmentName() {
        return fActions.getText(webDriver, attachmentNameSelector);
    }

    public String getCaseStatus() {
        String caseStatus;
        if (fActions.deviceIsDesktop(webDriver))
            caseStatus = fActions.getText(webDriver, caseStatusSelector);
        else
            caseStatus = fActions.getText(webDriver, mobileCaseStatusSelector);

        return caseStatus;
    }

    public String getInstituteName() {
        String instituteName = null;
        if (fActions.deviceIsDesktop(webDriver))
            instituteName = fActions.getText(webDriver, instituteNameSelector);
        else
            instituteName = fActions.getText(webDriver, mobileInstituteNameSelector);
        return instituteName;
    }

    public String getSubject() {
        return fActions.getText(webDriver, subjectSelector);
    }

    public String getDescription() {
        return fActions.getText(webDriver, descriptionSelector);
    }

    public String getInterfaceName() {
        return fActions.getText(webDriver, interfaceSelector);
    }

    public void clickRelatedTab() {
        fActions.clickElement(webDriver, relatedTabSelector);
    }

    public String getCaseNumber() {
        String caseNum;
        if (fActions.deviceIsDesktop(webDriver))
            caseNum = fActions.getText(webDriver, caseNumSelector);
        else
            caseNum = fActions.getText(webDriver, mobileCaseNumSelector);
        return caseNum;
    }

    public void goToHomePage() {
            //fActions.clickElement(webDriver, burgerSelector);
            fActions.clickElement(webDriver, homePageSelector);
    }


    @Step("Validate case details")
    public void validateCaseCreated(Map<String,String> casesData, String accountName, String profileName) {
        StringBuilder errMsg = new StringBuilder();
        try{
            String caseNumber = getCaseNumber();
        if(!getCaseTitle().equals(casesData.get("Subject")))
            errMsg.append(String.format("Incorrect case title. Found: %s", getCaseTitle()));
//        if(!COMMUNITY_PROFILE_NAME.equals(profileName))
//                errMsg.append(String.format("Incorrect Profile name. Found: %s", profileName));
        if(!getCaseStatus().equals("New"))
            errMsg.append(String.format("Incorrect case status: Found %s", getCaseStatus()));
        if(!getInstituteName().equals(accountName))
                errMsg.append(String.format("Incorrect Institute name: Found: %s", getInstituteName()));

        if(!getSubject().equals(casesData.get("Subject")))
                errMsg.append(String.format("Incorrect case subject: Found %s", getSubject()));
        if(!getDescription().equals(casesData.get("Description")))
                errMsg.append(String.format("Incorrect description: Found %s but should be %s", getDescription(), casesData.get("Description")));
        if(!getInterfaceName().equals("AutoMate"))
                errMsg.append(String.format("Incorrect interface name: Found %s but should be AutoMate", getInterfaceName()));

        clickRelatedTab();
        /**
         * Please uncomment after fixing upload file issue
         */
        /*String attachmentNameFound = getAttachmentName();
        String expectedAttachmentName = "New Text Document.txt";
        if(!expectedAttachmentName.equals(attachmentNameFound))
                errMsg.append(String.format("Incorrect attachment name: %s", attachmentNameFound));*/

        goToHomePage();
        PageObjectManager pom = InvokeInstances.getInvokeInstance().getPageObjectManager();
        pom.getHomePage().searchItem(caseNumber);
        if(!caseNumber.equals(pom.getCasesPage().getLastCaseNum()))
            errMsg.append("Case number not found.");

        if(!errMsg.toString().isEmpty()) Assert.fail(errMsg.toString());
        }catch (Exception e){
            Assert.fail(e.getMessage());
        }
    }

    @Step("Validate if all fields are non-editable.")
    public boolean allFieldsAreNonEditable() {
        fActions.executeOnDesktop(webDriver, driver -> fActions.clickElement(driver, editBtnSelector));
        fActions.executeOnMobile(webDriver, driver -> fActions.clickElement(driver, mobileEditBtnSelector));
        fActions.waitForElementVisible(webDriver, caseTitleSelector, 10);
        for (WebElement inputField : webDriver.findElements(editSectionFieldSelectors)) {
            if (textCanBeWritten(inputField)) {
                fActions.clickElement(webDriver, caseEditCancelBtnSelector);
                return false;
            }
        }

        boolean dropDownsValid = validateEditSectionDropDowns();
        fActions.clickElement(webDriver, caseEditCancelBtnSelector);
        return dropDownsValid;
    }

    public void createNewCaseMessage() {
        fActions.clickElement(webDriver, newMessageBtnSelector);
        fActions.waitForElementVisible(webDriver, subjectInputFieldSelector, 10);
        webDriver.findElement(subjectInputFieldSelector).sendKeys(AppProperties.getValueFor("test.casemessage.subject"));
        webDriver.findElement(textAreaSelector).sendKeys(AppProperties.getValueFor("test.casemessage.message"));
        fActions.clickElement(webDriver, createMsgBtnSelector);
    }

    @Step("Verify if message has been created.")
    public boolean verifyCreationOfCaseMsg(String userName) {
        String messageSender = fActions.getText(webDriver, latestCaseFromMsgSelector);
        String messageSubject = fActions.getText(webDriver, latestCaseSubjectMsgSelector);
        return messageSender.contains(userName) &&
                messageSubject.equals(AppProperties.getValueFor("test.casemessage.subject"));
    }

    public void clickAttachmentSection() {
        fActions.clickElement(webDriver, attachmentTabSelector);
    }

    private boolean textCanBeWritten(WebElement inputField) {
        try {
            String dummyText = "DUMMY TEXT";
            inputField.sendKeys(dummyText);
            return inputField.getText().equals(dummyText);
        } catch (WebDriverException e) {
            return false;
        }
    }

    private boolean validateEditSectionDropDowns() {
        for (WebElement element: webDriver.findElements(editSectionDropDownSelector)) {
            if (element.isEnabled()) {
//                logger.info("It's enabled.");
                return false;
            } else {
//                logger.info("It's disabled.");
            }
        }
        return true;
    }
}
