package com.ebsco.web.pageobjects.cases;

import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.managers.FileReaderManager;
import com.ebsco.web.pageobjects.common.GlobalPage;
import com.ebsco.web.utilities.LogUtil;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import static com.ebsco.common.constants.Constants.DESKTOP_WEB;
import static com.ebsco.common.constants.Constants.MOBILE_WEB;

public class CreateCasePage extends GlobalPage {

    private WebDriver driver;
    private By subjectElement = By.xpath("//span[text()='Subject']/parent::label/following-sibling::input");
    private By descElement = By.xpath("//textarea");
    private By attachElement = By.xpath("//div[@class='fileSelector']//span[text()='Add Attachment' and contains(@class, 'needsclick')]");
    private By prodDropDownElement = By.xpath("//a[contains(@class, 'select')]");
    private String productItem = "//a[@role='menuitemradio' and text()='";
    private By submitBtn = By.xpath("//span[text()='Submit']");

    public CreateCasePage(WebDriver driver) {
        this.driver = driver;
        platformName = FileReaderManager.getInstance().getConfigReader().getPlatform();
    }

    @Step("Select productname from dropdown")
    public void selectProductOrInterface(String productName) {

        if (platformName.equalsIgnoreCase(MOBILE_WEB)) {
            fActions.selectByValueFromDropDown(driver, By.xpath("//select"), productName);
        } else {
            fActions.clickElement(driver, prodDropDownElement);
            fActions.clickElement(driver, By.xpath(productItem + productName + "']"));
        }

    }

    @Step("Enter subject value")
    public void enterSubject(String subject) {
        fActions.enterText(driver, subjectElement, subject);
        LogUtil.log("Entered subject successfully in subject field");
    }

    @Step("Enter description and case description value")
    public void enterDescription(String description) {
        fActions.enterText(driver, descElement, description);
        LogUtil.log("Entered description successfully in description field");
    }

    @Step("Attach File")
    public void addAttachment(String filePath){
        try {
            fActions.fileUpload(driver, attachElement, filePath);
        }catch (Exception e){
            Assert.fail(e.getMessage());
        }
    }

    @Step("Click on submit button")
    public void clickSubmit() {
        fActions.clickElement(driver, submitBtn);
    }

   /* public String createNewCase(String productInterfaceName,String subject,String description)
    {
//        InvokeInstances.getInvokeInstance().getPageObjectManager().getHomePage();
        homePage.goToProfilePage();
        String accountName = globalPage.getAccountName();
        String profileName = globalPage.getProfileName();
        casesPage.selectCasesFromDropDownMenu(driver);
        casesPage.clickOnNewCase();
        createCasePage.selectProductOrInterface(productInterfaceName);
        createCasePage.enterSubject(subject);
        createCasePage.enterDescription(description);
        //createCasePage.addAttachment(System.getProperty("user.dir") + UPLOAD_TEST_FILE);
        createCasePage.clickSubmit();
        return casePage.getCaseNumber();
    }*/
}
