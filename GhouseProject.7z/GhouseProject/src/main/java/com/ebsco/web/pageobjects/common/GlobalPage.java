package com.ebsco.web.pageobjects.common;

import com.ebsco.web.appconfig.ConfigFileReader;
import com.ebsco.web.managers.FileReaderManager;
import com.ebsco.web.utilities.Reusable;
import com.ebsco.web.utilities.SeleniumWrappers;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

import static com.ebsco.common.constants.Constants.*;

public class GlobalPage {
    private WebDriver driver;
    public SeleniumWrappers fActions = new SeleniumWrappers();
    protected Reusable reusable = new Reusable();
    ConfigFileReader configs = FileReaderManager.getInstance().getConfigReader();
    protected String platformName = configs.getPlatform();
    protected String deviceType = configs.getMobileDeviceType();

    protected final By appMenuEle = By.xpath("//a[contains(@class, 'ThemeNavTrigger')]");
    protected final By toggleSideBar = By.xpath("//a[@title='Toggle SideBar']");
    private By profileNameSelector =
            By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only']/span[@class='uiOutputText'])[1]");
    private By accountNameSelector =
            By.xpath("//a[@class='textUnderline outputLookupLink slds-truncate forceOutputLookup']");

    private String mobileMenuListEle = "//ul[contains(@class, 'homeList')]//div[text()='menuItemName']";
    private String headerEle = "//span[text()='menuItemName']";
    private String commMenuElement = "//*[contains(@class, 'themeNavContainer')]//button[text()='menuItemName']";
    private String homeMenuElement = "//*[contains(@class, 'themeNavContainer')]//a[text()='menuItemName']";
    private By cxpSearchItems = By.xpath("//div[@id='input-1-base-combobox']/ul[@aria-label='All Searchable Items']/li//lightning-base-combobox-formatted-text");
    private By cxpMobileInputEle = By.xpath("//input");
    private By cxpDesktopInputEle = By.cssSelector("#input-1");
    private By cxpDesktopSearchDropDownMenu = By.xpath("//li[contains(@class,'lookup__item SEARCH_OPTION')]");
    private By cxpMobileSearchDropDownMenu = By.xpath("//div[contains(@class, 'nameWrapper')]/p");
    private By searchBox = By.xpath("//input[@role='combobox']");


    public GlobalPage() {
    }

    public GlobalPage(WebDriver driver) {
        this.driver = driver;
    }

    // custsat method
    protected boolean selectSearchItem(WebDriver driver, String itemName) {
        fActions.clickElement(driver, cxpDesktopInputEle);
        List<WebElement> data = driver.findElements(cxpSearchItems);
        for (WebElement ele : data) {
            String title = ele.getAttribute(ATTRIBUTE_TITLE);
            if (title.equals(itemName)) {
                fActions.moveOnToElement(driver, ele).click().build().perform();
                return true;
            }
        }
        return false;
    }

    protected boolean searchText(WebDriver driver, String text) {
        try {
            By menuDropDown = null;
            fActions.enterText(driver, searchBox, text);
            switch (platformName.toLowerCase()){
                case DESKTOP_WEB:
                    menuDropDown = cxpDesktopSearchDropDownMenu;
                    break;
                case MOBILE_WEB:
                    menuDropDown = cxpMobileSearchDropDownMenu;
            }
            fActions.waitForElementVisible(driver, menuDropDown, TIME_SECONDS_THIRTY);
            fActions.clickElement(driver, menuDropDown);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Custsat menu items
    protected void clickMenu(WebDriver driver, String menuItem) {
        if (platformName.equalsIgnoreCase(MOBILE_WEB)) {
            if (deviceType.equalsIgnoreCase(PHONE)) {
                fActions.clickElement(driver, toggleSideBar);
                fActions.clickElement(driver, By.xpath(mobileMenuListEle.replace("menuItemName", menuItem)));
            }else{
                fActions.clickElement(driver, By.xpath(headerEle.replace("menuItemName", menuItem)));
            }
        }else {
            fActions.clickElement(driver, By.xpath(headerEle.replace("menuItemName", menuItem)));
        }
    }

    // community menu items
    protected void clickMenuItem(WebDriver driver, String menuItemName) {
        if (platformName.equalsIgnoreCase(MOBILE_WEB)) {
            if (deviceType.equalsIgnoreCase(PHONE)) fActions.clickElement(driver, appMenuEle);
        }
        if (menuItemName.equals(COMM_HOME_MENU)) {
            fActions.clickElement(driver, By.xpath(homeMenuElement.replace("menuItemName", menuItemName)));
        } else fActions.clickElement(driver, By.xpath(commMenuElement.replace("menuItemName", menuItemName)));
    }

    @Step("Click on home button")
    public void goToHome(WebDriver driver) {
        clickMenuItem(driver, COMM_HOME_MENU);
    }

    public String getProfileName() {
        return fActions.getText(driver, profileNameSelector);
    }

    public String getAccountName() {
        return fActions.getText(driver, accountNameSelector);
    }
}