package com.ebsco.web.pageobjects.login;

import com.ebsco.web.appconfig.ConfigFileReader;
import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.managers.FileReaderManager;
import com.ebsco.web.pageobjects.common.GlobalPage;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

import static com.ebsco.common.constants.Constants.*;

public class LoginPage extends GlobalPage {

    private WebDriver driver;
    final private By commuUsernameField = By.xpath("//input[@placeholder='Email']");
    final private By commuPasswordField = By.xpath("//input[@placeholder='Password']");
    final private By commuSignInBtn = By.xpath("//button/span");
    final private By profileMenuField = By.xpath("//button[contains(@class, 'profile-menu')]");
    final private By classicField = By.xpath("//a[@class='switch-to-lightning']");
    final private By custSatIcon = By.xpath("//div[@class='slds-icon-waffle']");
    final private By profileIcon = By.xpath("//img[@class='profile-icon']");
    final private By logoutField = By.xpath("//a[@title='Logout']");
    final private By myAccountField=By.xpath("//a[@title='My Account']");
    final private By cusSatUsernameField = By.id("username");
    final private By cusSatPasswordField = By.id("password");
    final private By cusSatLoginBtn = By.id("Login");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    @Step("Login into portal")
    public void login(boolean isCommunity){
        try{
            ConfigFileReader cfr = FileReaderManager.getInstance().getConfigReader();
            if(isCommunity){
                loginToCommunity(cfr.getCommunityURL(), cfr.getCommunityUsername(), cfr.getCommunityPassword());
            }else{
                fActions.openURL(driver, cfr.getCxpURL());
                fActions.enterText(driver, cusSatUsernameField, cfr.getCxpUsername());
                fActions.enterText(driver, cusSatPasswordField, cfr.getCxpPassword());
                fActions.clickElement(driver, cusSatLoginBtn);
                List<WebElement> classicPage = fActions.getWebElements(driver, classicField);
                if (classicPage.size() > 0) {
                    fActions.clickElement(driver, classicField);
                    fActions.waitForElementInvisible(driver, classicField, TIME_SECONDS_SIXTY);
                }
                switch (platformName.toLowerCase()){
                    case DESKTOP_WEB:
                        fActions.waitForElementVisible(driver, custSatIcon, TIME_SECONDS_SIXTY);
                        break;
                    case MOBILE_WEB:
                        fActions.waitForElementVisible(driver, toggleSideBar, TIME_SECONDS_SIXTY);
                }
            }
        }catch (Exception e){
            Assert.fail(e.getMessage());
        }
    }

    public void loginToCommunity(String username, String password) {
        ConfigFileReader cfr = FileReaderManager.getInstance().getConfigReader();
        fActions.openURL(driver, cfr.getCommunityURL());
        InvokeInstances.getInvokeInstance().getPageObjectManager().getUnAuthHomePage().clickOnSignInButton();
        fActions.enterText(driver, commuUsernameField, username.trim());
        fActions.enterText(driver, commuPasswordField, password.trim());
        fActions.clickElement(driver, commuSignInBtn);
        fActions.waitForElementVisible(driver, profileMenuField, TIME_SECONDS_SIXTY);
    }

    public void loginToCommunity(String url, String username, String password) {
        ConfigFileReader cfr = FileReaderManager.getInstance().getConfigReader();
        fActions.openURL(driver, cfr.getCommunityURL());
        InvokeInstances.getInvokeInstance().getPageObjectManager().getUnAuthHomePage().clickOnSignInButton();
        fActions.enterText(driver, commuUsernameField, username.trim());
        fActions.enterText(driver, commuPasswordField, password.trim());
        fActions.clickElement(driver, commuSignInBtn);
        fActions.waitForElementVisible(driver, profileMenuField, TIME_SECONDS_SIXTY);
    }

    @Step("Logout from CommunityPortal")
    public void logoutFromCommunity(WebDriver driver) {
        try {
            fActions.clickElement(driver, profileIcon);
            fActions.waitInSeconds(TIME_SECONDS_TWO);
            fActions.clickElement(driver, logoutField);
            fActions.waitInSeconds(TIME_SECONDS_FOUR);
            fActions.waitForElementVisible(driver, commuSignInBtn, TIME_SECONDS_TEN);
        }catch (Exception e){
            Assert.fail(e.getMessage());
        }
    }

    public void navigateToMyAccountsPage()
    {
        try
        {
            fActions.clickElement(driver,profileIcon);
            fActions.waitInSeconds(TIME_SECONDS_TWO);
            fActions.clickElement(driver, myAccountField);
            fActions.waitInSeconds(TIME_SECONDS_FOUR);
        }
        catch (Exception e)
        {
            Assert.fail(e.getMessage());
        }
    }

}
