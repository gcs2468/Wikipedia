package com.ebsco.web.pageobjects.common;

import com.ebsco.web.utilities.SeleniumWrappers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProfilePage {
    private By profileNameSelector = By.xpath("(//span[@class='uiOutputText'])[1]");
    private By accountNameSelector = By.xpath("//a[contains(@class, 'outputLookupLink')]");
    private WebDriver webDriver;
    private SeleniumWrappers fActions = new SeleniumWrappers();

    public ProfilePage(WebDriver webDriver) {
        this.webDriver = webDriver;
    }

    public String getProfileName() {
        return fActions.getText(webDriver, profileNameSelector);
    }

    public String getAccountName() {
        return fActions.getText(webDriver, accountNameSelector);
    }

}
