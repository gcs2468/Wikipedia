package com.ebsco.web.managers;

import com.ebsco.web.utilities.AppiumServer;
import com.ebsco.web.utilities.Driver;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

import static com.ebsco.common.constants.Constants.*;

public class WebDriverManager {
    private WebDriver driver;
    private static String browserType;
    private static String environmentType;
    private static String platformName;
    private AppiumServer appiumServer;

    public WebDriverManager() {
        browserType = FileReaderManager.getInstance().getConfigReader().getBrowser();
        environmentType = FileReaderManager.getInstance().getConfigReader().getEnvironment();
        platformName = FileReaderManager.getInstance().getConfigReader().getPlatform();
    }

    public WebDriver getDriver() {
        if (driver == null) {
            switch (environmentType.toLowerCase()) {
                case LOCAL_ENV_TYPE:
                    driver = getLocalDriver();
                    break;
                case REMOTE_ENV_TYPE:
                    driver = getRemoteDriver();
                    break;
            }
        }
        return driver;
    }

    private WebDriver getRemoteDriver() {
        driver = new Driver().getDriver(browserType, platformName);
        driver.manage().timeouts().implicitlyWait(FileReaderManager.getInstance().getConfigReader().getImplicitlyWait(), TimeUnit.SECONDS);
        return driver;
    }

    private WebDriver getLocalDriver() {
        if (platformName.equalsIgnoreCase(MOBILE_WEB)) {
            appiumServer = new AppiumServer();
            if (!appiumServer.checkIfServerIsRunnning(PORT)) {
                appiumServer.startServer();
            }
        }
        driver = new Driver().getDriver(browserType, platformName);
        driver.manage().timeouts().implicitlyWait(FileReaderManager.getInstance().getConfigReader().getImplicitlyWait(), TimeUnit.SECONDS);
        return driver;
    }

    public void closeDriver() {
        driver.quit();
        if (environmentType.equalsIgnoreCase(LOCAL_ENV_TYPE) && appiumServer != null) appiumServer.stopServer();
    }

}
