package com.ebsco.web.pageobjects.accounts;

import com.ebsco.web.launcher.InvokeInstances;
import com.ebsco.web.pageobjects.cases.CasesPage;
import com.ebsco.web.pageobjects.common.GlobalPage;
import com.ebsco.web.pageobjects.login.LoginPage;
import com.ebsco.web.utilities.LogUtil;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.ebsco.common.constants.Constants.*;

public class AccountsPage extends GlobalPage {
    private WebDriver driver;
    private CasesPage casesPage = InvokeInstances.getInvokeInstance().getPageObjectManager().getCasesPage();
    private By searchField = By.xpath("//h2/ancestor::div[contains(@class, 'page-header')]/following-sibling::div//table[contains(@class, 'VirtualDataTable')]/tbody/tr/td[1]/following-sibling::th//a");
    private By casesLinkEle = By.xpath("//a/span[@title='Cases']");
    private By accSpinner = By.id("Accspinner");
    private By accountsViewAll = By.xpath("//span[@title='Contacts']/ancestor::article//span[contains(@class, 'view-all')]");
    private By relatedListLink = By.xpath("//a[contains(@class, 'ListLink')]/span[contains(@title, 'Cases')]");
    private By appMenu = By.xpath("//div[@class='slds-icon-waffle']");
    private By appSearch = By.xpath("//h2[text()='App Launcher']/parent::div/following-sibling::div//input");
    private By accountEle = By.xpath("//mark[text()='Accounts']");
    private By mobileRelatedTab = By.xpath("//div[contains(@class, 'base-home-tab')]//span[text()='Related']");
    private By mobileCasesEle = By.xpath("//h2/span[contains(@title, 'Cases')]");
    private By desktopCasesEle = By.xpath("//h1[@title='Cases']/ancestor::div[@role]/following-sibling::div//table/tbody/tr/th//a");
    private By mobileCasesTotalEle = By.xpath("//span[contains(text(), 'sorted by Case')]/ancestor::div[contains(@class, 'listTitleContainer')]/following-sibling::div//h3");
    private String fieldEle = "//div[@role='tablist']//li/a/span[text()='fieldName']";
    private final By institutionNameLabelInAccountPage=By.xpath("(.//*[@class='test-id__field-value slds-form-element__static slds-grow  is-read-only']/span[@class='uiOutputText'])[1]");

    public AccountsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void setupAccountsTab() {

        fActions.waitForElementVisible(driver, appMenu, TIME_SECONDS_THIRTY);
        try {
            Thread.sleep(5000);
        } catch (Exception e) {
        }
        fActions.clickElement(driver, appMenu);
        fActions.waitForElementVisible(driver, appSearch, TIME_SECONDS_THIRTY);
        try {
            Thread.sleep(1000 * TIME_SECONDS_THREE);
        } catch (Exception e) {
        }
        fActions.enterText(driver, appSearch, ACCOUNTS_LABEL);
        fActions.clickElement(driver, accountEle);
        try {
            Thread.sleep(1000* TIME_SECONDS_FOUR);
        } catch (Exception e) {
        }

    }

    @Step("Click On Institution")
    public void clickAccountsMenu() {
        try {
            clickMenu(driver, CXP_INSTIUTION_MENU);
            fActions.waitForElementInvisible(driver, accSpinner, TIME_SECONDS_THIRTY);
            LogUtil.log("Account menu: " + CXP_INSTIUTION_MENU + " clicked successfully");
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }


    @Step("Click on Accounts ViewAll Link")
    public void clickAccountsViewAll() {
        fActions.clickElement(driver, accountsViewAll);
    }

    @Step("Click on Cases Link")
    public void clickCases() {
        try {
            if (platformName.equalsIgnoreCase(DESKTOP_WEB))
                fActions.clickElement(driver, casesLinkEle);
            LogUtil.log("Successfully clicked on cases link");
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    @Step("Get Number of cases")
    public String getCasesCount() {
        try {
            String casesCount;
            if (platformName.equalsIgnoreCase(MOBILE_WEB)) {
                fActions.clickElement(driver,mobileRelatedTab);
                fActions.clickElement(driver, mobileCasesEle);
                casesCount = fActions.getText(driver, By.xpath("//span[contains(text(), 'sorted by Case')]")).split(" ")[0];
                return casesCount;
            } else {
                Thread.sleep(1000 * TIME_SECONDS_FOUR);
                fActions.waitForElementVisible(driver, relatedListLink, TIME_SECONDS_TEN);
                casesCount = fActions.getText(driver, relatedListLink);
                casesCount = casesCount.substring(casesCount.indexOf("(") + 1, casesCount.lastIndexOf(")"));
                return casesCount;
            }
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    public List<WebElement> getContacts() {
        return fActions.getWebElements(driver, By.xpath("//h1[@title='Contacts']/ancestor::div[@role]/following-sibling::div//table/tbody/tr/th//a"));
    }

    public List<String> getCaseNumbers() {
        List<String> caseNums = new ArrayList<>();
        List<WebElement> cases;
        if (platformName.equalsIgnoreCase(MOBILE_WEB)) {
            cases = fActions.getWebElements(driver, mobileCasesTotalEle);
        } else {
            cases = fActions.getWebElements(driver, desktopCasesEle);
        }
        cases.forEach(x -> caseNums.add(x.getText()));
        fActions.moveBack(driver);
        return caseNums;
    }


    @Step("Search For Institution")
    public void searchAccount(String accountName) {
        try {
            if (platformName.equalsIgnoreCase(DESKTOP_WEB))
                selectSearchItem(driver, CXP_INSTIUTION_MENU);
            searchText(driver, accountName);
            LogUtil.log("Institution search successfully");
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    @Step("Click on Institution Which you search")
    public void clickOnSearchAccount() {
        try {
            fActions.waitForElementVisible(driver, searchField, 30);
            fActions.clickElement(driver, searchField);
            LogUtil.log("Successfully click on the institution name");
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    public void viewFields() {
        for (int i = 1; i <= 2; i++) {
            switchToField("Details");
            switchToField("News");
            switchToField("Related");
        }
    }

    private void switchToField(String fieldName) {
        try {
            fActions.clickElement(driver, By.xpath(fieldEle.replace("fieldName", fieldName)));
            Thread.sleep(1000);
        } catch (Exception e) {
        }
    }


    @Step("Open Each Contact and verify number of cases and case numbers")
    public void openEachContactAndValidate(List<String> casesNums, int casesCount, Map<String, Map<String, String>> testData) {
        StringBuilder errorMsg = new StringBuilder();
        try {
            clickAccountsViewAll();
            List<WebElement> contacts = getContacts();
            String contactListWindow = fActions.getWindowName(driver);
            LoginPage loginPage = InvokeInstances.getInvokeInstance().getPageObjectManager().getLoginPage();

            for (int i = 0; i < contacts.size(); i++) {
                Map<String, String> mapList = testData.get("Independent" + (i + 1));
                String contactName = contacts.get(i).getText();
                fActions.openElementInNewTab(driver, contacts.get(i));
                List<String> tabHandles = fActions.getWindowNames(driver);
                for (String tab : tabHandles) {
                    if (!tab.equalsIgnoreCase(contactListWindow)) {
                        fActions.switchToWindow(driver, tab);
                        loginPage.loginToCommunity(mapList.get(URL), mapList.get(USERNAME), mapList.get(PASSWORD));
                        casesPage.selectCasesFromDropDownMenu(driver);
                        List<String> allCases = casesPage.getAllCaseNumbers();
                        try {
                            if (allCases.size() != casesCount) {
                                errorMsg.append(String.format("Cases are mismatch for the contact: %s \n", contactName));
                                for (String caseNum : casesNums) {
                                    if (!allCases.contains(caseNum))
                                        errorMsg.append(String.format("CaseNumber %s not found", caseNum)).append("\n");
                                }
                            }
                        } finally {
                            loginPage.logoutFromCommunity(driver);
                            fActions.closeVisibleWindow(driver);
                        }
                    }
                }
                fActions.switchToWindow(driver, contactListWindow);
            }
            if (!errorMsg.toString().isEmpty()) Assert.fail("Contact Details :\n" + errorMsg);
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    public String getInstitutionNameFromMyAccountsPage()
    {
        LoginPage loginPage = InvokeInstances.getInvokeInstance().getPageObjectManager().getLoginPage();
        loginPage.navigateToMyAccountsPage();
        return fActions.getText(driver,institutionNameLabelInAccountPage);
    }
}