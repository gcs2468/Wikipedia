package com.ebsco.web.utilities;


import com.ebsco.common.utility.AppProperties;

import javax.mail.*;
import java.io.IOException;
import java.util.Properties;

public class Email {


    private static final String PASSWORD = "dummy123maya";
    private static final String EMAIL_FROM_ADDRESS = "dummy.maya.taken@gmail.com";
    private static final String IMAP_HOST = AppProperties.getValueFor("imap.host.value");
    private static final String PORT = "993";
    private static final String IMAP_PROTOCOL = "imaps";


    public static Session createEmailSessionForReading() {
        Properties properties = new Properties();
        properties.put("mail.pop.auth", "true");
        properties.put("mail.pop3.starttls.enable", "true");
        properties.put("mail.pop3.host", IMAP_HOST);
        properties.put("mail.pop3.port", PORT);
        return Session.getDefaultInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EMAIL_FROM_ADDRESS, PASSWORD);
            }
        });
    }

    public static String getMostRecentEmail(Session session) throws MessagingException, IOException {
        Store store = session.getStore(IMAP_PROTOCOL);
        store.connect(IMAP_HOST,  EMAIL_FROM_ADDRESS, PASSWORD);
        Folder folder = store.getDefaultFolder().getFolder("INBOX");
        folder.open(Folder.READ_WRITE);
        return (String) folder.getMessage(folder.getMessageCount()).getContent();
    }

}
