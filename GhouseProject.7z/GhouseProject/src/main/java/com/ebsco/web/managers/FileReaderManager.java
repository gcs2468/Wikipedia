package com.ebsco.web.managers;

import com.ebsco.common.utility.CommonUtils;
import com.ebsco.web.appconfig.ConfigFileReader;


public class FileReaderManager {

    private static FileReaderManager fileReaderManager;
    private static ConfigFileReader configFileReader;
    private static CommonUtils commonUtils;

    private FileReaderManager() {
    }

    public static FileReaderManager getInstance() {
        return fileReaderManager == null? fileReaderManager = new FileReaderManager(): fileReaderManager;
    }

    public ConfigFileReader getConfigReader() {
        return (configFileReader == null) ? configFileReader = new ConfigFileReader() : configFileReader;
    }

    public CommonUtils getExcelReader() {
        return (commonUtils == null) ? commonUtils = new CommonUtils() : commonUtils;
    }

}
