package com.ebsco.web.utilities;

import com.ebsco.web.managers.FileReaderManager;
import io.github.bonigarcia.wdm.ChromeDriverManager;
import io.github.bonigarcia.wdm.EdgeDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

import static com.ebsco.common.constants.Constants.*;

public class Driver {
    WebDriver wDriver;

    public WebDriver getDriver(String browserName, String platformName) {
        String environmentType = FileReaderManager.getInstance().getConfigReader().getEnvironment();
        try {
            switch (platformName.toLowerCase()) {
                case DESKTOP_WEB:
                    switch (environmentType.toLowerCase()) {
                        case LOCAL_ENV_TYPE:
                            switch (browserName.toLowerCase()) {
                                case CHROME_BROWSER:
                                    ChromeDriverManager.getInstance().setup();
                                    ChromeOptions localChromeOptions = new ChromeOptions();
                                    localChromeOptions.setExperimentalOption("useAutomationExtension", false);
                                    localChromeOptions.addArguments("test-type");
                                    localChromeOptions.setAcceptInsecureCerts(true);
                                    localChromeOptions.addArguments("--disable-notifications");
                                    localChromeOptions.addArguments("--disable-infobars");
                                    localChromeOptions.addArguments("--disable-extensions");
                                    localChromeOptions.addArguments("--disable-popup-blocking");
                                    localChromeOptions.addArguments("--disable-default-apps");
                                    localChromeOptions.addArguments("--allow-file-access-from-files");
                                    wDriver = new ChromeDriver(localChromeOptions);
                                    break;
                                case EDGE_BROWSER:
                                    EdgeDriverManager.getInstance().setup();
                                    EdgeOptions localEdgeOptions = new EdgeOptions();
                                    localEdgeOptions.setCapability("requireWindowFocus", true);
                                    wDriver = new EdgeDriver(localEdgeOptions);
                                    break;
                                default:
                                    throw new Exception("Local desktopweb env supports only chrome and edge browser");
                            }
                            break;
                        case REMOTE_ENV_TYPE:
                            String sauceUsername = FileReaderManager.getInstance().getConfigReader().getSauceUsername();
                            String accessKey = FileReaderManager.getInstance().getConfigReader().getSauceAccessKey();
                            String SAUCE_LABS_URL = "http://" + sauceUsername + ":" + accessKey + ON_DEMAND_URL;
                            switch (browserName.toLowerCase()) {
                                case CHROME_BROWSER:
                                    DesiredCapabilities chromeCapabillities = DesiredCapabilities.chrome();
                                    ChromeOptions remoteChromeOptions = new ChromeOptions();
                                    remoteChromeOptions.setExperimentalOption("useAutomationExtension", false);
                                    remoteChromeOptions.addArguments("test-type");
                                    remoteChromeOptions.setAcceptInsecureCerts(true);
                                    remoteChromeOptions.addArguments("--disable-notifications");
                                    remoteChromeOptions.addArguments("--disable-infobars");
                                    remoteChromeOptions.addArguments("--disable-extensions");
                                    remoteChromeOptions.addArguments("--disable-popup-blocking");
                                    remoteChromeOptions.addArguments("--disable-default-apps");
                                    remoteChromeOptions.addArguments("--allow-file-access-from-files");
                                    chromeCapabillities.setCapability(ChromeOptions.CAPABILITY, remoteChromeOptions);
                                    chromeCapabillities.setCapability("platform.type", FileReaderManager.getInstance().getConfigReader().getDesktopOs());
                                    chromeCapabillities.setCapability("version", "latest");
                                    wDriver = new RemoteWebDriver(new URL(SAUCE_LABS_URL), chromeCapabillities);
                                    break;
                                case EDGE_BROWSER:
                                    DesiredCapabilities edgeCapabillities = DesiredCapabilities.edge();
                                    edgeCapabillities.setCapability("platform.type", FileReaderManager.getInstance().getConfigReader().getDesktopOs());
                                    edgeCapabillities.setCapability("version", "latest");
                                    wDriver = new RemoteWebDriver(new URL(SAUCE_LABS_URL), edgeCapabillities);
                                    break;
                                default:
                                    throw new Exception("Remote desktopweb env supports only chrome and edge browser");
                            }
                            break;
                    }
                    wDriver.manage().window().maximize();
                    break;
                case MOBILE_WEB:
                    wDriver = new MobileCapablities().setMobileCapablities(browserName);
                    break;
                default:
                    throw new Exception("Please mention platform type as mobileweb or desktopweb");
            }
            wDriver.manage().deleteAllCookies();
            wDriver.navigate().refresh();
            return wDriver;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

