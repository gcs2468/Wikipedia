package com.ebsco.web.utilities;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class Links {
    private static final int WAIT_TIME_OUT = 10;
    private static Logger logger = LogManager.getLogger(Links.class);
    private static SeleniumWrappers wrappers = new SeleniumWrappers();

    private Links() {}
    public static List<String> getAllLinks(WebDriver driver, By[] dropDownSelectors) {
        List<String> allLinks = getAllAnchorTagLinks(driver, dropDownSelectors);
        allLinks.addAll(getAllImageLinks(driver));
        return allLinks;
    }

    private static List<String> getAllImageLinks(WebDriver driver) {
        By allImages = By.xpath("//img");
        wrappers.waitForElementVisible(driver, allImages, WAIT_TIME_OUT);
        return driver.findElements(allImages)
                .stream()
                .map(image -> image.getAttribute("src"))
                .collect(Collectors.toList());
    }

    /**
     * Gets all the anchor tags from the current page the driver is in.
     * @param driver to be provided.
     * @param selectors upon clicking should load new anchor tags.
     * @return list of url present in the anchor tags.
     */
    private static List<String> getAllAnchorTagLinks(WebDriver driver, By[] selectors) {
        By allLinks = By.xpath("//a");
        wrappers.waitForElementVisible(driver, allLinks, WAIT_TIME_OUT);
        //Click all drop downs and make their links visible.
        for (By selector : selectors) {
            for (WebElement dropDown : driver.findElements(selector)) {
                try {
                    dropDown.click();
                } catch (ElementNotVisibleException ex) {
                    logger.error("Selector did not work.");
                }
            }
        }
        return driver.findElements(allLinks)
                .stream().map(link -> link.getAttribute("href")).collect(Collectors.toList());
    }

}
