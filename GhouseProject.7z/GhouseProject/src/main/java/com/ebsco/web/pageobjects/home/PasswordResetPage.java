package com.ebsco.web.pageobjects.home;

import com.ebsco.web.utilities.SeleniumWrappers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PasswordResetPage {

    private static final By passConfirmSelector = By.xpath("//input[@id='newpassword']");
    private static final By passReConfirmSelector = By.xpath("//input[@id='confirmpassword']");
    private static final By passwordBtnSelector = By.xpath("//button[@id='password-button']");
    private static final String DUMMY_PASSWORD = "dummypassword123";
    private WebDriver webDriver;
    public SeleniumWrappers fActions = new SeleniumWrappers();
    public PasswordResetPage(WebDriver webDriver) {
        this.webDriver = webDriver;
    }


    public void enterCredentials() {
        fActions.waitForElementVisible(webDriver, passConfirmSelector, 10);
        webDriver.findElement(passConfirmSelector).sendKeys(DUMMY_PASSWORD);
        webDriver.findElement(passReConfirmSelector).sendKeys(DUMMY_PASSWORD);
        webDriver.findElement(passwordBtnSelector).click();
    }
}
