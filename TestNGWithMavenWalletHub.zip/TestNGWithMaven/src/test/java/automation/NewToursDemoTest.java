package automation;

import base.TestBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.NewToursDemoPage;

public class NewToursDemoTest extends TestBase {

    //private static final Logger logger = LogManager.getLogger(NewToursDemoTest.class); // Using Log4j
    private static final Logger logger = LoggerFactory.getLogger(NewToursDemoTest.class);// Using slf4j

    @Test(priority = 1)
    public void newTourseDemoLoginTest() {
        System.out.println();
        System.out.println("*** Start of Priority 1 ***");
        System.out.println();

        NewToursDemoPage newToursDemoPage = new NewToursDemoPage(driver, properties, seleniumUtils);

        String url = "http://newtours.demoaut.com/";//properties.getProperty(PropertyConstants.URL);
        seleniumUtils.getUrl(url);
        seleniumUtils.waitForPageLoad(driver);

        newToursDemoPage.loginToNewTours();

        seleniumUtils.waitForPageLoad(driver);

        String signOFF = newToursDemoPage.getSignOFF();
        logger.info("SignOff text from appln is :: "+signOFF);
        Assert.assertEquals(signOFF,"SIGN-OFF");
        
        newToursDemoPage.logououtNewTours();

        System.out.println();
        System.out.println("*** End of Priority 1 ***");
        System.out.println();

    }

}
