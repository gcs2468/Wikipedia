package util;

import com.google.common.base.Function;
import base.Constants;
import base.PropertyConstants;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static base.TestBase.driver;

/**
 * @author Chandrashekhar Gomasa
 * @project TestNGWithMavenFramework
 */

public class SeleniumUtils {

    private static final Logger logger = LoggerFactory.getLogger(SeleniumUtils.class);

    public int maxRetry;
    public int explicitWait;
    public int pageRefreshWait;
    public int waitInMilliSec;
    public int refreshWaitInMilliSec;
    public int alertWaitInMilliSec;

    public SeleniumUtils(Properties properties) {
        maxRetry = Integer.parseInt(properties.getProperty("maxRetry"));
        explicitWait = Integer.parseInt(properties.getProperty(PropertyConstants.EXPLICIT_WAIT));
        pageRefreshWait = Integer.parseInt(properties.getProperty(PropertyConstants.PAGE_REFRESH_WAIT));
        waitInMilliSec = Integer.parseInt(properties.getProperty(PropertyConstants.WAIT_IN_MILLI_SEC));
        alertWaitInMilliSec = Integer.parseInt(properties.getProperty(PropertyConstants.ALERT_WAIT_IN_MILLI_SEC));
        refreshWaitInMilliSec = Integer.parseInt(properties.getProperty(PropertyConstants.REFRESH_WAIT_IN_MILLI_SEC));
    }

    /**
     * Navigate to the given url.
     */
    public void getUrl(String url) {
        if (driver == null)
            return;
        driver.get(url);
    }

    public enum Identifier {ID, NAME, CLASS_NAME, CSS, XPATH}

    /**
     * Find element with given parameter.
     */
    public WebElement findElement(WebDriver driver, Identifier identifier, String locator) {
        By by = getByLocator(identifier, locator);
        return driver.findElement(by);
    }

    /**
     * Find all element with given parameter.
     */
    public List<WebElement> findElements(WebDriver driver, Identifier identifier, String locator) {
        By by = getByLocator(identifier, locator);
        return driver.findElements(by);
    }

    public By getByLocator(Identifier identifier, String locator) {
        By by = null;
        switch (identifier) {
            case ID:
                by = By.id(locator);
                break;
            case NAME:
                by = By.name(locator);
                break;
            case CLASS_NAME:
                by = By.className(locator);
                break;
            case CSS:
                by = By.cssSelector(locator);
                break;
            case XPATH:
                by = By.xpath(locator);
                break;
        }
        return by;
    }

    /**
     * Send text key to webelement. Clear the text before sending the key.
     */
    public void sendKeys(WebElement webElement, String text) {
        webElement.clear();
        waitElementValueTextEmpty(webElement, pageRefreshWait, TimeUnit.SECONDS);
        webElement.sendKeys(text);
    }

     /**
     * Waits until given element is displayed.
     */
    public boolean waitForElementDisplay(WebElement webElement, int timeOut) {
        try {
            Wait<WebElement> wait = new FluentWait<WebElement>(webElement).withTimeout(timeOut, TimeUnit.SECONDS).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(new Function<WebElement, Boolean>() {
                           @Override
                           public Boolean apply(WebElement element) {
                               return element.isDisplayed();
                           }
                       }
            );
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till text in the element is empty then returns the test.
     */
    public boolean waitElementValueTextEmpty(WebElement element, int timeOut, TimeUnit timeUnit) {
        try {
            new FluentWait<WebElement>(element).withTimeout(timeOut, timeUnit).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class).
                    until(new Function<WebElement, Boolean>() {
                              @Override
                              public Boolean apply(WebElement element) {
                                  String text = element.getAttribute(Constants.VALUE);
                                  return null == text || text.isEmpty();
                              }
                          }
                    );
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits until page is loaded.
     */
    public void waitForPageLoad(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, explicitWait);
        wait.until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript(
                        "return document.readyState"
                ).equals("complete");
            }
        });
    }

    public WebElement explicitWait(WebDriver driver, final String elementLoc) {
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(50, TimeUnit.SECONDS)
                .pollingEvery(1, TimeUnit.SECONDS)
                .ignoring(NoSuchElementException.class);
        if (elementLoc.contains(".//")) {
            WebElement element = wait.until(new Function<WebDriver, WebElement>() {

                public WebElement apply(WebDriver driver) {
                    return driver.findElement(By.xpath(elementLoc));
                }
            });
            return element;
        } else {
            WebElement element = wait.until(new Function<WebDriver, WebElement>() {

                public WebElement apply(WebDriver driver) {
                    return driver.findElement(By.id(elementLoc));
                }
            });
            return element;
        }
    }

    public synchronized static long getCurrentTimeStamp() {
        return System.nanoTime();
    }

    public String takeScreenshot(WebDriver driver) {

        TakesScreenshot screenshot = (TakesScreenshot) driver;
        File source = screenshot.getScreenshotAs(OutputType.FILE);
        File dest = new File(Constants.SCREENSHOT_DIR + "Screenshot_" + getCurrentTimeStamp() + ".png");
        try {
            org.apache.commons.io.FileUtils.copyFile(source, dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dest.getAbsolutePath();
    }

    public void implicitlyWait(int timeOut, TimeUnit timeUnit) {
        driver.manage().timeouts().implicitlyWait(timeOut, timeUnit);
    }

    public void scrollUp() {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, -250);");
    }

    public void scrollDown() {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, 250);");
    }

    public void moveToElementClick(WebDriver driver, WebElement element) {
        try {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).click().perform();
            while (isAlertPresent(driver)) {
                Alert alert;
                alert = driver.switchTo().alert();
                alert.accept();
            }
        } catch (StaleElementReferenceException | ClassCastException e) {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).click().perform();
            while (isAlertPresent(driver)) {
                Alert alert;
                alert = driver.switchTo().alert();
                alert.accept();
            }
        }
    }

    public void moveToElement(WebDriver driver, WebElement element) {
        try {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).perform();
        } catch (StaleElementReferenceException e) {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).perform();
        }
    }

    public void selectByValueFromDropDown(WebElement element, String value) {
        Select selectFromDropDown = new Select(element);
        selectFromDropDown.selectByValue(value);
    }


    public void selectByVisibleTextFromDropDown(WebElement element, String value) {
        Select selectFromDropDown = new Select(element);
        selectFromDropDown.selectByVisibleText(value);
    }

    public void selectByIndexFromDropDown(WebElement element, int index) {
        Select selectFromDropDown = new Select(element);
        selectFromDropDown.selectByIndex(index);
    }

    public boolean isAlertPresent(WebDriver driver) {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
    }

    public void isAlertPresent() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 15);
            implicitlyWait(10, TimeUnit.SECONDS);
            wait.until(ExpectedConditions.alertIsPresent());
            Alert alert = driver.switchTo().alert();
            alert.dismiss();
            System.out.println("Alert is cancelled");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
