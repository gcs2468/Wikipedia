package net.serenitybdd.demos.model.locations;

public class UnknownTubeStationException extends RuntimeException {
    public UnknownTubeStationException(String message) {
        super(message);
    }
}
