package net.serenitybdd.demos.model.locations;

public enum Place {
    TaxiRank
}
