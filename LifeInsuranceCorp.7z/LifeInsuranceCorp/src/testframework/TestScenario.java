package testframework;

import java.util.List;

public class TestScenario implements Cloneable{
	
	private String testFlow;
	private String keyWord;
	private String objectElement;
	private String dataColumn;
	private String status;
	private String description;
	private String screentShot;
	private String failMessage;
	private String scenarioName;
	private String actualValue;
	private String expectedValue;
	private String valueGotFromControl;
	
	public List<TestScenario> getPomList() {
		return pomList;
	}
	public void setPomList(List<TestScenario> pomList) {
		this.pomList = pomList;
	}
	public String applicationID=null;
	public String quoteID;
	public List<TestScenario> pomList;
	
	public String getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(String applicationID) {
		this.applicationID = applicationID;
	}
	
	public String getActualValue() {
		return actualValue;
	}
	public void setActualValue(String actualValue) {
		this.actualValue = actualValue;
	}
	public String getExpectedValue() {
		return expectedValue;
	}
	public void setExpectedValue(String expectedValue) {
		this.expectedValue = expectedValue;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getScreentShot() {
		return screentShot;
	}
	public void setScreentShot(String screentShot) {
		this.screentShot = screentShot;
	}
	public String getTestFlow() {
		return testFlow;
	}
	public void setTestFlow(String testFlow) {
		this.testFlow = testFlow;
	}
	public String getKeyWord() {
		return keyWord;
	}
	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}
	public String getObjectElement() {
		return objectElement;
	}
	public void setObjectElement(String objectElement) {
		this.objectElement = objectElement;
	}
	public String getDataColumn() {
		return dataColumn;
	}
	public void setDataColumn(String dataColumn) {
		this.dataColumn = dataColumn;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFailMessage() {
		return failMessage;
	}
	public void setFailMessage(String failMessage) {
		this.failMessage = failMessage;
	}
	public String getScenarioName() {
		return scenarioName;
	}
	public void setScenarioName(String scenarioName) {
		this.scenarioName = scenarioName;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	public String getValueGotFromControl() {
		return valueGotFromControl;
	}
	public void setValueGotFromControl(String valueGotFromControl) {
		this.valueGotFromControl = valueGotFromControl;
	}
}
