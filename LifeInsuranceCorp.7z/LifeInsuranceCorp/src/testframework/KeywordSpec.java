
package testframework;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;

import org.openqa.selenium.Point;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
 import org.sikuli.script.Screen;

public class KeywordSpec extends TestScenario{

	public String keyword,object;
	public WebDriver driver;
	public String browsers;
	public String refenceID;
	public String quoteRefID;//only for trial and not mandatory

	ResourceBundle OR = ResourceBundle.getBundle("configuration.OR");
	ResourceBundle settings = ResourceBundle.getBundle("configuration.Settings");

	public String getRefenceID() {
		return refenceID;
	}

	public void setRefenceID(String refenceID) {
		this.refenceID = refenceID;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	Date date = new Date();
	String CurrentDate=dateFormat.format(date);

	/*public void getURL(String url,String browser) throws AWTException, MalformedURLException{

		if(browser.equalsIgnoreCase("IE")){
			browsers="IE";
			System.setProperty("webdriver.ie.driver", settings.getString("iePath"));
			driver = new InternetExplorerDriver();
			//driver.manage().window().setPosition(new Point(0,0));
			//driver.manage().window().setSize(new Dimension(500,500));

		} else if(browser.equalsIgnoreCase("IEForGrid")){
			browsers="IE";
			DesiredCapabilities capability= DesiredCapabilities.internetExplorer(); 
			capability.setBrowserName("internet explorer");         
			capability.setPlatform(org.openqa.selenium.Platform.ANY);
			driver = new RemoteWebDriver(new URL(settings.getString("hubURL")), capability);
			setDriver(driver);

		} else if(browser.equalsIgnoreCase("HTMLUnit")){
			//driver=new HtmlUnitDriver();
		} else if(browser.equalsIgnoreCase("Firefox")){
			browsers="Firefox";
			System.setProperty("webdriver.firefox.bin",settings.getString("firefoxPath"));
			driver = new FirefoxDriver();

		} else if(browser.equalsIgnoreCase("FirefoxForGrid")){
			browsers="Firefox";
			DesiredCapabilities capability= DesiredCapabilities.firefox(); 
			capability.setBrowserName("firefox");         
			capability.setPlatform(org.openqa.selenium.Platform.ANY);
			driver = new RemoteWebDriver(new URL(settings.getString("hubURL")), capability); 
			setDriver(driver);

		} else if(browser.equalsIgnoreCase("Chrome")){
			browsers="Chrome";
			System.setProperty("webdriver.chrome.driver", settings.getString("chromePath"));
			//********************
			
			// Create object of HashMap Class
			Map<String, Object> prefs = new HashMap<String, Object>();
	        // Set the notification setting it will override the default setting
			prefs.put("profile.default_content_setting_values.notifications", 2);
			// Disable save password in chrome
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
	        // Create object of ChromeOption class
			ChromeOptions options = new ChromeOptions();
	        // Set the experimental option
			options.setExperimentalOption("prefs", prefs);
			
			//*********************
			driver=new ChromeDriver(options);
			driver.manage().window().maximize();

		} else if(browser.equalsIgnoreCase("ChromeForGrid")){
			browsers="Chrome";
			DesiredCapabilities capability= DesiredCapabilities.chrome(); 
			capability.setBrowserName("chrome");         
			capability.setPlatform(org.openqa.selenium.Platform.VISTA);
			System.out.println("Platform :"+org.openqa.selenium.Platform.getCurrent());
			driver = new RemoteWebDriver(new URL(settings.getString("hubURL")), capability); 
			setDriver(driver);

		} else if(browser.equalsIgnoreCase("safari")){
			browsers="safari";
			driver=new SafariDriver();
		}		
		setDriver(driver);
		driver.get(settings.getString(settings.getString("ENV")+"url"));
		driver.manage().window().maximize();
		waitForPageLoad();
	}*/
	
	public synchronized WebDriver getURL(String url,String browser) throws AWTException, MalformedURLException{

		if(browser.equalsIgnoreCase("IEForGrid")){
			browsers="IE";
			DesiredCapabilities capability= DesiredCapabilities.internetExplorer(); 
			capability.setBrowserName("internet explorer");         
			capability.setPlatform(org.openqa.selenium.Platform.VISTA);
			driver = new RemoteWebDriver(new URL(settings.getString("hubURL")), capability);
			setDriver(driver);

		} else if(browser.equalsIgnoreCase("Firefox")){
			browsers="Firefox";
			System.setProperty("webdriver.firefox.bin",settings.getString("firefoxPath"));
			driver=	new FirefoxDriver();

		}else if(browser.equalsIgnoreCase("FirefoxForGrid")){
			browsers="Firefox";
			DesiredCapabilities capability= DesiredCapabilities.firefox(); 
			capability.setBrowserName("firefox");         
			capability.setPlatform(org.openqa.selenium.Platform.ANY);
			driver = new RemoteWebDriver(new URL(settings.getString("hubURL")), capability); 
			setDriver(driver);
		}else if(browser.equalsIgnoreCase("Chrome")){
			browsers="Chrome";
			System.setProperty("webdriver.chrome.driver", settings.getString("chromePath"));
			//********************
			// Create object of HashMap Class
			Map<String, Object> prefs = new HashMap<String, Object>();
			// Set the notification setting it will override the default setting
			prefs.put("profile.default_content_setting_values.notifications", 2);
			// Disable save password in chrome
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			// Create object of ChromeOption class
			ChromeOptions options = new ChromeOptions();
			// Set the experimental option
			options.setExperimentalOption("prefs", prefs);
			//*********************
			driver=new ChromeDriver(options);
			driver.manage().window().maximize();
		}else if(browser.equalsIgnoreCase("ChromeForGrid")){
			browsers="Chrome";
			
			/*//********************
			// Create object of HashMap Class
			Map<String, Object> prefs = new HashMap<String, Object>();
			// Set the notification setting it will override the default setting
			prefs.put("profile.default_content_setting_values.notifications", 2);
			// Disable save password in chrome
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			// Create object of ChromeOption class
			ChromeOptions options = new ChromeOptions();
			// Set the experimental option
			options.setExperimentalOption("prefs", prefs);
			//********************* */	
			
			DesiredCapabilities capability= DesiredCapabilities.chrome(); 
			capability.setBrowserName("chrome");         
			capability.setPlatform(org.openqa.selenium.Platform.VISTA);
			System.out.println("Platform :"+org.openqa.selenium.Platform.getCurrent());
			driver = new RemoteWebDriver(new URL(settings.getString("hubURL")), capability); 
			setDriver(driver);
		} else if(browser.equalsIgnoreCase("safari")){
			browsers="safari";
			driver=new SafariDriver();
		}
		driver.get(settings.getString(settings.getString("ENV")+"url"));
		driver.manage().window().maximize();
		return driver;
	}

	public void waitForPageLoad(){
		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.MINUTES);
	}
	
	public synchronized void closeExtentReports(){

	}
	
	public void closeExtentCompletely(){
	}
	
	public synchronized void startTest(TestSuite suite,int count1,String scenarioNum){
		Instance();
		//String browser=settings.getString("browser");
	}
	
	public synchronized void Instance()
	{

	}
	
	public void modifyEnteredTextNW(String textboxId,String inputData,TestScenario testCase) throws InterruptedException{
		WebElement element=explicitWait(driver, textboxId);	
		element.clear();
		element.sendKeys(inputData);
		Thread.sleep(50);
	}

	public void modifyEnteredText2(String elementLoc,String data) throws InterruptedException {
		WebElement element=explicitWait(driver, elementLoc);	
		element.clear();
		element.sendKeys(data);
		Thread.sleep(50);
	}

	public void compareEnterTextNW(String xpathExpression,String inputData,TestScenario testCase){
		WebElement element=explicitWait(driver, xpathExpression);
		String data=element.getAttribute("value");
		if(!data.equals("")){
			if(inputData.equals(data)){
				testCase.setValueGotFromControl("Entered Data exists and matched");
			}
			else if(!inputData.equals(data)){
				testCase.setValueGotFromControl("Entered Data is not matching");
				testCase.setStatus("Fail");
				if(data.equals("MM/DD/YYYY")){
					element.clear();
					element.sendKeys(inputData);
					testCase.setValueGotFromControl("New data is Entered Data");
				}
			}
		} else{
			element.clear();
			element.sendKeys(inputData);
		}
	}

	public synchronized void compareEnterText(String elementLoc,String inputData,TestScenario testCase) throws InterruptedException{
		WebElement element=explicitWait(driver, elementLoc);
		if(element==null){
			testCase.setStatus("Fail");
			//testCase.setScreentShot(compareCaptureScreenshot(settings.getString("ScreenShotPath")));
			testCase.setValueGotFromControl("Element is not displayed/Identified");
		}else{
			//runtimeValues.put(testSuite.getSenarioDescription(), inputData);
			element.clear();
			testCase.setStatus("Pass");
			element.sendKeys(inputData);
		}   	
	}

	public void modifySelectedValueFromDropDown(String elementLoc,String inputData,TestScenario testCase){
		if(driver.findElements(By.xpath(elementLoc)).size()!=0 && inputData!=null || inputData!=""){
			WebElement element=explicitWait(driver, elementLoc);
			Select select = new Select(element);
			select.selectByVisibleText(inputData);
		}
		else {
			System.out.println("Dropdown Not Found");
			driver.quit();
		}
	}

	public WebElement explicitWait(WebDriver driver,final String elementLoc)  {  
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)  
				.withTimeout(50, TimeUnit.SECONDS)  
				.pollingEvery(1, TimeUnit.SECONDS)  
				.ignoring(NoSuchElementException.class); 
		if(elementLoc.contains(".//")){
			WebElement element= wait.until(new Function<WebDriver, WebElement>() {  

				public WebElement apply(WebDriver driver) {  
					return driver.findElement(By.xpath(elementLoc));  
				}  
			});  
			return element; 
		}else{
			WebElement element= wait.until(new Function<WebDriver, WebElement>() {  

				public WebElement apply(WebDriver driver) {  
					return driver.findElement(By.id(elementLoc));  
				}  
			});  
			return element;   
		}
	}  

	public String compareCaptureScreenshot(String screenshotspath) throws Exception{
		DateFormat df = new SimpleDateFormat("yyyy_MMM_dd HH_mm_ss");
		Date d = new Date();
		String time=df.format(d);
		File f = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File(screenshotspath+time+".png"));
		return time+".png";
	}

	public void compareClick_Element1(String elementloc)throws MyException, InterruptedException{
		WebElement element=explicitWait(driver, elementloc);
		element.click();
		waitForPageLoad();
	}

	
	public synchronized void compareClick_Element(String elementloc,TestScenario testCase)throws Exception{
		final WebElement element=explicitWait(driver, elementloc);
		try{
			if(element==null){
				testCase.setStatus("Fail");
				testCase.setValueGotFromControl("Element is not displayed/Identified");

			} else{
				FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
				wait.withTimeout(100, TimeUnit.SECONDS);
				wait.pollingEvery(500, TimeUnit.MILLISECONDS);
				wait.ignoring(Exception.class);

				Function<WebDriver, WebElement> function = new Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver webDriver) {
						element.click();
						return element;
					}
				};
				wait.until(function);
				testCase.setStatus("Pass");	
				System.out.println(" Clicked on "+(testCase.getObjectElement()));
			}
		}catch(Exception e){
			testCase.setStatus("Fail");
			testCase.setValueGotFromControl("element is not displayed");
			testCase.setFailMessage(e.getMessage());
		}
	}
	
	public synchronized void compareClick_Element2(String elementloc,TestScenario testCase)throws Exception{
		String propValue=OR.getString(testCase.getObjectElement());
		WebDriver driver=new FirefoxDriver();
		driver.findElement(By.xpath(propValue));
		
	}
	
	public void Click_Cancel(String elementloc) throws InterruptedException{
		WebElement element=explicitWait(driver, elementloc);
		element.click();
		Thread.sleep(2000);
		checkAlertisPresent();
	} 

	public void listbox(String elementLoc,String data,TestScenario testCase,HashMap<String,String> runtimeValues){
		String planNumber=runtimeValues.get("planNumber");
		if(!data.equalsIgnoreCase("All")){
			int index=elementLoc.lastIndexOf("/");
			String id=elementLoc.substring(0, index);
			System.out.println("ID is::"+id);			
			Select listbox = new Select(driver.findElement(By.xpath(id)));
			String [] testData=data.split(",");
			for(int i=0; i<testData.length; i++){
				System.out.println("In For Loop for TestData");
				System.out.println("Test Data is ::"+testData[i]);
				listbox.selectByValue(testData[i]);
			}
			if(testData[0].equalsIgnoreCase("Retirement Plans") && new Select(driver.findElement(By.xpath(OR.getString("CreateRequirements_DocumentCategory"))))
					.getFirstSelectedOption().getText().equals("Claim Level")){
				driver.findElement(By.xpath(OR.getString("CreateRequirements_PlanName"))).sendKeys(planNumber);
				System.out.println("Plan Number is ::"+planNumber);
			}
		}
		if(data.equalsIgnoreCase("All")){
			List<WebElement> optionCount = driver.findElements(By.xpath(elementLoc));
			System.out.println("List box Count is ::"+optionCount.size());
			String [] testData=data.split(",");
			for (int i=1; i<=optionCount.size(); i++) {
				String listValue= elementLoc+"["+i+"]";
				System.out.println("List values is::" +listValue);
				driver.findElement(By.xpath(listValue)).click();
			}
			if(testData[0].equalsIgnoreCase("Retirement Plans") && new Select(driver.findElement(By.xpath(OR.getString("CreateRequirements_DocumentCategory"))))
					.getFirstSelectedOption().getText().equals("Claim Level")){
				driver.findElement(By.xpath(OR.getString("CreateRequirements_PlanName"))).sendKeys(planNumber);
				System.out.println("Plan Number is ::"+planNumber);
			}
		}
		else{
			System.out.println("No Items Found..");
		}
	}

	public String compareSummaryData(String elementLoc,String inputData,TestScenario testCase){
		String capturedData=null;
		boolean result = false;
		String data=null;
		WebElement element=explicitWait(driver, elementLoc);
		capturedData=element.getText();
		try{
			if(new BigDecimal(inputData).compareTo(new BigDecimal(capturedData))==0){
				result = true;
			}
		}
		catch(Exception e){
		}
		if(capturedData!=null && inputData.equalsIgnoreCase(capturedData)|| result){
			data=capturedData;
			testCase.setStatus("Pass");	
			testCase.setValueGotFromControl("Matched");
			return data;
		}
		else{
			data=capturedData;
			testCase.setStatus("Fail");
			testCase.setValueGotFromControl("Not Matched");
			return data;
		}
	}

	public void waitForAction() throws InterruptedException{
		Thread.sleep(10000);
	}

	public void waitForElement(String elementLoc){
		WebDriverWait wait = new WebDriverWait(driver, 5000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(elementLoc)));
	}

	public void refreshPage(){
		driver.navigate().refresh();
	}

	public void comparePageScroll(){
		JavascriptExecutor jsx = (JavascriptExecutor)driver;
		jsx.executeScript("window.scrollBy(0,100)", "");
	}

	public void compareLongPageScroll(){
		JavascriptExecutor jsx = (JavascriptExecutor)driver;
		jsx.executeScript("window.scrollBy(0,250)", "");
	}

	public void clickOnAlert() throws InterruptedException{			
		try {
			driver.switchTo().alert().accept();
			waitForPageLoad();
		} catch (NoAlertPresentException e) {		}
	}

	public void runtimeCapture(String elementLoc,HashMap<String,String> runtimeValues,String runValue){
		WebElement element=explicitWait(driver, elementLoc);
		String runtimeElement=element.getText();
		//runtimeValues.put("runtimeValue",runtimeElement);
		runtimeValues.put(runValue, runtimeElement);
		//System.out.println("All Runtime values::"+runtimeValues);
	}

	public void runtimeSetFromTestData(HashMap<String,String> runtimeValues,String Set_runtimeFieldName_From_Controller,String Get_runtimeDataFrom_TestData){
		runtimeValues.put(Set_runtimeFieldName_From_Controller,Get_runtimeDataFrom_TestData);
	}

	public String splitMethod(String inputID, int row_num){
		String outputId=null;
		String inputId = OR.getString(inputID);
		if(!inputId.contains(":0:")) {
			if(row_num == 1) {
				//System.out.println("Actual Id is :: "+inputId);	
				outputId=inputId.replace("tr[1]", "tr");
				//System.out.println("Updated Id is :: "+outputId);
			} else if(row_num != 1){
				outputId=inputId.replace("tr[1]", "tr["+row_num+"]");
				//	System.out.println("Updated Id is :: "+outputId);		
			} else{  
				System.out.println("No ID Updated");
			}
		} else{	
			outputId=inputId.replace(":0:", ":"+(row_num-1)+":");
		}
		return outputId;	
	}

	public void compareSelectedValueFromDropDown(String elementLoc,String inputData,TestScenario testCase){
		if(driver.findElements(By.xpath(elementLoc)).size()!=0){
			WebElement element=explicitWait(driver, elementLoc);
			String data1=element.getAttribute("value");
			Select select = new Select(element);
			String data=select.getFirstSelectedOption().getText();
			//System.out.println("Dropdown:"+data);
			if(data1.equals("")&& data.equals("Select")){
				select.selectByVisibleText(inputData);

			}else if(inputData.equals(data)){
				testCase.setValueGotFromControl("Selected value matched");
			}else if(!inputData.equals(data)){
				testCase.setValueGotFromControl("Selected value not matched/New Value Selected");
				select.selectByVisibleText(inputData);
			}		
		}
	}

	public void modifySelectedValueFromDropDown(String elementLoc,String data){
		WebElement element=explicitWait(driver, elementLoc);
		Select select = new Select(element);
		select.selectByVisibleText(data);
	}

	public void Policynumber(String elementLoc,HashMap<String,String> runtimeValues,String inputData) throws InterruptedException{
		if(inputData==null || inputData==""){
			inputData=runtimeValues.get("PolicyNumber");
		}
		WebElement element=explicitWait(driver, elementLoc);
		element.sendKeys(inputData);
	}
	
	public void PolicySearchRunTime(String elementloc,HashMap<String,String> runtimeValues,String inputData) throws InterruptedException{

		if(inputData==null ||inputData.equals("")){
			inputData = runtimeValues.get("PolicyNumber");
		}
		else{
			inputData = runtimeValues.get(inputData);
		}
		WebElement element=explicitWait(driver, elementloc);
		element.sendKeys(inputData);
	}

	public void clearMapp(HashMap<String,String> runtimeValues){
		runtimeValues.remove("Number of Beneficiary to Process");
		runtimeValues.remove("Number of Contactmgnt_BeneficiaryStatus to Minor on Hold");
		runtimeValues.remove("CntMgt_BeneficiaryStatus_DropdownValue");
		runtimeValues.remove("CorrectiveActionScenario");
		//runtimeValues.remove("Number of Beneficiary to Process");
		runtimeValues.remove("Payment Option");
		//runtimeValues.remove("CorrectiveActionScenario");
		//runtimeValues.remove("Number of Beneficiary to Process");
		runtimeValues.remove("FullcheckReviewAmount");

	}

	public boolean verify_ElementPresent_InTable(String tableXpathRow,String inputData,TestScenario testCase) {
		int row_Cnt= driver.findElements(By.xpath(tableXpathRow)).size();	
		for (int row_num = 1; row_num <= row_Cnt; row_num++){
			if(driver.findElement(By.xpath(tableXpathRow+"["+row_num+"]/td")).getText().equals(inputData)){
				return true;
			}
		}
		return false;
	}

	public boolean Duplicatealert(String elementLoc){  
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);  
		try {  
			driver.findElement(By.xpath(elementLoc)).click();
			return true;  
		} catch(Exception e) {  
			return false;  
		}  
	}  

	public void runtimeCapturesingleelement(String elementLoc,HashMap<String,String> runtimeValues){
		WebElement element=explicitWait(driver, elementLoc);
		String runtimeElement=element.getText();
		System.out.println("The RuntimeElement is: "+runtimeElement);
		runtimeValues.put("runtimeValue",runtimeElement);
	}

	public boolean isElementPresent(String elementLoc){  
		try  
		{  
			driver.findElement(By.xpath(elementLoc)).click();
			return true;  
		}  
		catch(Exception e)  
		{  
			return false;  
		}  
	} 

	public void compareTwoStrings(String inputdata, TestScenario testCase, HashMap<String,String> runtimeValues){
		String value1="true",value2="flase";
		if(inputdata.equalsIgnoreCase("Raised Comments")){
			value1 = runtimeValues.get("Raised Comments");
			value2 = runtimeValues.get("Received Comments");
			System.out.println("In IF compareTwoStrings"+value1+" and "+value2);
		}else if(inputdata.equalsIgnoreCase("Opinion Provider Comments")){
			System.out.println("Inside else in compareTwoStrings");
			value1 = runtimeValues.get("Opinion Provider Comments");
			value2 = runtimeValues.get("Opinion Provider Received Comments");
			System.out.println("In Else IF compareTwoStrings"+value1+" and "+value2);
		}
		if(value1.equalsIgnoreCase(value2)){
			testCase.setStatus("Pass");
			testCase.setActualValue(value1);
			testCase.setExpectedValue(value2);
			testCase.setValueGotFromControl("Matched");
		}else{
			System.out.println("Values not matched");
			testCase.setStatus("Fail");
			testCase.setActualValue(value1);
			testCase.setExpectedValue(value2);
			testCase.setValueGotFromControl("Values not matched");
		}
	}

	public String compareerrorSummaryData(String elementLoc,String inputData,TestScenario testCase){
		String capturedData=null;
		boolean result = false;
		String data=null;
		WebElement element=explicitWait(driver, elementLoc);
		capturedData=element.getText();
		try{
			if(new BigDecimal(inputData).compareTo(new BigDecimal(capturedData))==0){
				result = true;
			}
		}
		catch(Exception e){
		}
		if(capturedData!=null && inputData.contains("Please refer to Contact Management Details section")|| result){
			data=capturedData;
			testCase.setStatus("Pass");	
			testCase.setValueGotFromControl("Matched");
			return data;
		}
		else{
			data=capturedData;
			testCase.setStatus("Fail");
			testCase.setValueGotFromControl("Not Matched");
			return data;
		}
	}

	public void moveToElement(String elementLoc , TestScenario testCase)throws MyException{
		WebElement element=explicitWait(driver, elementLoc);
		Actions action = new Actions(driver);
		action.moveToElement(element).build().perform();
	}	

	public synchronized void isElementDisplayed(String elementLoc,TestScenario testCase){
		WebElement element=explicitWait(driver, elementLoc);
		if(element==null){
			testCase.setStatus("Fail");
			testCase.setValueGotFromControl("Element is not displayed/Identified");  
		}else{
			if(element.isDisplayed()){
				testCase.setStatus("Pass");
				testCase.setActualValue("Element has been displayed");
				testCase.setExpectedValue("Element should be displayed");
				System.out.println("Element "+(testCase.getObjectElement())+" is displayed");
			}else{
				testCase.setStatus("Fail");
				testCase.setActualValue("Element is not displayed");
				testCase.setExpectedValue("Element should be displayed");
				testCase.setValueGotFromControl("Element is not Displayed");
				System.out.println("Element "+(testCase.getObjectElement())+" is not displayed");
			}
		}
	}
	public synchronized WebElement xpathExpression(String inputData,TestScenario testcase) throws InterruptedException{
		WebElement element=null;
		String elementLoc = ".//*[text()='"+inputData+"']";
		System.out.println("Xpath xpression : " +elementLoc);
		try{
			element=explicitWait(driver, elementLoc);
		}catch(Exception e){
			System.out.println("Element not found");
		}if(element==null){
			elementLoc= ".//*[contains(text(),'"+inputData+"')]";
			element = driver.findElement(By.xpath(elementLoc));
			element.click();
		}else{
			element.click();
		}
		return element;
	}
	
	public synchronized WebElement listXpathExpression(String inputData,TestScenario testcase) throws InterruptedException{
		WebElement element=null;
		String elementLoc = ".//li[text()='"+inputData+"']";
		System.out.println("Xpath xpression : " +elementLoc);
		element=explicitWait(driver, elementLoc);
		if(element==null){
			System.out.println("Element not found");
			elementLoc= ".//*[contains(text(),'"+inputData+"')]";
			element = driver.findElement(By.xpath(elementLoc));
			element.click();
		}else{
			element.click();
		}
		return element;
	}
	public synchronized void getWindow(HashMap<String,String> runtimeValues,TestSuite testSuite){
		String parentWindow = driver.getWindowHandle();
		System.out.println("Parent Window name in getWindow :: "+parentWindow);
		runtimeValues.put("ParentWindow", parentWindow);
	}
	public synchronized void switchToNewTab(){
		System.out.println("***In Navigate to Next Tab****");
		for(String winHandle : driver.getWindowHandles()){
			driver.switchTo().window(winHandle);  
		}
	}
	public synchronized void switchToPreviousWindow(HashMap<String,String> runtimeValues,TestSuite testSuite){
		System.out.println("***In Navigate to Previous Tab****");
		String parentWindow=runtimeValues.get("ParentWindow");
		System.out.println("Parent window name in switchToPreviousWindow :: "+parentWindow);
		driver.switchTo().window(parentWindow);
	}
	
	public synchronized void compareTitleOfPage(String inputdata,TestScenario testCase){
		System.out.println("***In Compare Title of the page method***");
		String title= driver.getTitle();
		System.out.println("Page Title : "+title);
		System.out.println("inputdata Title : "+inputdata);
		if(title.equalsIgnoreCase(inputdata)){
			System.out.println("Title matched");
			testCase.setStatus("Pass");
			testCase.setActualValue("Page Title "+inputdata+" has been Displayed ");
			testCase.setExpectedValue("Page Title "+title+ " should be Display");
			testCase.setValueGotFromControl("Title : "+title);
		}else if(title.contains(inputdata)){
			System.out.println("Title partially matched");
			testCase.setStatus("Pass");
			testCase.setActualValue("Page Title is "+inputdata+", partially matched");
			testCase.setExpectedValue("Page Title is"+title+" should be Display");
			testCase.setValueGotFromControl("Title : "+title);
		}else{
			testCase.setStatus("Fail");
			testCase.setActualValue("Page Title not displayed");
			testCase.setExpectedValue("Page Title "+title+ " should be Display");
			testCase.setValueGotFromControl("Title : "+title);
		}
	}
	
	public synchronized void compareTitleOfPageUpdate(String inputData, String testDataColumn,TestScenario testCase){
		System.out.println("***In Compare Title of the page updated method***");
		String title= driver.getTitle();
		System.out.println("Page Title : "+title);
		System.out.println("inputdata Title : "+inputData);
		if(title.equalsIgnoreCase(inputData)){
			System.out.println("Title matched");
			testCase.setStatus("Pass");
			testCase.setActualValue("Page Title "+inputData+" has been Displayed ");
			testCase.setExpectedValue("Page Title "+title+ " should be Display");
			testCase.setValueGotFromControl("Title : "+title);
		}else if(title.contains(inputData)){
			System.out.println("Title partially matched");
			testCase.setStatus("Pass");
			testCase.setActualValue("Page Title is "+inputData+", partially matched");
			testCase.setExpectedValue("Page Title is"+title+" should be Display");
			testCase.setValueGotFromControl("Title : "+title);
		}else{
			testCase.setStatus("Fail");
			testCase.setActualValue("Page Title not displayed");
			testCase.setExpectedValue("Page Title "+title+ " should be Display");
			testCase.setValueGotFromControl("Title : "+title);
		}
	}
	
	public synchronized void compareTitleOfPageNew(String inputdata,TestScenario testCase, HashMap<String,String> runtimeValues){
		String title= driver.getTitle();
		System.out.println("Page Title : "+title);
		String parentWindow=runtimeValues.get("ParentWindow");
		if(title.equalsIgnoreCase(parentWindow)){
			System.out.println("Title matched");
			testCase.setStatus("Pass");
			testCase.setActualValue("Page Title "+parentWindow+" has been Displayed ");
			testCase.setExpectedValue("Page Title "+title+ " should be Display");
			testCase.setValueGotFromControl("Title : "+title);
		}else if(title.contains(parentWindow)){
			System.out.println("Title partially matched");
			testCase.setStatus("Pass");
			testCase.setActualValue("Page Title "+parentWindow+" partially matched");
			testCase.setExpectedValue("Page Title "+title+ " should be Display");
			testCase.setValueGotFromControl("Title : "+title);
		}else{
			testCase.setStatus("Fail");
			testCase.setActualValue("Page Title "+parentWindow+" has been Displayed ");
			testCase.setExpectedValue("Page Title "+title+ " should be Display");
			testCase.setValueGotFromControl("Title : "+title);
		}
	}
	
	public synchronized String compareSummaryData(String elementLoc,String inputData,HashMap<String,String> runtimeValues,TestScenario testCase,TestSuite testSuite) throws Exception{
		WebElement element=explicitWait(driver, elementLoc);
		String data=null;
		if(element==null){
			testCase.setStatus("Fail");
			testCase.setValueGotFromControl("Element is not displayed/Identified");  
		}
		else{
			String capturedData=element.getText();
			runtimeValues.put(testSuite.getSecenarioKey()+"summaryData", capturedData);
			if(capturedData.equalsIgnoreCase("")){
				capturedData=element.getAttribute("value");
				System.out.println("Comparing data from app is :: "+capturedData);
				System.out.println("Comparing data from input is :: "+capturedData);
			}if(capturedData.equalsIgnoreCase(inputData)){
				System.out.println("In equalsIgnoreCase condition");
				data=capturedData;
				System.out.println("Comparing data from app is :: "+capturedData);
				System.out.println("Comparing data from input is :: "+capturedData);
				testCase.setValueGotFromControl("Matched");
				testCase.setStatus("Pass");	
				testCase.setActualValue("Value "+data+" has been compared ");
				testCase.setExpectedValue("Value "+inputData+ " should be compared");
				return data;
			}else if(capturedData.contains(inputData)){
				System.out.println("In contains condition");
				data=capturedData;
				System.out.println("Comparing data from app is :: "+capturedData);
				System.out.println("Comparing data from input is :: "+capturedData);
				testCase.setValueGotFromControl("Partially Matched");
				testCase.setStatus("Pass");	
				testCase.setActualValue("Value "+data+" has been compared ");
				testCase.setExpectedValue("Value "+inputData+ " should be compared");
				return data;
			}else if(!capturedData.equalsIgnoreCase(inputData)) {
				System.out.println("In not equalsIgnoreCase condition");
				data=capturedData;
				System.out.println("Comparing data from app is :: "+capturedData);
				System.out.println("Comparing data from input is :: "+capturedData);
				testCase.setValueGotFromControl("Not Matched");
				testCase.setStatus("Fail");
				testCase.setActualValue("Value "+data+" has been compared ");
				testCase.setExpectedValue("Value "+inputData+ " should be compared");
				if(capturedData.equals(null)&&inputData.equals(null)||capturedData.equals("")&&inputData.equals("")||capturedData.equals(null)&&inputData.equals("")||capturedData.equals("")&&inputData.equals(null)){
					testCase.setValueGotFromControl("Matched");
					testCase.setStatus("Pass");
					testCase.setActualValue("Value "+capturedData+" has been compared ");
					testCase.setExpectedValue("Value "+inputData+ " should be compared");
				}	
				return data;
			}
		}
		return data;
	}
	
	public synchronized void Tab_Click(String elementloc)throws MyException{
		if(elementloc.contains(".//")){
			driver.findElement(By.xpath(elementloc)).sendKeys(Keys.TAB);

		}else{
			driver.findElement(By.xpath(elementloc)).sendKeys(Keys.TAB);
		}
	}

	public synchronized String comparePartOfString(String elementLoc,String inputData,TestScenario testCase) throws Exception{
		WebElement element=explicitWait(driver, elementLoc);
		String data=null;
		if(element==null){
			testCase.setStatus("Fail");
			testCase.setValueGotFromControl("Element is not displayed/Identified");  
		}else{
			String capturedData=element.getText();
			System.out.println("Comparing data : "+capturedData);
			System.out.println("Input Data : "+inputData);
			if(capturedData.contains(inputData)){
				data=capturedData;
				testCase.setValueGotFromControl("Matched");
				testCase.setStatus("Pass");
			}else{
				testCase.setValueGotFromControl("Not Matched");
				testCase.setStatus("Fail");
			}
		}
		return data;
	}
	public synchronized String comparePartOfStringInList(String elementLoc,String inputData,TestScenario testCase) throws Exception{
		WebElement element=explicitWait(driver, elementLoc);
		String data=null;
		Boolean comparisionStatus=null;
		if(element==null){
			testCase.setStatus("Fail");
			testCase.setScreentShot(compareCaptureScreenshot(settings.getString("ScreenShotPath")));
			testCase.setValueGotFromControl("Element is not displayed/Identified");  
		}else{
			List<WebElement> listOfElements = driver.findElements(By.xpath(elementLoc));
			if(listOfElements.size()>0){
				for(WebElement ele:listOfElements){
					String capturedData=ele.getText();
					System.out.println("Comparing data : "+capturedData);
					System.out.println("Input Data : "+inputData);
					if(capturedData.contains(inputData)){
						data=capturedData;
						testCase.setStatus("Pass");
						testCase.setActualValue("Value "+data+ " has been compared ");
						testCase.setExpectedValue("Value "+data+ " should be compared");
						testCase.setValueGotFromControl("Matched");
						comparisionStatus = true;
						break;
					}
				}
				if(comparisionStatus==null){
					System.out.println("Data not matched");
					testCase.setStatus("Fail");
					testCase.setActualValue("Value "+inputData+ " has been compared and not matched ");
					testCase.setExpectedValue("Value "+inputData+ " should be matched");
					testCase.setValueGotFromControl("Not Matched");
					testCase.setScreentShot(compareCaptureScreenshot(settings.getString("ScreenShotPath")));
				}
			}else{
				testCase.setValueGotFromControl("No data Displayed");
				testCase.setStatus("Fail");
				testCase.setScreentShot(compareCaptureScreenshot(settings.getString("ScreenShotPath")));
			}
		}
		return data;
	}
	
	public synchronized void downarrow1(String xpathExpression,TestScenario testCase) throws InterruptedException{
		Thread.sleep(3000);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(3000);
	}
	
	public synchronized void downarrow(String xpathExpression,TestScenario testCase) throws InterruptedException, AWTException{
		Thread.sleep(3000);
		Robot robot=new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		/*driver.findElement(By.xpath(xpathExpression)).sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(3000);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(Keys.ENTER);
		Thread.sleep(3000);*/
	}
	
	
	public void click_IfElementDisplayed(String elementLoc,TestScenario testCase) {
		WebElement element=explicitWait(driver, elementLoc);
		try{
		if(element==null){
			testCase.setStatus("Pass");
		    testCase.setActualValue("element not displayed");
			testCase.setExpectedValue("Element should not display");
			testCase.setValueGotFromControl("Element is not displayed");
			
		}else{
			
			element.click();
			testCase.setActualValue("Element displayed and clicked on element");
			testCase.setExpectedValue("element should be clicked if display");
			testCase.setValueGotFromControl("Element is Displayed and clicked on element");
			testCase.setStatus("Pass");	
		}
		}catch(Exception e){
			testCase.setStatus("Pass");
			testCase.setValueGotFromControl("Element is not displayed");
			testCase.setFailMessage(e.getMessage());
		}
	}
	
	public void compareClaimHistorymessages(String inputData,TestScenario testCase) throws Exception {
		if(driver.findElement(By.xpath(OR.getString("Policy_ClaimHistory_InfoIcon"))).isDisplayed()){
			String unableMsg=driver.findElement(By.xpath(OR.getString("Policy_ClaimHistory_Unable_Text"))).getText();
			if(unableMsg.contains(inputData)){
				testCase.setStatus("Pass");
			} else {
				testCase.setStatus("Fail");
				
			}
		}
		else if(driver.findElement(By.xpath(OR.getString("Popup_Alert_ok_button"))).isDisplayed()){
			String alertText=driver.findElement(By.xpath(OR.getString("Popup_Alert_Msg"))).getText();
			driver.findElement(By.xpath(OR.getString("Popup_Alert_ok_button"))).click();
			if(alertText.contains(inputData)){
				testCase.setStatus("Pass");
			} else {
				testCase.setStatus("Fail");
			}
		}
	}
	
	public void handlingGoogleAccountLink(TestScenario testCase) throws Exception{
		Thread.sleep(20000);
		String facebooklinkText=driver.findElement(By.xpath(OR.getString("GoogleAccount_Link"))).getText();
		if(facebooklinkText.equalsIgnoreCase("Unlink Google Account")){
			driver.findElement(By.xpath(OR.getString("SocialPreferences_UnlinkGoogleAccount_button"))).click();
			Thread.sleep(20000);
			driver.findElement(By.xpath(OR.getString("SocialPreferences_Status_Confirm_OK_button"))).click();
			Thread.sleep(20000);
			driver.findElement(By.xpath(OR.getString("SocialPreferences_Link_GoogleAccount_button"))).click();
		}else if(facebooklinkText.equalsIgnoreCase("Link Google Account")){
			driver.findElement(By.xpath(OR.getString("SocialPreferences_Link_GoogleAccount_button"))).click();
		}
	}
	
	public void handlingFacebookAccountLink(TestScenario testCase) throws Exception{
		Thread.sleep(20000);
		String facebooklinkText=driver.findElement(By.xpath(OR.getString("FacebookAccount_Link"))).getText();
		if(facebooklinkText.equalsIgnoreCase("Unlink Facebook Account")){
			driver.findElement(By.xpath(OR.getString("SocialPreferences_UnlinkFacebookAccount_button"))).click();
			Thread.sleep(20000);
			driver.findElement(By.xpath(OR.getString("SocialPreferences_Status_Confirm_OK_button"))).click();
			Thread.sleep(20000);
			driver.findElement(By.xpath(OR.getString("SocialPreferences_Link_FacebookAccount_button"))).click();
		}else if(facebooklinkText.equalsIgnoreCase("Link Facebook Account")){
			driver.findElement(By.xpath(OR.getString("SocialPreferences_Link_FacebookAccount_button"))).click();
		}
	}
	
	public void handlingTwitterAccountLink(TestScenario testCase) throws Exception{
		Thread.sleep(20000);
		String twitterlinkText=driver.findElement(By.xpath(OR.getString("TwitterAccount_Link"))).getText();
		if(twitterlinkText.equalsIgnoreCase("Unlink Twitter Account")){
			driver.findElement(By.xpath(OR.getString("SocialPreferences_UnLink_TwitterAccount_button"))).click();
			Thread.sleep(20000);
			driver.findElement(By.xpath(OR.getString("SocialPreferences_Status_Confirm_OK_button"))).click();
			Thread.sleep(20000);
			driver.findElement(By.xpath(OR.getString("SocialPreferences_Link_TwitterAccount_button"))).click();
		}else if(twitterlinkText.equalsIgnoreCase("Link Twitter Account")){
			Thread.sleep(20000);
			driver.findElement(By.xpath(OR.getString("SocialPreferences_Link_TwitterAccount_button"))).click();
		}
	}
	
	public void modifyEnteredText(String textboxId,String inputData,TestScenario testCase) throws InterruptedException{
		WebElement element=explicitWait(driver, textboxId);	
		element.clear();
		element.sendKeys(inputData);
		Thread.sleep(50);
	}
	
	public void gettingCoordinatesofElement(String elementLoc, TestScenario testCase) throws AWTException{
		WebElement element=explicitWait(driver, elementLoc);
		Point point = element.getLocation();
		int xcord=point.getX();
		int ycord=point.getY();
		System.out.println("xcord is :: "+xcord+", ycord is :: "+ycord);
	}	
	
	public void OfficeLocatorHandling() throws AWTException, FindFailed{
		Screen screen=new Screen();
		Pattern image = new Pattern("D:\\Workspace\\LifeInsuranceCorp\\SikuliImages\\OfficeLocatorIcon.PNG");
		screen.wait(image, 10);
		screen.click(image);
		System.out.println("Clicked on Office Locator Icon");
	}
	
	public void OfficeLocatorGetDirection() throws AWTException, FindFailed{
		Screen screen=new Screen();
		Pattern image = new Pattern("D:\\Workspace\\LifeInsuranceCorp\\SikuliImages\\OfficeLocatorGetDirection.PNG");
		screen.wait(image, 10);
		screen.click(image);
		System.out.println("Clicked on Office Locator Get Direction Link");
	}
	
	public void OfficeLocatorAlertClose() throws AWTException, FindFailed{
		Screen screen=new Screen();
		Pattern image = new Pattern("D:\\Workspace\\LifeInsuranceCorp\\SikuliImages\\OfficeLocatorAlertClose.PNG");
		screen.wait(image, 10);
		screen.click(image);
		System.out.println("Closed Office Locator Alert");
	}
	
	public void OfficeLocatorHomeButton() throws AWTException, FindFailed{
		Screen screen=new Screen();
		Pattern image = new Pattern("D:\\Workspace\\LifeInsuranceCorp\\SikuliImages\\OfficeLocatorHomeButton.PNG");
		screen.wait(image, 10);
		screen.click(image);
		System.out.println("Clicked on office locator home button");
	}
	
	public void CompareOfficeLocatorImages() throws AWTException{
		Screen screen=new Screen();
		Pattern baseImagePattern = new Pattern("D:\\Workspace\\LifeInsuranceCorp\\SikuliImages\\OfficeLocatorA.PNG");
		Pattern capturedImagePattern = new Pattern("D:\\Workspace\\LifeInsuranceCorp\\SikuliImages\\OfficeLocatorB.PNG");

		if(screen.exists(baseImagePattern) != null && screen.exists(capturedImagePattern) != null){
			System.out.println("Images Matched");
		}
	}
	
	public void handlingSavePswdAlert() throws AWTException{
		Screen screen=new Screen();
		Pattern image = new Pattern("D:\\Workspace\\LifeInsuranceCorp\\SikuliImages\\NeverSavePassword.PNG");
		try{
		    if(screen.exists(image) != null){
		    	screen.wait(image, 10);
		    	screen.click(image);
		    	System.out.println("Clicked on close button of save password alert");
		    }
	    }catch(FindFailed e){
		    e.getStackTrace();
		}
	}
	
	public void handlingSecurityAlert() throws AWTException{
		Screen screen=new Screen();
		Pattern image = new Pattern("D:\\Workspace\\LifeInsuranceCorp\\SikuliImages\\ContinuePayment.PNG");
		try{
		    if(screen.exists(image) != null){
		    	screen.wait(image, 10);
		    	screen.click(image);
		    	System.out.println("Clicked on close button of save password alert");
		    }
	    }catch(FindFailed e){
		    e.getStackTrace();
		}
	}
	
	public synchronized void SpaceBarClick(String elementloc)throws MyException{
		if(elementloc.contains(".//")){
			driver.findElement(By.xpath(elementloc)).sendKeys(Keys.SPACE);
		}else{
			driver.findElement(By.xpath(elementloc)).sendKeys(Keys.SPACE);
		}
	}
	
	public synchronized void isElementEnabled(String elementLoc,TestScenario testCase){
		WebElement element=explicitWait(driver, elementLoc);
		if(element.isEnabled()){
			System.out.println("Element is enabled");
			element.click();
			testCase.setStatus("Pass");
			testCase.setValueGotFromControl("Element is enabled and clicked");
		}else{
			System.out.println("Element is not enabled");
			testCase.setStatus("Fail");
			testCase.setValueGotFromControl("Element is not enabled");
		}
	}
	
	public synchronized void clickViewIfStatusOpen(String elementLoc,TestScenario testCase,HashMap<String,String> runtimeValues,String  serReqIDValue){
		WebElement element=explicitWait(driver, elementLoc);
		String status=element.getText();
		System.out.println("Service req sttus is "+status);
		String serReqID=driver.findElement(By.xpath(OR.getString("ServiceReg_ListSerReq_SerReqID_FirstRecord"))).getText();
		System.out.println("Service req ID is "+serReqID);
		runtimeValues.put(serReqIDValue, serReqID);
		if(status.equalsIgnoreCase("OPEN")){
			driver.findElement(By.xpath(OR.getString("ServiceReg_ReqDetailsView_Link"))).click();
			testCase.setStatus("Pass");
			testCase.setValueGotFromControl("Service req sttus is "+status+" so clicked on View link");
		}else{
			testCase.setStatus("Fail");
			testCase.setValueGotFromControl("Service req sttus is "+status+" so not clicked on View link");
		}
	}
	
	public synchronized void canceReqlIfStatusOpen(String elementLoc,TestScenario testCase,HashMap<String,String> runtimeValues,String  serReqIDValue){
		WebElement element=explicitWait(driver, elementLoc);
		String status=element.getText();
		System.out.println("Service req sttus is "+status);
		String serReqID=driver.findElement(By.xpath(OR.getString("ServiceReg_ReqDetailsView_ReqID"))).getText();
		System.out.println("Service req ID is "+serReqID);
		String serReqIDValue2=runtimeValues.get(serReqIDValue);
		if(status.equalsIgnoreCase("OPEN") && serReqID.equalsIgnoreCase(serReqIDValue2)){
			driver.findElement(By.xpath(OR.getString("ServiceReg_ReqDetailsView_CancelReq"))).click();
			testCase.setStatus("Pass");
			testCase.setValueGotFromControl("Service req sttus is "+status+" so clicked on cancel link");
		}else{
			testCase.setStatus("Fail");
			testCase.setValueGotFromControl("Service req sttus is "+status+" so not clicked on cancel link");
		}
	}
	
	public void clickLinkByHref(String btnInnerEl) {
	    List<WebElement> anchors = driver.findElements(By.tagName("a"));
	    Iterator<WebElement> i = anchors.iterator();
	 
	    while(i.hasNext()) {
	        WebElement anchor = i.next();
		    if(anchor.getAttribute(" data-ref").contains(btnInnerEl)) {
		        anchor.click();
		        break;
	        }
	    }
	}
	
	public boolean compareRegGrievanceConfirmMsg(String s) { 
       // String str = "Registration request has been generated successfully. Please note down the Service Request ID 171800000651 for future reference. Please download the Registration form, sign and upload the form along with an identity proof to process your request."; 
        String pattern= "^[a-zA-Z0-9\\.\\s]+$"; 
		return s.matches(pattern);  
    } 

	public static boolean isAlphaNumeric(String s){ 
        String pattern= "^[a-zA-Z0-9\\.\\,\\s]+$"; 
        return s.matches(pattern); 
	}
	
	public static boolean serviceReqconfirmMsg(String s){ 
		String pattern= "^[a-zA-Z0-9\\.\\,\\s]+$"; 
		return s.matches(pattern); 
	} 
	
	public void compareServiceRequestConfirmMsg(TestScenario testCase) throws Exception { 
		String SerReqText=driver.findElement(By.xpath(OR.getString("ServiceReg_SuccessMsg_Text"))).getText();
		boolean alphaNumeric = serviceReqconfirmMsg(SerReqText); 
		if (alphaNumeric){
			testCase.setStatus("Pass");						
			testCase.setActualValue("Value "+SerReqText+" has been compared ");
			testCase.setExpectedValue("Value "+SerReqText+" should be compared ");
			HybridFrameWork.log.info(testCase.getTestFlow()+" Value "+SerReqText+" has been compared ");
		}
		else{
			testCase.setStatus("Fail");
			testCase.setActualValue("Value "+SerReqText+" has been compared ");
			testCase.setExpectedValue("Value "+SerReqText+" should be compared ");
			testCase.setScreentShot(compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
			HybridFrameWork.log.info(testCase.getTestFlow()+" Failed and took the screenshot");
		}
	}
	
	public boolean titleOfThePage(String s){ 
	    String re1=".*?";	
	    String re2="(?:[a-z][a-z]*[0-9]+[a-z0-9]*)";	
	    String re3=".*?";	
	    String re4="((?:[a-z][a-z]*[0-9]+[a-z0-9]*))";	
	    String pattern= re1+re2+re3+re4; 
        return s.matches(pattern); 
	}
	
	/*public void comparePageTitle(TestScenario testCase) throws Exception { 
		
		boolean check_AlertisPresent = check_AlertisPresent();
		if(check_AlertisPresent){
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			//alert.getText();
			System.out.println("Alert is displayed......");
			System.out.println("Alert text is : "+alert.getText());
			testCase.setStatus("Fail");
			testCase.setActualValue("Alert is displayed......");
			testCase.setExpectedValue("Alert is displayed......");
			testCase.setValueGotFromControl("Alert text is : "+alert.getText());
		}
		else {
			String pageTitle=driver.getTitle();
			System.out.println("pageTitle is :: "+pageTitle);
			boolean alphaNumeric = titleOfThePage(pageTitle); 
			if (alphaNumeric){
				testCase.setStatus("Pass");						
				testCase.setActualValue("Value "+pageTitle+" has been compared ");
				testCase.setExpectedValue("Value "+pageTitle+" should be compared ");
				testCase.setValueGotFromControl("Page Title is : "+pageTitle);
				HybridFrameWork.log.info(testCase.getTestFlow()+" Value "+pageTitle+" has been compared ");
			}
			else{
				testCase.setStatus("Fail");
				testCase.setActualValue("Value "+pageTitle+" has been compared ");
				testCase.setExpectedValue("Value "+pageTitle+" should be compared ");
				testCase.setValueGotFromControl("Page Title is : "+pageTitle);
				testCase.setScreentShot(compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" Value "+pageTitle+" has not compared");
			}
		}
	}*/
	
	public void comparePageTitle(TestScenario testCase) throws Exception { 

		String pageTitle=driver.getTitle();
		System.out.println("pageTitle is :: "+pageTitle);
		boolean alphaNumeric = titleOfThePage(pageTitle); 
		if (alphaNumeric){
			testCase.setStatus("Pass");						
			testCase.setActualValue("Value "+pageTitle+" has been compared ");
			testCase.setExpectedValue("Value "+pageTitle+" should be compared ");
			testCase.setValueGotFromControl("Page Title is : "+pageTitle);
			HybridFrameWork.log.info(testCase.getTestFlow()+" Value "+pageTitle+" has been compared ");
		}
		else{
			testCase.setStatus("Fail");
			testCase.setActualValue("Value "+pageTitle+" has been compared ");
			testCase.setExpectedValue("Value "+pageTitle+" should be compared ");
			testCase.setValueGotFromControl("Page Title is : "+pageTitle);
			testCase.setScreentShot(compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
			HybridFrameWork.log.info(testCase.getTestFlow()+" Value "+pageTitle+" has not compared");
		}
	}
	
	public boolean check_AlertisPresent() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 0);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.getText();
		} catch (Exception e) {		}
		return check_AlertisPresent();
	}
	
	public String HandlingTibcoAlerts(String inputData, String testDataColumn, HashMap<String,String> runtimeValues, TestScenario testCase) throws Exception {
		Thread.sleep(5000);
		
		String ErrorMsg=null;
		if(driver.findElements(By.xpath(OR.getString("ServerError_PopUp_HeaderName"))).size()!=0 ){
			ErrorMsg=driver.findElement(By.xpath(OR.getString("ServerError_PopUp_Text"))).getText();
			System.out.println("Server Error Msg is ::"+ErrorMsg);
			 String AlertText="Unable to Connect the service, Please try again later";
			
			if(ErrorMsg.equalsIgnoreCase(AlertText)){
				testCase.setValueGotFromControl("Matched");
				testCase.setStatus("Pass");	
				testCase.setActualValue("Value "+ErrorMsg+" has been compared ");
				testCase.setExpectedValue("Value "+AlertText+ " should be compared");
			} 
			driver.findElement(By.xpath(OR.getString("PopUp_OK_Button"))).click();
			
		} else if(driver.findElements(By.xpath(OR.getString("UnableToFetch_PopUp_HeaderName"))).size()!=0 && 
													driver.findElements(By.xpath(OR.getString("UnableToFetch_PopUp_InfoIcon"))).size()!=0){ 
			
			if(driver.findElement(By.xpath(OR.getString("Alert_PopupMsg"))).getText().equalsIgnoreCase("Unable to fetch these details now, please try again later.")){
				ErrorMsg=driver.findElement(By.xpath(OR.getString("UnableToFetch_PopUp_Text"))).getText();
				System.out.println("UnableToFetch_PopUp_Text is :: "+ErrorMsg);
				String AlertText="Unable to fetch these details now, please try again later.";
				testCase.setValueGotFromControl("Matched");
				testCase.setStatus("Pass");	
				testCase.setActualValue("Value "+ErrorMsg+" has been compared ");
				testCase.setExpectedValue("Value "+AlertText+ " should be compared");
			} else if(driver.findElement(By.xpath(OR.getString("LoanInterest_Alert_Msg"))).getText().equalsIgnoreCase("No loan is exists under this policy.")){
				ErrorMsg=driver.findElement(By.xpath(OR.getString("LoanInterest_Alert_Msg"))).getText();
				System.out.println("LoanInterest_Alert_Msg is :: "+ErrorMsg);
				String AlertText="No loan is exists under this policy.";
				testCase.setValueGotFromControl("Matched");
				testCase.setStatus("Pass");	
				testCase.setActualValue("Value "+ErrorMsg+" has been compared ");
				testCase.setExpectedValue("Value "+AlertText+ " should be compared");
			}
			driver.findElement(By.xpath(OR.getString("PopUp_OK_Button"))).click();
			
		} else if(driver.findElements(By.xpath(OR.getString("UnableToFetch_PopUp_InfoIcon"))).size()!=0 && 
												driver.findElements(By.xpath(OR.getString("UnableToFetch_PopUp_HeaderName"))).size()==0 ){
			ErrorMsg=driver.findElement(By.xpath(OR.getString("UnableToFetch_PopUp_Text"))).getText();
			System.out.println("UnableToFetch text is ::"+ErrorMsg);
			runtimeValues.put("InfoText", ErrorMsg);
			String AlertText="Unable to fetch these details now, please try again later.";
			
			if(ErrorMsg.equalsIgnoreCase(AlertText)){
				testCase.setValueGotFromControl("Matched");
				testCase.setStatus("Pass");	
				testCase.setActualValue("Value "+ErrorMsg+" has been compared ");
				testCase.setExpectedValue("Value "+AlertText+ " should be compared");
			} 
		} else if(driver.findElements(By.xpath(OR.getString("ServerError_PopUp_HeaderName"))).size()==0 &&
							driver.findElements(By.xpath(OR.getString("UnableToFetch_PopUp_InfoIcon"))).size()==0 && 
							driver.findElements(By.xpath(OR.getString("UnableToFetch_PopUp_HeaderName"))).size()==0 ) {

			System.out.println("No Alerts are available So policy/proposal image is downloaded");

			switchToNewTab();
			Thread.sleep(3000);
			comparePageTitle(testCase);
			//compareTitleOfPageUpdate(inputData,"", testCase);
			//Thread.sleep(3000);
			//7536e231-1e7d-4020-9644-cd57bbfeb2e7
			//9d010851-655f-4cb3-8c69-3f88cc9cca8e
			switchToPreviousWindow(runtimeValues, null);
		} 
		return ErrorMsg;
	}
	
	public void checkAlertisPresent() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 5); //describes how much time the driver has to wait
			wait.until(ExpectedConditions.alertIsPresent()); //describes the waiting condition
			Alert alert = driver.switchTo().alert();
			alert.accept(); 
			} catch (Exception e) {		}
	}
	
	public void FileUpload(String inputData, TestScenario testCase) throws AWTException{
		
		Robot robot = new Robot();
		
		robot.setAutoDelay(2000);
		//StringSelection is a class that can be used for copy and paste operations.
		
		StringSelection Selection = new StringSelection("D:\\Workspace\\LifeInsuranceCorp\\SikuliImages\\CancelPayment.PNG");
		//StringSelection stringSelection = new StringSelection(inputData);
		System.out.println("stringSelection path is ::"+Selection);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(Selection, null);
		
		robot.setAutoDelay(1000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.setAutoDelay(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

	}
	
	public void GeneratePDFInPolicyStatus() throws InterruptedException{
		Thread.sleep(500);
		driver.findElement(By.linkText(OR.getString("Basicservies_PolicyStatus_GeneratePDF_linkText"))).click();
		
	}
	
	public void DeletePolicy() throws InterruptedException{
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[text()='151563304']/following::i[@class='fa fa-trash-o fa-2x'][1]")).click();
		
		
	}
	
	//*************LIC Methods*********************************//

	public void compareCloseBrowser(){
		driver.quit();
	}

}
