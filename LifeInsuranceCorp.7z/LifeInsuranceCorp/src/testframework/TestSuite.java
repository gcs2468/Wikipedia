package testframework;

import java.util.LinkedList;
import java.util.List;

public class TestSuite {
	private String secenarioKey;
	private String senarioDescription;
	private String runMode;
	private List<String> status=new LinkedList<String>();
	private List<String> executionStartTime=new LinkedList<String>();
	private List<String> executionEndTime=new LinkedList<String>();
	
	public List<String> getStatus() {
		return status;
	}
	public void setStatus(List<String> status) {
		this.status = status;
	}
	public List<String> getExecutionStartTime() {
		return executionStartTime;
	}
	public void setExecutionStartTime(List<String> executionStartTime) {
		this.executionStartTime = executionStartTime;
	}
	public List<String> getExecutionEndTime() {
		return executionEndTime;
	}
	public void setExecutionEndTime(List<String> executionEndTime) {
		this.executionEndTime = executionEndTime;
	}
	
	public String getSenarioDescription() {
		return senarioDescription;
	}
	public void setSenarioDescription(String senarioDescription) {
		this.senarioDescription = senarioDescription;
	}

	public String getSecenarioKey() {
		return secenarioKey;
	}
	public void setSecenarioKey(String secenarioKey) {
		this.secenarioKey = secenarioKey;
	}
	public String getRunMode() {
		return runMode;
	}
	public void setRunMode(String runMode) {
		this.runMode = runMode;
	}

}
