package testframework;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;

import readinginputfiles.ReadingControllerAndDataSheet;
import readinginputfiles.ReadingControllerAndTestDataSheets;
import testreports.SummaryReport;

public class HybridFrameworkWithGrid {

	public static  int ThreadCount =0;

	static{
		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy HH-mm-ss");
		System.setProperty("current.date.time", df.format(new Date()));		
	}	

	static Logger log = Logger.getLogger("LIC Application");
	ResourceBundle settings = ResourceBundle.getBundle("configuration.Settings");
	
	public void LifeInsuranceCorp() throws IOException{
		try{
			DOMConfigurator.configure(settings.getString("log4jxmlfilepath"));
			PropertyConfigurator.configure(settings.getString("log4jpropertiesfilepath"));
			
			System.out.println("<<< ******** Start of Execution ******** >>>");
			System.out.println("Environment is :: "+settings.getString("ENV"));
			System.out.println("URL is :: "+settings.getString(settings.getString("ENV")+"url"));
			
			String className=settings.getString("openOfficeOrMSOffice");
			ReadingControllerAndDataSheet inputfiles=null;
			try {
				inputfiles = (ReadingControllerAndDataSheet) Class.forName(className).newInstance();
			} catch (InstantiationException | IllegalAccessException
					| ClassNotFoundException e) {
				e.printStackTrace();
			}
			
			List<TestSuite> suiteList=inputfiles.readingSuite();
			Map<String,List<TestScenario>> keyController=inputfiles.readingControllerSheet();
			Map<String,List<Map<String,String>>> testDataSht=inputfiles.readingTestDataSheet();
			HashMap<String,String> runtimeValues=new HashMap<String,String>();
			
			String threadPool=settings.getString("threadPoolSize");
			Integer threadPoolSize=Integer.parseInt(threadPool);
			ExecutorService pool = Executors.newFixedThreadPool(threadPoolSize);
			
			SummaryReport mtr=new SummaryReport();
			int tcount=1;
			KeywordWithgrid g1=null;
			for(Entry<String,List<Map<String,String>>> testDataSht2:testDataSht.entrySet ()){
				g1=new KeywordWithgrid(testDataSht, keyController, suiteList, runtimeValues, testDataSht2,mtr);
				//g1.start();
				pool.submit(g1);
				tcount++;	
			}
			pool.submit(g1).get();
			pool.shutdown();

			ThreadCount=ReadingControllerAndTestDataSheets.testDatasetCount;
			//ThreadCount=10;
			System.out.println("Main END: "+ThreadCount);

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}finally{
			System.out.println("Test Suite executed");
		}

	}
}

