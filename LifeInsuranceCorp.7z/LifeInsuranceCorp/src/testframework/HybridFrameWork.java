package testframework;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;
import org.junit.Test;

import readinginputfiles.ReadingControllerAndTestDataSheets;
import testreports.SummaryReport;

public class HybridFrameWork { 
		
	static{
		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy HH-mm-ss");
		System.setProperty("current.date.time", df.format(new Date()));		
	}	
	
	static Logger log = Logger.getLogger("LIC Application");
	ResourceBundle settings = ResourceBundle.getBundle("configuration.Settings");
	
	@Test 
	public void LicTest() throws IOException {
		
		DOMConfigurator.configure(settings.getString("log4jxmlfilepath"));
		PropertyConfigurator.configure(settings.getString("log4jpropertiesfilepath"));
		
		System.out.println("<<< ******** Start of Execution ******** >>>");
		System.out.println("Environment is :: "+settings.getString("ENV"));
		System.out.println("URL is :: "+settings.getString(settings.getString("ENV")+"url"));
				
		ReadingControllerAndTestDataSheets inputfiles=new ReadingControllerAndTestDataSheets();
		List<TestSuite> suiteList=inputfiles.readingSuite();
		Map<String,List<TestScenario>> keyController=inputfiles.readingControllerSheet();
		Map<String,List<Map<String,String>>> testDataSht=inputfiles.readingTestDataSheet();
		SummaryReport summaryReport =new SummaryReport();
		Keyword gData=new Keyword(testDataSht);
		gData.readKeywordsFromController(suiteList,keyController,summaryReport);
		
		System.out.println("<<< ======= End of Execution ======= >>>");
	}

}


