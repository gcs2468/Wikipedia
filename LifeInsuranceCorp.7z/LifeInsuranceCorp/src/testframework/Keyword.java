package testframework;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import testreports.DetailReport;
import testreports.POMReport;
import testreports.SummaryReport;

public class Keyword extends KeywordSpec {
	ResourceBundle settings = ResourceBundle.getBundle("configuration.Settings");
	ResourceBundle OR = ResourceBundle.getBundle("configuration.OR");
	HashMap<String,String> runtimeValues=new HashMap<String,String>();
	String propValue;	
	String ScreenShotPath=settings.getString("Path")+settings.getString(settings.getString("ENV")+"ScreenShotPath");
	Map<String,List<Map<String,String>>> testDataShtMap;

	public Keyword(Map<String, List<Map<String, String>>> testDataShtMap) {
		this.testDataShtMap=testDataShtMap;
	}

	public Map<String,List<List<TestScenario>>> readKeywordsFromController(List<TestSuite> suiteList, Map<String,List<TestScenario>> keyController, SummaryReport summaryReport){

		Map<String,List<List<TestScenario>>> caseResult=null;
		try{
			caseResult=new LinkedHashMap<String,List<List<TestScenario>>>();
			List<List<TestScenario>> updatedTestcases=null;
			KeywordSpec keyspec=new KeywordSpec();
			int sno=1;
			String POMValue = "";
			for(Entry<String,List<Map<String,String>>> testData:testDataShtMap.entrySet()){
				LinkedList<Map<String,String>> actualDataPair=(LinkedList<Map<String,String>>)testData.getValue();
				List<TestScenario> scenariosList=(List<TestScenario>) keyController.get(testData.getKey());
				if(scenariosList!=null){
					TestSuite suite=null;
					for(TestSuite suite1:suiteList){
						if(suite1.getSecenarioKey().equalsIgnoreCase(testData.getKey()))
							suite=suite1;
					}

					if(suite.getRunMode().equalsIgnoreCase("Y")){
						int nc=0;						
						for(Map<String,String> testDataSht:actualDataPair){	
							int POMNum = 0;
							DateFormat df = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
							Date date = new Date();
							String startTime=df.format(date);
							suite.getExecutionStartTime().add(startTime);
							suite.getStatus().add("Fail");
							int testScenarioCount=0;
							List<TestScenario> testSteps = new ArrayList<TestScenario>(scenariosList.size());
							for (TestScenario item : scenariosList) {
								testSteps.add((TestScenario) item.clone());
							}
							for(TestScenario testStep : testSteps){

								if(testStep.getKeyWord().contains("POM//")){
									testStep.setStatus("Pass");
								} else if(testStep.getKeyWord().contains("POM")){
									POMNum++;
									POMValue = testStep.getKeyWord();
									int i = 0;
									for(TestScenario subScenario : testStep.getPomList()){
										executeKeywords(subScenario, keyspec, suite, testDataSht);
										if(subScenario.getStatus().equalsIgnoreCase("fail") && i==0){
											testStep.setStatus("Fail");
											i++;
											//keyspec.compareCloseBrowser(); 
											System.out.println("As Fail occured, Skip the scenario and started next scenario");
											break;
										}
									}
									if(i==0){
										testStep.setStatus("Pass");
									}
									if(testStep.getStatus().equals("Fail")){
										testScenarioCount++;
									}
									POMReport pr=new POMReport();
									pr.generatePOMReport(testStep.getPomList(),suite,testDataSht,nc,summaryReport,sno,POMValue,POMNum);


								} else if(!testStep.getKeyWord().contains("POM")){
									executeKeywords(testStep, keyspec, suite, testDataSht);
									if(testStep.getStatus().equals("Fail")){
										testScenarioCount++;
										//keyspec.compareCloseBrowser(); 
										break;
									}
								}
							}
							if(caseResult.containsKey(suite.getSecenarioKey())){
								updatedTestcases.add(testSteps);		
							}else{
								updatedTestcases=new LinkedList<List<TestScenario>>();
								updatedTestcases.add(testSteps);
								caseResult.put(suite.getSecenarioKey(), updatedTestcases);
							}
							System.out.println      ("=================== END ["+suite.getSecenarioKey()+"]======================");
							HybridFrameWork.log.info("=================== END ["+suite.getSecenarioKey()+"]======================");
							HybridFrameWork.log.info(" ");
							System.out.println("  ");
							DateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
							Date date1 = new Date();
							String endTime=df1.format(date1);
							suite.getExecutionEndTime().add(endTime);
							if(testScenarioCount==0)
								suite.getStatus().set(nc, "Pass");
							DetailReport dr=new DetailReport();
							dr.generateDetailedReport(testSteps,suite,testDataSht,nc,summaryReport,sno++);	
							nc++;	

						}
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return caseResult;
	}
	
	public void commonKeywordsLIC(TestScenario testCase, KeywordSpec keyspec, TestSuite suite, Map<String,String> testDataSht) throws Exception{
		
		testCase.setStatus("Pass");

		// ******************Start copying if...else blocks here*********************************		
		
		if(testCase.getKeyWord().equals("url")){
			String propUrl=settings.getString(settings.getString("ENV")+"url");
			String browser=settings.getString("browser");
			//Pass ur url to selenium code
			try{
				System.out.println      ("=================== Started ["+suite.getSecenarioKey()+"]======================");
				HybridFrameWork.log.info("=================== Started ["+suite.getSecenarioKey()+"]======================");
				HybridFrameWork.log.info(" ");
				keyspec.getURL(propUrl, browser);
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Application Should launch with Provided URL");
				testCase.setActualValue("Application has launched Successfully with Provided URL");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Application has launched on Browser = "+browser);
				HybridFrameWork.log.info((testCase.getTestFlow())+" Application has launched on URL = "+propUrl);

			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				HybridFrameWork.log.info("Failed to Launch Application");
			}

		} else if(testCase.getKeyWord().equalsIgnoreCase("click")){
			String propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.compareClick_Element(propValue,testCase);
				testCase.setStatus("Pass");
				testCase.setActualValue("Element has been clicked");
				testCase.setExpectedValue("Element should be clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked on "+(testCase.getObjectElement()));

		    }catch(Exception e){
		    	testCase.setActualValue("element is not clicked");
		    	if(propValue.equals(".//*[@id='submitForm:accordID:Producer_Name_customAuto_panel']/ul/li")){
		    		try{
		    		driver.findElement(By.xpath(propValue));
		    		}catch(NoSuchElementException e1){
		    		testCase.setValueGotFromControl("Producer is logged in and element is not displayed");
		    		testCase.setStatus("Pass");
					testCase.setActualValue("Element has been clicked");
					testCase.setExpectedValue("Element should be clicked");
					HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked on "+(testCase.getObjectElement()));
		    		}
				}else{
					testCase.setFailMessage(e.getMessage());
					testCase.setStatus("Fail");
					testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
					HybridFrameWork.log.info((testCase.getTestFlow())+" Not clicked on "+(testCase.getObjectElement()));
			}
		 }
	    } else if(testCase.getKeyWord().equals("textbox")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.modifyEnteredText(propValue, testDataSht.get(testCase.getDataColumn()),testCase);
				testCase.setStatus("Pass");	
				testCase.setActualValue("Value "+testDataSht.get(testCase.getDataColumn())+ " has been entered/modified ");
				testCase.setExpectedValue("Value "+testDataSht.get(testCase.getDataColumn())+ " should be entered/modified ");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Entered Textbox "+(testCase.getDataColumn())+" = "+testDataSht.get(testCase.getDataColumn()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Entered Textbox "+(testCase.getDataColumn())+" = "+e.getMessage());
			}

		} else if(testCase.getKeyWord().equalsIgnoreCase("isElementDisplayed")){
			propValue=OR.getString(testCase.getObjectElement());

			try{
				keyspec.isElementDisplayed(propValue,testCase);
				/* testCase.setStatus("Pass");
		    	testCase.setActualValue("element has been clicked");
				testCase.setExpectedValue("element should be clicked");*/
				HybridFrameWork.log.info((testCase.getTestFlow())+" Element "+(testCase.getObjectElement())+" is displayed");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Element "+(testCase.getObjectElement())+" is not displayed");
			}
		} else if(testCase.getKeyWord().equals("xpathExpression")){
			//String propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.xpathExpression(testDataSht.get(testCase.getDataColumn()),testCase);
				testCase.setStatus("Pass");
				testCase.setActualValue("element should be clicked");
				testCase.setExpectedValue("element has been clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" xpath created for "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" xpath not created for "+(testCase.getObjectElement()));
			}
	 } else if(testCase.getKeyWord().equals("listXpathExpression")){
			//propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.listXpathExpression(testDataSht.get(testCase.getDataColumn()),testCase);
				testCase.setStatus("Pass");
				testCase.setActualValue("element should be clicked");
				testCase.setExpectedValue("element has been clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Xpath created for "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Xpath not created for "+(testCase.getObjectElement()));
			}
		} else if(testCase.getKeyWord().equals("Arrow_Down")){
			String propValue=OR.getString(testCase.getObjectElement());
			try{
			keyspec.downarrow(propValue, testCase);
		    testCase.setStatus("Pass");
		    testCase.setActualValue("Status changed successfully");
			testCase.setExpectedValue("Status should be updated");
			HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked down arrow for "+(testCase.getObjectElement()));

		    }catch(Exception e){
			testCase.setFailMessage(e.getMessage());
			testCase.setStatus("Fail");
			testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
			HybridFrameWork.log.info((testCase.getTestFlow())+" Not clicked down arrow for "+(testCase.getObjectElement()));
		 	}
	    } else if(testCase.getKeyWord().equalsIgnoreCase("getWindowName")){
			try{
				keyspec.getWindow(runtimeValues,suite);
				HybridFrameWork.log.info((testCase.getTestFlow())+" Captured window name "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not captured window name "+(testCase.getObjectElement()));
			}

		} else if(testCase.getKeyWord().equalsIgnoreCase("navigateToNextTab")){
			try{
				keyspec.switchToNewTab();
				HybridFrameWork.log.info((testCase.getTestFlow())+" Navigated to "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not navigated to "+(testCase.getObjectElement()));
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("navigateToPreviousTab")){
			try{
				keyspec.switchToPreviousWindow(runtimeValues,suite);
				HybridFrameWork.log.info((testCase.getTestFlow())+" Navigated to "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not navigated to "+(testCase.getObjectElement()));
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("compareTitleOfPage")){
			try{
				keyspec.compareTitleOfPage(testDataSht.get(testCase.getDataColumn()),testCase);
			}catch(Exception e){	
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Failed and took the screenshot");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("compare")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.compareSummaryData(propValue, testDataSht.get(testCase.getDataColumn()),runtimeValues,testCase,suite);
				HybridFrameWork.log.info((testCase.getTestFlow())+" is Compared");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				testCase.setValueGotFromControl("Element is not displayed/Identified");  
				HybridFrameWork.log.info((testCase.getTestFlow())+" Failed and took the screenshot");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("HandlingTibcoAlerts")){
			
			try{
				keyspec.HandlingTibcoAlerts(testDataSht.get(testCase.getDataColumn()), testDataSht.get(testCase.getDataColumn()), runtimeValues,testCase);
				HybridFrameWork.log.info((testCase.getTestFlow())+"is Compared"); 
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				testCase.setValueGotFromControl("Element is not displayed/Identified");  
				HybridFrameWork.log.info((testCase.getTestFlow())+" Failed and took the screenshot");
			}
		} else if(testCase.getKeyWord().equals("Tabclick")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.Tab_Click(propValue);
				testCase.setStatus("Pass");
				testCase.setActualValue("element has been clicked");
				testCase.setExpectedValue("element should be clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked on "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not clicked on "+(testCase.getObjectElement()));
			}
		} else if(testCase.getKeyWord().equals("SpaceBarClick")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.SpaceBarClick(propValue);
				testCase.setStatus("Pass");
				testCase.setActualValue("element has been clicked");
				testCase.setExpectedValue("element should be clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked on "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not clicked on "+(testCase.getObjectElement()));
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("compareTaskComments")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.comparePartOfString(propValue, testDataSht.get(testCase.getDataColumn()),testCase);
				testCase.setActualValue("Value "+keyspec.comparePartOfString(propValue, testDataSht.get(testCase.getDataColumn()),testCase)+" has been compared ");
				testCase.setExpectedValue("Value "+testDataSht.get(testCase.getDataColumn())+ " should be compared");
				HybridFrameWork.log.info(testDataSht.get(testCase.getDataColumn())+" is entered");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info("Failed and took the screenshot");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("compareTaskComments_list")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.comparePartOfStringInList(propValue, testDataSht.get(testCase.getDataColumn()),testCase);
				HybridFrameWork.log.info(testDataSht.get(testCase.getDataColumn())+" is entered");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info("Failed and took the screenshot");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("click_IfElementDisplayed")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.click_IfElementDisplayed(propValue,testCase);
				testCase.setStatus("Pass");
				testCase.setActualValue("Element has been clicked");
				testCase.setExpectedValue("Element should be clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked on "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setActualValue("Element not clicked");
				testCase.setValueGotFromControl("Element is not displayed");
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not clicked on "+(testCase.getObjectElement()));
			}	
		} else if(testCase.getKeyWord().equalsIgnoreCase("handlingGoogleAccountLink")){
			try{
				keyspec.handlingGoogleAccountLink(testCase);
				testCase.setStatus("Pass");
				testCase.setActualValue("Element has been clicked");
				testCase.setExpectedValue("Element should be clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked on "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setActualValue("Element not clicked");
				testCase.setValueGotFromControl("Element is not displayed");
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not clicked on "+(testCase.getObjectElement()));
			}	
		} else if(testCase.getKeyWord().equalsIgnoreCase("handlingFacebookAccountLink")){
			try{
				keyspec.handlingFacebookAccountLink(testCase);
				testCase.setStatus("Pass");
				testCase.setActualValue("Element has been clicked");
				testCase.setExpectedValue("Element should be clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked on "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setActualValue("Element not clicked");
				testCase.setValueGotFromControl("Element is not displayed");
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not clicked on "+(testCase.getObjectElement()));
			}	
		} else if(testCase.getKeyWord().equalsIgnoreCase("handlingTwitterAccountLink")){
			try{
				keyspec.handlingTwitterAccountLink(testCase);
				testCase.setStatus("Pass");
				testCase.setActualValue("Element has been clicked");
				testCase.setExpectedValue("Element should be clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked on "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setActualValue("Element not clicked");
				testCase.setValueGotFromControl("Element is not displayed");
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not clicked on "+(testCase.getObjectElement()));
			}	
		} else if(testCase.getKeyWord().equalsIgnoreCase("Re_Enter_textbox")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.modifyEnteredText(propValue, testDataSht.get(testCase.getDataColumn()),testCase);
				testCase.setStatus("Pass");	
				testCase.setActualValue("Value "+testDataSht.get(testCase.getDataColumn())+ " has been entered/modified ");
				testCase.setExpectedValue("Value "+testDataSht.get(testCase.getDataColumn())+ " should be entered/modified ");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Re-entered Textbox "+(testCase.getDataColumn())+" = "+testDataSht.get(testCase.getDataColumn()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setActualValue("Value "+testDataSht.get(testCase.getDataColumn())+ " has been entered/modified ");
				testCase.setExpectedValue("Value "+testDataSht.get(testCase.getDataColumn())+ " should be entered/modified ");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Re-entered Textbox "+(testCase.getDataColumn())+" = "+e.getMessage());
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("minWait")){
			Thread.sleep(3000);
			HybridFrameWork.log.info((testCase.getTestFlow())+" Waited for 3 secs");
		} else if(testCase.getKeyWord().equalsIgnoreCase("wait")){			
				Thread.sleep(10000);
				HybridFrameWork.log.info((testCase.getTestFlow())+" Waited for 10 secs");
		} else if(testCase.getKeyWord().equalsIgnoreCase("longwait")){			
				Thread.sleep(120000);
				HybridFrameWork.log.info((testCase.getTestFlow())+" Waited for 2 minutes");
		} else if(testCase.getKeyWord().equalsIgnoreCase("waitForPageLoad")){
			keyspec.waitForPageLoad();
			HybridFrameWork.log.info((testCase.getTestFlow())+" Waited for 2 minutes");
		} else if(testCase.getKeyWord().equalsIgnoreCase("waitForElement")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.waitForElement(propValue);
				testCase.setActualValue("Waited for element to visible");
				testCase.setExpectedValue("Wait for element to visible");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Waited for 10 seconds");
			}catch(Exception e){
				testCase.setStatus("Fail");
				testCase.setFailMessage(e.getMessage());
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
			}
		} else if(testCase.getKeyWord().equals("moveToElement")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.moveToElement(propValue, testCase);
				testCase.setStatus("Pass");	
				testCase.setActualValue("element has been clicked");
				testCase.setExpectedValue("element should be clicked");
				HybridFrameWork.log.info((testCase.getTestFlow())+" is entered/modified");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setActualValue("element is not displayed ");
				testCase.setExpectedValue("element should be clicked");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Failed and took the screenshot");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("scroll")){
			try{
				keyspec.comparePageScroll();
				testCase.setStatus("Pass");
				testCase.setActualValue("Page has scrolled");
				testCase.setExpectedValue("Page should be scrolled");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Page has scrolled "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(ScreenShotPath));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Page has not scrolled "+(testCase.getObjectElement()));
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("longScroll")){
			try{
				keyspec.compareLongPageScroll();
				testCase.setStatus("Pass");
				testCase.setActualValue("Page has scrolled");
				testCase.setExpectedValue("Page should be scrolled");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Page has scrolled "+(testCase.getObjectElement()));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(ScreenShotPath));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Page has not Refreshed "+(testCase.getObjectElement()));
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("clickLinkByHref")){
			String anchor = null;
			try{
				keyspec.clickLinkByHref(anchor);
				testCase.setStatus("Pass");
				testCase.setActualValue("Clicked on Upload link");
				testCase.setExpectedValue("Should be clicked on Upload linkd");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Clicked on Upload link");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setActualValue("Not clicked on Upload link");
				testCase.setExpectedValue("Should not be clicked on Upload linkd");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Not clicked on Upload link");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("OfficeLocatorHandling")){
			try{
				keyspec.OfficeLocatorHandling(); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Security alert is Accepted/Canceled");
				testCase.setActualValue("Security alert should be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" is Accepted/Canceled");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Security alert is not Accepted/Canceled");
				testCase.setActualValue("Security alert should not be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" failed to Accept/Cancel security alert");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("OfficeLocatorGetDirection")){
			try{
				keyspec.OfficeLocatorGetDirection(); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Security alert is Accepted/Canceled");
				testCase.setActualValue("Security alert should be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" is Accepted/Canceled");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Security alert is not Accepted/Canceled");
				testCase.setActualValue("Security alert should not be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" failed to Accept/Cancel security alert");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("OfficeLocatorCloseAlert")){
			try{
				keyspec.OfficeLocatorAlertClose(); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Security alert is Accepted/Canceled");
				testCase.setActualValue("Security alert should be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" is Accepted/Canceled");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Security alert is not Accepted/Canceled");
				testCase.setActualValue("Security alert should not be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" failed to Accept/Cancel security alert");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("OfficeLocatorHomeButton")){
			try{
				keyspec.OfficeLocatorHomeButton(); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Security alert is Accepted/Canceled");
				testCase.setActualValue("Security alert should be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" is Accepted/Canceled");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Security alert is not Accepted/Canceled");
				testCase.setActualValue("Security alert should not be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info((testCase.getTestFlow())+" failed to Accept/Cancel security alert");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("refreshPage")){
			try{
				keyspec.compareLongPageScroll();
				testCase.setStatus("Pass");
				testCase.setActualValue("Page has refreshed");
				testCase.setExpectedValue("Page should be refreshed");
				HybridFrameWork.log.info((testCase.getTestFlow())+" Page has refreshed ");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(ScreenShotPath));
				HybridFrameWork.log.info((testCase.getTestFlow())+" Page has not Refreshed ");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("handlingSecurityAlert")){
			try{
				keyspec.handlingSecurityAlert(); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Security alert is Accepted/Canceled");
				testCase.setActualValue("Security alert should be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" is Accepted/Canceled");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Security alert is not Accepted/Canceled");
				testCase.setActualValue("Security alert should not be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" failed to Accept/Cancel security alert");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("handlingSavePswdAlert")){
			try{
				keyspec.handlingSavePswdAlert(); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Security alert is Accepted/Canceled");
				testCase.setActualValue("Security alert should be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" is Accepted/Canceled");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Security alert is not Accepted/Canceled");
				testCase.setActualValue("Security alert should not be Accepted/Canceled");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" failed to Accept/Cancel security alert");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("CompareOfficeLocatorImages")){
			try{
				keyspec.CompareOfficeLocatorImages(); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Images should be matched");
				testCase.setActualValue("Images has been matched");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" Compared the images");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Images should be matched");
				testCase.setActualValue("Images has been not matched");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" failed to Compare the images");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("clickViewIfStatusOpen")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				String serReqIDValue=null;
				keyspec.clickViewIfStatusOpen(propValue, testCase, runtimeValues, serReqIDValue); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Selected TopUp olicy checkbox");
				testCase.setActualValue("TopUp olicy checkbox should be selected");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" is selected");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Not Selected TopUp olicy checkbox");
				testCase.setActualValue("TopUp olicy checkbox should not be selected");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" is not be selected");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("clickCancelIfStatusOpen")){
			propValue=OR.getString(testCase.getObjectElement());
			try{
				String serReqIDValue=null;
				keyspec.canceReqlIfStatusOpen(propValue, testCase, runtimeValues, serReqIDValue); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Selected TopUp olicy checkbox");
				testCase.setActualValue("TopUp olicy checkbox should be selected");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" is selected");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Not Selected TopUp olicy checkbox");
				testCase.setActualValue("TopUp olicy checkbox should not be selected");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" is not be selected");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("compareServiceRequestConfirmMsg")){
			try{
				keyspec.compareServiceRequestConfirmMsg(testCase);
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" Failed and took the screenshot");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("FileUpload")){
			String inputData="";
			try{
				keyspec.FileUpload(inputData, testCase);
				testCase.setStatus("Pass");
				testCase.setExpectedValue("File should be uploaded");
				testCase.setActualValue("File has been uploaded");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" File has been uploaded");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("File should be uploaded");
				testCase.setActualValue("File has not been uploaded");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" File has not been uploaded");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("GeneratePDFInPolicyStatus")){
			//propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.GeneratePDFInPolicyStatus();
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Should be clicked on Generate PDF");
				testCase.setActualValue("Has been clicked on Generate PDF");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" Has been clicked on Generate PDF");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("File should be uploaded");
				testCase.setActualValue("File has not been uploaded");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" File has not been uploaded");
			}
		} else if(testCase.getKeyWord().equalsIgnoreCase("DeletePolicy")){
			//propValue=OR.getString(testCase.getObjectElement());
			try{
				keyspec.DeletePolicy();
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Should be clicked on Delete policy button");
				testCase.setActualValue("Has been clicked on Delete policy button");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" Has been clicked on Delete policy button");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setExpectedValue("Should be clicked on Delete policy button");
				testCase.setActualValue("Not clicked on Delete policy button");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" Not clicked on Delete policy button");
			}
		} 
		
		
		
		
		else if(testCase.getKeyWord().equalsIgnoreCase("closeBrowser")){
			try{
				keyspec.compareCloseBrowser(); 
				testCase.setStatus("Pass");
				testCase.setExpectedValue("Browser should be Closed");
				testCase.setActualValue("Browser has Closed");
				HybridFrameWork.log.info(testCase.getTestFlow()+" Browser is closed");
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
				HybridFrameWork.log.info(testCase.getTestFlow()+" Failed to close browser");
			}
		}

		//*************Stop copying if...else blocks*************************************************

		if((testCase.getScreentShot().equalsIgnoreCase("Y") || testCase.getScreentShot().contains(".png")) && (!testCase.getKeyWord().contains("//"))){
			try{
				testCase.setScreentShot(keyspec.compareCaptureScreenshot(settings.getString(settings.getString("ENV")+"ScreenShotPath")));
			}catch(Exception e){
				testCase.setFailMessage(e.getMessage());
				testCase.setStatus("Fail");
			}
		}

	}
	
	public  void  executeKeywords(TestScenario testCase, KeywordSpec keyspec, TestSuite suite, Map<String,String> testDataSht) throws Exception{
		commonKeywordsLIC(testCase, keyspec, suite,testDataSht);
	}

	public String getSpecificData(String elementLoc,String key,String dataColumnName,int pos){
		String data=testDataShtMap.get(key).get(pos).get(dataColumnName);
		return data;
	}
	
}
