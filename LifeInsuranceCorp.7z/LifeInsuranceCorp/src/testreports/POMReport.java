package testreports;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import testframework.TestScenario;
import testframework.TestSuite;

public class POMReport {

	ResourceBundle settings = ResourceBundle.getBundle("configuration.Settings");

	public void generatePOMReport(List<TestScenario> testSteps, TestSuite suite,
			Map<String, String> usedData, int c,
			SummaryReport mtr, int sno ,String POMValue, int pomNum){
        
		//DateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
		/*SimpleDateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy-hh-mm-ss");
		Date date1 = new Date();
  		String endTime=df1.format(date1);*/
  		
		//System.out.println("in generatePOMReport");
		String testSheetNo=suite.getSecenarioKey();
		StringBuilder sb=new StringBuilder();
		sb.append("<html><head><h1 align='center'><a href='http://www.intellectdesign.com/best-viewed.asp'><img src='D:\\Workspace\\LifeInsuranceCorp\\src\\testreports\\LicLogo.png' alt='Intellect Website' style='width:200px;height:80px;border:0'></a> </h1>");
		//sb.append("<html><head><h2 align='left'><font color='blue'>"+"POMValue"+" Report : "</font></h2></head>");
		sb.append("<html><head><h3 align='left'><font color='blue'>"+"Report For : "+POMValue+"</font></h3></head>");
		sb.append("<body><table align='center'border='2'><tr style='background-color:brown;color:white;border-color:blue'><th>Test Steps</th><th>Step Description</th><th>Keyword</th><th>Object ID</th><th>Test Data Column</th><th>Test Data</th><th>Status</th><th>Expected Value<th>Actual Value</th><th>Ref Value</th><th>Data Comparison</th><th>Screen Shot</th></tr>");
		//System.out.println("POM Report endTime is :: "+endTime);
		File file=new File(settings.getString("Path")+settings.getString(settings.getString("ENV")+"POM"+"ReportsPath")+testSheetNo+""+POMValue+"[ Set-"+c+" ]"+pomNum+".html");//"+endTime+"
																																			 
		
		int tcount=0;    
		String ssPath=settings.getString("Path")+settings.getString(settings.getString("ENV")+"ScreenShotPath");
		for (TestScenario testStep : testSteps) {
			if(!testStep.getKeyWord().equalsIgnoreCase("wait")&&!testStep.getKeyWord().equalsIgnoreCase("longWait")&&!testStep.getKeyWord().equalsIgnoreCase("minWait")&&!testStep.getKeyWord().equalsIgnoreCase("scroll")&&!testStep.getKeyWord().equalsIgnoreCase("longScroll")&&!testStep.getKeyWord().equalsIgnoreCase("waitForAjaxCallProcess")&&!testStep.getKeyWord().equalsIgnoreCase("waitForAjaxCallLoad")&&!testStep.getKeyWord().equalsIgnoreCase("waitForPageLoad")){
				sb.append("<tr>");
				if((testStep.getTestFlow().equals("")||testStep.getTestFlow()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					sb.append("<td>").append(testStep.getTestFlow()).append("</td>");
				if((testStep.getDescription().equals("")||testStep.getDescription()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					sb.append("<td>").append(testStep.getDescription()).append("</td>");
				if((testStep.getKeyWord().equals("")||testStep.getKeyWord()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					sb.append("<td>").append(testStep.getKeyWord()).append("</td>");
				if((testStep.getObjectElement().equals("")||testStep.getObjectElement()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					sb.append("<td>").append((testStep.getObjectElement().equals("")||testStep.getObjectElement()==null)?"&nbsp;":testStep.getObjectElement()).append("</td>");
				if((testStep.getDataColumn().equals("")||testStep.getDataColumn()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					sb.append("<td>").append(testStep.getDataColumn()).append("</td>");
				sb.append("<td>").append((usedData.get(testStep.getDataColumn())==null||usedData.get(testStep.getDataColumn()).equals(""))?"&nbsp;":usedData.get(testStep.getDataColumn())).append("</td>");
				if(testStep.getStatus()==null){
					testStep.setStatus("fail");
					testStep.setFailMessage("failed to locate element");
				}
				if(testStep.getStatus().equalsIgnoreCase("pass"))
					sb.append("<td style='background-color:green;'>").append(testStep.getStatus()).append("</td>");
				else
					sb.append("<td style='background-color:red;'>").append(testStep.getStatus()).append("  :  ").append(testStep.getFailMessage()).append("</td>");
				//for actual value and expected value
				sb.append("<td>").append((testStep.getExpectedValue()==null)?"&nbsp;":testStep.getExpectedValue()).append("</td>");
				sb.append("<td>").append((testStep.getActualValue()==null)?"&nbsp;":testStep.getActualValue()).append("</td>");
				//need to add extra coloumns
				sb.append("<td>").append((testStep.getApplicationID()==null)?"&nbsp;":testStep.getApplicationID()).append("</td>");
				sb.append("<td>").append((testStep.getValueGotFromControl()==null)?"&nbsp;":testStep.getValueGotFromControl()).append("</td>");

				if(testStep.getScreentShot().equals("N")||testStep.getScreentShot()==null||testStep.getScreentShot().equals(""))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else					
					sb.append("<td><a href='"+ssPath+"").append(testStep.getScreentShot()).append("'>").append("Screen Shot").append("</a></td>");
				sb.append("</tr>");

			}
			tcount++;
			if(testSteps.size()==tcount){
				//System.out.println("Inside count");
				//mtr.generateScenarioReportPOM(suite,testSteps,c,sno,POMValue);
			}

		}

		FileWriter fw = null;
		BufferedWriter bw=null;
		try {
			file=new File(settings.getString("Path")+settings.getString(settings.getString("ENV")+"POM"+"ReportsPath"));
			if(!file.exists()){
				file.mkdir();
			}
			//System.out.println("POM Report endTime is :: "+endTime);
			file=new File(settings.getString("Path")+settings.getString(settings.getString("ENV")+"POM"+"ReportsPath")+testSheetNo+""+POMValue+"[ Set-"+c+" ]"+pomNum+".html");//"+endTime+"
			fw = new FileWriter(file);
			bw = new BufferedWriter(fw);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			fw = new FileWriter(file);
			bw = new BufferedWriter(fw);
			bw.write(sb.toString());
			bw.close();			
		} catch (IOException e) {
			e.printStackTrace();
		}
		//System.out.println("Returned time is :: "+endTime);
		//return endTime;

	}


}
