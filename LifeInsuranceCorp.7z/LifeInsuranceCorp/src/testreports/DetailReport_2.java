package testreports;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import testframework.TestScenario;
import testframework.TestSuite;

public class DetailReport{

	ResourceBundle settings = ResourceBundle.getBundle("configuration.Settings");
	BufferedWriter bw=null;
	public void generateDetailedReport(List<TestScenario> testSteps, TestSuite suite,Map<String, String> usedData, int c,SummaryReport mtr, int sno){
		
		String testSheetNo=suite.getSecenarioKey();
		StringBuilder sb=new StringBuilder();
		sb.append("<html><head><h1 align='center'><a href='http://www.intellectdesign.com/best-viewed.asp'><img src='D:\\Workspace\\LifeInsuranceCorp\\src\\testreports\\LicLogo.png' alt='Intellect Website' style='width:200px;height:80px;border:0'></a> </h1>");
		sb.append("<html><table align='center' border='2' cellpadding=5><tr style='background-color:#8B008B;color:white;border-color:white'>"
				+ "<th>Test Scenario No </th><td align='center' border: 1px solid #8C1717; padding: 4px;>"+testSheetNo+"</td></th>");
		
		sb.append("<body><table align='center'border='2' cellpadding=5><tr style='background-color:#8B008B;color:white;'><th>Test Steps</th><th>Step Description</th><th>Keyword</th><th>Object ID</th><th>Test Data Column</th><th>Test Data</th><th>Status</th><th>Expected Value<th>Actual Value</th><th>Ref Value</th><th>Data Comparison</th><th>Screen Shot</th></tr>");
		File file=new File(settings.getString("Path")+settings.getString(settings.getString("ENV")+"ReportsPath")+testSheetNo+" [ Set-"+c+" ]Results.html");
		
		int tcount=0;
		int pomNum=1;
		for (TestScenario testStep : testSteps) {
			if(!testStep.getKeyWord().equalsIgnoreCase("wait")&&!testStep.getKeyWord().equalsIgnoreCase("longWait")&&!testStep.getKeyWord().equalsIgnoreCase("minWait")&&!testStep.getKeyWord().equalsIgnoreCase("scroll")&&!testStep.getKeyWord().equalsIgnoreCase("longScroll")&&!testStep.getKeyWord().equalsIgnoreCase("waitForAjaxCallProcess")&&!testStep.getKeyWord().equalsIgnoreCase("waitForAjaxCallLoad")&&!testStep.getKeyWord().equalsIgnoreCase("waitForPageLoad")){
				sb.append("<tr>");
				if((testStep.getTestFlow().equals("")||testStep.getTestFlow()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					sb.append("<td>").append(testStep.getTestFlow()).append("</td>");
				if((testStep.getDescription().equals("")||testStep.getDescription()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					sb.append("<td>").append(testStep.getDescription()).append("</td>");
				if((testStep.getKeyWord().equals("")||testStep.getKeyWord()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					if(!testStep.getKeyWord().contains("POM")){
						sb.append("<td>").append(testStep.getKeyWord()).append("</td>");
					}else if(testStep.getKeyWord().contains("POM") && !testStep.getKeyWord().contains("POM//")){
						//System.out.println("Detailed Report endTime is :: "+endTime);
						sb.append("<td><a href='").append(settings.getString("Path")+settings.getString(settings.getString("ENV")+"POM"+"ReportsPath")).append(testSheetNo).append(""+testStep.getKeyWord()+"[ Set-"+c+" ]"+pomNum+".html'>").append(testStep.getKeyWord()).append("</a></td>");//"+endTime+"
						pomNum++;
					}else if(testStep.getKeyWord().contains("POM//")){
						sb.append("<td>").append(testStep.getKeyWord()).append("</td>");
					}
				if((testStep.getObjectElement().equals("")||testStep.getObjectElement()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					sb.append("<td>").append((testStep.getObjectElement().equals("")||testStep.getObjectElement()==null)?"&nbsp;":testStep.getObjectElement()).append("</td>");
				if((testStep.getDataColumn().equals("")||testStep.getDataColumn()==null))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					sb.append("<td>").append(testStep.getDataColumn()).append("</td>");
				sb.append("<td>").append((usedData.get(testStep.getDataColumn())==null||usedData.get(testStep.getDataColumn()).equals(""))?"&nbsp;":usedData.get(testStep.getDataColumn())).append("</td>");
				if(testStep.getStatus()==null){
					testStep.setStatus("Failed Reason");
					testStep.setFailMessage("Unable to find Element");
				}
				if(testStep.getStatus().equalsIgnoreCase("pass"))
					sb.append("<td style='background-color:green;'>").append(testStep.getStatus()).append("</td>");
				else
					sb.append("<td style='background-color:red;'>").append(testStep.getStatus()).append("  :  ").append(testStep.getFailMessage()).append("</td>");
				//for actual value and expected value
				sb.append("<td>").append((testStep.getExpectedValue()==null)?"&nbsp;":testStep.getExpectedValue()).append("</td>");
				sb.append("<td>").append((testStep.getActualValue()==null)?"&nbsp;":testStep.getActualValue()).append("</td>");
				//need to add extra coloumns
				sb.append("<td>").append((testStep.getApplicationID()==null)?"&nbsp;":testStep.getApplicationID()).append("</td>");
				sb.append("<td>").append((testStep.getValueGotFromControl()==null)?"&nbsp;":testStep.getValueGotFromControl()).append("</td>");

				if(testStep.getScreentShot().equals("N")||testStep.getScreentShot()==null||testStep.getScreentShot().equals(""))
					sb.append("<td>").append(("&nbsp;")).append("</td>");
				else
					//sb.append("<td><a href='").append(testStep.getScreentShot()).append("'>").append("Screen Shot").append("</a></td>");
					sb.append("<td><a href='Screenshots\\").append(testStep.getScreentShot()).append("'>").append("Screen Shot").append("</a></td>");
				sb.append("</tr>");

			}
			tcount++;
			if(testSteps.size()==tcount)
				mtr.generateScenarioReport(suite,testSteps,c,sno);

		}

		FileWriter fw = null;
		BufferedWriter bw=null;
		try {
			fw = new FileWriter(file);
			bw = new BufferedWriter(fw);
			bw.write(sb.toString());
			bw.close();			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
}
