package testreports;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ResourceBundle;

import testframework.TestScenario;
import testframework.TestSuite;

public class SummaryReport {
	ResourceBundle settings = ResourceBundle.getBundle("configuration.Settings");
	FileWriter fw = null;
	BufferedWriter bw=null;
	File file=null;
	public static String scenarioNumber="0"; 

	String statusTable="<table align='center' border='2' cellpadding=7><tr style='background-color:#8B008B;color:white;'>"
			+ "<th>Total Scenarios Executed</th><td id='totalTestCasesCount'>0</td></th>"
			+ "<th>Scenarios Passed </th><td id='totalTestCasePassed'>0</td></th>"
			+ "<th>Scenarios Failed</th><td id='totalTestCaseFailed'>0</td></th>"
			+ "<th>ENV</th><td id='env'>"+settings.getString("ENV")+"</td></th></tr></table>";
	
	public SummaryReport(){
		StringBuffer sb=new StringBuffer();
		sb.append("<html><head><h1 align='left'><a href='http://www.licindia.in'> <img src='D:\\Workspace\\LifeInsuranceCorp\\src\\testreports\\liclogo.png' alt='Lic Website' style='width:220px;height:90px;border:0'></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href='http://www.intellectdesign.com/best-viewed.asp'> <img src='D:\\Workspace\\LifeInsuranceCorp\\src\\testreports\\intellect-logo.png' alt='Intellect Website' style='width:220px;height:90px;border:0'> </a></h1>");
		sb.append("<html><head><u><h2 align='center'><font color='blue'>LIC Automation Summary Report</u> </font></h2>");
		sb.append("<script>");
		sb.append("function executeTestCaseStatus(){");
		sb.append("var failCount=0;");
		sb.append("var passCount=0;");
		sb.append("var TestCaseCount=document.getElementsByTagName('table')[2].getElementsByTagName('tr').length-1;");
		sb.append("document.getElementById('totalTestCasesCount').innerHTML=TestCaseCount;");
		sb.append("for(var s=1;s<TestCaseCount+1;s++){");
		sb.append("if(document.getElementsByTagName('table')[2].getElementsByTagName('tr')[s].getElementsByTagName('td')[3].innerHTML==='Pass')");
		sb.append("passCount++;");
		sb.append("else if(document.getElementsByTagName('table')[2].getElementsByTagName('tr')[s].getElementsByTagName('td')[3].innerHTML==='Fail')");
		sb.append("failCount++;");
		sb.append("}");
		sb.append("document.getElementById('totalTestCaseFailed').innerHTML=failCount;");
		sb.append("document.getElementById('totalTestCasePassed').innerHTML=passCount;");
		sb.append("}");
		sb.append("</script>");
		sb.append("<body onload='executeTestCaseStatus();'>").append("<table align='center'><tr><td>").append(statusTable)
		.append("<table align='center' border='2' id='sortabletable' cellpadding=7><tr style='background-color:#8B008B;color:white;'><th>S.No</th><th>Test Scenario</th><th>Scenario Description</th><th>Status</th><th>Execution Start Time</th><th>Execution End Time</th></tr>");
		try {
			file=new File(settings.getString("Path")+settings.getString(settings.getString("ENV")+"ReportsPath"));
			if(!file.exists()){
				file.mkdir();
			}	        	
			file=new File(settings.getString("Path")+settings.getString(settings.getString("ENV")+"ReportsPath")+"Summary Report.html");
			fw = new FileWriter(file);
			bw = new BufferedWriter(fw);
		} catch (IOException e) {
			e.printStackTrace();
		}			
		sendDataTowriteSummary(sb.toString());
	}
	
	public void generateScenarioReport(TestSuite testSuiteScenario,List<TestScenario> testSteps,int kount, int sno){
		
		StringBuffer sb=new StringBuffer();	
		sb.append("<td align='center' border: 1px solid #8C1717; padding: 4px;>").append(sno).append("</td>");
		sb.append("<td border: 1px solid #8C1717; padding: 4px;>").append(testSuiteScenario.getSecenarioKey()).append("</td>");
		sb.append("<td border: 1px solid #8C1717; padding: 4px;><a href='").append(testSuiteScenario.getSecenarioKey()).append(" [ Set-"+kount+" ]Results.html'>").append(testSuiteScenario.getSenarioDescription()).append("</a></td>");
		if(testSuiteScenario.getStatus().get(kount).equalsIgnoreCase("pass"))
			sb.append("<td style='background-color:green; border: 1px solid #8C1717; padding: 4px;'>").append(testSuiteScenario.getStatus().get(kount)).append("</td>");
		else
			sb.append("<td style='background-color:red; border: 1px solid #8C1717; padding: 4px;'>").append(testSuiteScenario.getStatus().get(kount)).append("</td>");		
		sb.append("<td border: 1px solid #8C1717; padding: 4px;>").append(testSuiteScenario.getExecutionStartTime().get(kount)).append("</td>");
		sb.append("<td border: 1px solid #8C1717; padding: 4px;>").append(testSuiteScenario.getExecutionEndTime().get(kount)).append("</td>");
		sb.append("</tr>");
		sendDataTowriteSummary(sb.toString());				

	}

	public void endHtml() {
		sendDataTowriteSummary("</table></td></tr></table></body></html>");
		try {
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void sendDataTowriteSummary(String sb){
		try {
			bw.write(sb);
			bw.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}
