package readinginputfiles;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;

import testframework.TestScenario;
import testframework.TestSuite;

public class ReadingControllerAndTestDataSheets  implements ReadingControllerAndDataSheet{

	public static int testDatasetCount = 0;
	ResourceBundle settings = ResourceBundle.getBundle("configuration.Settings");
	String controllerSheetPath=settings.getString(settings.getString("ENV")+"ControllerSheetPath");
	File controllerFile = new File(settings.getString("Path")+controllerSheetPath);
	String pomSheetPath=settings.getString(settings.getString("ENV")+"POMSheetPath");
	File pomfile = new File(settings.getString("Path")+pomSheetPath);
	String testDataSheetPath=settings.getString(settings.getString("ENV")+"TestDataSheetPath");
	File testDataFile = new File(settings.getString("Path")+testDataSheetPath);

	public List<TestSuite> readingSuite(){
		Sheet suiteSheet = null;		
		try {
			suiteSheet = SpreadSheet.createFromFile(controllerFile).getSheet(settings.getString("SuiteSheetName"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		List<TestSuite> suiteList=new LinkedList<TestSuite>();
		TestSuite suite=null;         
		for(int rowNum = 1; rowNum < suiteSheet.getRowCount(); rowNum++){
			suite=new TestSuite();
			suite.setSecenarioKey(suiteSheet.getCellAt(0, rowNum).getTextValue());
			suite.setSenarioDescription(suiteSheet.getCellAt(1, rowNum).getTextValue());
			suite.setRunMode(suiteSheet.getCellAt(2, rowNum).getTextValue());
			suiteList.add(suite);
		}
		return suiteList;
	}

	public  Map<String,List<TestScenario>> readingControllerSheet(){

		Map<String,List<TestScenario>> keyController=null;
		List<TestSuite> suiteList= readingSuite();
		try {
			keyController=new LinkedHashMap<String,List<TestScenario>>();
			for(TestSuite suite:suiteList){
				if(suite.getRunMode().equalsIgnoreCase("Y") && !suite.getSecenarioKey().equals("")){
					Sheet keySheet=SpreadSheet.createFromFile(controllerFile).getSheet(suite.getSecenarioKey());
					List<TestScenario> testScenarioList=new LinkedList<TestScenario>();
					TestScenario testScenario=null;
					for(int rowNum = 1; rowNum <keySheet.getRowCount(); rowNum++){
						testScenario=new TestScenario();
						testScenario.setTestFlow(keySheet.getCellAt(0, rowNum).getTextValue());
						testScenario.setDescription(keySheet.getCellAt(1, rowNum).getTextValue());
						testScenario.setKeyWord(keySheet.getCellAt(2, rowNum).getTextValue());
						testScenario.setObjectElement(keySheet.getCellAt(3, rowNum).getTextValue());
						testScenario.setDataColumn(keySheet.getCellAt(4, rowNum).getTextValue());
						testScenario.setScreentShot(keySheet.getCellAt(5, rowNum).getTextValue());
						if(keySheet.getCellAt(2, rowNum).getTextValue().contains("_POM") && !keySheet.getCellAt(2, rowNum).getTextValue().contains("_POM//")){
							Sheet pomSheet = null ;
							String pomSheetName=keySheet.getCellAt(2, rowNum).getTextValue();
							try {
								pomSheet = SpreadSheet.createFromFile(pomfile).getSheet(pomSheetName);
							} catch (IOException e) {
								e.printStackTrace();
							}
							List<TestScenario> pomList=new LinkedList<TestScenario>();
							TestScenario testPomScenario=null;        
							for(int i = 1; i < pomSheet.getRowCount(); i++){
								testPomScenario=new TestScenario();
								testPomScenario.setTestFlow(pomSheet.getCellAt(0, i).getTextValue());
								testPomScenario.setDescription(pomSheet.getCellAt(1, i).getTextValue());
								testPomScenario.setKeyWord(pomSheet.getCellAt(2, i).getTextValue());
								testPomScenario.setObjectElement(pomSheet.getCellAt(3, i).getTextValue());
								testPomScenario.setDataColumn(pomSheet.getCellAt(4, i).getTextValue());
								testPomScenario.setScreentShot(pomSheet.getCellAt(5, i).getTextValue());
								pomList.add(testPomScenario);
								testScenario.setPomList(pomList);
							}

						}
						testScenarioList.add(testScenario);
					}
					keyController.put(suite.getSecenarioKey(), testScenarioList);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 	keyController;
	}

	public Map<String,List<Map<String,String>>> readingTestDataSheet(){

		Map<String,List<TestScenario>> keySht=readingControllerSheet();
		Map<String,List<Map<String,String>>> testSheetDataMap=new LinkedHashMap<String,List<Map<String,String>>>();
		List<Map<String,String>> testSheetData=null;
		Map<String,String> testDataSheet=null;		
		Sheet dataSheet = null;
		List<String> dataSheetColField=null;
		String testDataScenarioNo=null;		

		try {
			dataSheet = SpreadSheet.createFromFile(testDataFile).getSheet(settings.getString("dataSheetName"));
			for(int rowNum = 0; rowNum <dataSheet.getRowCount(); rowNum++){
				if(dataSheet.getCellAt(0, rowNum).getTextValue()!=null){
					if(dataSheet.getCellAt(0, rowNum).getTextValue().equalsIgnoreCase("Test Scenario No:")){
						testDataScenarioNo=dataSheet.getCellAt(1, rowNum).getTextValue();
					}else if(dataSheet.getCellAt(1, rowNum).getTextValue().equalsIgnoreCase("Field Names")){
						dataSheetColField=new LinkedList<String>();
						for(int col=2; col<dataSheet.getColumnCount(); col++){
							dataSheetColField.add(dataSheet.getCellAt(col, rowNum).getTextValue());
						}
						testSheetData=new LinkedList<Map<String,String>>();
					}else if(dataSheet.getCellAt(1, rowNum).getTextValue().contains("Test Data Set")){
						List<TestScenario> testScenario=keySht.get(testDataScenarioNo);
						testDataSheet=new LinkedHashMap<String,String>();
						if(testScenario!=null){						
							if(dataSheet.getCellAt(0, rowNum).getTextValue().equalsIgnoreCase("Y")){
								for(int i=0; i<testScenario.size(); i++){
									TestScenario testField=testScenario.get(i);
									if(testField != null && (testField.getPomList() != null) && (testField.getPomList().size() != 0)){
										for( int i1=1; i1<testField.getPomList().size(); i1++){
											TestScenario testField1=testField.getPomList().get(i1);
											if(testField.getKeyWord().contains("POM") && !testField.getKeyWord().contains("POM//")){
												if(testField1.getDataColumn()!= null && !testField1.getDataColumn().equals("")){
													for(int dt=0; dt<dataSheetColField.size(); dt++){
														if(testField1.getDataColumn().equalsIgnoreCase(dataSheetColField.get(dt))){
															testDataSheet.put(testField1.getDataColumn(),dataSheet.getCellAt(dt+2, rowNum).getTextValue());
															break;

														}
													}
												}
											}
										}
									}
									else if(!testField.getKeyWord().contains("POM") && !testField.getKeyWord().contains("POM//") ){
										for(int dt=0; dt<dataSheetColField.size(); dt++){
											if(testField.getDataColumn().equalsIgnoreCase(dataSheetColField.get(dt))){
												testDataSheet.put(testField.getDataColumn(),dataSheet.getCellAt(dt+2, rowNum).getTextValue());
												break;
											}
										}
									}
								}
								testDatasetCount++;
								testSheetData.add(testDataSheet);
							}
						}
					}
					if(testSheetData!=null && dataSheet.getCellAt(0, rowNum).getTextValue().equals("") && dataSheet.getCellAt(1, rowNum).getTextValue().equals("")){
						testSheetDataMap.put(testDataScenarioNo, testSheetData);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return testSheetDataMap; 
	}

}
