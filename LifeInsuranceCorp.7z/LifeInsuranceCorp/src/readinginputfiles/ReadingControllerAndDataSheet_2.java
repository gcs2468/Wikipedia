/**
 * 
 */
package readinginputfiles;

import java.util.List;
import java.util.Map;
import testframework.TestScenario;
import testframework.TestSuite;
/**
 * @author ISHAQ
 *
 */
public interface ReadingControllerAndDataSheet {

	public List<testframework.TestSuite> readingSuite();
	public  Map<String,List<TestScenario>> readingControllerSheet();
	public Map<String,List<Map<String,String>>> readingTestDataSheet();
	
}
