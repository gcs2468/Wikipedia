

package com.relevantcodes.extentreports;


public enum DisplayOrder {
    NEWEST_FIRST,
    OLDEST_FIRST
}
