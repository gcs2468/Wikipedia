

package com.relevantcodes.extentreports.model;

public class ScreenCapture extends Media {   
    public ScreenCapture() { }
}
