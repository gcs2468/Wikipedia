

package com.relevantcodes.extentreports.model;

public class Author extends TestAttribute {
    public Author(String name) {
        super(name.trim());
    }
}
