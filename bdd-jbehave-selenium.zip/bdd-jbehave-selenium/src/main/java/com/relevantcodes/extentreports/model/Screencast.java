

package com.relevantcodes.extentreports.model;

public class Screencast extends Media {
    public Screencast() { }
}
