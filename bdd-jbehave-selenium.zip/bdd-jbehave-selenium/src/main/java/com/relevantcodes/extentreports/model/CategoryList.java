

package com.relevantcodes.extentreports.model;

import java.util.ArrayList;

public class CategoryList {
    public ArrayList<String> categories;
    
    public CategoryList() {
        categories = new ArrayList<String>();
    }
}
