

package com.relevantcodes.extentreports.model;

import java.util.Date;

import com.relevantcodes.extentreports.LogStatus;

public class Log {
    public Date timestamp;
    public LogStatus logStatus;
    public String stepName;
    public String details;
}
