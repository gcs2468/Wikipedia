

package com.relevantcodes.extentreports.model;

public class Category extends TestAttribute {
    public Category(String name) {
        super(name.trim());
    }
}
