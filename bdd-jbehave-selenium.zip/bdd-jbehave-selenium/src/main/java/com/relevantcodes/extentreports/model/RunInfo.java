

package com.relevantcodes.extentreports.model;

public class RunInfo {
    public String startedAt;
    public String endedAt;
    
    public RunInfo() { } 
}
