

package com.relevantcodes.extentreports.model;

import java.util.HashMap;
import java.util.Map;

public class SystemProperties {
    public Map<String, String> info;

    public SystemProperties() {
        info = new HashMap<String, String>();        
    }
}
