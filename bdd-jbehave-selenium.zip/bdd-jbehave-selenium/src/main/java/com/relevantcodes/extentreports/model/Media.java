package com.relevantcodes.extentreports.model;

public abstract class Media {
	public String src;
    public String testName;
}
