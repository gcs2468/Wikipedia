package starter.pageobjects;

import org.openqa.selenium.By;

/**
 * @author Gomasa Chandra Shekhar on 4/26/2019
 * @project serenity-cucumber-starter
 */

public class PageObjects {

    public static By SEARCH_FIELD = By.cssSelector(".js-testpages-input");
    public static By SEARCH_BUTTON = By.cssSelector(".js-testpages-button");

    public static By RESULT_TITLES = By.cssSelector("#links .result__title");

    public static By userId = By.xpath("//input[@name='userName']");

    public static By password = By.xpath("//input[@name='password']");

    public static By loginButton = By.xpath("//input[@name='login']");

    public static By logoutButton = By.xpath("//a[text()='SIGN-OFF']");

    public static By fLogo = By.xpath("//img[@class='_1e_EAo']");

    public static By closeLoginAlert = By.xpath("//button[@class='_2AkmmA _29YdH8']");

}
