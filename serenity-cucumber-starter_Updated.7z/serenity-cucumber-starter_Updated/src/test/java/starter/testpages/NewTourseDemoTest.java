package starter.testpages;

import net.serenitybdd.core.steps.UIInteractionSteps;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.annotations.Step;
import starter.pageobjects.PageObjects;

/**
 * @author Gomasa Chandra Shekhar on 4/26/2019
 * @project serenity-cucumber-starter
 */


@DefaultUrl("http://newtours.demoaut.com/")
public class NewTourseDemoTest extends UIInteractionSteps {

    @Step("enter UserName and Password in new tourse demo appln")
    public void enterUserNamePassword(String uName, String pswd) {

        $(PageObjects.userId).clear();
        $(PageObjects.userId).type(uName);
        $(PageObjects.password).clear();
        $(PageObjects.password).type(pswd);

    }

    @Step("CLick on login button")
    public void clickOnLogin() {
        $(PageObjects.loginButton).click();
    }

    @Step("Close login alert")
    public void clickOnLoginClose() {
        $(PageObjects.closeLoginAlert).click();
    }

    @Step("VerifySignOffLinkDisplayed")
    public boolean VerifySignOffLinkDisplayed() {
        return $(PageObjects.logoutButton).isDisplayed();
    }

    @Step("VerifyLogoDisplayed")
    public boolean VerifyLogoDisplayed() {
        return $(PageObjects.fLogo).isDisplayed();
    }


}
