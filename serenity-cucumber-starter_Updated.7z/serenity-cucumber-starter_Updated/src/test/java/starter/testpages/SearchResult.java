package starter.testpages;

import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.steps.UIInteractionSteps;
import starter.pageobjects.PageObjects;

import java.util.List;
import java.util.stream.Collectors;

public class SearchResult extends UIInteractionSteps {

    public List<String> titles() {
        return findAll(PageObjects.RESULT_TITLES)
                .stream()
                .map(WebElementFacade::getTextContent)
                .collect(Collectors.toList());
    }
}
