package starter.testpages;

import net.serenitybdd.core.steps.UIInteractionSteps;
import net.thucydides.core.annotations.Step;
import starter.pageobjects.PageObjects;

public class SearchFor extends UIInteractionSteps {

    @Step("Search for term {0}")
    public void term(String term) {
        $(PageObjects.SEARCH_FIELD).clear();
        $(PageObjects.SEARCH_FIELD).type(term);
        $(PageObjects.SEARCH_BUTTON).click();
    }
}
