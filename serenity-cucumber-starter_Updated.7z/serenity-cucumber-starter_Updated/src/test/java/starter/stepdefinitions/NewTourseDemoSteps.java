package starter.stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.homepages.NavigateTo;

/**
 * @author Gomasa Chandra Shekhar on 4/26/2019
 * @project serenity-cucumber-starter
 */

public class NewTourseDemoSteps {

    @Steps
    NavigateTo navigateTo;

    @Given("^I am at home page of the application$")
    public void iAmAtHomePageOfTheApplication() {
        navigateTo.theNewTourseDemoPage();
    }

    @And("^I click on close button$")
    public void iClickOnCloseButton() {
        navigateTo.clickOnLoginClose();
    }

    @Then("^I should see the logo$")
    public void iShouldSeeTheLogo() {
        navigateTo.VerifyLogoDisplayed();
    }

    @And("^I enter \"([^\"]*)\" and \"([^\"]*)\"$")
    public void iEnterAnd(String userName, String password) {
        navigateTo.enterUserNamePassword(userName, password);
    }

    @When("^I click on Login button$")
    public void iClickOnLoginButton() {
        navigateTo.clickOnLogin();
    }

    @Then("^I should see SignOff link$")
    public void iShouldSeeSignOffLink() {
        navigateTo.VerifySignOffLinkDisplayed();
    }




}
