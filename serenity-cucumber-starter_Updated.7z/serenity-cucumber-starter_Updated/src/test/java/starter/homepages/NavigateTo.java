package starter.homepages;

import net.serenitybdd.core.steps.UIInteractionSteps;
import net.thucydides.core.annotations.Step;
import starter.pageobjects.PageObjects;

public class NavigateTo extends UIInteractionSteps {

    DuckDuckGoHomePage duckDuckGoHomePage;

    NewTourseDemoPage newTourseDemoPage;

    @Step("Open the DuckDuckGo home page")
    public void theDuckDuckGoHomePage() {
        duckDuckGoHomePage.open();
    }

    @Step("Open the new toure emo home page")
    public void theNewTourseDemoPage() {
        newTourseDemoPage.open();
    }

    @Step("enter UserName and Password in new tourse demo appln")
    public void enterUserNamePassword(String uName, String pswd) {

        $(PageObjects.userId).clear();
        $(PageObjects.userId).type(uName);
        $(PageObjects.password).clear();
        $(PageObjects.password).type(pswd);

    }

    @Step("CLick on login button")
    public void clickOnLogin() {
        $(PageObjects.loginButton).click();
    }

    @Step("Close login alert")
    public void clickOnLoginClose() {
        $(PageObjects.closeLoginAlert).click();
    }

    @Step("VerifySignOffLinkDisplayed")
    public boolean VerifySignOffLinkDisplayed() {
        return $(PageObjects.logoutButton).isDisplayed();
    }

    @Step("VerifyLogoDisplayed")
    public boolean VerifyLogoDisplayed() {
        return $(PageObjects.fLogo).isDisplayed();
    }



}
