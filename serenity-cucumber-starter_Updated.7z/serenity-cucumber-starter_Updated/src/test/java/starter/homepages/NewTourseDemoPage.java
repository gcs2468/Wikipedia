package starter.homepages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

/**
 * @author Gomasa Chandra Shekhar on 4/26/2019
 * @project serenity-cucumber-starter
 */


@DefaultUrl("http://newtours.demoaut.com/")
public class NewTourseDemoPage extends PageObject {


}
