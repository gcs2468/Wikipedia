To execute the Build provide the below Maven Goal:
mvn clean verify serenity:aggregate

To execute Tagged tests, provide the goal as shown in the below format

mvn clean install -Denvironment=prod -Dtestingmode=UI -Dcucumber.options="--tags @SMOKE"


mvn clean install -Dcucumber.options="--tags @SMOKE"