package com.airtel.api.helper;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by B0097352 on 18/08/2017.
 */
public class Excel {

    private Map<Integer, ExcelRow> excelRowMap;

    public Excel(Object[][] rows) {
        this.excelRowMap= new HashMap<>();
        populateMap(rows);
    }

    private void populateMap(Object[][] rows) {

        for (int i = 0; i < rows.length; i++) {
            Object[] rowObj = rows[i];

            ExcelRow excelRow = new ExcelRow(rowObj);

            if (excelRow != null) {
                excelRowMap.put(i, excelRow);
            }
        }
    }

    public ExcelRow getRow(Integer row) {
        return this.excelRowMap.get(row);
    }
}
