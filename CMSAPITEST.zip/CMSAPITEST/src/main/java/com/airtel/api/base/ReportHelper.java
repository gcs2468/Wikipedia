package com.airtel.api.base;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.testng.IRetryAnalyzer;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.io.*;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;


public class ReportHelper extends MyAirtelBase   {

    static int count = 0;
    static int passCount = 0;
    static int failCount = 0;
    static String newDate = null;
    public static String scenario = "";
    static int x;

    private static String resultFolderpath;





    public String getResultFolderpath() {
        return resultFolderpath;
    }

    public void setResultFolderpath(String resultFolderpath) {
        ReportHelper.resultFolderpath = resultFolderpath;
    }

    private static String suiteFileStringPath;
    private static String resultFileStringPath;

    public String getResultFileStringPath() {
        return resultFileStringPath;
    }

    public void setResultFileStringPath(String resultFileStringPath) {
        ReportHelper.resultFileStringPath = resultFileStringPath;
    }

    @BeforeSuite(alwaysRun = true)
    public void beforeSuite() throws IOException {
        //Create object for Report with filepath
        String timestamp = getDate("dd-MM-yyyy hh-mm-ss");
        report = new ExtentReports("./test-output/ExtentReports/TestReport_" + timestamp + ".html", true);
        report.loadConfig(new File(System.getProperty("user.dir") + "//extent-config.xml"));
        String file_name = null;
        String env_name = System.getProperty("ENVIRONMENT", "preprod");
        System.out.println("Environment is >> " + System.getProperty("ENVIRONMENT"));
        comparitiveTestingRequired = booleanValue("comp", comparitiveTestingRequired);

        properties = new Properties();
        FileInputStream inputStream;
        try {
            if (env_name.equalsIgnoreCase("PROD"))
                file_name = "config/config_prod.properties";
            else if (env_name.equalsIgnoreCase("PREPROD"))
                file_name = "config/config_preprod.properties";
            else file_name = "config/config_test.properties";
            inputStream = new FileInputStream(file_name);
            properties.load(inputStream);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        String resultsFolderPath = "./Results";
        File resultFolder = new File(resultsFolderPath);
        resultFolder.mkdir();

        Date date = new Date();
        SimpleDateFormat oDateFormat = new SimpleDateFormat("ddMMM_hh:mm");
        newDate = oDateFormat.format(date);

        resultFolderpath = resultsFolderPath + "/Result_" + newDate;
        File resultFileFolder = new File(resultFolderpath);
        resultFileFolder.mkdir();

        suiteFileStringPath = resultsFolderPath + "/AirtelTestResult_" + newDate + ".html";
        date = new Date();
        oDateFormat = new SimpleDateFormat("dd/MMM/yyyy hh:mm:s");
        String sRunStartTime = oDateFormat.format(date);
        String sUserReq = System.getenv("ComputerName");
        String sEnvName = System.getProperty("os.name");
        String sReleaseName = "CMS API Automation";
        BufferedWriter resultFile = new BufferedWriter(new FileWriter(suiteFileStringPath, true));
        resultFile.append(
                "<html><HEAD><TITLE>Automation Report</TITLE></HEAD><body><h4 align=\"center\"><FONT COLOR=\"660066\" FACE=\"Arial\"SIZE=5><b>API Automation Test Report</b>");
        resultFile.append("<table cellspacing=1 cellpadding=1   border=1> <tr>");
        resultFile.append("<h4> <FONT COLOR=\"660000\" FACE=\"Arial\" SIZE=4.5> Test Details :</h4>");
        resultFile.append(
                "<td width=150 align=\"left\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2.75><b>Run Start Date Time</b></td>");
        resultFile.append("<td width=150 align=\"left\"><FONT COLOR=\"#385daa\" FACE=\"Arial\" SIZE=2.75><b>"
                + sRunStartTime + "</b></td></tr>");
        resultFile.append(
                "<tr  border=1><td width=150 align=\"left\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2.75><b>User Requested</b></td>");
        resultFile.append("<td width=150 align=\"left\"><FONT COLOR=\"#385daa\" FACE=\"Arial\" SIZE=2.75><b>" + sUserReq
                + "</b></td></tr>");
        resultFile.append(
                "<tr  border=1><td width=150 align=\"left\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2.75><b>Environment</b></td>");
        resultFile.append("<td width=150 align=\"left\"><FONT COLOR=\"#385daa\" FACE=\"Arial\" SIZE=2.75><b>" + sEnvName
                + "</b></td></tr>");
        resultFile.append(
                "<tr><td  border=1 width=150 align=\"left\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2.75><b>Release</b></td>");
        resultFile.append("<td  border=1 width=150 align=\"left\"><FONT COLOR=\"#385daa\" FACE=\"Arial\" SIZE=2.75><b>"
                + sReleaseName + "</b></td></tr></table>");
        resultFile.append(
                "<h4> <FONT COLOR=\"660000\" FACE=\"Arial\" SIZE=4.5> Detailed Report :</h4><table  border=1 cellspacing=1  cellpadding=1 ><tr>");
        resultFile.append(
                "<td width=150  align=\"center\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2><b>Test Scenario</b></td>");
        resultFile.append(
                "<td width=150 align=\"center\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2><b>Test Scenario File</b></td>");
        resultFile.append(
                "<td width=150 align=\"center\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2><b>Status</b></td>");
        resultFile.close();
        setResultFolderpath(resultFolderpath);
    }

    @AfterSuite(alwaysRun = true)
    public void afterSuite() throws Exception {
        report.flush();
        //report.close();
        System.out.println("API Execution Done !!!");
        BufferedWriter resultFile = new BufferedWriter(new FileWriter(suiteFileStringPath, true));
        resultFile.append("</table>");
        resultFile.append("<h4> <FONT COLOR=\"660000\" FACE=\"Arial\" SIZE=4.5> Summary :</h4>");
        resultFile.append("<table cellspacing=1 cellpadding=1   border=1>");

        resultFile.append(
                "<tr><td width=300  align=\"center\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2><b>Total TestNg Test Executed</td></b>");
        resultFile.append("<td width=150 align=\"center\"><FONT COLOR=\"#385daa\" FACE=\"Arial\" SIZE=2.75><b>"
                + String.valueOf(passCount + failCount) + "</b></td></tr>");

        resultFile.append(
                "<tr><td width=300  align=\"center\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2><b>Total TestNg Pass Test count</td></b>");
        resultFile.append("<td width=150 align=\"center\"><FONT COLOR=\"#385daa\" FACE=\"Arial\" SIZE=2.75><b>"
                + String.valueOf(passCount) + "</b></td></tr>");

        resultFile.append(
                "<tr><td width=300  align=\"center\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2><b>Total TestNg Fail Test count</td></b>");
        resultFile.append("<td width=150 align=\"center\"><FONT COLOR=\"#385daa\" FACE=\"Arial\" SIZE=2.75><b>"
                + String.valueOf(failCount) + "</b></td></tr>");

        Date date = new Date();
        SimpleDateFormat oDateFormat = new SimpleDateFormat("dd/MMM/yyyy hh:mm:s");
        String sRunEndTime = oDateFormat.format(date);
        resultFile.append(
                "<tr><td width=150 align=\"center\" bgcolor=\"#e63d00\"><FONT COLOR=\"#E0E0E0\" FACE=\"Arial\" SIZE=2.75><b>Run End Date Time</b></td>");
        resultFile.append("<td width=150 align=\"center\"><FONT COLOR=\"#385daa\" FACE=\"Arial\" SIZE=2.75><b>"
                + sRunEndTime + "</b></td></tr>");

        resultFile.append("</table></body></html>");
        resultFile.close();
    }

    public void appendMethodInformationInSuite(String scenarioName, String methodName, String methodFilePath,
                                               String status) throws IOException {
        BufferedWriter resultFile = new BufferedWriter(new FileWriter(suiteFileStringPath, true));
        String statusTag = null;
        if (status.equalsIgnoreCase("Pass")) {
            statusTag = "<td bgcolor='#00FF7F'>";
        } else if (status.equalsIgnoreCase("Fail")) {
            statusTag = "<td bgcolor='#FF4500'>";
        } else {
            statusTag = "<td>";
        }
        resultFile.append("<tr>");
        resultFile.append("<td>" + scenarioName + "</td>");
        resultFile.append("<td><a href='" + methodFilePath + "' />" + methodName + "</td>");
        resultFile.append(statusTag + status + "</td>");
        resultFile.append("</tr>");
        resultFile.close();
    }

    @BeforeMethod(alwaysRun = true)
    public void createinitialHTMLReport(Method method) {

        if (report != null)
            //logger = report.startTest((method.getDeclaringClass().getSimpleName() + " :: " + method.getName()), method.getName());



            try {

                resultFileStringPath = resultFolderpath + "/" + method.getName().toString() + "_"  + ".html";

                BufferedWriter resultFile = new BufferedWriter(new FileWriter(resultFileStringPath, true));
                resultFile.append("<html>");
                resultFile.append("</head>");
                resultFile.append("<body>");
                resultFile.append("<title>API Test Report</title>");

                resultFile.append("<table style=table-layout:fixed; width:40px border = '1'><tr>" + "<th>API URL</th>");
                resultFile.append("<th>Request</th>");
                resultFile.append("<th>Response</th>");

                resultFile.append("<th>Message</th>");
                resultFile.append("<th>Status</th>");
                resultFile.append("<th>Calling Method</th>");
                resultFile.append("<th>Backend Logs</th>");
                resultFile.append("<th>Transaction Logs</th></tr>");
                resultFile.close();
                setResultFileStringPath(resultFileStringPath);
            } catch (Exception e) {
                resultFileStringPath = null;
            }
    }
    @AfterMethod(alwaysRun = true)
    public void appendFinalHTMLReport(ITestResult result) throws IOException {

        if (result.getStatus() == ITestResult.FAILURE) {
            logger.log(LogStatus.FAIL, "Test Failed. REASON :: " + result.getThrowable());
        } else if (result.getStatus() == ITestResult.SKIP) {
            logger.log(LogStatus.SKIP, "Test Case Skipped is " + result.getName());
        } else {logger.log(LogStatus.PASS, "Test Case Passed");}
        // ending test
        //endTest(logger); //: It ends the current test and prepares to create HTML base
        report.endTest(logger);
        ITestNGMethod testNGMethod = result.getMethod();
        int number = testNGMethod.getCurrentInvocationCount();
        String tc = result.getName();
        String status = "Pass";

        if (result.getStatus() == ITestResult.FAILURE) {
            status = "Fail";
            failCount = failCount + 1;
        } else {
            passCount = passCount + 1;
        }
        count = count + 1;
        ++x;
        String resultFilePath = resultFileStringPath.split("/Results")[1];
        resultFilePath = "." + resultFilePath;

        appendMethodInformationInSuite(x+". "+scenario, result.getMethod().getMethodName() + "_" + String.valueOf(number),
                resultFilePath, status);
        BufferedWriter resultFile = new BufferedWriter(new FileWriter(resultFileStringPath, true));

        resultFile.append("</table></body></html>");
        resultFile.close();

    }


    public void appendresultHTMLReport(String resultFileStringPath, String apiURL, String requestFile,
                                       String responseFile, String message, String status, String comment) throws IOException {
        BufferedWriter resultFile = new BufferedWriter(new FileWriter(resultFileStringPath, true));
        String statusTag = null;
        if (status.equalsIgnoreCase("True") || status.equalsIgnoreCase("Pass")) {
            statusTag = "<td bgcolor='#00FF7F'>";
        } else if (status.equalsIgnoreCase("false") || status.equalsIgnoreCase("Fail")) {
            statusTag = "<td bgcolor='#FF4500'>";
        } else {
            statusTag = "<td>";
        }
        resultFile.append("<tr>");

        resultFile.append("<td width=30% style=WORD-break:BREAK-all>" + apiURL + "</td>");
        resultFile.append("<td width=40% style=WORD-break:BREAK-all>" + requestFile + "</td>");
        resultFile.append("<td style=word-wrap: break-word>" + responseFile + "</td>");
        resultFile.append("<td width=70% style=WORD-break:BREAK-all>" + message + "</td>");
        resultFile.append(statusTag + status + "</td>");
        resultFile.append("<td style=word-wrap: break-word>" + comment + "</td>");
        //resultFile.append("<td style=word-wrap: break-word>" + logs + "</td>");
        // resultFile.append("<td style=word-wrap: break-word>" + tLogs + "</td>");
        resultFile.append("</tr>");
        resultFile.close();
    }

    public boolean reporterLogging(Boolean status, String sMessage) {
        ReportHelper reportHelper = new ReportHelper();
        try {
            reportHelper.appendresultHTMLReport(reportHelper.getResultFileStringPath(), "", "", "", sMessage,
                    String.valueOf(status), Thread.currentThread().getStackTrace()[2].getMethodName());
            Reporter.log("<br>");
            if (status) {
                Reporter.log("<Font Color=#008000> PASS </Font>" + sMessage);
            } else {
                Reporter.log("<Font Color=red> FAIL </Font> " + sMessage);
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return status;
    }
}
