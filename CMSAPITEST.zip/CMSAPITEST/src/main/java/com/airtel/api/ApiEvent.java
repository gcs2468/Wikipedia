package com.airtel.api;


public interface ApiEvent {


    String MODULE_CONTROLLER = "/modules";    // get Module api
    String MODULE_NAME_SEARCH = "/modules/{name}";
    String USER_AUTH = "/users/auth";         // post api to login CMS
    String COMPONENT_CONTROLLER ="/components/find-all";  // get Component api
    String COMPONENT = "/components"; // post api to create component
    String COMPONENT_FINDALL = "/components/find-all";    // get api to find all components
    String LAYOUT_CONTROLLER = "/layouts";  // get Layout api
    String WIDGET_CONTROLLER = "/widgets";   // get Widgets api
    String ATTRIBUTE_CONTROLLER = "/attributes"; // get attributes api
    String ATTRIBUTE_BYNAME = "/attributes/{name}";    // getattributeByName
    String Release_CONTROLLER = "/release"; //   get releases api
    String Entities_State_Change = "/entities/state/change";   // change the entity state api
    String MICRO_SERVICES_GET = "/api/microservices/all";
    String MICRO_SERVICE_POST = "/api/microservices";
    String MICRO_SERVICE_NAMES = "/api/microservices/names";
    String MICRO_SERVICE_BYID = "/api/microservices/";







}
