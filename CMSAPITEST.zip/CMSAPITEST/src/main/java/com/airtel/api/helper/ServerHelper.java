package com.airtel.api.helper;

import com.jcraft.jsch.*;
import net.sf.expectit.Expect;
import net.sf.expectit.ExpectBuilder;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.io.*;

import static net.sf.expectit.filter.Filters.removeColors;
import static net.sf.expectit.filter.Filters.removeNonPrintable;
import static net.sf.expectit.matcher.Matchers.contains;
import static net.sf.expectit.matcher.Matchers.regexp;

public class ServerHelper {

    static Session session;
    JSch jsch = new JSch();
    static String timeStamp = "";

    @BeforeSuite
    public void connectSession() throws JSchException {
        session = jsch.getSession("a1ceo75f", "10.5.204.30",22);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setPassword("myairtelapp");
        session.connect();
    }

    /*
    TO DO:- Make only one channel to make multiple commands. -> Abhishek
     */

    public static String portalLogs(String uid, String API) throws JSchException, IOException {

        String threadId = "";
        String command = "less /data/logs/portallog.log | grep " + uid + " | grep " + API + " | grep " + timeStamp;

        System.out.println("Command: " + command);
        Channel channel = session.openChannel("exec");
        ((ChannelExec) channel).setCommand(command);
        channel.setInputStream(null);
        ((ChannelExec) channel).setErrStream(System.err);
        channel.connect();
        InputStream stream = channel.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(stream));
        String line;
        int count = 0;
        String line4 = "";
        while ((line = br.readLine()) != null) {
                System.out.println("Line: " + line);
                line4 = line;
        }
        String arr[] = line4.split("[\\[*\\]]");
        for (String str:arr
             ) {System.out.println(str);
        }
        threadId = arr[1];

        channel.disconnect();

        Channel channel2 = session.openChannel("exec");
        String command2 = "less /data/logs/portallog.log | grep "+ threadId + " \\| " + timeStamp ;
        System.out.println("command2: " + command2);

        ((ChannelExec) channel2).setCommand(command2);
        channel2.setInputStream(null);
        ((ChannelExec) channel2).setErrStream(System.err);
        channel2.connect();
        InputStream inputStream = channel2.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line2;
        String line3 = "";
        while ((line2 = bufferedReader.readLine()) != null) {
            line3 += "\n";
            line3 += line2;
        }
        //TO PRINT ALL THE LOGS, UNCOMMENT THE BELOW LINE
        System.out.println(line3);
        channel2.disconnect();
        return line3;
    }


    public static String analyticsLogs(String uid, String API) throws JSchException, IOException {

        String command = "less /data/logs/portal/analytics/maa_transaction_analytics.log | grep " + uid + " | grep " + API + " | tail -1";

        //String command2 = "grep " +uid+" | grep " +API+ " /data/logs/portal/analytics/maa_transaction_analytics.log";
        System.out.println(command);
        Channel channel = session.openChannel("exec");
        ((ChannelExec) channel).setCommand(command);
        channel.setInputStream(null);
        ((ChannelExec) channel).setErrStream(System.err);
        channel.connect();
        InputStream stream = channel.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(stream));
        String line = "", line2 = "";
        int count = 0;
        while ((line = br.readLine()) != null) {
            line2 = line;
        }
        System.out.println("Analytics Log " +line2);
        String arr[] = line2.split("[,]");

        timeStamp = arr[0];
        System.out.println("TimeStamp = " + timeStamp);
        channel.disconnect();
        return line2;
    }

    //Not used now, to read the entire file. To copy / move resources.
    public static void connectSftpChannel() throws JSchException, SftpException, IOException {
        Channel channel = session.openChannel("sftp");
        channel.connect();
        ChannelSftp sftpChannel = (ChannelSftp) channel;
        InputStream stream = sftpChannel.get("/data/logs/portallog.log");

        BufferedReader br = new BufferedReader(new InputStreamReader(stream));
        String line;
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }
        sftpChannel.exit();
        channel.disconnect();
    }

    @AfterSuite
    public static void closeSession()
    {
        session.disconnect();
    }
}

