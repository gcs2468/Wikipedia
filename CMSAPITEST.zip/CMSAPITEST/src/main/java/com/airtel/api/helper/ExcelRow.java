package com.airtel.api.helper;

/**
 * Created by B0097352 on 18/08/2017.
 */
public class ExcelRow {

    private String description;
    private String name;
    private String author;
    private String category;

    public ExcelRow(Object[] cols) {
        parseData(cols);
    }

    private void parseData(Object[] cols) {
        if (cols.length > 3) {

            this.description = (String) cols[0];
            this.name = (String) cols[1];
            this.author = (String) cols[2];
            this.category = (String) cols[3];


        }
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

}
