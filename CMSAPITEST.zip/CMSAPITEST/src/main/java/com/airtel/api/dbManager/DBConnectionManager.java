package com.airtel.api.dbManager;
import com.airtel.api.base.MyAirtelBase;
import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import org.testng.annotations.Test;
import java.util.*;
import static com.airtel.api.dbManager.MongoManager.db;

public class DBConnectionManager extends MyAirtelBase  {
    @Test
    public static void getMongoDBDatass() throws Exception {

        // get the values from the properties file and stored into variables
        String Collection = MyAirtelBase.setPropFile("CollectionName");


        try {

            //Selecting the collection
            DBCollection coll = db.getCollection(Collection);

            if (db.collectionExists(Collection)) {
                System.out.println("Entering into " + Collection);

                System.out.println(db.getCollectionNames());
                Set CollectionNames = db.getCollectionNames();
                for (Object c : CollectionNames) {
                    System.out.println("Available Collections are :" + c);

                }
                DBObject obj = db.getCollection(Collection).findOne();
                // to get the key names from the document
                System.out.println(obj.keySet());

                // Count the number of Documents
                System.out.println(db.getCollection(Collection).count());
                BasicDBObject allQuery = new BasicDBObject();

                BasicDBObject fields = new BasicDBObject();
                fields.put("id", "serv");
                DBCursor cursor = coll.find(allQuery, fields);
                while (cursor.hasNext()) {
                    System.out.println("module is :"+cursor.next());
                }

               System.out.println("valeus"+coll.find(fields));


                BasicDBObject dbObject = new BasicDBObject();
                dbObject.put("_id", "ALALGS");
                DBObject dbObject1 = coll.findOne(dbObject);
                System.out.println("Document is : "+dbObject1);


            } else {
                System.out.println("No Collection found in the Database");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static DBCollection getCollection(String collection){
        //Selecting the collection
        DBCollection coll = db.getCollection(collection);
        return coll;

    }

    public static DBObject getMongoDBQuery(String collection, String key, String value) {
        //Selecting the collection
        DBCollection coll = db.getCollection(collection);
        BasicDBObject searchQuery = new BasicDBObject();
        searchQuery.put(key, value);
        DBObject dbObject = coll.findOne(searchQuery);
        return dbObject;
    }




    /*
     * Function for get the First Document in the Collection
     */
    private static void selectFirstRecordInCollection(DBCollection collection) {
        DBObject dbObject = collection.findOne();
        System.out.println(dbObject);
    }

    /*
     * Function for get the single field values from all the documetns
     */

    public static void selectAllRecordBySingleFieldName(DBCollection collection) {
        BasicDBObject allQuery = new BasicDBObject();
        BasicDBObject fields = new BasicDBObject();
        fields.put("id", "serv");
        DBCursor cursor = collection.find(allQuery, fields);
        while (cursor.hasNext()) {
            System.out.println(cursor.next());
        }
    }


    /*
     * Function for get the documents where single field matched from all the documents
     */

    private static void selectAllRecordByAllTheFields(DBCollection collection) {
        BasicDBObject allQuery = new BasicDBObject();
        BasicDBObject fields = new BasicDBObject();
        fields.put("last_name", 1);
        DBCursor cursor = collection.find(allQuery, fields);
        while (cursor.hasNext()) {
            System.out.println(cursor.next());
        }
    }


    /*
     * Function for get all the documents from the collection
     */

    private static void printAllDocuments(DBCollection collection) {
        DBCursor cursor = collection.find();
            while (cursor.hasNext()) {
                System.out.println(cursor.next());
            }
    }

    /*
     * Function for insert documents with key values
     */

    private static void insertDocuments(DBCollection collection) {
        BasicDBObject document = new BasicDBObject();
       // document.put();
    }



    /*
     * Function for get the value based on key from the first document
     */

    private static String getValue(DBCollection collection, String key) {

        DBObject obj = collection.findOne();
        return obj.get(key).toString();
    }




    /*
     * Function for get the documents where field matches key with value
     */
    private static void getDocumentswithSameKeyValue(DBCollection collection) {
        // Getting the documents based on a Single key with value
        BasicDBObject searchQuery = new BasicDBObject();
        searchQuery.put("first_name", "prasad");
        DBCursor cursors = collection.find(searchQuery);
        while (cursors.hasNext()) {
            System.out.println(cursors.next());
        }
    }


    /*
     * Function for get the documents with required key with values
     */


    public static void getDocumentswithMuplipleKeyValues(String collection) {
        DBCollection coll = db.getCollection(collection);
        BasicDBObject searchQuerys = new BasicDBObject();
        List<String> list = new ArrayList<String>();
        list.add("prasad");
        list.add("raghu");
        searchQuerys.put("first_name", new BasicDBObject("$in", list));
        DBCursor cursorthr = coll.find(searchQuerys);
        while (cursorthr.hasNext()) {
            System.out.println(cursorthr.next());
        }

    }


    /*
     * Function for creating Collection
     */

    private static DB createCollection(DB db, String DBname, String CollectionName) throws Exception {
        DBCollection collections = db.createCollection(CollectionName, new BasicDBObject());
        System.out.println("Collection is created successfully with the name of " + CollectionName);
        return db;
    }


    @Test(enabled = false)
    private static void getMongoDBData() throws Exception {

        // get the values from the properties file and stored into variables
        String DBname = MyAirtelBase.setPropFile("DBName");
        String Collection = MyAirtelBase.setPropFile("CollectionName");
        String PortNum = MyAirtelBase.setPropFile("MongoPort");
        int MongoPort = Integer.parseInt(PortNum);
        String SysIp = MyAirtelBase.setPropFile("SystemIP");


        try {
            //Connecting to the mongoDB client
            MongoClient mongoClient = new MongoClient(SysIp, MongoPort);

            //Selecting the database
            DB db = mongoClient.getDB(DBname);

            //mongoClient.getDatabase("admin");
            System.out.println("Connected to Database");

            //Selecting the collection
            DBCollection coll = db.getCollection(Collection);

            if (db.collectionExists(Collection)) {
                System.out.println("Entering into " + Collection);

                System.out.println(db.getCollectionNames());
                Set CollectionNames = db.getCollectionNames();
                for (Object c : CollectionNames) {
                    System.out.println("Available Collections are :" + c);

                }
                DBObject obj = db.getCollection(Collection).findOne();
                // to get the key names from the document
                System.out.println(obj.keySet());

                // Count the number of Documents
                System.out.println(db.getCollection(Collection).count());


            } else {
                System.out.println("No Collection found in the Database");
            }
            //Closing the DB Connection
            mongoClient.close();
            System.out.println("Mongo DB Connection is Closed");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

}