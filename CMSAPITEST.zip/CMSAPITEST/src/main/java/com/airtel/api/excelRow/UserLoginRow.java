package com.airtel.api.excelRow;

public class UserLoginRow {


    private String userName;
    private String password;


    // Response
    private String statusCode;
    private String status;
    private String message;
    private String reportName;

    public UserLoginRow(Object[] cols) {
        parseData(cols);
    }


    private void parseData(Object[] cols) {
        if (cols.length > 5) {
            this.userName = (String) cols[0];
            this.password = (String) cols[1];
            this.statusCode = (String) cols[2];
            this.status = (String) cols[3];
            this.message = (String) cols[4];
            this.reportName = (String) cols[5];
        }
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String statusCode) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }
}
