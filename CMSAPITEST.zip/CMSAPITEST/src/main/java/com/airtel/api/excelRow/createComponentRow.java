package com.airtel.api.excelRow;

public class createComponentRow {

    private Double createdby;
    private String creator;
    private String entityState;
    private String layoutone;
    private String layouttwo;
    private String maxandroid;
    private String maxios;
    private String minandroid;
    private String minios;
    private String name;
    private String os1;
    private String os2;





    // Response
    private String statusCode;
    private String status;
    private String message;
    private String reportName;

    public createComponentRow(Object[] cols) {
        parseData(cols);
    }


    private void parseData(Object[] cols) {
        if (cols.length > 15) {
            this.createdby = (double) cols[0];
            this.creator = (String) cols[1];
            this.entityState = (String) cols[2];
            this.layoutone = (String) cols[3];
            this.layouttwo = (String) cols[4];
            this.maxandroid = (String) cols[5];
            this.maxios = (String) cols[6];
            this.minandroid = (String) cols[7];
            this.minios = (String) cols[8];
            this.name = (String) cols[9];
            this.os1 = (String) cols[10];
            this.os2 = (String) cols[11];
            this.statusCode = (String) cols[12];
            this.status = (String) cols[13];
            this.message = (String) cols[14];
            this.reportName = (String) cols[15];

        }
    }



    public Double getCreatedby() {
        return createdby;
    }

    public void setCreatedby(double createdby) {
        this.createdby = createdby;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getEntityState() {
        return entityState;
    }

    public void setEntityState(String entityState) {
        this.entityState = entityState;
    }
    public String getLayoutone() {

        return layoutone;
    }

    public void setLayoutone(String layoutone) {

        this.layoutone = layoutone;
    }

    public String getLayouttwo() {
        return layouttwo;
    }

    public void setLayouttwo(String layouttwo) {
        this.layouttwo = layouttwo;
    }
    public String getMinandroid() {
        return minandroid;
    }

    public void setMinandroid(String minandroid) {
        this.minandroid = minandroid;
    }

    public String getMaxandroid() {
        return maxandroid;
    }

    public void setMaxandroid(String maxandroid) {
        this.maxandroid = maxandroid;
    }
    public String getMaxios() {
        return maxios;
    }

    public void setMaxios(String maxios) {
        this.maxios = maxios;
    }

    public String getMinios() {
        return minios;
    }

    public void setMinios(String minios) {
        this.minios = minios;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOs1() {
        return os1;
    }

    public void setOs1(String os1) {
        this.os1 = os1;
    }

    public String getOs2() {
        return os2;
    }

    public void setOs2(String os2) {
        this.os2 = os2;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

}
