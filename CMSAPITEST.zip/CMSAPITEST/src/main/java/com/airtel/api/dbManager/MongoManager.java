package com.airtel.api.dbManager;


import com.mongodb.DB;
import com.mongodb.MongoClient;

public class MongoManager {

    public static volatile MongoClient mongoClient;
    public static  DB db;

    public static MongoClient getInstance(String serverIp, Integer port) {
        if (mongoClient == null) {
            synchronized (MongoManager.class) {
                if (mongoClient == null) {
                    mongoClient = new MongoClient(serverIp, port);
                    System.out.println("MongoDB Connection Successfully");
                }
            }
        }
        return mongoClient;
    }

    public static DB getDb(String DBName) {
        synchronized (MongoManager.class) {
            DB db = mongoClient.getDB(DBName);
            System.out.println("DB Connecting");
            return db;
            }
    }
}


