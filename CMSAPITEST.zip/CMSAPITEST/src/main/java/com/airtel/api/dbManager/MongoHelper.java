package com.airtel.api.dbManager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.mongodb.*;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.json.JSONObject;


import java.util.ArrayList;
import java.util.List;

import static com.airtel.api.dbManager.MongoManager.mongoClient;

public class MongoHelper {

    public static MongoCollection getCollection(String dataBase, String collection) {
        MongoDatabase mongoDatabase = mongoClient.getDatabase(dataBase);
        return mongoDatabase.getCollection(collection);
    }


    public static BasicDBObject getMongoDBQuery(String key, String value) {
        BasicDBObject searchQuery = new BasicDBObject();
        searchQuery.put(key, value);
        System.out.println(searchQuery.toString());
        return searchQuery;
    }

    public static List<Object> getResultFromMongo(MongoCollection mongoCollection, BasicDBObject searchQuery) {
        FindIterable findIterable = mongoCollection.find(searchQuery);
        MongoCursor mongoCursor = findIterable.iterator();
        List<Object> mongoAsObjectResult = new ArrayList<>();

        if (mongoCursor.hasNext())
            mongoAsObjectResult.add(mongoCursor.next());

        return mongoAsObjectResult;
    }

    public static List<JSONObject> parseMongoDocuments(List<Object> resultFromMongoAsObject) {

        List<JSONObject> jsonObjectListOfMongo = new ArrayList<JSONObject>();
        for (int k = 0; k < resultFromMongoAsObject.size(); k++) {
            JSONObject jsonObject = new JSONObject(convertToJson(resultFromMongoAsObject.get(k)));
            jsonObjectListOfMongo.add(jsonObject);
        }

        return jsonObjectListOfMongo;
    }

    public static String convertToJson(Object obj) {
        Gson gsonConverter = new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();
        String jsonData = gsonConverter.toJson(obj);
        return jsonData;

    }

    /*
     * Function for get the First Document in the Collection
     */
    public static void selectFirstRecordInCollection(DBCollection collection) {
        DBObject dbObject = collection.findOne();
        System.out.println(dbObject);
    }

    /*
     * Function for get all the documents from the collection
     */

    public static void printAllDocuments(DBCollection collection) {
        DBCursor cursor = collection.find();
        while (cursor.hasNext()) {
            System.out.println(cursor.next());
        }

    }

    public static String getEntityDataFromDB(String collectionName, String key, String entityName) {
        DBObject object = DBConnectionManager.getMongoDBQuery(collectionName, key, entityName);
        System.out.println("entity name  is :" + entityName);
        System.out.println("entity object key values are : " + object);
        String entityjson = MongoHelper.convertToJson(object);
        return entityjson;
    }
}