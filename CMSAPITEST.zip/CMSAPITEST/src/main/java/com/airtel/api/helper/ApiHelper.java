package com.airtel.api.helper;

import com.airtel.api.base.ReportHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.bind.JAXB;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * This class contains methods for generic functions over the API that includes
 * fetching response for GET/POST Request, marshalling & unmarshalling between
 * object & XML/JSON.
 *
 * @author b0202849
 */
public class ApiHelper {
    private static ReportHelper reporter = new ReportHelper();
    private static FileHelper fileHelper = new FileHelper();

    public static void logRequestResponse(String request, String response, String url, long responseTime) {
        try {
            String requestFilePath = fileHelper.createRequestJsonFile(request, "");
            String responseFilePath = fileHelper.createResponseJsonFile(response, "");
            //String logsFilePath = fileHelper.createResponseJsonFile(logs,"");
            //String tLogsFilePath = fileHelper.createResponseJsonFile(tLogs,"");


            reporter.appendresultHTMLReport(reporter.getResultFileStringPath(), url,
                    "<a href='" + requestFilePath + "'>Request_Post" + "file" + "</a>",
                    "<a href='" + responseFilePath + "'>Response_Post" + "file" + "</a>",
                    "Response Time(in msec) :- " + String.valueOf(responseTime), "", "");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Set<String> getAllProperty(String filePath) {
        try {
            Properties prop = new Properties();
            InputStream inpStream = null;
            inpStream = new FileInputStream(filePath);
            prop.load(inpStream);
            return prop.stringPropertyNames();
        } catch (IOException e) {
            Reporter.log("Filepath mentioned is not correct and method breaks with exception " + e);
            return null;
        }
    }
}

