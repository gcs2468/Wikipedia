package com.airtel.api.excelRow;

public class createLayoutRow {

    private Double createdby;
    private String creator;
    private String entityState;
    private String name;
    private String maxandroid;
    private String maxios;
    private String minandroid;
    private String minios;
    private String os1;
    private String os2;





    // Response
    private String statusCode;
    private String status;
    private String message;
    private String reportName;

    public createLayoutRow(Object[] cols) {
        parseData(cols);
    }


    private void parseData(Object[] cols) {
        if (cols.length > 13) {
            this.createdby = (double) cols[0];
            this.creator = (String) cols[1];
            this.entityState = (String) cols[2];
            this.name = (String) cols[3];
            this.maxandroid = (String) cols[4];
            this.maxios = (String) cols[5];
            this.minandroid = (String) cols[6];
            this.minios = (String) cols[7];
            this.os1 = (String) cols[8];
            this.os2 = (String) cols[9];
            this.statusCode = (String) cols[10];
            this.status = (String) cols[11];
            this.message = (String) cols[12];
            this.reportName = (String) cols[13];

        }
    }



    public double getCreatedby() {

        return createdby;
    }

    public void setCreatedby(double createdby) {
        this.createdby = createdby;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getEntityState() {
        return entityState;
    }

    public void setEntityState(String entityState) {
        this.entityState = entityState;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMaxandroid() {
        return maxandroid;
    }

    public void setMaxandroid(String maxandroid) {
        this.maxandroid = maxandroid;
    }

    public String getMinandroid() {
        return minandroid;
    }

    public void setMinandroid(String minandroid) {
        this.minandroid = minandroid;
    }

    public String getMaxios() {
        return maxios;
    }

    public void setMaxios(String maxios) {
        this.maxios = maxios;
    }

    public String getMinios() {
        return minios;
    }

    public void setMinios(String minios) {
        this.minios = minios;
    }

    public String getOs1() {
        return os1;
    }

    public void setOs1(String os1) {
        this.os1 = os1;
    }

    public String getOs2() {
        return os2;
    }

    public void setOs2(String os2) {
        this.os2 = os2;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

}
