package com.airtel.api;

import com.airtel.api.helper.Excel;
import com.airtel.api.base.MyAirtelBase;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Iterator;

public class ReusableMethods {

    /*
   /this function for getting two dimensional data from excel
   */
    @DataProvider(name = "ExcelDataProvider")
    public static Object[][] getDataFromDataProvider(Method method) {

        String packageName = method.getDeclaringClass().getPackage().getName();


        System.out.println("packageName>>>>"+packageName);

        packageName = packageName.split("RestAssured.")[1];

        packageName=packageName.replace(".","/");

        String pathName = "src" + File.separator + "test" + File.separator + "resources" +  File.separator +"test_data" + File.separator + packageName + File.separator
                + method.getName() + ".xlsx";

        System.out.println("packageName  >>>>>" + packageName + " pathName   >>>>>>>" + pathName);

        Object[][] testDataObject = getDataFromExcel(pathName);

        return testDataObject;
    }

   public static Excel getExcelMap(String fileName) {
        String absolutePath = MyAirtelBase.class.getClassLoader().getResource(fileName).getPath();
        Excel excel = null;
        if (StringUtils.isNotBlank(absolutePath)) {
            Object[][] testCases = getDataFromExcel(absolutePath);
            excel = new Excel(testCases);
        } else {
            System.out.println("Irrelevant Path");
        }
        return excel;
    }


    /*
   /this function for getting row columnn data from excel based on filename as a parameter
   */
    public static Object[][] getDataFromExcel(String fileName) {
        File file = new File(fileName);

        Object[][] testDataObject = null;

        try {
            FileInputStream fileInputStream = new FileInputStream(file);

            XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
            XSSFSheet datatypeSheet = workbook.getSheetAt(0);

            int startRow = 1;
            int startCol = 0;

            int ci=0,cj=0;

            Iterator<Row> rowIterator= datatypeSheet.iterator();

            int totalRows = datatypeSheet.getLastRowNum();
            int totalcolumns= getTotalColoumnNumberInExcel(rowIterator.next());

            testDataObject = new Object [totalRows][totalcolumns];


            for(startRow=1 ;startRow<=totalRows;startRow++,ci++)
            {  cj=0;
                for(startCol=0 ; startCol<totalcolumns ; startCol++,cj++)
                {

                    Cell cell =datatypeSheet.getRow(startRow).getCell(startCol);
                    if(cell==null)
                    {testDataObject[ci][cj]="";}
                    else {
                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_STRING: {
                                testDataObject[ci][cj] = cell.getStringCellValue().equalsIgnoreCase("null")? null:cell.getStringCellValue();
                                break;
                            }
                            case Cell.CELL_TYPE_NUMERIC: {
                                testDataObject[ci][cj] = cell.getNumericCellValue();
                                break;
                            }
                            case Cell.CELL_TYPE_BOOLEAN: {
                                testDataObject[ci][cj] = cell.getBooleanCellValue();
                                break;
                            }
                            case Cell.CELL_TYPE_BLANK: {
                                testDataObject[ci][cj] = "";
                                break;
                            }
                            default:
                        }
                    }

                }

            }



        } catch (FileNotFoundException e) {
            throw new RuntimeException("File " + fileName + " was not found" + e.getStackTrace().toString());

        } catch (IOException e) {
            throw new RuntimeException("Can't Read Excel " + fileName + e.getStackTrace().toString());
        }
        return testDataObject ;
    }

    /*
   /this function for getting row columnn data from excel based on filename and sheetName as a parameter
   */

    @DataProvider(name = "ExcelData")
    public static Object[][] getDataFromExcel(String fileName, String sheetName) {

       String filePath = MyAirtelBase.class.getClassLoader().getResource(fileName).getPath();
        File file = new File(filePath);

        Object[][] testDataObject = null;

        try {
            FileInputStream fileInputStream = new FileInputStream(file);

            XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
            XSSFSheet dataSheet = workbook.getSheet(sheetName);


            int startRow;
            int startCol;

            int ci=0,cj;

            Iterator<Row> rowIterator= dataSheet.iterator();

            int totalRows = dataSheet.getLastRowNum();
            int totalcolumns= getTotalColoumnNumberInExcel(rowIterator.next());

            testDataObject = new Object [totalRows][totalcolumns];


            for(startRow=1 ;startRow<=totalRows;startRow++,ci++)
            {  cj=0;
                for(startCol=0 ; startCol<totalcolumns ; startCol++,cj++)
                {

                    Cell cell =dataSheet.getRow(startRow).getCell(startCol);
                    if(cell==null)
                    {
                        testDataObject[ci][cj]="";
                    }
                    else {
                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_STRING: {
                                testDataObject[ci][cj] = cell.getStringCellValue().equalsIgnoreCase("null")? null:cell.getStringCellValue();
                                break;
                            }
                            case Cell.CELL_TYPE_NUMERIC: {
                                testDataObject[ci][cj] = cell.getNumericCellValue();
                                break;
                            }
                            case Cell.CELL_TYPE_BOOLEAN: {
                                testDataObject[ci][cj] = cell.getBooleanCellValue();
                                break;
                            }
                            case Cell.CELL_TYPE_BLANK: {
                                testDataObject[ci][cj] = "";
                                break;
                            }
                            default:
                        }
                    }

                }

            }



        } catch (FileNotFoundException e) {
            throw new RuntimeException("File " + fileName + " was not found" + e.getStackTrace().toString());


        } catch (IOException e) {
            throw new RuntimeException("Can't Read Excel " + fileName + e.getStackTrace().toString());
        }
        return testDataObject ;
    }







    public static  int getTotalColoumnNumberInExcel(Row row)
    {
        Iterator<Cell>cellIterator=  row.cellIterator();


        int totalcolumnsInExcel=0;

        while (cellIterator.hasNext())
        {
            cellIterator.next();
            totalcolumnsInExcel++;
        }

        return  totalcolumnsInExcel;
    }




    //public void

    }
