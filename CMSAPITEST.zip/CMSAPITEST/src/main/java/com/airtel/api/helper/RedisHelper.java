package com.airtel.api.helper;
import com.aerospike.client.*;
import com.aerospike.client.policy.ClientPolicy;
import com.aerospike.client.policy.ScanPolicy;
import com.aerospike.client.policy.WritePolicy;
import com.aerospike.client.query.RecordSet;
import com.aerospike.client.query.Statement;
import org.testng.annotations.Test;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.Iterator;
import java.util.Set;

public class RedisHelper {

    private static Jedis redisConnection(String ServerIp, int Port) throws Exception {
        JedisPool pool = null;
        String password = "!gn8t0r_F1r#w$$L";
        pool = new JedisPool(ServerIp,Port);
        Jedis jedis = pool.getResource();
        jedis.auth(password);
        System.out.println("Redis Server Connection Successfully");
        return jedis;
    }

    private static AerospikeClient aeroSpikeConnection(String HostName, int PortNumber) throws Exception {

        Host host = new Host(HostName, PortNumber);
        // intialize clientpolicy
        ClientPolicy clientPolicy = new ClientPolicy();
        AerospikeClient client = new AerospikeClient(clientPolicy, host);
        System.out.println("Aerospike server  Connection Successfully");
        return client;
    }

    @Test(enabled = true)
    private void getRedisData() throws Exception{

        String Serverip = "10.5.204.30";
        String Port = "6379";
        int RedisPort = Integer.parseInt(Port);

        // calling function for creating redis connection
        Jedis jedis = redisConnection(Serverip, RedisPort);
        System.out.println("Server is running: "+jedis.ping());
        Set<String> names = jedis.keys("*");

        Iterator<String> it = names.iterator();
        while (it.hasNext()){
            System.out.println(it.next());
        }
        jedis.close();
        System.out.println("Jedis server conncection is successfully closed");
    }

    @Test(enabled = true)
    public void getAerospikeData() throws Exception{
        String Serverip = "10.5.204.30";
        String Port = "3000";
        String HostName = "127.0.0.1";
        int AeroSpikePort = Integer.parseInt(Port);

        // Initialize policy
        WritePolicy writePolicy = new WritePolicy();

        ScanPolicy policy = new ScanPolicy();

        // calling function for creating aeroSpike DB Connection

        AerospikeClient client = aeroSpikeConnection(Serverip, AeroSpikePort);

        if (client.isConnected()) {

            // Key key = new Key("disk_Dialer", "transaction_summary","beneficiary_id");

            Key key = new Key("test","Test", "marathon");

            //Bin bin = new Bin("mybin" ,30);
            //Bin bin1 = new Bin("testbin", "marathonvlaue");
            // getting all the namespaces names

            String nameSpaces = Info.request(client.getNodes()[0], "namespaces");

            // print all the namesspaces

            System.out.println("List of namespaces are available :"+nameSpaces);

            // getting all the sets names

            String sets = Info.request(client.getNodes()[0], "sets");


            // print all the sets

            System.out.println("List os sets are availabel :"+sets);

            // write a value in to the bin

            // client.put(writePolicy,key,bin,bin1);


            // Record record = client.get(writePolicy,key);
            if (client.exists(writePolicy,key)) {
                Record record1 = client.get(writePolicy, key);
                System.out.println("Available bins along with values are : "+record1);
            }
            else
            {
                System.out.println("Key is not available");
            }

            // to get the all the records
            Statement statement = new Statement();
            statement.setNamespace("test");
            statement.setSetName("Test");

            Record record;

            RecordSet recordSet = client.query(null,statement);

            while (recordSet !=null && recordSet.next()){
                key = recordSet.getKey();
                record = recordSet.getRecord();
                System.out.println("Available Records : " +record);
            }
            client.close();
            System.out.println("Aerospike connection is closed successfully");
        }
        else {
            System.out.println("Aerospike server is not connected");}
    }
}