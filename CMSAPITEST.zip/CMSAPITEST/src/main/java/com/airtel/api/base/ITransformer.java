package com.airtel.api.base;


import org.testng.IAnnotationTransformer;
import org.testng.IRetryAnalyzer;
import org.testng.annotations.ITestAnnotation;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class ITransformer implements IAnnotationTransformer {


    /* Reading thre failed tests while run time  */

    public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod){
        IRetryAnalyzer retry = annotation.getRetryAnalyzer();
            annotation.setRetryAnalyzer(RetryAnalyzer.class);
        }
    }

