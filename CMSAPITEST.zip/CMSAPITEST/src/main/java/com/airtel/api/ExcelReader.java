package com.airtel.api;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutionException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
    public String path;
    public File file;
    FileInputStream fis;
    XSSFWorkbook workbook;
    XSSFSheet sheet;
    XSSFRow row;
    XSSFCell cell;

    /*
   /this function for reading workbook
   */
    public ExcelReader(String path) {
        System.out.println(path);
        this.path = path;
        try {
            file = new File(path);
            fis = new FileInputStream(file);
            workbook = new XSSFWorkbook(fis);
            System.out.println("workbook is :"+workbook);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /*
   /this function for getting cell value based on sheetName, coluNo, rowNo
   */
    public String getCellData(String sheetName, int colNum, int rowNum) {
        try {
            int index = workbook.getSheetIndex(sheetName);
            sheet = workbook.getSheetAt(index);
            //XSSFRow row = sheet.getRow(0);
            row = sheet.getRow(rowNum-1);
            cell = row.getCell(colNum);
            if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
                return cell.getStringCellValue();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }


    /*
   /this function for getting row count
   */
    public int getRowCount(String sheetName) {
        try {
            int index = workbook.getSheetIndex(sheetName);
            if (index == -1) {
                return 0;
            } else {
                sheet = workbook.getSheetAt(index);
                int number = sheet.getLastRowNum() + 1;
                return number;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /*
   /this function for getting column count
   */
    public int getColumnCount(String sheetName) {
        try {
            int index = workbook.getSheetIndex(sheetName);
            if (index == -1) {
                return 0;
            } else {
                sheet = workbook.getSheet(sheetName);
                row = sheet.getRow(0);
                return row.getLastCellNum();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


     /*
    /this function for putting cell data
    */

    public  void putCellData(String filePath,String sheetName,int RowNum, int ColNum, String Value){

        try{
            sheet = workbook.getSheet(sheetName);
            cell = sheet.getRow(RowNum).getCell(ColNum);
            //cell.setCellType(cell.StringCellValue());
            cell.removeCellComment();
            cell.setCellType(Cell.CELL_TYPE_STRING);
                   cell.setCellValue(Value);
            FileOutputStream out = new FileOutputStream(new File(filePath));
            workbook.write(out);
            workbook.close();
            out.close();
            out.flush();
        }catch (Exception e){
            //System.out.println("Error in Putting cell data...");
            e.printStackTrace();
        }
    }


}

