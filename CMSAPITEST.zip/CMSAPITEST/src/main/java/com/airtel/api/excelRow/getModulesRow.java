package com.airtel.api.excelRow;

public class getModulesRow {

    private String os;
    private String minandroid;
    private String maxandroid;
    private String minios;
    private String maxios;
    private String createdby;



    // Response
    private String status;
    private String statusCode;
    private String message;
    private String reportName;

    public getModulesRow(Object[] cols) {

        parseData(cols);
    }


    private void parseData(Object[] cols) {
        if (cols.length > 9) {
            this.os = (String) cols[0];
            this.minandroid = (String) cols[1];
            this.maxandroid = (String) cols[2];
            this.minios = (String) cols[3];
            this.maxios = (String) cols[4];
            this.createdby = (String) cols[5];
            this.status = (String) cols[6];
            this.statusCode = (String) cols[7];
            this.message = (String) cols[8];
            this.reportName = (String) cols[9];
        }
    }

    public String getOs() {

        return os;
    }

    public void setOs(String osversion) {

        this.os = osversion;
    }

    public String getMinandroid() {
        return minandroid;
    }

    public void setMinandroid(String minandroid) {
        this.minandroid = minandroid;
    }

    public String getMaxandroid() {
        return maxandroid;
    }

    public void setMaxandroid(String maxandroid) {
        this.maxandroid = maxandroid;
    }

    public String getMinios() {
        return minios;
    }

    public void setMinios(String minios) {
        this.minios = minios;
    }

    public String getMaxios() {
        return maxios;
    }

    public void setMaxios(String maxios) {
        this.maxios = maxios;
    }

    public String getCreatedby() {
        return createdby;
    }

    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }

    public String getStatus() {
        return status;
    }

    public void setStatusMessage(String status) {
        this.status = status;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getreportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }


}
