package com.airtel.api.excelRow;



public class CreateMicroServiceRow {


    private String devEnv;
    private String devHost;
    private Double devPort;
    private String qaEnv;
    private String qaHost;
    private Double qaPort;
    private String prodEvn;
    private String prodHost;
    private Double prodPort;
    private String msName;






    // Response
    private String statusCode;
    private String status;
    private String message;
    private String reportName;

    public CreateMicroServiceRow(Object[] cols) {
        parseData(cols);
    }


    private void parseData(Object[] cols) {
        if (cols.length > 9) {
            this.devEnv = (String) cols[0];
            this.devHost = (String) cols[1];
            this.devPort =  (Double) cols[2] ;
            this.qaEnv = (String) cols[3];
            this.qaHost = (String) cols[4];
            this.qaPort = (Double) cols[5];
            this.prodEvn = (String) cols[6];
            this.prodHost = (String) cols[7];
            this.prodPort = (Double) cols[8];
            this.msName = (String) cols[9];
            this.statusCode = (String) cols[10];
            this.status = (String) cols[11];
            this.message = (String) cols[12];
            this.reportName = (String) cols[13];

        }
    }



    public String getDevEvn() {

        return devEnv;
    }

    public void setDevEnv(String devEnv) {
        this.devEnv = devEnv;
    }

    public String getDevHost() {
        return devHost;
    }

    public void setDevHost(String devHost) {
        this.devHost = devHost;
    }

    public Double getDevPort() {
        return devPort;
    }

    public void setDevPort(Double devPort) {
        this.devPort = devPort;
    }

    public String getQaEnv() {
        return qaEnv;
    }

    public void setQaEnv(String qaEnv) {
        this.qaEnv = qaEnv;
    }

    public String getQaHost() {
        return qaHost;
    }

    public void setQaHost(String qaHost) {
        this.qaHost = qaHost;
    }

    public Double getQaPort() {
        return qaPort;
    }

    public void setQaPort(Double qaPort) {
        this.qaPort = qaPort;
    }

    public String getProdEvn() {
        return prodEvn;
    }

    public void setProdEvn(String prodEvn) {
        this.prodEvn = prodEvn;
    }

    public String getProdHost() {
        return prodHost;
    }

    public void setProdHost(String prodHost) {
        this.prodHost = prodHost;
    }

    public Double getProdPort() {
        return prodPort;
    }

    public void setProdPort(Double prodPort) {
        this.prodPort = prodPort;
    }

    public String getMsName() {
        return msName;
    }

    public void setMsName(String msName) {
        this.msName = msName;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }


}
