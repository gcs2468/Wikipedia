
package pojo.getModules;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Object {

    @SerializedName("entityState")
    @Expose
    private String entityState;
    @SerializedName("minandroid")
    @Expose
    private String minandroid;
    @SerializedName("maxandroid")
    @Expose
    private java.lang.Object maxandroid;
    @SerializedName("minios")
    @Expose
    private java.lang.Object minios;
    @SerializedName("maxios")
    @Expose
    private java.lang.Object maxios;
    @SerializedName("os")
    @Expose
    private List<String> os = null;
    @SerializedName("createdat")
    @Expose
    private String createdat;
    @SerializedName("updatedat")
    @Expose
    private String updatedat;
    @SerializedName("createdby")
    @Expose
    private String createdby;
    @SerializedName("updatedby")
    @Expose
    private String updatedby;
    @SerializedName("wasProdAtOnce")
    @Expose
    private java.lang.Object wasProdAtOnce;
    @SerializedName("creator")
    @Expose
    private String creator;
    @SerializedName("disabled")
    @Expose
    private java.lang.Object disabled;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("components")
    @Expose
    private List<String> components = null;

    public String getEntityState() {

        return entityState;
    }

    public void setEntityState(String entityState) {

        this.entityState = entityState;
    }

    public java.lang.Object getMinandroid() {
        return minandroid;
    }

    public void setMinandroid(String minandroid) {
        this.minandroid = minandroid;
    }

    public java.lang.Object getMaxandroid() {
        return maxandroid;
    }

    public void setMaxandroid(java.lang.Object maxandroid) {
        this.maxandroid = maxandroid;
    }

    public java.lang.Object getMinios() {
        return minios;
    }

    public void setMinios(java.lang.Object minios) {
        this.minios = minios;
    }

    public java.lang.Object getMaxios() {
        return maxios;
    }

    public void setMaxios(java.lang.Object maxios) {
        this.maxios = maxios;
    }

    public List<String> getOs() {
        return os;
    }

    public void setOs(List<String> os) {
        this.os = os;
    }

    public String getCreatedat() {
        return createdat;
    }

    public void setCreatedat(String createdat) {
        this.createdat = createdat;
    }

    public String getUpdatedat() {
        return updatedat;
    }

    public void setUpdatedat(String updatedat) {
        this.updatedat = updatedat;
    }

    public String getCreatedby() {
        return createdby;
    }

    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }

    public String getUpdatedby() {
        return updatedby;
    }

    public void setUpdatedby(String updatedby) {
        this.updatedby = updatedby;
    }

    public java.lang.Object getWasProdAtOnce() {

        return wasProdAtOnce;
    }

    public void setWasProdAtOnce(java.lang.Object wasProdAtOnce) {
        this.wasProdAtOnce = wasProdAtOnce;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public java.lang.Object getDisabled() {
        return disabled;
    }

    public void setDisabled(java.lang.Object disabled) {
        this.disabled = disabled;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getComponents() {
        return components;
    }

    public void setComponents(List<String> components) {
        this.components = components;
    }

}
