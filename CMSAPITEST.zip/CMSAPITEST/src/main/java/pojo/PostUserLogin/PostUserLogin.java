
package pojo.PostUserLogin;


public class PostUserLogin {

    private String[] role;
    private String name;
    private String email;
    private String token;
    static private PostUserLogin instance;
    private PostUserLogin(){

    }


    public static PostUserLogin getInstance(){
        if(instance==null)
            instance=new PostUserLogin();
        return instance;
    }

    public String[] getRole() {
        return role;
    }

    public void setRole(String[] role) {
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String message) {
        this.name = message;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String statusCode) {
        this.email = statusCode;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "Object{" +
                "role='" + role + '\'' +
                ", name='" + name + '\'' +
                ", email=" + email +
                ", token=" + token +
                '}';
    }


}
