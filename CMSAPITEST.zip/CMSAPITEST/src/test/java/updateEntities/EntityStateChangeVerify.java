package updateEntities;

import com.airtel.api.ApiEvent;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.excelRow.createAttributeRow;
import com.airtel.api.helper.ApiHelper;
import com.google.gson.Gson;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojo.getEntitiesResponse.ResponseObj;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

public class EntityStateChangeVerify extends ReportHelper{

    private static Response JsonResponse;
    private static Response JsonResponse1;
    private String API = ApiEvent.Entities_State_Change;
    private static com.airtel.api.excelRow.createAttributeRow[] createAttributeRows;
    createAttributeRow createAttributeRow;
    private static String responseMessage = "Entity State Updated Successfully !!";
    SoftAssert softAssert = new SoftAssert();


     /*
    /this function for changing the entity state
    */


     public  void entityStateVerify(String entityId, String entityState, String entityType){


         ReportHelper.scenario = entityType+" Entity: state validation \n" +
                 "        -> by changing the  different states and  \n" +
                 "        -> schema validation";


         logger = report.startTest(entityType+" "+entityState+" entitystate verify ");
         JSONObject obj = new JSONObject();
         obj.put("entityId", entityId)
                 .put("entityState", entityState)
                 .put("entityType", entityType);
         JsonResponse = RestAssured.given().headers(setHeaders()).log().all().contentType(ContentType.JSON).body(obj.toString()).post(API);
         JsonResponse.prettyPrint();
         ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
         ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(), ResponseObj.class);
         softAssert.assertEquals(responseObj.getMessage(), responseMessage);
         softAssert.assertEquals(responseObj.getStatus(), "Success");
         softAssert.assertEquals(responseObj.getStatusCode(),"200");
         // verifying the schema validation
         System.out.println("validating schema");
         JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("entityStateVerify.json")));
         logger.log(LogStatus.PASS, "Schema validated");
         softAssert.assertAll();
         report.endTest(logger);


     }



    
}
