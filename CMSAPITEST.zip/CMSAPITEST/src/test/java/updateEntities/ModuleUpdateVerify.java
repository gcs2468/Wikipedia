package updateEntities;

import com.airtel.api.ApiEvent;
import com.airtel.api.base.MyAirtelBase;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.dbManager.MongoHelper;
import com.airtel.api.helper.ApiHelper;
import com.google.gson.Gson;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.airtel.api.excelRow.createModuleRow;
import pojo.getEntitiesResponse.ResponseObj;
import java.util.*;
import static com.airtel.api.ReusableMethods.getDataFromExcel;

public class ModuleUpdateVerify extends ReportHelper {

    static Response JsonResponse;
    String API = ApiEvent.MODULE_CONTROLLER;
    private static createModuleRow[] createModuleRows;
    createModuleRow createModuleRow;


   /*
    /this function for updating a module and verifying in the db and validating schema with valid and invalid data
    */


    public void updateModuleapiValidation(String moduleName) {

        ReportHelper.scenario = "Module Updation Verify : \n" +
                "        -> updating module\n" +
                "        -> by passing valid and invalid data \n" +
                "        -> schema validation & db verification";


        Map<String, String> headers = setHeaders();
        JSONObject obj = new JSONObject();
        logger = report.startTest("updateModuleWithMulParameters");
        Object[][] body = new Object[4][15];
        if (createModuleRows == null) {
            body = getDataFromExcel(("test_data/Entities_Data.xlsx"), "ModuleUpdate");
            createModuleRows = new createModuleRow[body.length];
            for (int i = 0; i < body.length; i++) {
                createModuleRows[i] = new createModuleRow(body[i]);
            }
        }

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < createModuleRows.length; i++) {
            System.out.println("Number of time this API will hit: " + createModuleRows.length);
            createModuleRow = createModuleRows[i];
            String timestamp = getDate("dd-MM-yyyy hh-mm-ss");
            JSONArray comp = new JSONArray();
            comp.put("test");
            obj.put("components", Arrays.asList(createModuleRow.getComponentsone(), createModuleRow.getComponentstwo()))
                    .put("createdby", createModuleRow.getCreatedby())
                    .put("creator", createModuleRow.getCreator())
                    .put("entityState", createModuleRow.getEntityState())
                    .put("maxandroid", createModuleRow.getMaxandroid())
                    .put("maxios", createModuleRow.getMaxios())
                    .put("minandroid", createModuleRow.getMinandroid())
                    .put("minios", createModuleRow.getMinios())
                    .put("name", moduleName)
                    .put("os", Arrays.asList(createModuleRow.getOs1(), createModuleRow.getOs2()));
            logger.log(LogStatus.INFO, createModuleRow.getReportName() + " passed");
            JsonResponse = RestAssured.given().headers(setHeaders()).log().all().contentType(ContentType.JSON).body(obj.toString()).put(API);
            JsonResponse.prettyPrint();
            ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
            ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(),ResponseObj.class);
            System.out.println("Response Object :: "+responseObj);
            // verifying statusCode, status, message.
            String  expcode = createModuleRow.getStatusCode();
            int expStatusCode = Integer.parseInt(expcode);
            softAssert.assertEquals(JsonResponse.getStatusCode(), expStatusCode);
            softAssert.assertEquals(responseObj.getStatus(), createModuleRow.getStatus());
            softAssert.assertEquals(responseObj.getMessage(), createModuleRow.getMessage());
            // calling function for verifying the module exists
            if (createModuleRow.getStatus().equalsIgnoreCase("success")) {
                System.out.println("calling moduleapi validation function");
                //moduleVerifyValidationApi(module, timestamp);
                // calling function for module db validation
                getModuleDataFromDB("module", "_id", moduleName);
            }


            //JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("createEntityResponse.json")));
            logger.log(LogStatus.PASS, "Schema validated");

        }
        softAssert.assertAll();
        //report.endTest(logger);

    }

    // function for verifying the created api through get modulebyname api
/*
    public void moduleVerifyValidationApi(String moduleName, String timestamp) {
        module = moduleName + timestamp;
        JsonResponse1 = given().spec(setParams()).get(API + "/" + module).then().extract().response();
        JsonResponse1.prettyPrint();
        String bodyAsString = JsonResponse1.asString();
        System.out.println("Verifying the module existed or not through modulebyname get api");
        Assert.assertTrue(bodyAsString.contains(moduleName + timestamp));
        extentTest.log(LogStatus.PASS, "Module is verified and existed");
    }*/

    // function for verifying the module values from db

    public void getModuleDataFromDB(String collectionName, String key, String moduleName){
        String entityJson =MongoHelper.getEntityDataFromDB(collectionName, "_id", moduleName);
        System.out.println("the entity json response  is :"+entityJson);
        JsonPath jsonPath = new JsonPath(entityJson);
        List<String> components =jsonPath.getList("components");
        Assert.assertEquals(components.get(0), createModuleRow.getComponentsone());
        Assert.assertEquals(components.get(1), createModuleRow.getComponentstwo());
        logger.log(LogStatus.PASS, "module object components key value validated from db");
        String expState = jsonPath.getString("entityState");
        Assert.assertEquals(expState, createModuleRow.getEntityState());
        logger.log(LogStatus.PASS, "module object entity key value validated from db");
        List<String> os = jsonPath.getList("os");
        Assert.assertEquals(os.get(0), createModuleRow.getOs1());
        Assert.assertEquals(os.get(1), createModuleRow.getOs2());
        logger.log(LogStatus.PASS, "module object os key values validated from db");

    }

}
