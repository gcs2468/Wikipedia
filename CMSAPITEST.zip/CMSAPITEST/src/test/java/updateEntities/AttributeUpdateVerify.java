package updateEntities;

public class AttributeUpdateVerify {
}
