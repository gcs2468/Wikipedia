package updateEntities;

import com.airtel.api.ApiEvent;
import com.airtel.api.base.MyAirtelBase;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.dbManager.DBConnectionManager;
import com.airtel.api.dbManager.MongoHelper;
import com.airtel.api.excelRow.createComponentRow;
import com.airtel.api.excelRow.getComponentsRow;
import com.airtel.api.helper.ApiHelper;
import com.google.gson.Gson;
import com.mongodb.DBObject;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojo.getEntitiesResponse.ResponseObj;
import pojo.getModules.GetModule;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.airtel.api.ReusableMethods.getDataFromExcel;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

public class ComponentUpdateVerify extends ReportHelper {

    static Response JsonResponse;
    static Response JsonResponse1;
    String API = ApiEvent.COMPONENT;
    private static createComponentRow[] createComponentRows;
    createComponentRow createComponentRow;
    String component;



    /*
    /this method for creating a component and verifying in the db and validating schema with valid and invalid data
    */
    @Test
    public void updateComponentapiValidation(String componentName) {

        ReportHelper.scenario = "-> Component Update Verify : \n" +
                "        -> updating components\n" +
                "        -> by passing valid and invalid data \n" +
                "        -> schema validation & db verification";


        Map<String, String> headers = setHeaders();
        JSONObject obj = new JSONObject();
        logger = report.startTest("createComponentWithMulParameters");
        Object[][] body = new Object[4][15];
        if (createComponentRows == null) {
            body = getDataFromExcel(("test_data/Entities_Data.xlsx"), "Component_Data");
            createComponentRows = new createComponentRow[body.length];
            for (int i = 0; i < body.length; i++) {
                createComponentRows[i] = new createComponentRow(body[i]);
            }
        }
        SoftAssert softAssert = new SoftAssert();

        for (int i = 0; i < createComponentRows.length; i++) {
            System.out.println("Number of time this API will hit: " + createComponentRows.length);

            createComponentRow = createComponentRows[i];

            JSONArray comp = new JSONArray();
            comp.put("test");
            obj.put("createdby", createComponentRow.getCreatedby())
                    .put("creator", createComponentRow.getCreator())
                    .put("entityState", createComponentRow.getEntityState())
                    .put("layouts", Arrays.asList(createComponentRow.getLayoutone(), createComponentRow.getLayouttwo()))
                    .put("maxandroid", createComponentRow.getMaxandroid())
                    .put("maxios", createComponentRow.getMaxios())
                    .put("minandroid", createComponentRow.getMinandroid())
                    .put("minios", createComponentRow.getMinios())
                    .put("name", componentName)
                    .put("os", Arrays.asList(createComponentRow.getOs1(), createComponentRow.getOs2()));

            logger.log(LogStatus.INFO, createComponentRow.getReportName() + " passed");
            JsonResponse = RestAssured.given().headers(setHeaders()).log().all().contentType(ContentType.JSON).body(obj.toString()).put(API);
            JsonResponse.prettyPrint();
            ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
            ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(),ResponseObj.class);
            System.out.println("Response Object :: "+responseObj);

            // verifying the status code, status, message.
            String  expcode = createComponentRow.getStatusCode();
            int expStatusCode = Integer.parseInt(expcode);

            softAssert.assertEquals(JsonResponse.getStatusCode(), expStatusCode);

            softAssert.assertEquals(responseObj.getStatus(), createComponentRow.getStatus());

            softAssert.assertEquals(responseObj.getMessage(), createComponentRow.getMessage());

            // calling function for verifying the component exists
            if (createComponentRow.getStatus().equalsIgnoreCase("success")) {
                System.out.println("calling componentapi validation function");
                // calling function for component db validation
                getComponentDataFromDB("component", "_id", componentName);
                System.out.println("validating schema of positive testcases");
                // JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("createComponent.json")));
                logger.log(LogStatus.PASS, "Schema validated");
            }
            if (createComponentRow.getStatus().equalsIgnoreCase("ERROR") || createComponentRow.getStatus().equalsIgnoreCase("failed")) {

                System.out.println("validating schema of native testcases");
               // JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("createEntityResponse.json")));
                logger.log(LogStatus.PASS, "Schema validated");
            }

        }

        softAssert.assertAll();

        //report.endTest(logger);

    }

    // function for verifying the module values from db

    public void getComponentDataFromDB(String collectionName, String key, String componentName){
        String entityJson =MongoHelper.getEntityDataFromDB(collectionName, "_id", componentName);
        System.out.println("the entity json response  is :"+entityJson);
        JsonPath jsonPath = new JsonPath(entityJson);
        List<String> layouts =jsonPath.getList("layouts");
        Assert.assertEquals(layouts.get(0), createComponentRow.getLayoutone());
        Assert.assertEquals(layouts.get(1), createComponentRow.getLayouttwo());
        logger.log(LogStatus.PASS, "component object layout key value validated from db");
        String expState = jsonPath.getString("entityState");
        Assert.assertEquals(expState, createComponentRow.getEntityState());
        logger.log(LogStatus.PASS, "component object  entity key value validated from db");
        List<String> os = jsonPath.getList("os");
        Assert.assertEquals(os.get(0), createComponentRow.getOs1());
        Assert.assertEquals(os.get(1), createComponentRow.getOs2());
        logger.log(LogStatus.PASS, "component object os key values validated from db");


    }

}
