package userController;

import com.airtel.api.ApiEvent;
import com.airtel.api.ExcelReader;
import com.airtel.api.base.MyAirtelBase;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.excelRow.UserLoginRow;
import com.airtel.api.excelRow.getModulesRow;
import com.airtel.api.helper.ApiHelper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojo.getEntitiesResponse.ResponseObj;
import pojo.getModules.GetModule;

import static com.airtel.api.ReusableMethods.getDataFromExcel;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

public class PostUserLogin extends ReportHelper {

    Response JsonResponse;
    ExcelReader reader = null;
    String API = ApiEvent.USER_AUTH;
    private static UserLoginRow[] UserLoginrows;

    /*
    /this function for login to cms and validating schema with valid and invalid data
    */

    @Test
    public void userValidation() {

        ReportHelper.scenario = "CMS Login: validation \n" +
                "        -> login into cms\n" +
                "        -> by passing different valid and invalid credentials \n" +
                "        -> schema validation";

        JSONObject obj = new JSONObject();
        logger = report.startTest("logincmswithmulparamas");
        Object[][] body = new Object[4][6];

        if (UserLoginrows == null) {
            body = getDataFromExcel(("test_data/QueryParameters.xlsx"), "Login_Data");


            UserLoginrows = new UserLoginRow[body.length];
            for (int i = 0; i < body.length; i++) {
                UserLoginrows[i] = new UserLoginRow(body[i]);
            }
        }

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < UserLoginrows.length; i++) {
            System.out.println("Number of time this API will hit: " + UserLoginrows.length);

            UserLoginRow userLoginrow = UserLoginrows[i];
            obj.put("username", userLoginrow.getUserName())
                    .put("password", userLoginrow.getPassword());
            configure("CMS");
            String value = obj.toString();
            JsonResponse = RestAssured.given().contentType(ContentType.JSON).body(value).post(API);
            ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
            JsonResponse.prettyPrint();
            ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(),ResponseObj.class);
            logger.log(LogStatus.INFO, userLoginrow.getReportName() + " passed");
            //softAssert.assertEquals(responseObj.getStatusCode(), userLoginrow.getStatusCode());
            softAssert.assertEquals(responseObj.getStatus(), userLoginrow.getStatus());
            softAssert.assertEquals(responseObj.getMessage(), userLoginrow.getMessage());
            // Verifying schema validation
            System.out.println("Validating schema of user login");
            if(userLoginrow.getStatusCode().equalsIgnoreCase("200")){
                JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("PostUserLogin.json")));
                System.out.println("Checking the response time of login api");
            if (statusChecks(JsonResponse))
                System.out.println("Executing the test case");
            else
                assert (false);

        }
        else {
                JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("invalidPostUserLogin.json")));
            }
            logger.log(LogStatus.PASS, " Schema validated");
        }
        //report.endTest(logger);
    }
}
