package getEntities;


import com.airtel.api.ApiEvent;
import com.airtel.api.ExcelReader;
import com.airtel.api.base.MyAirtelBase;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.helper.ApiHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojo.getEntitiesResponse.ResponseObj;
import pojo.getModules.GetModule;
import com.airtel.api.excelRow.getModulesRow;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.airtel.api.ReusableMethods.getDataFromExcel;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;


public class GetModules extends ReportHelper {
    private static Response JsonResponse;
    ExcelReader reader = null;
    private static String API = ApiEvent.MODULE_CONTROLLER;
    private static getModulesRow[] getModulesRows;

    /*
    /this function for getting modules and verifying in the db and validating schema with valid and invalid data
    */

    @Test
    private void getModulesValidationwithMultipleParams()  {

        ReportHelper.scenario = "Modules: validation \n" +
                "        -> getting all modules\n" +
                "        -> by passing different valid and invalid parameters \n" +
                "        -> schema validation";

        logger = report.startTest("getModulesapiwithMultiParameters");

        Object[][] params = new Object[4][10];
        if (getModulesRows == null) {
            params = getDataFromExcel(("test_data/QueryParameters.xlsx"), "Module_Params");
            getModulesRows = new getModulesRow[params.length];
            for (int i = 0; i < params.length; i++) {
                getModulesRows[i] = new getModulesRow(params[i]);
            }
        }
        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < getModulesRows.length; i++) {
            System.out.println("Number of time this API will hit: " + getModulesRows.length);
            getModulesRow getModulesRow = getModulesRows[i];
            JsonResponse = given().spec(setParams()).
                    queryParam("os",getModulesRow.getOs()).
                    queryParam("minandroid", getModulesRow.getMinandroid()).
                    queryParam("maxandroid", getModulesRow.getMaxandroid()).
                    queryParam("minios", getModulesRow.getMinios()).
                    queryParam("maxios", getModulesRow.getMaxios()).
                    queryParam("createdby", getModulesRow.getCreatedby()).
                    get(API).
                    then().extract().response();
            JsonResponse.prettyPrint();
            ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
            ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(),ResponseObj.class);
            // verifying the statusCode, status, message
            String  expcode = getModulesRow.getStatusCode();
            int expStatusCode = Integer.parseInt(expcode);
            softAssert.assertEquals(JsonResponse.getStatusCode(), expStatusCode, "satusCode is not matched");
            softAssert.assertEquals(responseObj.getStatus(),getModulesRow.getStatus());
            softAssert.assertEquals(responseObj.getMessage(), getModulesRow.getMessage());
            logger.log(LogStatus.INFO, getModulesRow.getreportName()+" passed");
            if(getModulesRow.getStatus().equalsIgnoreCase("ERROR")) {
                System.out.println("validating schema of native test case");
                JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("GetEntityErrorParams.json")));
                logger.log(LogStatus.PASS, "schema validated of native testcase params");
            }
            else{
                System.out.println("validating schema of positive test case");
                JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("GetModules.json")));
                logger.log(LogStatus.PASS, "schema validated of positive testcase params");
            }
        }

        softAssert.assertAll();
        //report.endTest(extentTest);
    }

    }



