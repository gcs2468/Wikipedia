package getEntities;

import com.airtel.api.ApiEvent;
import com.airtel.api.ExcelReader;
import com.airtel.api.base.MyAirtelBase;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.excelRow.getWidgetsRow;
import com.airtel.api.helper.ApiHelper;
import com.google.gson.Gson;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojo.getEntitiesResponse.ResponseObj;

import java.util.Map;

import static com.airtel.api.ReusableMethods.getDataFromExcel;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

public class GetWidgets extends ReportHelper {

    private static Response JsonResponse;
    ExcelReader reader = null;
    private static String API = ApiEvent.WIDGET_CONTROLLER;
    private static getWidgetsRow[] getWidgetsRows;

   /*
    /this function for getting widgets and verifying in the db and validating schema with valid and invalid data
    */

    @Test
    private void getWidgetsValidationwithMultipleParams()  {

        ReportHelper.scenario = "Widgets: validation \n" +
                "        -> getting all widgets\n" +
                "        -> by passing different valid and invalid parameters \n" +
                "        -> schema validation";

        logger = report.startTest("getWidgetsapiwithMultiParameters");

        Object[][] params = new Object[4][10];
        if (getWidgetsRows == null) {
            params = getDataFromExcel(("test_data/QueryParameters.xlsx"), "Widget_Params");
            getWidgetsRows = new getWidgetsRow[params.length];
            for (int i = 0; i < params.length; i++) {
                getWidgetsRows[i] = new getWidgetsRow(params[i]);
            }
        }
        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < getWidgetsRows.length; i++) {
            System.out.println("Number of time this API will hit: " + getWidgetsRows.length);
            getWidgetsRow getWidgetsRow = getWidgetsRows[i];
            JsonResponse = given().spec(setParams()).
                    queryParam("os",getWidgetsRow.getOs()).
                    queryParam("minandroid", getWidgetsRow.getMinandroid()).
                    queryParam("maxandroid", getWidgetsRow.getMaxandroid()).
                    queryParam("minios", getWidgetsRow.getMinios()).
                    queryParam("maxios", getWidgetsRow.getMaxios()).
                    queryParam("createdby", getWidgetsRow.getCreatedby()).
                    get(API).
                    then().extract().response();
            JsonResponse.prettyPrint();
            ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
            ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(),ResponseObj.class);
            // verifying the statusCode, status, message
            String  expcode = getWidgetsRow.getStatusCode();
            int expStatusCode = Integer.parseInt(expcode);
            softAssert.assertEquals(JsonResponse.getStatusCode(), expStatusCode, "satusCode is not matched");
            softAssert.assertEquals(responseObj.getStatus(),getWidgetsRow.getStatus());
            softAssert.assertEquals(responseObj.getMessage(), getWidgetsRow.getMessage());
            logger.log(LogStatus.INFO, getWidgetsRow.getreportName()+" passed");
            if(getWidgetsRow.getStatus().equalsIgnoreCase("ERROR")) {
                System.out.println("validating schema of native test case");
                JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("GetEntityErrorParams.json")));
                logger.log(LogStatus.PASS, "schema validated of native testcase params");
            }
            else{
                System.out.println("validating schema of positive test case");
                //JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("GetWidgets.json")));
                logger.log(LogStatus.PASS, "schema validated of positive testcase params");
            }
        }

        softAssert.assertAll();
        //report.endTest(extentTest);
    }
}
