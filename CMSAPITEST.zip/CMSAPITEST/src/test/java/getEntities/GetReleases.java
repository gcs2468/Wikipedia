package getEntities;

import com.airtel.api.ApiEvent;
import com.airtel.api.ExcelReader;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.excelRow.getModulesRow;
import com.airtel.api.helper.ApiHelper;
import com.google.gson.Gson;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojo.getEntitiesResponse.ResponseObj;

import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

public class GetReleases extends ReportHelper{

    private static Response JsonResponse;
    ExcelReader reader = null;
    private static String API = ApiEvent.Release_CONTROLLER;
    private static getModulesRow[] getModulesRows;


    /*
    /this function for getting released and verifying in the db and validating schema with valid and invalid data
    */

    @Test
    private void getReleasesValidation() {

        ReportHelper.scenario = "Releases: validation \n" +
                "        -> getting all releases\n" +
                "        -> by passing different valid and invalid parameters \n" +
                "        -> schema validation";

        logger = report.startTest("getAllReleasesapiValidation");
        JsonResponse = given().spec(setParams()).when().get(API);
        JsonResponse.prettyPrint();
        ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
        String responseBody = JsonResponse.asString();
        if (statusChecks(JsonResponse))
            System.out.println("Executing the test case");
        else
            assert (false);

        // verifying statusCode, status, message from response
        ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(),ResponseObj.class);
        SoftAssert softAssert = new SoftAssert();
        logger.log(LogStatus.INFO, "Verifying statusCode, status, message");
        softAssert.assertEquals(JsonResponse.getStatusCode(), 200);
        softAssert.assertEquals(responseObj.getStatus(), "Success");
        softAssert.assertEquals(responseObj.getMessage(), null);
        softAssert.assertAll();
        System.out.println("validating schema correction");
        logger.log(LogStatus.INFO, "Verifying the schmea validation");
        if(JsonResponse.getStatusCode() == 200) {
            //JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("GetReleases.json")));
        }
        report.endTest(logger);
    }

}
