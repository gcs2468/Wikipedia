package createEntities;

import com.airtel.api.ApiEvent;
import com.airtel.api.ExcelReader;
import com.airtel.api.base.MyAirtelBase;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.dbManager.DBConnectionManager;
import com.airtel.api.dbManager.MongoHelper;
import com.airtel.api.excelRow.createComponentRow;
import com.airtel.api.excelRow.getComponentsRow;
import com.airtel.api.helper.ApiHelper;
import com.google.gson.Gson;
import com.mongodb.DBObject;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojo.getEntitiesResponse.ResponseObj;
import pojo.getModules.GetModule;
import updateEntities.ComponentUpdateVerify;
import updateEntities.EntityStateChangeVerify;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.airtel.api.ReusableMethods.getDataFromExcel;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

public class CreateComponent extends ReportHelper {

    private static Response JsonResponse;
    private static Response JsonResponse1;
    private String API = ApiEvent.COMPONENT;
    private static createComponentRow[] createComponentRows;
    ComponentUpdateVerify componentUpdateVerify = new ComponentUpdateVerify();
    EntityStateChangeVerify entityStateChangeVerify = new EntityStateChangeVerify();
    createComponentRow createComponentRow;
    private String component;





    /*
    /this method for creating a component and verifying in the db and validating schema with valid and invalid data
    */
    @Test
    private void createComponentapiValidation() {

        ReportHelper.scenario = "Component Creation : \n" +
                "        -> creating components\n" +
                "        -> by passing valid and invalid data \n" +
                "        -> schema validation & db verification";
        Map < String, String > headers = setHeaders();
        JSONObject obj = new JSONObject();
        logger = report.startTest("createComponentWithMulParameters");
        Object[][] body = new Object[4][15];
        if (createComponentRows == null) {
            body = getDataFromExcel(("test_data/Entities_Data.xlsx"), "Component_Data");
            createComponentRows = new createComponentRow[body.length];
            for (int i = 0; i < body.length; i++) {
                createComponentRows[i] = new createComponentRow(body[i]);
            }
        }
        SoftAssert softAssert = new SoftAssert();

        for (int i = 0; i < createComponentRows.length; i++) {
            System.out.println("Number of time this API will hit: " + createComponentRows.length);

            createComponentRow = createComponentRows[i];
            String timestamp = getDate("dd-MM-yyyy hh-mm-ss");
            System.out.println("time stamp is :" + timestamp);

            JSONArray comp = new JSONArray();
            comp.put("test");
            obj.put("createdby", createComponentRow.getCreatedby())
                    .put("creator", createComponentRow.getCreator())
                    .put("entityState", createComponentRow.getEntityState())
                    .put("layouts", Arrays.asList(createComponentRow.getLayoutone()))
                    .put("maxandroid", createComponentRow.getMaxandroid())
                    .put("maxios", createComponentRow.getMaxios())
                    .put("minandroid", createComponentRow.getMinandroid())
                    .put("minios", createComponentRow.getMinios())
                    .put("name", createComponentRow.getName() + timestamp)
                    .put("os", Arrays.asList(createComponentRow.getOs1(), createComponentRow.getOs2()));

            logger.log(LogStatus.INFO, createComponentRow.getReportName() + " passed");
            JsonResponse = RestAssured.given().headers(setHeaders()).log().all().contentType(ContentType.JSON).body(obj.toString()).post(API);
            JsonResponse.prettyPrint();
            ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
            ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(), ResponseObj.class);
            System.out.println("Response Object :: " + responseObj);

            // verifying the status code, status, message.

            softAssert.assertEquals(responseObj.getStatusCode(), createComponentRow.getStatusCode());

            softAssert.assertEquals(responseObj.getStatus(), createComponentRow.getStatus());

            softAssert.assertEquals(responseObj.getMessage(), createComponentRow.getMessage());

            // calling function for putting component value in module sheet file
            if (createComponentRow.getName().equalsIgnoreCase("home")) {
                String componentName = createComponentRow.getName() + timestamp;
                System.out.println("created component name is :" + componentName);
                ExcelReader reader = new ExcelReader("/Users/veeraprasad/IdeaProjects/CMSAPITEST/src/test/resources/test_data/Entities_Data.xlsx");
                reader.putCellData("/Users/veeraprasad/IdeaProjects/CMSAPITEST/src/test/resources/test_data/Entities_Data.xlsx", "Module_Data", 4, 0, componentName);

            }

            // calling function for verifying the component exists
            if (createComponentRow.getStatus().equalsIgnoreCase("success")) {
                System.out.println("calling componentapi validation function");
                component = createComponentRow.getName();
                // calling function for component db validation
                System.out.println("verifying component from db with all keys and values");
                //getComponentDataFromDB("component", "_id", component);
                System.out.println("validating schema of positive testcases");
                // JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("createComponent.json")));
                logger.log(LogStatus.PASS, "Schema validated");
            }
            if (createComponentRow.getStatus().equalsIgnoreCase("ERROR") || createComponentRow.getStatus().equalsIgnoreCase("failed")) {

                System.out.println("validating schema of native testcases");
                JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("createEntityResponse.json")));
                logger.log(LogStatus.PASS, "Schema validated");
            }

        }

        softAssert.assertAll();

        //report.endTest(logger);

    }

    // function for verifying the module values from db

    private void getComponentDataFromDB(String collectionName, String key, String componentName) {
        String entityJson = MongoHelper.getEntityDataFromDB(collectionName, "_id", componentName);
        System.out.println("the entity json response  is :" + entityJson);
        JsonPath jsonPath = new JsonPath(entityJson);
        List < String > layouts = jsonPath.getList("layouts");
        Assert.assertEquals(layouts.get(0), createComponentRow.getLayoutone());
        Assert.assertEquals(layouts.get(1), createComponentRow.getLayouttwo());
        logger.log(LogStatus.PASS, "component object layout key value validated from db");
        String expState = jsonPath.getString("entityState");
        Assert.assertEquals(expState, createComponentRow.getEntityState());
        logger.log(LogStatus.PASS, "component object  entity key value validated from db");
        List < String > os = jsonPath.getList("os");
        Assert.assertEquals(os.get(0), createComponentRow.getOs1());
        Assert.assertEquals(os.get(1), createComponentRow.getOs2());
        logger.log(LogStatus.PASS, "component object os key values validated from db");

    }


    //@Test
    private void updateModuleVerify() {
        // calling function for updating module verify function.

        componentUpdateVerify.updateComponentapiValidation(component);
    }

    // function for verifying the state change

    // @Test
    private void componentStateVerify() {

        logger = report.startTest("change the component state to QA");

        entityStateChangeVerify = new EntityStateChangeVerify();


        // calling function for changing the state

        entityStateChangeVerify.entityStateVerify(component, "QA", "component");


    }

}