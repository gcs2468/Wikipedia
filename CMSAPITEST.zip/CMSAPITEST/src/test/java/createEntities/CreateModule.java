package createEntities;

import com.airtel.api.ApiEvent;
import com.airtel.api.base.MyAirtelBase;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.dbManager.MongoHelper;
import com.airtel.api.excelRow.getModulesRow;
import com.airtel.api.helper.ApiHelper;
import com.google.gson.Gson;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.airtel.api.excelRow.createModuleRow;
import pojo.getEntitiesResponse.ResponseObj;
import pojo.getModules.GetModule;
import updateEntities.EntityStateChangeVerify;
import updateEntities.ModuleUpdateVerify;

import java.util.*;
import static com.airtel.api.ReusableMethods.getDataFromExcel;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

public class CreateModule extends ReportHelper {

    private static Response JsonResponse;
    private static Response JsonResponse1;
    private static String API = ApiEvent.MODULE_CONTROLLER;
    private static createModuleRow[] createModuleRows;
    createModuleRow createModuleRow;
    ModuleUpdateVerify moduleUpdateVerify = new ModuleUpdateVerify();
    EntityStateChangeVerify entityStateChangeVerify;
    private String module;

    /*
     /this function for creating a module and verifying in the db and validating schema with valid and invalid data
     */

    @Test
    private void createModuleapiValidation() {

        ReportHelper.scenario = "Module Creation : \n" +
                "        -> creating modules\n" +
                "        -> by passing valid and invalid data \n" +
                "        -> schema validation & db verification";

        Map < String, String > headers = setHeaders();
        JSONObject obj = new JSONObject();
        logger = report.startTest("createModuleWithMulParameters");
        Object[][] body = new Object[4][15];
        if (createModuleRows == null) {
            body = getDataFromExcel(("test_data/Entities_Data.xlsx"), "Module_Data");
            createModuleRows = new createModuleRow[body.length];
            for (int i = 0; i < body.length; i++) {
                createModuleRows[i] = new createModuleRow(body[i]);
            }
        }

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < createModuleRows.length; i++) {
            System.out.println("Number of time this API will hit: " + createModuleRows.length);
            createModuleRow = createModuleRows[i];
            String timestamp = getDate("dd-MM-yyyy hh-mm-ss");
            JSONArray comp = new JSONArray();
            comp.put("test");
            obj.put("components", Arrays.asList(createModuleRow.getComponentsone()))
                    .put("createdby", createModuleRow.getCreatedby())
                    .put("creator", createModuleRow.getCreator())
                    .put("entityState", createModuleRow.getEntityState())
                    .put("maxandroid", createModuleRow.getMaxandroid())
                    .put("maxios", createModuleRow.getMaxios())
                    .put("minandroid", createModuleRow.getMinandroid())
                    .put("minios", createModuleRow.getMinios())
                    .put("name", createModuleRow.getName() + timestamp)
                    .put("os", Arrays.asList(createModuleRow.getOs1(), createModuleRow.getOs2()));
            logger.log(LogStatus.INFO, createModuleRow.getReportName() + " passed");
            JsonResponse = RestAssured.given().headers(setHeaders()).log().all().contentType(ContentType.JSON).body(obj.toString()).post(API);
            JsonResponse.prettyPrint();
            ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
            ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(), ResponseObj.class);
            // verifying statusCode, status, message.
            softAssert.assertEquals(responseObj.getStatusCode(), createModuleRow.getStatusCode());
            softAssert.assertEquals(responseObj.getStatus(), createModuleRow.getStatus());
            softAssert.assertEquals(responseObj.getMessage(), createModuleRow.getMessage());
            // calling function for verifying the module exists
            if (createModuleRow.getStatus().equalsIgnoreCase("success")) {
                System.out.println("calling moduleapi validation function");
                module = createModuleRow.getName();
                // calling function for module db validation
                System.out.println("verifying module from db with all keys and values");
                getModuleDataFromDB("module", "_id", module);


            }
            JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("createEntityResponse.json")));
            logger.log(LogStatus.PASS, "Schema validated");

        }
        softAssert.assertAll();
        //report.endTest(logger);

    }


    // function for verifying the module values from db

    private void getModuleDataFromDB(String collectionName, String key, String moduleName) {

        String entityJson = MongoHelper.getEntityDataFromDB(collectionName, key, moduleName);
        System.out.println("the entity json response  is :" + entityJson);
        JsonPath jsonPath = new JsonPath(entityJson);
        List < String > components = jsonPath.getList("components");
        Assert.assertEquals(components.get(0), createModuleRow.getComponentsone());
        Assert.assertEquals(components.get(1), createModuleRow.getComponentstwo());
        logger.log(LogStatus.PASS, "module object components key value validated from db");
        String expState = jsonPath.getString("entityState");
        Assert.assertEquals(expState, createModuleRow.getEntityState());
        logger.log(LogStatus.PASS, "module object entity key value validated from db");
        List < String > os = jsonPath.getList("os");
        Assert.assertEquals(os.get(0), createModuleRow.getOs1());
        Assert.assertEquals(os.get(1), createModuleRow.getOs2());

        logger.log(LogStatus.PASS, "module object os key values validated from db");

    }

    //@Test
    private void updateModuleVerify() {
        // calling function for updating module verify function.

        moduleUpdateVerify.updateModuleapiValidation(module);
    }

    // function for verifying the state change

    //@Test
    private void moduleStateVerify() {

        logger = report.startTest("change the module state to QA");

        entityStateChangeVerify = new EntityStateChangeVerify();


        // calling function for changing the state

        entityStateChangeVerify.entityStateVerify(module, "QA", "module");


    }




}