package createEntities;

import com.airtel.api.ApiEvent;
import com.airtel.api.ExcelReader;
import com.airtel.api.base.MyAirtelBase;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.dbManager.DBConnectionManager;
import com.airtel.api.dbManager.MongoHelper;
import com.airtel.api.excelRow.createLayoutRow;
import com.airtel.api.excelRow.getModulesRow;
import com.airtel.api.helper.ApiHelper;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojo.getModules.GetModule;
import updateEntities.EntityStateChangeVerify;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.airtel.api.ReusableMethods.getDataFromExcel;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

public class CreateLayout extends ReportHelper {

   private static Response JsonResponse;
    private static Response JsonResponse1;
    String status = null;
    String message = null;
    String statusCode = null;
    String API = ApiEvent.LAYOUT_CONTROLLER;
    public static createLayoutRow[] createLayoutRows;
   // LayoutUpdateVerify layoutUpdateVerify = new LayoutUpdateVerify();
    EntityStateChangeVerify entityStateChangeVerify;
    createLayoutRow createLayoutRow;
    String layout;


    @Test

   /*
    /this method for creating a layout and verifying in the db and validating schema with valid and invalid data
    */
    private void createLayoutapiValidation() {

        ReportHelper.scenario = "Layout Creation : \n" +
                "        -> creating layouts\n" +
                "        -> by passing valid and invalid data \n" +
                "        -> schema validation & db verification";


        Map<String, String> headers = setHeaders();
        JSONObject obj = new JSONObject();
        logger = report.startTest("createLayoutWithMulParameters");
        Object[][] body = new Object[4][15];
        if (createLayoutRows == null) {
            body = getDataFromExcel(("test_data/Entities_Data.xlsx"), "Layout_Data");
            createLayoutRows = new createLayoutRow[body.length];
            for (int i = 0; i < body.length; i++) {
                createLayoutRows[i] = new createLayoutRow(body[i]);
            }
        }

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < createLayoutRows.length; i++) {
            System.out.println("Number of time this API will hit: " + createLayoutRows.length);
            createLayoutRow = createLayoutRows[i];
            String timestamp = getDate("dd-MM-yyyy hh-mm-ss");
            System.out.println("time stamp is :" + timestamp);
            System.out.println("createdbyname :"+createLayoutRow.getCreatedby());
            //JSONArray comp = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("api",new JSONObject());
            jsonObject.put("name",createLayoutRow.getName()+timestamp);
            jsonObject.put("widgets",new JSONObject());
           // comp.put("test");
           obj.put("createdby", createLayoutRow.getCreatedby())
                   .put("creator", createLayoutRow.getCreator())
                    .put("entityState", createLayoutRow.getEntityState())
                    .put("layoutRequest", jsonObject)
                    .put("maxandroid", createLayoutRow.getMaxandroid())
                    .put("maxios", createLayoutRow.getMaxios())
                    .put("minandroid", createLayoutRow.getMinandroid())
                    .put("minios", createLayoutRow.getMinios())
                    .put("os", Arrays.asList(createLayoutRow.getOs1(), createLayoutRow.getOs2()));


            logger.log(LogStatus.INFO, createLayoutRow.getReportName() + " passed");
            System.out.println("payload is is  :"+obj);
            JsonResponse = RestAssured.given().headers(setHeaders()).log().all().contentType(ContentType.JSON).body(obj.toString()).post(API);
            JsonResponse.prettyPrint();
            ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
            String sbody = JsonResponse.asString();
            JsonPath jp = new JsonPath(sbody);
            status = jp.getString("status");
            message = jp.getString("message");
            statusCode = jp.getString("statusCode");

            // verifying the status code
            softAssert.assertEquals(statusCode, createLayoutRow.getStatusCode());

            // verifying the status message.
            softAssert.assertEquals(status, createLayoutRow.getStatus());

            // verifying the message
            softAssert.assertEquals(message, createLayoutRow.getMessage());

            // calling function for putting component value in module sheet file
            if(createLayoutRow.getName().equalsIgnoreCase("coupon")){
                String componentName  = createLayoutRow.getName()+timestamp;
                System.out.println("created component name is :"+componentName);
                ExcelReader reader = new ExcelReader("/Users/veeraprasad/IdeaProjects/CMSAPITEST/src/test/resources/test_data/Entities_Data.xlsx");
                reader.putCellData("/Users/veeraprasad/IdeaProjects/CMSAPITEST/src/test/resources/test_data/Entities_Data.xlsx", "Component_Data",4,3,componentName);

            }

            // calling function for verifying the module exists
            if (createLayoutRow.getStatus().equalsIgnoreCase("success")) {
                System.out.println("calling layoutapi validation function");
                 layout = createLayoutRow.getName();
                // calling function for layout db validation
                System.out.println("verifying layout from db with all keys and values");
                //getLayoutDataFromDB("layout", "_id", layout);
            }

            System.out.println("validating schema of creating layout with all test steps");
            JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("createEntityResponse.json")));
            logger.log(LogStatus.PASS, "Schema validated");

        }
        softAssert.assertAll();
        report.endTest(logger);

    }


    // function for verifying the layout values from db



    public void getLayoutDataFromDB(String collectionName, String key, String layoutName){
        String entityJson =MongoHelper.getEntityDataFromDB(collectionName, "_id", layoutName);
        System.out.println("the entity json response  is :"+entityJson);
        JsonPath jsonPath = new JsonPath(entityJson);
        List<String> layouts =jsonPath.getList("layouts");
        String expState = jsonPath.getString("entityState");
        Assert.assertEquals(expState, createLayoutRow.getEntityState());
        logger.log(LogStatus.PASS, "layout object  entity key value validated from db");
        List<String> os = jsonPath.getList("os");
        Assert.assertEquals(os.get(0), createLayoutRow.getOs1());
        Assert.assertEquals(os.get(1), createLayoutRow.getOs2());
        logger.log(LogStatus.PASS, "layout object os key values validated from db");


    }

    //@Test
    private void updateModuleVerify(){
        // calling function for updating layout verify function.

    }



    // function for verifying the state change

    //@Test
    private void layoutStateVerify(){

        logger = report.startTest("change the layout state to QA");

        entityStateChangeVerify = new EntityStateChangeVerify();


        // calling function for changing the state

        entityStateChangeVerify.entityStateVerify(layout, "QA", "layout");



    }

}
