package createEntities;

import com.airtel.api.ApiEvent;
import com.airtel.api.ExcelReader;
import com.airtel.api.base.MyAirtelBase;
import com.airtel.api.base.ReportHelper;
import com.airtel.api.dbManager.DBConnectionManager;
import com.airtel.api.dbManager.MongoHelper;
import com.airtel.api.excelRow.creatWidgetRow;
import com.airtel.api.helper.ApiHelper;
import com.google.gson.Gson;
import com.mongodb.DBObject;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojo.getEntitiesResponse.ResponseObj;
import updateEntities.EntityStateChangeVerify;
import updateEntities.WidgetUpdateVerify;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.airtel.api.ReusableMethods.getDataFromExcel;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

 public class CreateWidget extends ReportHelper{

    private static Response JsonResponse;
    private static Response JsonResponse1;
    static Response JsonResponse2;
    String API = ApiEvent.WIDGET_CONTROLLER;
    private static creatWidgetRow[] creatWidgetRows;
    creatWidgetRow creatWidgetRow;
    EntityStateChangeVerify entityStateChangeVerify;
    String widget;




   /*
    /this method for creating a widget and verifying in the db and validating schema with valid and invalid data
    */

   @Test
   private void createWidgetapiValidation() {

        ReportHelper.scenario = "Widget Creation : \n" +
                "        -> creating widgets\n" +
                "        -> by passing valid and invalid data \n" +
                "        -> schema validation & db verification";
        Map<String, String> headers = setHeaders();
        JSONObject obj = new JSONObject();
        logger = report.startTest("createWidgetWithMulParameters");
        Object[][] body = new Object[4][15];
        if (creatWidgetRows == null) {
            body = getDataFromExcel(("test_data/Entities_Data.xlsx"), "Widget_Data");
            creatWidgetRows = new creatWidgetRow[body.length];
            for (int i = 0; i < body.length; i++) {
                creatWidgetRows[i] = new creatWidgetRow(body[i]);
            }
        }

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < creatWidgetRows.length; i++) {
            System.out.println("Number of time this API will hit: " + creatWidgetRows.length);
            creatWidgetRow = creatWidgetRows[i];
            String timestamp = getDate("dd-MM-yyyy hh-mm-ss");
            System.out.println("time stamp is :" + timestamp);
            JSONArray comp = new JSONArray();
            comp.put("test");
            obj.put("allowedAttributes", Arrays.asList(creatWidgetRow.getAttributeone()))
                    .put("createdby", creatWidgetRow.getCreatedby())
                    .put("creator", creatWidgetRow.getCreator())
                    .put("entityState", creatWidgetRow.getEntityState())
                    .put("maxandroid", creatWidgetRow.getMaxandroid())
                    .put("maxios", creatWidgetRow.getMaxios())
                    .put("minandroid", creatWidgetRow.getMinandroid())
                    .put("minios", creatWidgetRow.getMinios())
                    .put("os", Arrays.asList(creatWidgetRow.getOs1(), creatWidgetRow.getOs2()))
                    .put("type", creatWidgetRow.getName() + timestamp);

            logger.log(LogStatus.INFO, creatWidgetRow.getReportName() + " passed");
            JsonResponse = RestAssured.given().headers(setHeaders()).log().all().contentType(ContentType.JSON).body(obj.toString()).post(API);
            JsonResponse.prettyPrint();
            ApiHelper.logRequestResponse(API, JsonResponse.asString(), API, JsonResponse.getTime());
            ResponseObj responseObj = new Gson().fromJson(JsonResponse.asString(),ResponseObj.class);
            String sbody = JsonResponse.asString();

            // verifying the status code
            softAssert.assertEquals(responseObj.getStatusCode(), creatWidgetRow.getStatusCode());

            // verifying the status message.
            softAssert.assertEquals(responseObj.getStatus(), creatWidgetRow.getStatus());

            // verifying the message
            softAssert.assertEquals(responseObj.getMessage(), creatWidgetRow.getMessage());

            // calling function for verifying the module exists
            System.out.println("validating schema testcases");
            if (creatWidgetRow.getStatus().equalsIgnoreCase("success")) {
                System.out.println("calling widgetapi validation function");
                 widget = creatWidgetRow.getName();
                // calling function for widget db validation
                System.out.println("verifying widget from db with all keys and values");
                //getWidgetDataFromDB("widget", "_id", widget);
                System.out.println("validating schema of positive testcases");
                //JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("createWidget.json")));
                logger.log(LogStatus.PASS, "Schema validated");
            }

            else {


                System.out.println("validating schema of creating widget with native steps");
            JsonResponse.then().assertThat().body(matchesJsonSchema(getTestDataClassPath("createEntityResponse.json")));
            logger.log(LogStatus.PASS, "Schema validated");
            }

        }
        softAssert.assertAll();
       // report.endTest(logger);

    }


    // function for verifying the widget values from db


    private void getWidgetDataFromDB(String collectionName, String key, String widgetName){
        String entityJson =MongoHelper.getEntityDataFromDB(collectionName, "_id", widgetName);
        System.out.println("the entity json response  is :"+entityJson);
        JsonPath jsonPath = new JsonPath(entityJson);
        List<String> attributes =jsonPath.getList("allowedAttributes");
        Assert.assertEquals(attributes.get(0), creatWidgetRow.getAttributeone());
        Assert.assertEquals(attributes.get(1), creatWidgetRow.getAttributetwo());
        logger.log(LogStatus.PASS, "widget object attributes key value validated from db");
        String expState = jsonPath.getString("entityState");
        Assert.assertEquals(expState, creatWidgetRow.getEntityState());
        logger.log(LogStatus.PASS, "widget object entity key value validated from db");
        List<String> os = jsonPath.getList("os");
        Assert.assertEquals(os.get(0), creatWidgetRow.getOs1());
        Assert.assertEquals(os.get(1), creatWidgetRow.getOs2());
        logger.log(LogStatus.PASS, "widget object os key values validated from db");

    }


    //@Test
    private void updateWidgetVerify(){
        // calling function for updating module verify function.
    }


     // function for verifying the state change

     //@Test
     private void widgetStateVerify(){

         logger = report.startTest("change the widget state to QA");

         entityStateChangeVerify = new EntityStateChangeVerify();


         // calling function for changing the state

         entityStateChangeVerify.entityStateVerify(widget, "QA", "widget");



     }
}
