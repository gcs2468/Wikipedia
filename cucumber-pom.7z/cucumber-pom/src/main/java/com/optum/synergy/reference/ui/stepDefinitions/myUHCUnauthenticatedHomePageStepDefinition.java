package com.optum.synergy.reference.ui.stepDefinitions;


import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.myUHCUnathenticatedHomePage;
import com.optum.synergy.reference.ui.utility.dataStorage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class myUHCUnauthenticatedHomePageStepDefinition {
	private myUHCUnathenticatedHomePage page;
	
	public myUHCUnauthenticatedHomePageStepDefinition() {
		page = new myUHCUnathenticatedHomePage();
	}

	@Given("^I am at myUHC unauthenticated home page$")
	public void iAmAtMyUHCUnauthenticatedHomePage() throws Throwable {
		page.openmyUHCHomePage();
		Assert.assertTrue("Issue while loading the myUHC Unathenticated page", page.verifyIfPageLoaded());
	}

	@Given("^I enter valid username into Username field$")
	public void iEnterValidUsernameIntoUsernameField() throws Throwable {
		page.enterUserName(dataStorage.getUserName());
	}

	@Given("^I enter valid password into Password field$")
	public void iEnterValidPasswordIntoPasswordField() throws Throwable {
		page.enterPassword(dataStorage.getPassword());
	}
	
	@Given("^I am at myUHC-MyHealthOverView unauthenticated home page$")
	public void iAmAtMyUHCMyHealthOverViewUnauthenticatedHomePage() throws Throwable {
		page.openMyHealthOverViewHomePage();
		Assert.assertTrue("Issue while loading the myUHC Unathenticated page", page.verifyIfPageLoaded());
	}
	
	@Given("^I am at myUHC-HealthSelect unauthenticated home page$")
	public void iAmAtMyUHCHealthSelectUnauthenticatedHomePage() throws Throwable {
		page.openHealthSelectPortalHomePage();
		Assert.assertTrue("Issue while loading the myUHC Unathenticated page", page.verifyIfPageLoaded());
	}
	
	@Given("^I am at myUHC-CommunityAndState unauthenticated home page$")
	public void iAmAtMyUHCCommunityAndStateUnauthenticatedHomePage() throws Throwable {
		page.openCommunityAndStateURLHomePage();
		Assert.assertTrue("Issue while loading the myUHC Unathenticated page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should be at myUHC unauthenticated sign in page$")
	public void iAmAtMyUHCUnauthenticatedSignInPage() throws Throwable {
		Assert.assertTrue("Issue while loading the myUHC unauthenticated page", page.verifyIfPageLoaded());
	}

	@When("^I click on Sign In button in MyUhc unauthenticated home page$")
    public void iClickOnSignInButtonInMyUhcUnauthenticatedHomePage() throws Throwable {
       page.clickOnSignInButton();
	}

	@Then("^I should see an error message \"(.*)\" after clicking on SignIn button from pre-login page$")
	public void iShouldSeeAnErrorMessage(String expectedMessage ) {
		Assert.assertEquals("FAIL: Did not find expected error message",expectedMessage.replaceAll("\\s+", ""), page.getErrorMessageOnmyUHCUnauthenticatedHomePage());
	}
	
	@Then("^I should be at \"([^\"]*)\" unauthenticated page$")
	public void iAmAtUnauthenticatedPage(String portalName) throws Throwable {
		Assert.assertTrue("Issue while loading the "+portalName+" unauthenticated page", page.verifyIfPageLoaded());
	}
}
