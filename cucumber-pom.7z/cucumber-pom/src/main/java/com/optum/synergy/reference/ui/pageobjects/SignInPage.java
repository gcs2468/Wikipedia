package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class SignInPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[@id='Login']|//div[@id='hsid-login']")
	private WebElement loginForm;

	@FindBy(how = How.XPATH, using = "//flex-content[@class='ng-binding']/h1")
	private WebElement pageHeading;

	@FindBy(how = How.XPATH, using = "//input[@id='EMAIL']|//input[@id='hsid-username']")
	private WebElement userNameTextBox;

	@FindBy(how = How.XPATH, using = "//input[@id='PASSWORD']|//input[@id='hsid-password']")	
	private WebElement passwordTextBox;

	@FindBy(how = How.XPATH, using = "//button[@class='button button--primary ng-scope' and contains(.,'Sign in')]")
	private WebElement signInButton;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Username or email address')]/following-sibling::input[@id='EMAIL']|//span[@class='strong ng-binding' and contains(.,'Username')]/following-sibling::input[@id='EMAIL']")
	private WebElement usernameOrEmailAddressLabelWithTextbox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Password')]/following-sibling::input[@id='PASSWORD']")
	private WebElement passwordLablelWithTextbox;

	@FindBy(how = How.CLASS_NAME, using = "ng-scope")
	// @FindBy(how=How.ID, using = "helpText")
	private WebElement verifyLabel;

	// @FindBy(how = How.XPATH, using =
	// "//img[@src='https://stg.liveandworkwell.com/images/member/shell/logo_6.gif']")
	@FindBy(how = How.XPATH, using = "//img[@src='https://myoptum-stage.optum.com/content/dam/OptumDashboard/ad-box/logos/optum_2x.png']")
	private WebElement optumBrandLogo;

	@FindBy(how = How.XPATH, using = "//flex-content[@id='Logo']/p/a/img[@alt='Live and Work Well Logo']")
	private WebElement contentLogo;

	@FindBy(how = How.XPATH, using = "//*[@id='usermenu']/a")
	private WebElement Usermenu;

	@FindBy(how = How.XPATH, using = "//*[@id='usermenu']//a[text()='Sign In & Security']")
	private WebElement SignInSecurity;

	@FindBy(how = How.ID, using = "accessCode")
	private WebElement accessCode;

	@FindBy(how = How.XPATH, using = "//div[@class='ng-binding']/p|//div[@id='hsid-commonError']/p|//*[@id='Login']//span[contains(@ng-bind-html,'SigninEmailConfirmed')]")
	private WebElement confirmationMessage;

	// added 2/23 authoobWrapper

	@FindBy(how = How.ID, using = "authoobWrapper")
	private WebElement confirmIdentity;

	@FindBy(how = How.ID, using = "authQuestionWrapper")
	private WebElement alertMessage;

	@FindBy(how = How.XPATH, using = "//*[@id='authQuestionWrapper']/div[1]/p")
	private WebElement secureMessage;

	@FindBy(how = How.ID, using = "authOobCallRadio")
	private WebElement phoneCall;

	@FindBy(how = How.XPATH, using = "//div[@class='authQuestionAnswerBox']")
	private WebElement securityAnswerTextField;

	@FindBy(how = How.ID, using = "authQuestiontextLabelId")
	private WebElement SecurityLabel;

	@FindBy(how = How.XPATH, using = "//*[@class='ng-scope']/span[@class='ng-binding']")
	private WebElement errorMsg;
	
	@FindBy(how = How.XPATH, using = "//input[@id='EMAIL']/../span[@class='error']/span")
	private WebElement errmsg_userName;

	@FindBy(how = How.XPATH, using = "//input[@id='PASSWORD']/../span[@class='error']/span")
	private WebElement errmsg_pwd;
	
	@FindBy(how = How.XPATH, using = "//*[@bind-to-modal='signInHeader']/a|//*[@ng-if='stepUpType']/a/u[contains(text(),'HealthSafe')]")
	private WebElement healthSafeIdLink;
	
	@FindBy(how = How.XPATH, using = "//*[@id='ognheader']//nav//div[2]/ul/li[2]//a")
	private WebElement globalNavSignInLink;
	
	
	public boolean securityAnswerLabel() {
		return SecurityLabel.isDisplayed();
	}

	public boolean securityAnswerTextField() {
		return securityAnswerTextField.isDisplayed();
	}

	public boolean automatedPhoneCalldisplay() {
		return phoneCall.isDisplayed();
	}

	public String getErrorMessage() {
		waitForPageLoad(driver);
		boolean blnflag = false;
		String errmsg = null;
		int cntr = 0;
		while (!blnflag && cntr < 15) {
			try {
				errmsg = mediumWait.get().until(ExpectedConditions.visibilityOf(errorMsg)).getText();
				blnflag = true;
				return errmsg;

			} catch (StaleElementReferenceException e) {
				waitForPageLoad(driver);
				cntr++;
			}
			
		}
		return "ELEMENT WAS NOT FOUND ON PAGE";

	}

	public boolean verifysecureMessage(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(secureMessage));
		return secureMessage.getText().contains(message);
	}

	public boolean verifyConfirmIdentity(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmIdentity));
		return confirmIdentity.getText().contains(message);
	}

	public boolean verifyAlertMessage(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(alertMessage));
		return alertMessage.getText().contains(message);
	}
	
	public String getMessageOnSignInPage() {
		return smallWait.get()
				.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//form[@id='Login']//p[@class='strong ng-binding']")))
				.getText();
	}

	public void enterAccessCode(String text) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(accessCode));
		accessCode.clear();
		accessCode.sendKeys(text);
	}

	public boolean verifyForConfimationMessage(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmationMessage));
		return confirmationMessage.getText().contains(message);
	}

	public void SignInSecurityClick() throws InterruptedException {
		mediumWait.get().until(ExpectedConditions.visibilityOf(SignInSecurity)).click();
		Thread.sleep(2000);
	}

	public void userMenuClick() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(Usermenu)).click();
	}

	public void clickImg() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(optumBrandLogo)).click();
	}

	public boolean verifyContentLabel(String message) {
		return verifyLabel.getText().contains(message);
	}

	public void enterUserName(String username) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
		userNameTextBox.clear();
		userNameTextBox.sendKeys(username);
	}

	public void enterPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
		passwordTextBox.clear();
		passwordTextBox.sendKeys(password);
	}

	public void clickSignInButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(signInButton));
		signInButton.click();
	}

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOf(loginForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}

	}

	public boolean verifyIfUsernameOrEmailAddressLabelExistWithTextbox() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(usernameOrEmailAddressLabelWithTextbox))
				.isDisplayed();
	}

	public boolean verifyPasswordLableExistWithTextbox() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordLablelWithTextbox)).isDisplayed();
	}

	public boolean verifyForPageHeading(String heading) {
		longWait.get().until(ExpectedConditions.visibilityOf(pageHeading));
		System.out.println(pageHeading.getText());
		return pageHeading.getText().trim().contains(heading);
	}

	public boolean verifyLoginlabel(String heading) {
		return loginForm.getText().trim().equals(heading);
	}

	public String getcontentLogoSourceUrl() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(contentLogo)).getAttribute("src");

	}

	public String getErrorMsgForUserNamefield() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errmsg_userName)).getText();
		} catch (Exception e) {
			return null;
		}

	}

	public String getErrorMsgForPasswordfield() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errmsg_pwd)).getText();
		} catch (Exception e) {
			return null;
		}
	}
	
	public void clickHealthSafeIdLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(healthSafeIdLink)).click();
	}
	public void clickGlobalNavSignInLink() {
		longWait.get().until(ExpectedConditions.elementToBeClickable(globalNavSignInLink)).click();
	}
	
}
