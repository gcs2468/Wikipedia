package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class MultiplePlanSelector extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//table[@id='channelLeft']/tbody")
	private WebElement contentAbovePlanList;

	@FindBy(how = How.XPATH, using = "//table[@id='channelLeft']/tbody/tr[2]/td//table/tbody/tr/td/table[2]")
	private WebElement planLabels;

	@FindBy(how = How.ID, using = "continuebutton")
	public WebElement continueButton;

	@FindBy(how = How.CLASS_NAME, using = "prelogin")
	public WebElement preLoginPage;

	public String contentAbovePlanList() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(contentAbovePlanList)).getText();
	}

	public String planLabels() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(planLabels)).getText();
	}

	public WebElement getContinueButton() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(continueButton));
	}

	public boolean preLoginPage() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(preLoginPage)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

}
