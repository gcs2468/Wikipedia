package com.optum.synergy.reference.ui.stepDefinitions;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.TimeoutException;

import com.optum.synergy.reference.ui.pageobjects.DB_Sugar;
import com.optum.synergy.reference.ui.pageobjects.Hooks;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalAuthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalUserDeleteConfirmationPage;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalUserDeletePage;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalUserSearchPage;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalUserSearchResultsPage;
import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import com.optum.synergy.reference.ui.pageobjects.TestDataExcelPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class ExcelOperationsStepDefinition {

	@Given("^I get the following details for the story (.*) from excel sheet$")
	public void i_get_the_following_details_for_the_story_from_excel_sheet(String userStoryName,
			List<String> userDetails) throws Throwable {
		Hooks hook = new Hooks();
		TestDataExcelPage testDataWorkbook = new TestDataExcelPage();
		XSSFSheet lawwUsersSheet = testDataWorkbook
				.getSheetFromExcelWorkbook(PageObjectBase.getSystemVariable("laww_users_sheet"));
		Map<String, Integer> columnNamesWithIndices = testDataWorkbook
				.getColumnIndicesBasedOnColumnNamesFromASheet(lawwUsersSheet, userDetails);
		System.out.println(columnNamesWithIndices);
		Integer userStoryNameIndex = null;
		Row firstRow = lawwUsersSheet.getRow(0);
		Integer requiredStroyRowIndex = null;
		// System.out.println("row count: " + lawwUsersSheet.getLastRowNum());
		for (Cell cell : firstRow) {
			if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
				if (cell.getStringCellValue().trim().equals("UserStoryName")) {
					userStoryNameIndex = cell.getColumnIndex();
					// System.out.println(userStoryNameIndex);
					break;
	
				}
			}
		}
	
		for (int rowNum = 1; rowNum < lawwUsersSheet.getLastRowNum(); rowNum++) {
			Cell cell = lawwUsersSheet.getRow(rowNum).getCell(userStoryNameIndex);
			if (cell.getStringCellValue().equals(userStoryName)) {
				/*
				 * String storyName = cell.getStringCellValue();
				 * System.out.println(storyName);
				 */
				requiredStroyRowIndex = rowNum;
				System.out.println(requiredStroyRowIndex);
				break;
			}
		}
		if (requiredStroyRowIndex == null) {
			throw new Exception("No data found for " + userStoryName + " in test data excel sheet");
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("FirstName"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
	
				// firstName_US = "";
				hook.setFirstName("");
				// System.out.println("");
	
			} else {
				System.out.println(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("FirstName")).toString());
				hook.setFirstName(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("FirstName")).toString());
			}
		} catch (NullPointerException e) {
			hook.setFirstName("");
			// System.out.println("result is : " + result);
		}
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("LastName"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
	
				hook.setLastName("");
				// System.out.println("");
	
			} else {
				System.out.println(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("LastName")).toString());
				hook.setLastName(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("LastName")).toString());
			}
		} catch (NullPointerException e) {
			hook.setLastName("");
			// System.out.println("result is : " + result);
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("DOB"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
	
				hook.setDOB("");
				// System.out.println("");
	
			} else {
				System.out.println(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("DOB")).getRawValue());
				hook.setDOB(lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("DOB"))
						.getRawValue());
			}
		} catch (NullPointerException e) {
			hook.setDOB("");
		}
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("Zip"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
	
				hook.setZipcode("");
				// System.out.println("");
	
			} else {
				System.out.println(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("Zip"))));
				hook.setZipcode(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("Zip"))));
				;
			}
		} catch (NullPointerException e) {
			hook.setZipcode("");
			// System.out.println("");
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("SSN"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
	
				hook.setSSN("");
				// System.out.println("");
	
			} else {
				System.out.println(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("SSN"))));
				hook.setSSN(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("SSN"))));
			}
		} catch (NullPointerException e) {
			hook.setSSN("");
			// System.out.println("");
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("SubscriberID"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
	
				hook.setSubscriberId("");
				// System.out.println("");
	
			} else {
				System.out.println(new DataFormatter().formatCellValue(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("SubscriberID"))));
				hook.setSubscriberId(new DataFormatter().formatCellValue(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("SubscriberID"))));
			}
		} catch (NullPointerException e) {
			hook.setSubscriberId("");
			// System.out.println("");
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("UserName"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
	
				hook.setUserName("");
				// System.out.println("");
	
			} else {
				System.out.println(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("UserName"))));
				hook.setUserName(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("UserName"))));
				// hook.setUserName(lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("UserName"))
				// .getRawValue());
			}
		} catch (NullPointerException e) {
			hook.setUserName("");
			// System.out.println("");
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("Password"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
	
				hook.setPassword("");
				// System.out.println("");
	
			} else {
				System.out.println(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("Password"))));
				hook.setPassword(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("Password"))));
	
				/*
				 * hook.setPassword(lawwUsersSheet.getRow(requiredStroyRowIndex)
				 * .getCell(columnNamesWithIndices.get("Password"))
				 * .getRawValue());
				 */
			}
		} catch (NullPointerException e) {
			hook.setPassword("");
			// System.out.println("");
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("NewPassword"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
	
				hook.setNewPassword("");
				// System.out.println("");
	
			} else {
				System.out.println(new DataFormatter().formatCellValue(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("NewPassword"))));
				hook.setNewPassword(new DataFormatter().formatCellValue(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("NewPassword"))));
			}
		} catch (NullPointerException e) {
			hook.setNewPassword("");
			// System.out.println("");
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("Email"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
				hook.setEmailId("");
				// System.out.println("");
			} else {
				System.out.println(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("Email"))));
				hook.setEmailId(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("Email"))));
			}
		} catch (NullPointerException e) {
			hook.setEmailId("");
			// System.out.println("");
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("NewEmail"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
				hook.setNewEmailId("");
				// System.out.println("");
			} else {
				System.out.println(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("NewEmail"))));
				hook.setNewEmailId(new DataFormatter().formatCellValue(
						lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("NewEmail"))));
			}
		} catch (NullPointerException e) {
			hook.setNewEmailId("");
			// System.out.println("");
		}
	
		try {
			if (lawwUsersSheet.getRow(requiredStroyRowIndex).getCell(columnNamesWithIndices.get("PhoneNumber"))
					.getCellType() == Cell.CELL_TYPE_BLANK) {
				hook.setPhoneNumber("");
				// System.out.println("");
			} else {
				System.out.println(new DataFormatter().formatCellValue(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("PhoneNumber"))));
				hook.setPhoneNumber(new DataFormatter().formatCellValue(lawwUsersSheet.getRow(requiredStroyRowIndex)
						.getCell(columnNamesWithIndices.get("PhoneNumber"))));
			}
		} catch (NullPointerException e) {
			hook.setPhoneNumber("");
			// System.out.println("");
		}
		/*
		 * System.out.println(hook.getFirstName());
		 * System.out.println(hook.getLastName());
		 * System.out.println(hook.getDOB());
		 * System.out.println(hook.getZipcode());
		 * System.out.println(hook.getPassword());
		 */
	}

	@Given("^I should able to delete sugar users based on firstName and lastName$")
	public void i_should_able_to_delete_sugar_users_based_on_firstName_and_lastName() throws Throwable {
		List<String> details = new ArrayList<String>();
		details.add("FirstName");
		details.add("LastName");
		TestDataExcelPage testDataWorkbook = new TestDataExcelPage();
		XSSFSheet lawwUsersSheet = testDataWorkbook
				.getSheetFromExcelWorkbook(PageObjectBase.getSystemVariable("sugar_users_sheet"));
		Map<String, Integer> columnNamesWithIndices = testDataWorkbook
				.getColumnIndicesBasedOnColumnNamesFromASheet(lawwUsersSheet, details);
		System.out.println(columnNamesWithIndices);
		Integer resultColumnIndex = null;
		Row firstRow = lawwUsersSheet.getRow(0);
		for (Cell cell : firstRow) {
			if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
				if (cell.getStringCellValue().trim().equals("SugarDBDeletionResult")) {
					resultColumnIndex = cell.getColumnIndex();
					System.out.println(resultColumnIndex);
					break;
	
				}
			}
		}
	
		String firstName = "";
		String lastName = "";
		for (int i = 1; i < lawwUsersSheet.getPhysicalNumberOfRows(); i++) {
			String result = "";
			try {
				if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName"))
						.getCellType() == Cell.CELL_TYPE_BLANK) {
					firstName = "";
	
				} else {
					// System.out.println(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName")).toString());
					firstName = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName")).toString();
				}
			} catch (NullPointerException e) {
				firstName = "";
			}
	
			try {
				if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName"))
						.getCellType() == Cell.CELL_TYPE_BLANK) {
					lastName = "";
	
				} else {
					// System.out.println(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName")).toString());
					lastName = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName")).toString();
				}
			} catch (NullPointerException e) {
				lastName = "";
			}
			System.out.println("Last Name: " + lastName + "  First Name: " + firstName);
			// System.out.println(firstName);
	
			DB_Sugar sugarDataBase = new DB_Sugar();
			if (firstName == null || lastName == null || firstName.trim().isEmpty() || lastName.trim().isEmpty()) {
				// Do nothing
				result = "";
			} else {
				sugarDataBase.connectToDataBase();
				if (sugarDataBase.returnUserRecords(lastName, lastName) != 0) {
					Assert.assertTrue(sugarDataBase.deleteUserFromSugarDB(firstName, lastName));
				}
				System.out.println(firstName + " ," + lastName + " deleted successfully");
				sugarDataBase.closeConnectionToDataBase();
				result = firstName + " ," + lastName + " deleted successfully";
			}
	
			Cell cell = null;
			try {
				cell = lawwUsersSheet.getRow(i).getCell(resultColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (result.isEmpty()) {
					cell.setCellValue("FirstName or LastName or Both missing in the sheet");
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.setCellValue(result);
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
	
			} catch (NullPointerException e) {
				cell = lawwUsersSheet.getRow(i).createCell(resultColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (result.isEmpty()) {
					cell.setCellValue("FirstName or LastName or Both missing in the sheet");
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.setCellValue(result);
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
	
			}
			testDataWorkbook.fileIn.close();
			FileOutputStream output_file = new FileOutputStream(
					new File(PageObjectBase.getSystemVariable("test_data_Workbook_location")));
			testDataWorkbook.workbook.write(output_file);
			output_file.close();
	
		}
	
	}

	@Given("^I enter following details into search user form from excel sheet and return user ids into excel$")
	public void i_enter_following_details_into_search_user_form_from_excel_sheet_and_return_user_ids_into_excel(
			List<String> userDetails) throws Throwable {
	
		Assert.assertTrue(userDetails.contains("FirstName"));
		Assert.assertTrue(userDetails.contains("LastName"));
		TestDataExcelPage testDataWorkbook = new TestDataExcelPage();
		XSSFSheet lawwUsersSheet = testDataWorkbook
				.getSheetFromExcelWorkbook(PageObjectBase.getSystemVariable("laww_users_sheet"));
		Map<String, Integer> columnNamesWithIndices = testDataWorkbook
				.getColumnIndicesBasedOnColumnNamesFromASheet(lawwUsersSheet, userDetails);
		System.out.println(columnNamesWithIndices);
		Integer optumIdsColumnIndex = null;
		Row firstRow = lawwUsersSheet.getRow(0);
		for (Cell cell : firstRow) {
			if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
				if (cell.getStringCellValue().trim().equals("OptumIDs")) {
					optumIdsColumnIndex = cell.getColumnIndex();
					System.out.println(optumIdsColumnIndex);
					break;
	
				}
			}
		}
	
		String firstName = "";
		String lastName = "";
		for (int i = 1; i < lawwUsersSheet.getPhysicalNumberOfRows(); i++) {
	
			try {
				if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName"))
						.getCellType() == Cell.CELL_TYPE_BLANK) {
					firstName = "";
	
				} else {
					// System.out.println(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName")).toString());
					firstName = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName")).toString();
				}
			} catch (NullPointerException e) {
				firstName = "";
			}
	
			try {
				if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName"))
						.getCellType() == Cell.CELL_TYPE_BLANK) {
					lastName = "";
	
				} else {
					// System.out.println(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName")).toString());
					lastName = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName")).toString();
				}
			} catch (NullPointerException e) {
				lastName = "";
			}
			System.out.println("Last Name: " + lastName + "  First Name: " + firstName);
			// System.out.println(firstName);
			LAWWAdminPortalUserSearchPage lawwAdminUserSearchPage = new LAWWAdminPortalUserSearchPage();
			lawwAdminUserSearchPage.verifyIfPageLoaded();
			lawwAdminUserSearchPage.enterUserLastName(lastName);
			lawwAdminUserSearchPage.enterUserFirstName(firstName);
			lawwAdminUserSearchPage.clickSearchButton();
			List<String> userIds = new ArrayList<String>();
			try {
				Assert.assertTrue(lawwAdminUserSearchPage.verifySearchResults());
				LAWWAdminPortalUserSearchResultsPage lawwAdminUserSearchedResultsPage = new LAWWAdminPortalUserSearchResultsPage();
				Assert.assertTrue(lawwAdminUserSearchedResultsPage.verifyIfPageLoaded());
				userIds = lawwAdminUserSearchedResultsPage.getListOfSearchedUsers();
				lawwAdminUserSearchedResultsPage.clickTopBackButton();
			} catch (AssertionError e) {
				userIds = Collections.<String> emptyList();
			} catch (TimeoutException e) {
	
			}
	
			Cell cell = null;
			try {
				cell = lawwUsersSheet.getRow(i).getCell(optumIdsColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (userIds.isEmpty()) {
					cell.setCellValue("No users found with this search");
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.setCellValue(userIds.toString());
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
	
			} catch (NullPointerException e) {
				cell = lawwUsersSheet.getRow(i).createCell(optumIdsColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (userIds.isEmpty()) {
					cell.setCellValue("No users found with this search");
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.setCellValue(userIds.toString());
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
	
			}
			testDataWorkbook.fileIn.close();
			FileOutputStream output_file = new FileOutputStream(
					new File(PageObjectBase.getSystemVariable("test_data_Workbook_location")));
			testDataWorkbook.workbook.write(output_file);
			output_file.close();
		}
	}

	@Then("^I enter following detail into User Delete form from excel sheet and delete the user$")
	public void iEnterFollowingDetailIntoUserDeleteFormFromExcelSheetAndDeleteTheUser(List<String> optumIds)
			throws Throwable {
		Assert.assertTrue(optumIds.contains("optumId"));
		TestDataExcelPage testDataWorkbook = new TestDataExcelPage();
		XSSFSheet lawwUsersSheet = testDataWorkbook
				.getSheetFromExcelWorkbook(PageObjectBase.getSystemVariable("laww_users_sheet"));
		Integer optumIdsColumnIndex = null;
		Row firstRow = lawwUsersSheet.getRow(0);
		for (Cell cell : firstRow) {
			if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
				if (cell.getStringCellValue().trim().equals("OptumIDs")) {
					optumIdsColumnIndex = cell.getColumnIndex();
					System.out.println(optumIdsColumnIndex);
					break;
	
				}
			}
		}
	
		for (int i = 1; i < lawwUsersSheet.getPhysicalNumberOfRows(); i++) {
	
			int count = 0;
			try {
				String cellValue = lawwUsersSheet.getRow(i).getCell(optumIdsColumnIndex).getStringCellValue();
				if (lawwUsersSheet.getRow(i).getCell(optumIdsColumnIndex).getCellType() == Cell.CELL_TYPE_BLANK) {
					// Do nothing
				} else if (cellValue.equals("No users found with this search")) {
					// Do nothing
				} else if (cellValue.contains("[") && cellValue.contains("]")) {
					cellValue = cellValue.replace("[", "");
					cellValue = cellValue.replace("]", "");
					List<String> usersList = new ArrayList<String>(Arrays.asList(cellValue.split(",")));
	
					for (String user : usersList) {
						LAWWAdminPortalAuthenticatedHomePage adminPortalAuthenticatedPage = new LAWWAdminPortalAuthenticatedHomePage();
						adminPortalAuthenticatedPage.verifyIfPageLoaded();
						adminPortalAuthenticatedPage.clickDeleteAUserIDLink();
						LAWWAdminPortalUserDeletePage userDeletePage = new LAWWAdminPortalUserDeletePage();
						userDeletePage.verifyIfPageLoaded();
						userDeletePage.enterOptumUserId(user);
						userDeletePage.clickSearchUserToDeleteButton();
						try {
							LAWWAdminPortalUserDeleteConfirmationPage userDeleteConfirmationPage = new LAWWAdminPortalUserDeleteConfirmationPage();
							userDeleteConfirmationPage.verifyIfPageLoaded();
							userDeleteConfirmationPage.clickConfirmDeleteButton();
							userDeleteConfirmationPage.verifyForTheActionMessage("has been deleted sucessfully");
							userDeleteConfirmationPage.clickDoneButton();
							count = count + 1;
						} catch (Exception e) {
							userDeletePage.clickTopBackButton();
						}
						if (count != 0) {
							Cell cell = null;
							cell = lawwUsersSheet.getRow(i).getCell(optumIdsColumnIndex);
							CellStyle style = testDataWorkbook.workbook.createCellStyle();
							Font font = testDataWorkbook.workbook.createFont();
							cell.setCellValue(count + " users deleted successfully");
							font.setColor(HSSFColor.GREEN.index);
							style.setFont(font);
							cell.setCellStyle(style);
						}
	
					}
				}
	
			} catch (NullPointerException e) {
	
			}
			testDataWorkbook.fileIn.close();
			FileOutputStream output_file = new FileOutputStream(
					new File(PageObjectBase.getSystemVariable("test_data_Workbook_location")));
			testDataWorkbook.workbook.write(output_file);
			output_file.close();
		}
	}

}
