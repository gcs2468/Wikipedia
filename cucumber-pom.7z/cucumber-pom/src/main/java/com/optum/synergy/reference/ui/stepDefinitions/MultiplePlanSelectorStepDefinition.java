package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.MultiplePlanSelector;
import cucumber.api.java.en.Then;

public class MultiplePlanSelectorStepDefinition {
	private MultiplePlanSelector page;

	public MultiplePlanSelectorStepDefinition() {
		page = new MultiplePlanSelector();
	}

	@Then("^I should see that Member from \"([^\"]*)\" directed to \"([^\"]*)\"$")
	public void i_should_see_the_page_routed_to_valid_url_from_and_link(String pageName, String expectedPage)
			throws Throwable {
		Assert.assertEquals(page.getPagelinkFromTestDataXMLFile(pageName, expectedPage), page.getCurrentPageUrl());
	}

	@Then("^I should be at myUHC prelogin page$")
	public void iShouldBeAtMyUHCPreloginPage() throws Throwable {
		Assert.assertTrue("Issue while loading the Preloginpage", page.preLoginPage());
	}

	@Then("^I should see the following content in Multiple Plan Selector Page$")
	public void iShouldSeeTheFollowingContentInMultiplePlanSelectorPage(List<String> contentList) throws Throwable {
		String actualPageContent = page.contentAbovePlanList();
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\"" + " content is not displaying in the multiple plan sector page",
					actualPageContent.contains(content));
		}
	}

	@Then("^I should see the following labels in Multiple Plan Selector Page$")
	public void iShouldSeeTheFollowingLabelsInMultiplePlanSelectorPage(List<String> contentList) throws Throwable {
		String actualPageContent = page.planLabels();
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\"" + " content is not displaying in the multiple plan sector page",
					actualPageContent.contains(content));
		}
	}

	@Then("^I should see the Continue button in Multiple Plan Selector Page$")
	public void iShouldSeeTheContinueButtonInMultiplePlanSelectorPage() throws Throwable {
		Assert.assertTrue("Continue button is not displayed", page.getContinueButton().isDisplayed());
	}

}
