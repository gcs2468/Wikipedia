package com.optum.synergy.reference.ui.pageobjects;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.optum.synergy.reference.ui.utility.readXMLdata;

public class TestHarnessPage extends PageObjectBase {

	public static String page_url;

	public void openPage() throws FileNotFoundException, IOException, ParseException {
//		page_url = getEnvVariable("TestHarnessLoginUrl");
		page_url=readXMLdata.getTestData("TestHarness", "LoginUrl");
		openPage(page_url);
	}

	@FindBy(how = How.ID, using = "HTTP_TARGETPORTAL_INPUT")
	private WebElement targetPortal;

	@FindBy(how = How.XPATH, using = "//*[@id='HTTP_ACTION_INPUT']")
	private WebElement userAction;

	@FindBy(how = How.XPATH, using = "//*[@id='HTTP_ELIGIBILITY_INPUT']")
	private WebElement userEligibility;

	@FindBy(how = How.XPATH, using = "//*[@id='HTTP_LANGUAGE_INPUT']")
	private WebElement userLanguage;

	@FindBy(how = How.XPATH, using = "//*[@id='HTTP_ACCESSTYPE_INPUT']")
	private WebElement accessType;

	@FindBy(how = How.ID, using = "authQuestionSubmitButton")
	private WebElement clickHarnessSubmit;

	@FindBy(how = How.LINK_TEXT, using = "Register")
	private WebElement registerLink;

	public void enterTargetPortal(String tPortal) {
		Select targetDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(targetPortal)));
		targetDropdown.selectByVisibleText(tPortal);

	}

	public void enterTargetAction(String tAction) {
		Select actionDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(userAction)));
		actionDropdown.selectByVisibleText(tAction);
	}

	public void enterEligibility(String tEligibility) {
		Select eligibilityDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(userEligibility)));
		eligibilityDropdown.selectByVisibleText(tEligibility);
	}

	public void enterLanguage(String tLanguage) {
		Select languageDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(userLanguage)));
		languageDropdown.selectByVisibleText(tLanguage);
	}

	public void enterAccessType(String tAccesType) {
		Select accessTypeDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(accessType)));
		accessTypeDropdown.selectByVisibleText(tAccesType);
	}

	public void submitTestHarness() {
		clickHarnessSubmit.click();
	}

}
