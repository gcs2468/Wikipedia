package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ResetYourPasswordPage extends PageObjectBase {

	@FindBy(how = How.NAME, using = "accountInfo")
	private WebElement resetYourPasswordForm;

	@FindBy(how = How.ID, using = "header")
	private WebElement pageHeader;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'form__step1')]/div[@class='ng-binding']/p")
	private WebElement pageHeaderContent;

	@FindBy(how = How.XPATH, using = "//div[@ui-view='rightView']/div/div/p/a[contains(.,'register again')]")
	private WebElement registerAgainLinkInRightView;

	@FindBy(how = How.XPATH, using = "//label/span[@class='strong' and Contains(.,'Username')]/following-sibling::input[@id='username']")
	private WebElement userNameTextBoxWithLabel;

	@FindBy(how = How.XPATH, using = "//div[@ui-view='rightView']")
	private WebElement rightViewForm;
	
	@FindBy(how = How.XPATH, using = "//flex-content[@id='Logo']/p/a/img[@src='https://myoptum-stage.optum.com/content/dam/OptumDashboard/ad-box/logos/optum-logo.png']")
	private WebElement optumLogo;
	
	@FindBy(how = How.XPATH, using = "//img[contains(@src,'uhc_logo.gif']")
	private WebElement uhcLogo;


	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(resetYourPasswordForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyForPageHeader(String header)
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(pageHeader)).getText().trim().equals(header);
	}

	public boolean verifyFormContent(String content) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(resetYourPasswordForm));
		return resetYourPasswordForm.getText().contains(content);
	}

	public boolean verifyRightViewFormContent(String content) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(rightViewForm));
		return rightViewForm.getText().contains(content);
	}

	public boolean verifyReturnLinkOnHeaderBar(String link) {
		return mediumWait.get()
				.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//p[contains(@class,'header__return-bar')]/a[contains(.,'" + link + "')]")))
				.isDisplayed();
	}

	public void clickReturnLinkOnHeaderBar(String link) {
		mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//p[contains(@class,'header__return-bar')]/a[contains(.,'" + link + "')]"))).click();
	}

	public String getCaptchaImageSourceUrl() {
		mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@class='captcha__image']")));
		String captchaImageSourceUrl = mediumWait.get()
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@class='captcha__image']")))
				.getAttribute("src");
		return captchaImageSourceUrl;
	}

	public boolean verifyIfAudioPlayerDisplayed() {
		return mediumWait.get()
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//audio[contains(@src,'protected/captcha/voice')]")))
				.isDisplayed();
	}

	public boolean verifyIfRegisterAgainLinkInRightViewIsDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(registerAgainLinkInRightView)).isDisplayed();
	}

	public boolean verifyForUserNameTextBoxWithHeading(String heading) {
		return mediumWait.get()
				.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//input[@id='username']/preceding-sibling::span[contains(.,'" + heading + "')]")))
				.isDisplayed();

	}

	public boolean verifyForCaptchaTextBoxWithHeading(String heading) {
		return mediumWait.get()
				.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//input[@id='captcha1']/preceding-sibling::span[contains(.,'" + heading + "')]")))
				.isDisplayed();

	}
	
	public boolean verifyForTheOptumLogo()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(optumLogo)).isDisplayed();
	}
	public String getHeaderTextOfHeadingsAlongWithSteps(String stepNumber){
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath( "//*[contains(@class,'circle') and contains(text(),'"+stepNumber+"')]/parent::p/parent::flex-content/following-sibling::flex-content/h2"))).getText().trim();
		}
	public String getCSSValueIfHeaderBoldOrNotOfHeadingsAlongWithSteps(String stepNumber){
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath( "//*[contains(@class,'circle') and contains(text(),'"+stepNumber+"')]/parent::p/parent::flex-content/following-sibling::flex-content/h2"))).getCssValue("font-weight");
		}
}
