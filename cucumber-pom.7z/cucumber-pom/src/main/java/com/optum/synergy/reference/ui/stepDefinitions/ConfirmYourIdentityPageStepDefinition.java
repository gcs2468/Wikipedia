package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ConfirmYourIdentityPage_securityQuestions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConfirmYourIdentityPageStepDefinition {

	private ConfirmYourIdentityPage_securityQuestions page;
	public ConfirmYourIdentityPageStepDefinition() {
		page = new ConfirmYourIdentityPage_securityQuestions();
	}
	
	@Then("^I should be at Confirm your identity page$")
	public void i_should_be_at_Confirm_your_identity_page() throws Throwable {
	    Assert.assertTrue("Issue while loading the Confirm your identity page",page.verifyIfPageLoadedSQA());
	}
	
	@Then("^I should be at Confirm your identity through phone page$")
	public void i_should_be_at_Confirm_your_identity_through_phone_page() throws Throwable {
	    Assert.assertTrue("Issue while loading the Confirm your identity through phone page",page.verifyIfPageLoadedPhone());
	}

	@Then("^I should see Remember this device section is displayed$")
	public void i_should_see_Remember_this_device_section_is_displayed() throws Throwable {
		 Assert.assertTrue("Remember this device section is not displayed",page.verifyIfRememberThisDeviceSectionDisplayed());
	}
	
	@Given("^I click on the Submit button in Confirm your identity page$")
	public void i_click_on_the_Submit_button_in_Confirm_your_identity_page() throws Throwable {
		page.clickContinueButton();
	}

	@Then("^I should see a \"([^\"]*)\" button on Usermenu dropdown$")
	public void i_should_see_a_button_on_Usermenu_dropdown(String arg1) throws Throwable {
	    
	}

	@Given("^I check the Remember this device check box in Confirm your identity page$")
	public void i_check_the_Remember_this_device_check_box_in_Confirm_your_identity_page() throws Throwable {
	  page.clickRememberThisDeviceCheckbox();
	}
	
	@Then("^I enter valid security answer into Answer textbox$")
	public void i_enter_valid_security_answer_into_Answer_textbox() throws Throwable {
	    page.enterValidSecurityAnswer();
	}
	
	@Given("^I should see a radio button \"([^\"]*)\" in Confirm your identity page$")
	public void i_should_see_a_radio_button_in_Confirm_your_identity_page(String name) throws Throwable {
	    Assert.assertTrue("Issue while displaying the "+name+" radio button", page.verifyForRadioButton(name));
	}
	
	@Then("^I should see the text \"([^\"]*)\" on Confirm your identity page$")
	public void I_should_see_the_text_on_Confirm_your_identity_page(String message) throws Throwable {
	    Assert.assertTrue(page.verifyFormContent(message));
	}
	
	@Then("^I should see the help text \"([^\"]*)\" on Confirm your identity page$")
	public void I_should_see_the_help_text_on_Confirm_your_identity_page(String message) throws Throwable {
	    Assert.assertTrue(page.verifyForHelpMessage(message));
	}
	
	@When("^I manage the RBA page with security answer$")
	public void iManageTheRBAPageWithSecurityAnswer() throws Throwable {
	    if(page.verifyIfPageLoadedSQA()==true)
	    {
	    	page.enterValidSecurityAnswer();
	    	page.clickContinueButton();
	    }
	}

	@Then("^I should see the security question$")
	public void i_should_see_the_security_question() throws Throwable {
		Assert.assertTrue("Security question is not displaying in confirm your identity page",
				page.verifyIfSecurityQuestionIsDisplayed());
	}
}
