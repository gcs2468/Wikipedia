package com.optum.synergy.reference.ui.utility;

import java.io.IOException;
import java.util.Collection;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class HookDefinition {
	@After
	public void afterhook(Scenario scn) throws WebDriverException, IOException {

		// Wrap in try/finally block in case something is broken with driver
		// object
		// Want to ensure that is closed and nulled out for future use.
		try {
			scn.write(dataStorage.getCustomErrmsg());
			final byte[] screenshot = ((TakesScreenshot) DriverFactory.getDeviceDriver())
					.getScreenshotAs(OutputType.BYTES);
			scn.embed(screenshot, "image/png"); // ... and embed it in

		} finally {
			// Reset dataStorage values for next test using this thread
			// and return any ResourcePool data
			dataStorage.resetAllDataStorage();
			DriverFactory.closeDeviceDriver();
		}
	}

	@Before
	public void beforehook(Scenario scn) {

		Collection<String> Tags = scn.getSourceTagNames();
		//dataStorage.setScenarioName(scn.getId().substring(0, 8).toUpperCase() + "-" + scn.getName().replace(" ", "_"));

		String tagsclcnton = Tags.toString();
		//System.out.println("I am in before hook with tag collection [" + tagsclcnton + "]");

		if (tagsclcnton.toUpperCase().contains("@LAWW")) {
			dataStorage.setPortalName("LAWW");
		} else if (tagsclcnton.toUpperCase().contains("@HEN")) {
			dataStorage.setPortalName("HeN");
		} else if (tagsclcnton.toUpperCase().contains("@WCP")) {
			dataStorage.setPortalName("WCP");
		} else if (tagsclcnton.toUpperCase().contains("@MYUHC")
				|| tagsclcnton.toUpperCase().contains("@COMMUNITYANDSTATE")
				|| tagsclcnton.toUpperCase().contains("@MYHEALTHCAREVIEW")
				|| tagsclcnton.toUpperCase().contains("@HEALTHSELECT")) {
			dataStorage.setPortalName("MyUHC");
		} else if (tagsclcnton.toUpperCase().contains("@CAP")) {
			dataStorage.setPortalName("CAP");
		} else if (tagsclcnton.toUpperCase().contains("@GESSO")) {
			dataStorage.setPortalName("GESSO");
		} else if (tagsclcnton.toUpperCase().contains("@OPTUMRX")) {
			dataStorage.setPortalName("OptumRx");
		}

	}
}
