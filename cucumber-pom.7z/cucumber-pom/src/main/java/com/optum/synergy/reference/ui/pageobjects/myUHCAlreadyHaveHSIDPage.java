package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;


public class myUHCAlreadyHaveHSIDPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[starts-with(@ng-if,'alreadyHaveId')]")
	private WebElement alreadyHaveHSIDForm;
	
	@FindBy(how = How.XPATH, using = "//input[@id='PASSWORD']|//input[@id='hsid-password']")	
	private WebElement passwordTextBox;
	
	@FindBy(how = How.CLASS_NAME, using = "ng-scope")
	private WebElement contentLabels;
	
	@FindBy(how = How.XPATH, using = "//*[@id='Login']/div[@ng-if='hasUsername && isHSIDUser']/p[2]")
	private WebElement autoPopulatedUsernameOnAlreadyHaveHSIDPage;
	
	public boolean verifyIfAlreadyhaveHSIDPageLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((alreadyHaveHSIDForm))).isDisplayed();
	}
	
	public void enterPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
		passwordTextBox.clear();
		passwordTextBox.sendKeys(password);
	}
	
	public WebElement getContentLabels() {
		return contentLabels;
	}
	
	public String getAutoPopulatedUsernameFromAlreadyHaveHSIDPage() {	
		return mediumWait.get().until(ExpectedConditions.visibilityOf(autoPopulatedUsernameOnAlreadyHaveHSIDPage)).getText();	 
	}
	
}
