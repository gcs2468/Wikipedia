package com.optum.synergy.reference.ui.stepDefinitions;


import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.RxUnauthenticatedHomePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RxUnauthenticatedHomePageStepDefinition {
	private RxUnauthenticatedHomePage page;
	
	public RxUnauthenticatedHomePageStepDefinition() {
		page = new RxUnauthenticatedHomePage();
	}

	@Given("^I am at RX unauthenticated home page$")
	public void iAmAtRXUnauthenticatedHomePage() throws Throwable {
		page.openRXHomePage();
		Assert.assertTrue("Issue while loading the RX Unauthenticated page", page.getOptumRxUnauthenticatedPageelement().isDisplayed());
	}
	
	@When("^I click on Signin link in RxUnauthenticatedHomePage$")
	public void i_click_Signin_link_in_RxUnauthenticatedHomePage() throws Throwable {
		page.clickSigninLink();
	}
	
	@When("^I click on Register link in RxUnauthenticatedHomePage$")
	public void i_click_Register_link_in_RxUnauthenticatedHomePage() throws Throwable {
		page.clickRegisterLink();
	}
	
	@Then("^I should be at OptumRx unauthenticated page$")
	public void iShouldAtRXUnauthenticatedPage() throws Throwable {
		Assert.assertTrue("Issue while loading the RX Unathenticated page", page.getOptumRxUnauthenticatedPageelement().isDisplayed());
	}

}

