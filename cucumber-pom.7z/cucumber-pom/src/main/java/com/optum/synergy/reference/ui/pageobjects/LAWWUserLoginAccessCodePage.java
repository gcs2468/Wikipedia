package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class LAWWUserLoginAccessCodePage extends PageObjectBase{
        
        @FindBy(how = How.CLASS_NAME, using = "accesscode-content")
        private WebElement accessCodeEnteringSection;

        @FindBy(how = How.ID, using = "accesscode--company--selection")
        private WebElement accessCodeCompanyDropdown;
        
        @FindBy(how = How.ID, using = "accesscode--button")
        private WebElement continueButton;
        
        public boolean verifyIfPageLoaded() {
        	try {
	        	waitForPageLoad(driver);
	        	return mediumWait.get().until(ExpectedConditions.visibilityOf(accessCodeEnteringSection)).isDisplayed();
        	} catch (TimeoutException e) {
    			return false;
    		}
        }
        
        public void selectProviderFromMyBenefitsAreProvidedThroughList(String accessCodeCompany)
        {
                Select dropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(accessCodeCompanyDropdown)));
                dropdown.selectByVisibleText(accessCodeCompany);
        }
        
        public void clickOnContinueButton()
        {
        	mediumWait.get().until(ExpectedConditions.visibilityOf(continueButton)).click();
        }
}	