package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAdminPortalUserDeleteConfirmationPage extends PageObjectBase{
	
	@FindBy(how = How.ID, using = "admindeleteConfirmFormId")
	private WebElement userDeleteConfirmationForm;
	
	@FindBy(how = How.XPATH, using = "//input[@class='btnprimary' and @value='Confirm Delete']")
	private WebElement confirmDeleteButton;
	
	@FindBy(how = How.LINK_TEXT, using = "Back")
	private WebElement topBackButton;
	
	@FindBy(how = How.ID, using = "actionmessge")
	private WebElement actionMessge;
	
	@FindBy(how = How.XPATH, using = "//input[@class='btnprimary' and contains(@value, 'Done')]")
	private WebElement donebutton;
	
	
	@FindBy(how = How.XPATH, using = "//a[@href='/adminhome.laww']")
	private WebElement homelink;
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(userDeleteConfirmationForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void clickConfirmDeleteButton()
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmDeleteButton));
		confirmDeleteButton.click();
	}
	public void clickTopBackButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(topBackButton));
		topBackButton.click();
	}
	
	public boolean verifyForTheActionMessage(String messsage){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(actionMessge)).getText().contains(messsage);
	}
	
	public void clickDoneButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(donebutton));
		donebutton.click();
	}
	public void clickHomeLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(homelink));
		homelink.click();
	}
}
