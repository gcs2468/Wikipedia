package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class UpdateYourAccountRecoverySettingsPage extends PageObjectBase  {
	
	@FindBy(how = How.XPATH, using = "//*[@id='usermenu']/a")
	private WebElement userNameMenu;
	
	@FindBy(how = How.XPATH, using = "//*[@id='usermenu']//a[text()='Sign In & Security']")
	 private WebElement clickSignInSecurity;
	
	@FindBy(how = How.CLASS_NAME, using = "account_settings")
	private WebElement updateSecuritySettingsSection;
	
	@FindBy(how = How.ID, using = "email")
	private WebElement updateEmailAddrSection;
	
	@FindBy(how = How.ID, using = "currentPassword")
	private WebElement currentPasswordTextBox;
	
	@FindBy(how = How.XPATH, using = "//div[@class='ng-binding']/h1")
	private WebElement pageHeader;
	
	@FindBy(how = How.ID, using = "phoneNo")
	private WebElement phoneNum;
	
	@FindBy(how = How.ID, using = "noPhone")
	private WebElement noPhone;
	
	@FindBy(how = How.NAME, using = "recovery")
	private WebElement securityQuestionsRecoveryForm;
	
	@FindBy(how = How.XPATH, using = "//input[@id='noPhone']/following-sibling::label[contains(.,'rather not provide a phone number')]")
	private WebElement noPhoneCheckboxWithLabel;	
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'New phone number')]/following-sibling::input[@id='phoneNo']")
	private WebElement newPhoneNumberLabelWithTextbox;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Enter your current password')]/following-sibling::input[@id='currentPassword']")
	private WebElement enterYourCurrentPasswordLabelWithTextbox;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'New password')]/following-sibling::input[@id='password']")
	private WebElement newPasswordLabelWithTextbox;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Confirm new password')]/following-sibling::input[@id='confirmPassword']")
	private WebElement confirmNewPasswordLabelWithTextbox;
		
	@FindBy(how = How.XPATH, using = ".//*[@id='password']")
	private WebElement newPwdField ;
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmPassword']")
	private WebElement confirmPwdField ;
	
	@FindBy(how = How.CLASS_NAME, using = "row-fluid")
	private WebElement updatedPwd ;
	
	@FindBy(how = How.CLASS_NAME, using = "radio")
	private WebElement confirmPhNoRadio ;
	
	@FindBy(how = How.XPATH, using = "//div[@class='ruletip']")
	private WebElement passwordRules;
	
	@FindBy(how = How.CLASS_NAME, using = "success-text")
	private WebElement phoneNoVisualQSuccessConfirmation;
	
	@FindBy(how = How.ID, using = "phoneType")
	private WebElement phoneTypeVal;


	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(updateSecuritySettingsSection)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void selectPhoneType(String val){
		Select phoneType= new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(phoneTypeVal)));
		phoneType.selectByVisibleText(val);
	}
	
	public void clickUserMenu(String uDropdown) {
		Select userDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(userNameMenu)));
		userDropdown.selectByVisibleText(uDropdown);
		}
	
	public boolean verifyUserNameMenuDropDownDisplayed() {
		//mediumWait.get().until(ExpectedConditions.visibilityOf(recoverySection));
		return mediumWait.get().until(ExpectedConditions.visibilityOf(userNameMenu)).isDisplayed();
	}

	public void clickOnUserMenuDropDown(){
		smallWait.get().until(ExpectedConditions.visibilityOf(userNameMenu));
		userNameMenu.click();
	
	}
	
	public void clickPhoneCheckbox() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(noPhone)).click();
	}
	
	public void submitSignInSecurity() {
		clickSignInSecurity.click();
	}
	
	public void updateNewEmail(String email)
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(updateEmailAddrSection));
		updateEmailAddrSection.clear();
		updateEmailAddrSection.sendKeys(email);
	}
	
	// to find button is Enabled
	public boolean findBtnIsEnabled(String expectedLinkText) {
		return findBtnIsEnabled(expectedLinkText);

	}
	
	public boolean verifyErrorMessageOnSecurityQuestion1(String message) {

		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//select[@id='q1']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnSecurityQuestion2(String message) {

		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//select[@id='q2']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	public boolean verifyErrorMessageOnSecurityQuestion3(String message) {

		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//select[@id='q3']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnSecurityAnswer1(String message) {

		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='a1']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnSecurityAnswer2(String message) {

		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='a2']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnSecurityAnswer3(String message) {

		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='a3']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnUpdateNewEmail(String message) {

		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='email']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyNewEmailFieldIsNotDisplayed(){
		
		try{
		 smallWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id("email")));
		 return false;
		}
		catch(TimeoutException e)
		{
			return true;
		}
	}
	
	public boolean verifyLinkIsNotDisplayed(String linkText){
		return getAnchorElementByText(linkText)==null;
	}
	
/*	public void enterCurrentPassword(String currentPassword)
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(currentPwdField));
		currentPwdField.clear();
		currentPwdField.sendKeys(currentPassword);
	}
	*/
	public void enterNewPassword(String newpassword)
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(newPwdField));
		newPwdField.clear();
		newPwdField.sendKeys(newpassword);
	}
	
	public void enterConfirmNewPassword(String confirmPassword)
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPwdField));
		confirmPwdField.clear();
		confirmPwdField.sendKeys(confirmPassword);
	}
	
	public boolean verifyErrForOldPwdWrong(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[contains(@class,'error-text') and contains(.,'"+message+"')]")))
				.isDisplayed();	
	}
	
	public boolean verifyUpdatedVIsualq(String message) {
		
		return updatedPwd.getText().contains(message);
//		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
//				By.xpath("//p[contains(@class,'pwdUpdated') and contains(.,'"+message+"')]")))
//				.isDisplayed();
	}
	
	public boolean verifyRuleTipMessage(String message) {
		
		return passwordRules.getText().contains(message);
		
	}
	
	public boolean verifyErrorInvalidNewPwd(String message) {

		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='password']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorInvalidConfirmPwd(String message) {

		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='confirmPassword']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyNoPhoneCheckboxDisplayed() {
		//mediumWait.get().until(ExpectedConditions.visibilityOf(recoverySection));
		return smallWait.get().until(ExpectedConditions.visibilityOf(noPhone)).isDisplayed();
	}
	
	public boolean verifyErrorNewPhoneNo(String message) {
////input[@id='phoneNo']/following-sibling::p[contains(@class,'error') and contains(.,'"+ message + "')]
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='phoneNo']/following-sibling::p[contains(@class,'error') and contains(.,'"+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyPhoneConfirmationSuccessVisualQ(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(phoneNoVisualQSuccessConfirmation));
		return phoneNoVisualQSuccessConfirmation.getText().contains(message);
	}
	
	public boolean verifyPhoneErrorConfirmation(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//i[contains(@class,'error')]/following-sibling::span[contains(.,'"+ message +"')]")))
				.isDisplayed();
	}
	
	public boolean verifyConfirmPhoneRadio(String message) {
		
		return confirmPhNoRadio.getText().contains(message);
		
	}
	
	public boolean verifyEmailWithLink(String email, String link ) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[@class='ng-binding' and contains(.,'"+ email +"')]/a[contains(.,'"+ link +"')]")))
				.isDisplayed();
	}
	
	public boolean verifyIfNewEmailDisplayedInReadOnly(String mail)
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(.,'New email')]/following-sibling::p[contains(.,'"+mail+"')]"))).isDisplayed();
		
	}
	
	public boolean verifyLinkForNewEmail(String link)
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(.,'New email')]/following-sibling::p/a[contains(.,'"+link+"')]"))).isDisplayed();
	}
	
	public boolean verifyConfirmationStatusForNewEmail(String status)
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(.,'New email')]/following-sibling::span[contains(.,'"+status+"')]"))).isDisplayed();
	}
	public boolean verifyPageHeader(String header){
		mediumWait.get().until(ExpectedConditions.visibilityOf(pageHeader));
		return pageHeader.getText().contains(header);	
	}
	public boolean verifyIfNewPhoneNumberLabelWithTextboxExist()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(newPhoneNumberLabelWithTextbox)).isDisplayed();
		
	}
	
	public boolean verifyIfEnteryourcurrentpasswordLabelWithTextboxExist()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(enterYourCurrentPasswordLabelWithTextbox)).isDisplayed();
		
	}
	
	public boolean verifyIfNewpasswordLabelWithTextboxExist()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(newPasswordLabelWithTextbox)).isDisplayed();
		
	}
	
	public boolean verifyIfConfirmnewpasswordLabelWithTextboxExist()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmNewPasswordLabelWithTextbox)).isDisplayed();
		
	}
	
	public boolean verifyForSuccessText(String status ) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//i[contains(@class,'success-text')]/following-sibling::span[contains(.,'"+status+"')]")))
				.isDisplayed();
	}
	
	public void enterCurrentPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(currentPasswordTextBox));
		currentPasswordTextBox.clear();
		currentPasswordTextBox.sendKeys(password);
	}
	
	public void enterPhoneNumber(String text){
		mediumWait.get().until(ExpectedConditions.visibilityOf(phoneNum));
		phoneNum.clear();
		phoneNum.sendKeys(text);
	}
	
	public boolean verifyPhoneNumberVisualQueueStatus(String status){
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//div[contains(@class,'mt30')]/h2[contains(.,'Phone number')]/following-sibling::p/span/span[contains(.,'"+status+"')]")))
				.isDisplayed();
	}
	
	public boolean verifyIfIWouldNotProvideAPhoneNumberCheckBoxIsDisplayed()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(noPhoneCheckboxWithLabel)).isDisplayed();
	}
	
	public boolean verifyIfSecurityQuestionsRecoveryFormDisplayed()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestionsRecoveryForm)).isDisplayed();
	}
	
}