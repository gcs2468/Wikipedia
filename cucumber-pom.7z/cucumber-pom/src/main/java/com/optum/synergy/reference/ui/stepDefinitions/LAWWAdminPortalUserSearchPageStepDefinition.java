package com.optum.synergy.reference.ui.stepDefinitions;


import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalUserSearchPage;

import cucumber.api.java.en.Then;

public class LAWWAdminPortalUserSearchPageStepDefinition {

	
	
	private LAWWAdminPortalUserSearchPage page;

	public LAWWAdminPortalUserSearchPageStepDefinition() {
		page = new LAWWAdminPortalUserSearchPage();
	}

	
	@Then("I search for member ^\"([^\"]*) ([^\"]*)\" in LAWW admin portal$")
	public void foo(String FirstName, String LastName) {
		
		Assert.assertTrue("Failed to display LAWW admin search page", page.verifyIfPageLoaded());
		page.enterUserFirstName(FirstName);
		page.enterUserLastName(LastName);
		page.clickSearchButton();
	}
	
}