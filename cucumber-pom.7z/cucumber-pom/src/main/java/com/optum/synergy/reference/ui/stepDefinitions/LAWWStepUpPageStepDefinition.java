package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.LAWWStepUpPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LAWWStepUpPageStepDefinition {
	private LAWWStepUpPage page;

	public LAWWStepUpPageStepDefinition() {
		page = new LAWWStepUpPage();
	}
	
	@Then("^I click on \"([^\"]*)\" benefits dropdown$")
	public void iClickOnBenefitsDropdown(String arg1) throws Throwable {
		 page.clickOnBenefitProviderDropDown();
	}

	@Then("^I select \"([^\"]*)\" as benefitproviders$")
	public void iSelectAsBenefitproviders(String providerName) throws Throwable {
	 page.selectBenefitProvider(providerName);
	}
	
	@Given("^I click on \"([^\"]*)\" button in Access code page$")
	public void i_click_on_button_in_Access_code_page(String arg1) throws Throwable {
	   page.clickOnAccessCodeContinuBtn();
	}
	
	@Then("^I click on Benefits & Claims$")
	public void iClickOnBenefitsClaims() throws Throwable {
	  page.benefitsAndClaimsClick();
	}

	@Then("^I click on View Claim Status link$")
	public void iClickOnViewClaimStatusLink() throws Throwable {
	   page.viewClaimsStatusClick();
	}
	
	@Then("^I should be at View claims page$")
	public void iShouldBeAtViewClaimsPageBe() throws Throwable {
		Assert.assertTrue("Laww View Claim status page is not displayed as expected",
				page.verifyViewClaimStatusLabel());
	}
	
	@Then("^I click on behavioral Health Coverage link$")
	public void iClickOnbehavioralHealthCoverageLink() throws Throwable {
	   page.behaviouralHealthCoverageClick();
	}

	@Then("^I should be at We need you to verify your information page$")
	public void iShouldBeAtWeNeedYouToVerifyYourInformationPage() throws Throwable {
	   page.verifyIfPageLoaded();
	}
	
	@Then("^I should see an error message \"([^\"]*)\" $")
	public void iShouldSeeAnErrorMessage(String message) throws Throwable {
		page.verifyErrorMessageOnAccessNotConfirmed(message);
	    
	}
	
	@Then("^I should see an MDM error message \"([^\"]*)\"$")
	public void i_should_see_an_MDM_error_message(String message) throws Throwable {
	    Assert.assertEquals(message, page.getMDMErrorMessage());
	}

}
