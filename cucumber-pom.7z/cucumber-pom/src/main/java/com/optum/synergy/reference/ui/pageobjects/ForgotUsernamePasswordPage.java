package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ForgotUsernamePasswordPage extends PageObjectBase {

	@FindBy(how = How.ID, using = "username")
	private WebElement userNameTextBox;

	@FindBy(how = How.ID, using = "email")
	public WebElement enterEmailField;

	@FindBy(how = How.ID, using = "captcha1")
	private WebElement captchaTextBox;

	@FindBy(how = How.NAME, using = "accountInfo")
	private WebElement resetPasswordForm;

	@FindBy(how = How.XPATH, using = "//form[@name='personalInfo']")
	private WebElement recoverYourUserNameForm;

	// @FindBy(how = How.XPATH, using =
	// "//label[@for='captcha1']/img[@class='captcha__image']")
	@FindBy(how = How.XPATH, using = "//img[@class='captcha__image']")
	private WebElement captchaImg;

	@FindBy(how = How.XPATH, using = "//audio")
	private WebElement audioElement;

	public void enterUserName(String username) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
		userNameTextBox.clear();
		userNameTextBox.sendKeys(username);
	}

	public void enterCaptcha(String captcha) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(captchaTextBox));
		captchaTextBox.clear();
		captchaTextBox.sendKeys(captcha);
	}

	public void clearEmailField() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(enterEmailField));
		enterEmailField.clear();
	}

	public void enterEmail(String EmailAddress) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(enterEmailField));
		enterEmailField.sendKeys(EmailAddress);
	}

	public void clickResetPasswordInfoForm() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(resetPasswordForm));
		resetPasswordForm.click();
	}

	public void clickRecoverUsernameInfoForm() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(recoverYourUserNameForm));
		recoverYourUserNameForm.click();
	}

	public boolean verifyErrorMessageOnUsername(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='username']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}

	public boolean verifyNoErrorMessageOnUsername() {

		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//input[@id='username']/following-sibling::span[contains(@class,'error')]")))
				.isDisplayed() == false;
	}

	public boolean verifyErrorMessageOnCaptcha(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='captcha1']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}

	public boolean verifyNoErrorMessageOnCaptcha() {

		try {
			smallWait.get().until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//input[@id='captcha1']/following-sibling::span[contains(@class,'error')]")));
			return false;
		} catch (TimeoutException e) {
			return true;
		}

	}

	public boolean verifyErrorMessageOnEnterEmail(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'error') and contains(.,'" + message + "')]"))).isDisplayed();
	}

	public boolean verifyNoErrorMessageOnEnterEmail() {
		boolean noMessage = false;
		try {

			if (smallWait.get().until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(@class,'error')"))) == null)
				noMessage = true;
		} catch (TimeoutException e) {
			noMessage = true;

		}
		return noMessage;
	}

	public String getCaptchaSource() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(captchaImg));
		return captchaImg.getAttribute("src");

	}

	public boolean verifyIfCaptchImgExist() throws InterruptedException {
		Thread.sleep(5000);
		return mediumWait.get().until(ExpectedConditions.visibilityOf(captchaImg)).isDisplayed();

	}

	public boolean verifyAudioExist() throws InterruptedException {
		Thread.sleep(1000);
		return mediumWait.get().until(ExpectedConditions.visibilityOf(audioElement)).isDisplayed();

	}
}
