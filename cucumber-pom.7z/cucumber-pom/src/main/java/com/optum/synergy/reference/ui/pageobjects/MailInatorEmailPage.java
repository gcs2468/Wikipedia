package com.optum.synergy.reference.ui.pageobjects;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MailInatorEmailPage extends PageObjectBase {

	public MailInatorEmailPage() {
		
	}
	
	@FindBy(how = How.XPATH, using = "html/body/p")
	private List<WebElement> contentList;
	
	@FindBy(how = How.XPATH, using = "html/body")
	private WebElement formContent;
	
/** -----------------------  New Methods -------------------------  **/	
	public void switchToMailContentInFrame()
	{
		switchToFrameByNameOrId("publicshowmaildivcontent");
	}
	
	public boolean verifyForContent(String content)
	{
		
		return formContent.getText().contains(content);
		}
	
	public void switchToMailDefaultContent()
	{
		switchToDefaultContent();
	}

/** -------------------- Previous Methods ------------------------ **/	
	
	public boolean openMailInatorPageInNewTab(String url) {
		boolean isPageOpened = false;
		// openPage(url);
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(0));

		driver.get(url);
		try {
			//clickOnALinkByhrefPartialText(url);
			Assert.assertTrue(verifyElementById("inboxfield"));
			isPageOpened = true;
		} catch (NoSuchElementException e) {
			try{
			Assert.assertTrue(clickOnALinkByhrefPartialText(url));
			verifyElementById("inboxfield");
			isPageOpened = true;
			}
			catch(NoSuchElementException e1){
				Assert.assertTrue(clickOnALinkByhrefPartialText(url));
				verifyElementById("inboxfield");
				isPageOpened = true;
			}
		}
		catch(AssertionError e){
			
		}

		return isPageOpened;
	}
	public boolean openMailInatorPage(String url) {
		boolean isPageOpened = false;
      openPage(url);
	try {
			driver.navigate().refresh(); // sravan, added for refresh
			verifyElementById("inboxfield");
			isPageOpened = true;
		} catch (Exception e) {
			try{
			Assert.assertTrue(clickOnALinkByhrefPartialText(url));
			driver.navigate().refresh();                                   // sravan, added for refresh
			verifyElementById("inboxfield");
			isPageOpened = true;
			}
			catch(Exception e1)
			{Assert.assertTrue(clickOnALinkByhrefPartialText(url));
			verifyElementById("inboxfield");
			isPageOpened = true;
				
			}
		}

		return isPageOpened;
	}


	public boolean setEmail(String email) {
		boolean isMailSet = false;
		enterValueById("inboxfield", email);
		// clickElementByClassNameAndText("btn-dark", "Go!");
		clickButtonByText("Go!");
		isMailSet = true;
		return isMailSet;
	}

	public boolean clickOnAMailRow(String text) {
			//return clickElementByClassNameAndText("row", text);
		try{
		new WebDriverWait(driver,30).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'row') and contains (.,'"+text+"')]/div[2]/div[5]"))).click();
		return true;
		}
		catch(Exception e)
		{
			new WebDriverWait(driver,30).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'row') and contains (.,'"+text+"')]/div[2]/div[5]"))).click();
			return true;
		}
		
	}

	public boolean verifyForAnEmailWithText(String text) {
		return verifyTextByClassName("row", text);
	}

	public boolean verifyIfLoginSectionAndThankYouMessageAppearedInNewTab(String text) {
		String window = driver.getWindowHandle();
		try {
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			System.out.println("Toatl no of tabs: " + tabs.size());
			driver.switchTo().window(tabs.get(1));
			Thread.sleep(10000);
			Assert.assertTrue(verifyElementById("Login"));
			Assert.assertTrue(verifyTextByClassName("form__content", text));
			// Assert.assertTrue(verifyIfAParagraphMessageExist(text));
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			driver.switchTo().window(window);
			driver.navigate().refresh();
		}
	}
	public boolean verifyIfLoginSectionAndThankYouMessageAppearedInNewTabAndContinue(String text) {
		try {
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			System.out.println("Toatl no of tabs: " + tabs.size());
			driver.switchTo().window(tabs.get(1));
			Thread.sleep(10000);
			Assert.assertTrue(verifyElementById("Login"));
			Assert.assertTrue(verifyTextByClassName("form__content", text));
			// Assert.assertTrue(verifyIfAParagraphMessageExist(text));
			return true;
		} catch (Exception e) {
			return false;
		} 
	}

	public boolean clickOnGoButton() {
		return clickButtonByTypeAndTitle("Go!");
	}

	public void refreshMailPage() {
		driver.navigate().refresh();
	}

	public boolean clickOnEmailLink(String link) {
		try {
			driver.switchTo().frame("publicshowmaildivcontent");
			clickLink(link);
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			driver.switchTo().defaultContent();
		}
	}

	public boolean VerifyEmailLink(String link) {
		try {
			driver.switchTo().frame("publicshowmaildivcontent");
			return findLinkText(link);

		} catch (Exception e) {
			return false;
		} finally {
			driver.switchTo().defaultContent();
		}
	}

	public boolean VerifyEmailBodyContent(String content) {
		boolean isExist=false;
		driver.navigate().refresh();
		
	//	driver.switchTo().activeElement();
		
		try{
			driver.switchTo().frame(new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(By.id("publicshowmaildivcontent"))));
		//System.out.println(driver.findElement(By.tagName("body")).getText());
			List<WebElement> plist = new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("html/body/p")));
	//	List<WebElement> plist=driver.findElements(By.xpath("html/body/p"));
		for (WebElement p : plist) {
				System.out.println(p.getText());
				if (p.getText().contains(content)) {
					isExist= true;
				}
				break;
			}
		}
		catch(Exception e){
			isExist= false;
		}
		finally{
		driver.switchTo().defaultContent();
		}
		return isExist;
					
	}
	
	public boolean verifyTheEmailMetaDataContents(String detailName, String detailValue)
	{
		
		WebElement elem=new WebDriverWait(driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='publicShowMailCtrl']/table/tbody/tr/td[contains(.,'"+detailName+"')]/following-sibling::td[contains(.,'"+detailValue+"')]")));
		return elem !=null;
	}

}

