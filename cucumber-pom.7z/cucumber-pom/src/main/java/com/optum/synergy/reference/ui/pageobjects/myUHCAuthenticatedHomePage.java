package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class myUHCAuthenticatedHomePage extends PageObjectBase {
	
	@FindBy(how = How.ID, using = "homeprintContent")
	private WebElement homePageContent;
	
	@FindBy(how = How.XPATH, using = ".//img[contains(@src,'X-Close')]")
	private WebElement rallyPopUpCloseButton;
	
	public String getMyUHCAuthenticatedPageTitle()
	{
		return getPageTitle();
	}
	
	public boolean verifyIfHomePageContentIsDisplayed()
	{
		return longWait.get().until(ExpectedConditions.visibilityOf(homePageContent)).isDisplayed();
	}
	
	public boolean verifyIfRallyPopUpDisplayedAtMyUhcAuthenticatedHomePage()
	{
		
		waitForPageLoad(driver);
		try
		{	switchToFrameByNameOrId("floatingframe");		
			return mediumWait.get().until(ExpectedConditions.visibilityOf(rallyPopUpCloseButton)).isDisplayed();
		}
		catch(TimeoutException e)
		{
			return false;
		}
		catch(NoSuchFrameException i)
		{
			return false;
		}
	}
	
	public void closeRallyPopUpMyUhcAuthenticatedHomePage()
	{
		rallyPopUpCloseButton.click();
		//Wait for pop-up modal to go away
		smallWait.get().until(ExpectedConditions.invisibilityOfElementLocated(By.id("floatingframe")));
	}
}