package com.optum.synergy.reference.ui.pageobjects;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readXMLdata;

public class HeNUnauthenticatedHomePage extends PageObjectBase {
	@FindBy(how = How.CLASS_NAME, using = "intro")
	private WebElement unauthenticatedView;

	@FindBy(how = How.XPATH, using = "//a[contains(@class,'btn--primary') and contains(.,'Sign In')]")
	private WebElement signInButton;

	@FindBy(how = How.XPATH, using = "//img[contains(@alt,'HealtheNotes')]")
	private WebElement HenLogo;
	
	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo']")
	private WebElement brandLogoforHeN;
	
	@FindBy(how = How.LINK_TEXT, using = "Register")
	private WebElement registerLink;

	public void clickHenLogo() {
		HenLogo.click();
	}

	public void openPage() throws FileNotFoundException, IOException, ParseException {
		driver.manage().deleteAllCookies();
		String page_url = readXMLdata.getTestData(dataStorage.getPortalName(), "AppURL");
		openPage(page_url);
	}

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(unauthenticatedView)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void clickOnSignInButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(signInButton)).click();
	}

	public boolean verifyHeNBrandLogoIsDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(brandLogoforHeN)).isDisplayed();
	}

	public boolean verifyHeNTitleOnStep3RegisterationPage(String message) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//div[@class='navbar-header uhc-logo']/h1[contains(.,'" + message + "')]")))
				.getText().equalsIgnoreCase(message);
	}

	public boolean verifyHeNaunthenticatedHomePage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(registerLink)).isDisplayed();
	}

}
