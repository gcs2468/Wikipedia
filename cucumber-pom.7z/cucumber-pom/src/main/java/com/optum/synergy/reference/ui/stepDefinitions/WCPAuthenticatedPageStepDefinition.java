package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ConfirmYourIdentityPage_securityQuestions;
import com.optum.synergy.reference.ui.pageobjects.WCPAuthenticatedPage;

import cucumber.api.java.en.Then;

public class WCPAuthenticatedPageStepDefinition {
	private WCPAuthenticatedPage page;	
	
	public WCPAuthenticatedPageStepDefinition() {
		page = new WCPAuthenticatedPage();
	}
	
//	@Then("^I should see usermenu dropdown on global nav bar$")
//	public void i_should_see_usermenu_dropdown_on_global_nav_bar() throws Throwable {
//		Assert.assertTrue("Usermenu on Global Nav bar has not displayed", page.verifyIfUserMenuDisplayedOnGlobalNav());
//		
//	}
	@Then("^I should be at WCP Authenticated page$")
	public void i_should_be_at_WCP_Authenticated_page() throws Throwable {
		Thread.sleep(2000);
		Assert.assertTrue("Issue while loading the authenticated page", page.verifyIfUserMenuDisplayedOnGlobalNav());
		
	}
	
	@Then("^I should landed into Authenticated WCP Home Page$")
	public void i_should_landed_into_Authenticated_WCP_Home_Page() throws Throwable {
		//NOTE: copied from LAWWAUthenticatedPage
		
		//TODO: Should eventually remove this step Def and have feature files explicitly handle 
		//  potential landing on security question page.  For now, keep (for backward compatibility 
		//	with existing feature files) with simpler handling
		ConfirmYourIdentityPage_securityQuestions confirmIdentityPage = new ConfirmYourIdentityPage_securityQuestions();
		if ( confirmIdentityPage.verifyIfPageLoadedSQA() ) {
			confirmIdentityPage.handleSecurityQuestionWithAnswer();	// Fill in default security question answer, click continue			
		}
		
	}
	
	@Then("^I should be on Wellness Coaching Home Page$")
	public void iShouldBeOnWellnessCoachingHomePage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals("Wellness Coaching", page.getPageHeading());
	}
}
