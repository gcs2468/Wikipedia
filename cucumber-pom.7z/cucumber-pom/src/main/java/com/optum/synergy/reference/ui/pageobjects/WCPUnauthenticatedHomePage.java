package com.optum.synergy.reference.ui.pageobjects;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readXMLdata;

public class WCPUnauthenticatedHomePage extends PageObjectBase {
	
	@FindBy(how = How.CLASS_NAME, using = "container-content")
	private WebElement unathenticatedView;

	@FindBy(how = How.XPATH, using = "//a[contains(@class,'btn--secondary') and contains(.,'Sign In')]")
	private WebElement signInButton;
	
	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo']")
	private WebElement brandLogoforWCP;
	
	@FindBy(how = How.LINK_TEXT, using = "Register")
	private WebElement registerLink;

	public void openPage() throws FileNotFoundException, IOException, ParseException {

		String page_url = readXMLdata.getTestData(dataStorage.getPortalName(), "AppURL");
		openPage(page_url);
	}

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(unathenticatedView)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void clickOnSignInButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(signInButton)).click();
	}

	public boolean verifyWCPBrandLogoIsDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(brandLogoforWCP)).isDisplayed();
	}

	public boolean verifyWCPTitleOnStep3RegisterationPage(String message) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//div[@class='navbar-header optum-logo']/h1[contains(.,'" + message + "')]")))
				.getText().equalsIgnoreCase(message);
	}

	public boolean verifyWCPaunthenticatedHomePage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(registerLink)).isDisplayed();
	}
}
