package com.optum.synergy.reference.ui.pageobjects;


import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ConfirmYourIdentityPage_securityQuestions extends PageObjectBase {

	/*
	 * @FindBy(how = How.ID, using = "userCommand") private WebElement
	 * confirmYourIdentityForm;
	 */

	@FindBy(how = How.CLASS_NAME, using = "form__content")
	private WebElement formContent;
	
	@FindBy(how = How.ID, using = "authQuestionWrapper")
	private WebElement confirmYourIdentityFormSQA;
	
	@FindBy(how = How.ID, using = "authoobWrapper")
	private WebElement confirmYourIdentityFormPhone;

	@FindBy(how = How.CLASS_NAME, using = "rememberThisDevice")
	private WebElement rememberThisDeviceSection;

	@FindBy(how = How.ID, using = "continueSubmitButton")
	private WebElement continueButton;

	@FindBy(how = How.ID, using = "remembermydevice")
	private WebElement rememberThisDeviceCheckBox;
	
	
	@FindBy(how = How.ID, using = "helpText")
	private WebElement helptext;
	
	@FindBy(how = How.XPATH, using = "//img[@src='https://myoptum-stage.optum.com/content/dam/OptumDashboard/ad-box/logos/myuhc.gif']")
	private WebElement myUhcLogo;
	

	
	public boolean verifyIfPageLoadedSQA() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmYourIdentityFormSQA)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyIfPageLoadedPhone() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmYourIdentityFormPhone)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean verifyFormContent(String content)
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(formContent)).getText().contains(content);
	}
	
	public boolean verifyIfRememberThisDeviceSectionDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(rememberThisDeviceSection)).isDisplayed();
	}
	public boolean verifyIfSecurityQuestionIsDisplayed()
	{
		return mediumWait.get()
		.until(ExpectedConditions.presenceOfElementLocated(By.id("authQuestiontextLabelId"))).isDisplayed();
	}
	public void clickContinueButton() throws InterruptedException {
		longWait.get().until(ExpectedConditions.visibilityOf(continueButton));
		continueButton.click();
	}

	public void clickRememberThisDeviceCheckbox() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(rememberThisDeviceCheckBox));
		rememberThisDeviceCheckBox.click();
	}

	public void enterValidSecurityAnswer() throws Exception {
		Thread.sleep(1000);
		String SecurityQtn = mediumWait.get()
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("authQuestiontextLabelId"))).getText();
		WebElement answerField = mediumWait.get()
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("challengeQuestionList[0].userAnswer")));
		answerField.clear();
		formContent.click();
		
		if (SecurityQtn.contains("number")) {
			answerField.sendKeys("number1");
		} else if (SecurityQtn.contains("name")) {
			answerField.sendKeys("name1");
		} else if (SecurityQtn.contains("team")) {
			answerField.sendKeys("team1");
		} else if (SecurityQtn.contains("color")) {
			answerField.sendKeys("color1");
		} else {
			throw new Exception("unknown challenge " + SecurityQtn);
		}
		formContent.click();
	}

	public boolean verifyForRadioButton(String name) {
		return mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'radio') and contains(.,'"+name+"')]"))).isDisplayed();
	}
	
	public boolean verifyForHelpMessage(String message){
		mediumWait.get().until(ExpectedConditions.visibilityOf(helptext));
		return helptext.getText().contains(message);
	}

}
