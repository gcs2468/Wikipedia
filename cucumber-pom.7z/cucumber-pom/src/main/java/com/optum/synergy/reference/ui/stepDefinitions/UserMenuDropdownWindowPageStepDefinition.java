package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.UserMenuDropdownWindowPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserMenuDropdownWindowPageStepDefinition {
	private UserMenuDropdownWindowPage page;

	public UserMenuDropdownWindowPageStepDefinition() {
       page = new UserMenuDropdownWindowPage();
    }
    
    @Then("^I should see a Sign out button on Usermenu dropdown$")
    public void i_should_see_a_Sign_out_button_on_Usermenu_dropdown() throws Throwable {
        Assert.assertTrue("Issue while displaying the Sign out button", page.verifyIfSignoutButtonIsDisplayed());
    }

    @When("^I click on Sign out button on Usermenu dropdown$")
    public void i_click_on_Sign_out_button_on_Usermenu_dropdown() throws Throwable {
        page.clickSignoutButton();
    }
}
