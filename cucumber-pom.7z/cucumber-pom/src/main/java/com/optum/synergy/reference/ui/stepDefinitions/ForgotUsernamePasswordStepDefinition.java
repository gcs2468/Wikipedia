package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ForgotUsernamePasswordPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ForgotUsernamePasswordStepDefinition { 
	private ForgotUsernamePasswordPage page;
	private String captchImgSrc = null;
	
	public ForgotUsernamePasswordStepDefinition() {
		page = new ForgotUsernamePasswordPage();
	}
	
	@When("^I enter username with \"([^\"]*)\"$")
	public void i_enter_username_with(String username) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 page.enterUserName(username);
		 page.clickResetPasswordInfoForm();
	}
	@Then("^I should see an error message \"([^\"]*)\" for username$")
	public void i_should_see_an_error_message_for_username(String message) throws Throwable {
		
		Assert.assertTrue(page.verifyErrorMessageOnUsername(message));
	}
	
	@Then("^I should not see any error message for username$")
	public void i_should_not_see_any_error_message_for_username() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnUsername());
	}
	
	@When("^I enter captcha with \"([^\"]*)\"$")
	public void i_enter_captcha_with(String captcha) throws Throwable {
		page.enterCaptcha(captcha);
		page.clickResetPasswordInfoForm();
	}
	@Then("^I should see an error message \"([^\"]*)\" for captcha$")
	public void i_should_see_an_error_message_for_captcha(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnCaptcha(message));
	}
	
	@Then("^I should not see any error message for captcha$")
	public void i_should_not_see_any_error_message_for_captcha() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnCaptcha());
	}
	
	@When("^I enter Usercaptcha with \"([^\"]*)\"$")
	public void i_enter_Usercaptcha_with(String Usercaptcha) throws Throwable {
	  page.enterCaptcha(Usercaptcha);
	  page.clickRecoverUsernameInfoForm();
	}

	@Then("^I should see an error message \"([^\"]*)\" for Usercaptcha$")
	public void i_should_see_an_error_message_for_Usercaptcha(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnCaptcha(message));
	}

	@Then("^I should not see any error message for Usercaptcha$")
	public void i_should_not_see_any_error_message_for_Usercaptcha() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnCaptcha());
	}
	
	
	@When("^I enter email with \"([^\"]*)\"$")
	public void i_enter_email_with(String emailAddress) throws Throwable {
	   page.clearEmailField();
	   page.enterEmail(emailAddress);
	   page.clickRecoverUsernameInfoForm();
	}

	@Then("^I should not see any error message for email$")
	public void i_should_not_see_any_error_message_for_email() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnEnterEmail()); 
	}

	@Then("^I should see an error message \"([^\"]*)\" for email$")
	public void i_should_see_an_error_message_for_email(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnEnterEmail(message));
	    
	}
	
	@Then("^I should see a captcha image$")
	public void iShouldSeeACaptchaImage() throws Throwable {
		Assert.assertTrue(page.verifyIfCaptchImgExist());
		captchImgSrc = page.getCaptchaSource();
		
	}

	@Then("^I should see a new captcha image$")
	public void iShouldSeeANewCaptchaImage() throws Throwable {
		Assert.assertTrue(page.verifyIfCaptchImgExist());
		String changedCaptchImgSrc = page.getCaptchaSource();
		Assert.assertTrue(!captchImgSrc.equals(changedCaptchImgSrc));
	}

	@Then("^I should see audio image$")
	public void i_should_see_audio_image() throws Throwable {
		Assert.assertTrue(page.verifyAudioExist());
	}

}
