package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAdminPortalUserSearchPage extends PageObjectBase {

	@FindBy(how = How.ID, using = "lastName")
	private WebElement userLastNameTextBox;

	@FindBy(how = How.ID, using = "firstName")
	private WebElement userFirstNameTextBox;
	
	@FindBy(how = How.XPATH, using = "//input[@class='btnprimary' and @value='Search']")
	private WebElement searchButton;

	@FindBy(how = How.ID, using = "userSearchBean")
	private WebElement userSearchSection;
	
	@FindBy(how = How.XPATH, using = "//font[@class='error' and contains(text(), 'No Search results')]")
	private WebElement noSearchResultsErrorMessage;
	
	@FindBy(how = How.LINK_TEXT, using = "Back")
	private WebElement topBackButton;

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(userSearchSection)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void clickTopBackButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(topBackButton));
		topBackButton.click();
	}
	
	public void enterUserLastName(String lastName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userLastNameTextBox));
		userLastNameTextBox.clear();
		userLastNameTextBox.sendKeys(lastName);
	}

	public void enterUserFirstName(String firstName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userFirstNameTextBox));
		userFirstNameTextBox.clear();
		userFirstNameTextBox.sendKeys(firstName);
	}
	
	public void clickSearchButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(searchButton));
		searchButton.click();
	}
	
	public boolean verifySearchResults()
	{
		try{
		smallWait.get().until(ExpectedConditions.visibilityOf(noSearchResultsErrorMessage));
		return false;
		}
		catch(TimeoutException e)
		{
			return true;
		}
		
	}

	public boolean verifyForErrorMessage(String message) {
		return mediumWait.get().until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//font[@class='error' and contains(.,'" + message + "')]")))
				.isDisplayed();
	}

}
