package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.RecoverYourUsernamePage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RecoverYourUsernamePageStepDefinition {
	private RecoverYourUsernamePage page;
	
	public RecoverYourUsernamePageStepDefinition() {
		page = new RecoverYourUsernamePage();
	}

	@Then("^I should be at Recover your username page$")
	public void i_should_be_at_Recover_your_username_page() throws Throwable {
		Assert.assertTrue("Issue While loading the Recover your username page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should see the Recover your username page header as \"([^\"]*)\"$")
	public void i_should_see_the_Recover_your_username_page_header_as(String formHeading) throws Throwable {
	  Assert.assertTrue("\""+formHeading+"\" heading is not displaying on the Recover your username page", page.verifyForFormHeader(formHeading)); 
	}
	
	@Then("^I should see a Email associated with your account label with text box$")
	public void i_should_see_a_Email_associated_with_your_account_label_with_text_box() throws Throwable {
	    Assert.assertTrue("Issue while displaying Email associated with your account label with text box", page.verifyIfemailassociatedwithyouraccountLabelWithTextBoxExist());
	}
	
	@Then("^I should see the recaptcha widget on screen$")
	public void I_should_see_the_recaptcha_widget_on_screen(){
		Assert.assertTrue(page.verifyifrecaptchawidgetexist());
	}
	
	@Then("^I should see an error message \"([^\"]*)\" on recover your username page$")
	public void iShouldSeeAnErrorMessageOnRecoverYourUsernamePage(String errMsg)
			throws Throwable {
		Assert.assertEquals(
				"\""
						+ errMsg
						+ "\""
						+ " error message is not displaying on Recover Your Username page",
				errMsg, page.recoverYourUsernameTopErrorMessage());
	}
	
	@When("^I click on \"([^\"]*)\" button in Recover your username page$")
	public void i_click_on_button_in_RecoverYourUsernamePage(String buttonName) {
		page.clickButtonInRecoverYourUsernamePage(buttonName);
	}

	@Then("^I should see the header as \"([^\"]*)\" on Recover Username page$")
	public void i_should_see_the_header_On_Recover_Username_Page(String formHeading) throws Throwable {
	  Assert.assertEquals("Heading is displayed at Recover Your Username Page", formHeading, page.getFormHeaderOnRecoverUserNamePage());
	}
	
	@Then("^I should see the sub header as \"([^\"]*)\" on Recover Username page$")
	public void i_should_see_the_sub_header_On_Recover_Username_Page(String formSubHeading) throws Throwable {
	  Assert.assertEquals("Text is not displayed in sub header of Recover Your Username Page", formSubHeading, page.getFormSubHeaderOnRecoverUserNamePage());
	}
	
	@Then("^I should see a Home Icon$")
	public void i_should_see_a_Home_Icon() throws Throwable {
	    Assert.assertTrue("Issue while displaying Home Icon", page.getWebElementforHomeIcon().isDisplayed());
	}
	
	@Then("^I should not see the secondary logo$")
	public void i_should_validate_that_secondary_logo_not_displayed() throws Throwable {
		 Assert.assertTrue("Fail, the secondary Logo is displayed", page.verifyMyUhcLogoNotDisplayed());	
   } 
	
	@When("^I click on MyUHC logo$")
    public void i_click_on_MyUHC_logo() throws Throwable {
        page.clickMyUHCLogo();
    }
	
	@When("^I click on MyHealthCareView logo$")
    public void i_click_on_MyHealthCareLogo_logo() throws Throwable {
        page.clickMyHealthCareLogo();
    }
	
	@Then("^I should see the following content in Need help section$")
	public void iShouldSeeTheFollowingContentInNeedHelpSection(List<String> contentList) throws Throwable {
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" content is not displaying in the Need Help section",
					page.getNeedHelpContent().contains(content));
		}
	}

}
