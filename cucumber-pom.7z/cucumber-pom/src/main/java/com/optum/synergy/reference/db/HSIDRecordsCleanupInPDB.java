package com.optum.synergy.reference.db;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;

public class HSIDRecordsCleanupInPDB {

	private static Statement stmt;
	private static ResultSet rs;

	private static Connection con;
	private static Scanner scanner;
	static List<Pair<String, String>> myPairs = new ArrayList<Pair<String, String>>();

	public static void main(String args[]) {
		try {
			connectDataBase();
			System.out.print("Are you sure want to delete the records (Y/N)? ");
			 String confirmation = scanner.nextLine(); 
			 if(confirmation.equalsIgnoreCase("Y")) {
			for (Pair<String, String> pair : getFistNameAndLastNameFromExcelsheet()) {
				// following two lines are equivalent... whichever is easier for
				// you...
				// System.out.println(pair.getLeft() + ": " + pair.getRight());
				
				String firstName = pair.getKey();
				String lastName = pair.getValue();
				System.out.println("deleting the records for :"+ firstName+ " ," + lastName);
			// System.out.println(firstName);
			if ((firstName == "" || firstName == null) && (lastName == "" || lastName == null)) {

				System.out.println("Error: firstname and lastname should not be empty");
			} else {
				 
				
				deleteRecordsFrom_mbr_extrm_scl_dtl_table(returnHealthSafeId(firstName, lastName));
				deleteRecordsFrom_mbr_prtl_table(firstName, lastName);
				deleteRecordsFrom_mbr_table(firstName, lastName);
				 

				}
			}
			 } else if (confirmation.equalsIgnoreCase("N")) { 
				 System.out.println("deletion aborted for the users"); 
				 } else System.out.println("Please give only Y/N");
			closeConnection();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	static void connectDataBase() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.mysql.jdbc.Driver");
		String env = PageObjectBase.getSystemVariable("pdb_environment");
		String user = PageObjectBase.getSystemVariable("pdb_username");
		String pwd = PageObjectBase.getSystemVariable("pdb_password");
		if (env.equalsIgnoreCase("test")) {
			con = DriverManager.getConnection("jdbc:mysql://dbsrt0941.uhc.com:3306/ognt01", user, pwd);
		} else if (env.equalsIgnoreCase("stage"))
			con = DriverManager.getConnection("jdbc:mysql://dbsrs1395:3306/ogns", user, pwd);

		else if (env.equalsIgnoreCase("dev")) {
			con = DriverManager.getConnection("jdbc:mysql://dbsrd2303:3306/ognd01", user, pwd);
		} else {
			System.out.println("Please set the correct pdb_environment: dev/test/stage");
		}
		System.out.println("Connected to: " + env.toUpperCase() + " database");
		stmt = con.createStatement();
		scanner = new Scanner(System.in);
	}

	static void closeConnection() throws SQLException {
		con.close();
	}

	public static void deleteRecordsFrom_mbr_table(String firstName, String lastName) throws SQLException {

		// The following steps will return no. of selected records based on
		// first name and last name
		rs = stmt.executeQuery(
				"SELECT COUNT(*) FROM mbr where MDM_FST_NM = '" + firstName + "' and MDM_LST_NM = '" + lastName + "'");
		int initialrowcount = 0;
		while (rs.next()) {
			initialrowcount = rs.getInt(1);
		}
		System.out.println("Total selected records to delete from mbr table are: " + initialrowcount);

		// The following steps will delete records based on first name and last
		// name
		/*
		 * System.out.print(
		 * "Are you sure want to delete the records from table: mbr (Y/N)? ");
		 * String confirmation = scanner.nextLine(); if
		 * (confirmation.equalsIgnoreCase("Y")) {
		 */
		stmt.executeUpdate(
				"delete from mbr where MDM_FST_NM = '" + firstName + "' and MDM_LST_NM = '" + lastName + "'");

		rs = stmt.executeQuery(
				"SELECT COUNT(*) FROM mbr where MDM_FST_NM = '" + firstName + "' and MDM_LST_NM = '" + lastName + "'");
		/*int rowcount = 1;
		while (rs.next()) {
			rowcount = rs.getInt(1);
		}

		if (rowcount == 0) {
			System.out.println("Records deleted successfully from table: mbr");
		} else {
			System.out.println("Still Records exist in the table: mbr");
		}
*/
		/*
		 * } else if (confirmation.equalsIgnoreCase("N")) { System.out.println(
		 * "deletion aborted for mbr table"); } else System.out.println(
		 * "Please give only Y/N");
		 */

	}

	public static void deleteRecordsFrom_mbr_prtl_table(String firstName, String lastName) throws SQLException {

		// The following steps will return no. of selected records based on
		// first name and last name
		rs = stmt.executeQuery("SELECT COUNT(*) FROM mbr_prtl where MBR_PRTL_FST_NM = '" + firstName
				+ "' and MBR_PRTL_LST_NM = '" + lastName + "'");
		int initialrowcount = 0;
		while (rs.next()) {
			initialrowcount = rs.getInt(1);
		}
		System.out.println("Total selected records to delete from mbr_prtl table are: " + initialrowcount);

		// The following steps will delete records based on first name and last
		// name
		/*
		 * System.out.print(
		 * "Are you sure want to delete the records from table: mbr_prtl (Y/N)? "
		 * ); String confirmation = scanner.nextLine(); if
		 * (confirmation.equalsIgnoreCase("Y")) {
		 */
		stmt.executeUpdate("delete from mbr_prtl where MBR_PRTL_FST_NM = '" + firstName + "' and MBR_PRTL_LST_NM = '"
				+ lastName + "'");
		rs = stmt.executeQuery("SELECT COUNT(*) FROM mbr_prtl where MBR_PRTL_FST_NM = '" + firstName
				+ "' and MBR_PRTL_LST_NM = '" + lastName + "'");
		/*int rowcount = 1;
		while (rs.next()) {
			rowcount = rs.getInt(1);
		}

		if (rowcount == 0) {
			System.out.println("Records deleted successfully from table: mbr_prtl");
		} else {
			System.out.println("Still Records exist in the table: mbr_prtl");
		}*/

		/*
		 * } else if (confirmation.equalsIgnoreCase("N")) { System.out.println(
		 * "deletion aborted for mbr_prtl table"); } else System.out.println(
		 * "Please give only Y/N");
		 */
	}

	public static void deleteRecordsFrom_mbr_extrm_scl_dtl_table(String healthSafeId) throws SQLException {
		// The following steps will return no. of selected records based on
		// first name and last name
		rs = stmt.executeQuery("SELECT COUNT(*) FROM mbr_extrm_scl_dtl where HLTHSF_ID = '" + healthSafeId + "'");
		int initialrowcount = 0;
		while (rs.next()) {
			initialrowcount = rs.getInt(1);
		}
		System.out.println("Total selected records to delete from mbr_extrm_scl_dtl table are: " + initialrowcount);

		// The following steps will delete records based on first name and last
		// name
		/*
		 * System.out.print(
		 * "Are you sure want to delete the records from table: mbr_extrm_scl_dtl (Y/N)? "
		 * ); String confirmation = scanner.nextLine(); if
		 * (confirmation.equalsIgnoreCase("Y")) {
		 */
		stmt.executeUpdate("delete from mbr_extrm_scl_dtl where HLTHSF_ID = '" + healthSafeId + "'");
		rs = stmt.executeQuery("SELECT COUNT(*) FROM mbr_extrm_scl_dtl where HLTHSF_ID = '" + healthSafeId + "'");
		/*int rowcount = 1;
		while (rs.next()) {
			rowcount = rs.getInt(1);
		}

		if (rowcount == 0) {
			System.out.println("Records deleted successfully from table: mbr_extrm_scl_dtl");
		} else {
			System.out.println("Still Records exist in the table: mbr_extrm_scl_dtl");
		}*/
		/*
		 * } else if (confirmation.equalsIgnoreCase("N")) { System.out.println(
		 * "deletion aborted for mbr_extrm_scl_dtl table"); } else
		 * System.out.println("Please give only Y/N");
		 */
	}

	public static String returnHealthSafeId(String firstName, String lastName) throws SQLException {
		System.out.print("getting the HealthSafeId from mbr table");
		rs = stmt.executeQuery(
				"select HLTHSF_ID from mbr where MDM_FST_NM = '" + firstName + "' and MDM_LST_NM = '" + lastName + "'");
		String value = null;
		while (rs.next()) {
			value = rs.getString("HLTHSF_ID");
		}
		System.out.println(" :" + value);
		return value;

	}

	public static List<Pair<String, String>> getFistNameAndLastNameFromExcelsheet() throws IOException {
		FileInputStream fileIn = new FileInputStream("Test_Data.xlsx");
		// read file
		XSSFWorkbook filename = new XSSFWorkbook(fileIn);
		// open sheet 0 which is first sheet of your worksheet
		XSSFSheet sheet = filename.getSheet("PDB_Users");
		// we will search for column index containing string "Your Column Name"
		// in the row 0 (which is first row of a worksheet
		String columnWanted1 = "FirstName";
		String columnWanted2 = "LastName";
		Integer columnNo1 = null;
		Integer columnNo2 = null;
		Row firstRow = sheet.getRow(0);
		// sheet.getLastRowNum();

		for (Cell cell : firstRow) {
			// System.out.println(cell.getStringCellValue());
			if (cell.getStringCellValue().trim().equals(columnWanted1)) {
				columnNo1 = cell.getColumnIndex();
				// System.out.println(columnNo);
			} else if (cell.getStringCellValue().trim().equals(columnWanted2)) {
				columnNo2 = cell.getColumnIndex();

			}
		}

		if (columnNo1 != null & columnNo2 != null) {
			for (Row row : sheet) {
				if (row.getRowNum() != 0) {
					Cell c1 = row.getCell(columnNo1);
					Cell c2 = row.getCell(columnNo2);
					/*
					 * if ((c1 == null || c1.getCellType() ==
					 * Cell.CELL_TYPE_BLANK ) || ( c2 == null &&
					 * c2.getCellType() == Cell.CELL_TYPE_BLANK)) { // Nothing
					 * in the cell in this row, skip it
					 * 
					 * } else {
					 */
					myPairs.add(Pair.of(c1.getStringCellValue(), c2.getStringCellValue()));
					// cells.add(c1);
					/* } */
				}
			}
		} else {
			System.out.println("could not find columns combination " + columnWanted1+" : "+columnWanted2 + " in first row of " + fileIn.toString());
		}
		return myPairs;

	}

	/*public static ArrayList<String> selectRecords() throws SQLException {
		ArrayList<String> list = new ArrayList<String>();
		rs = stmt.executeQuery("select MBR_PRTL_FST_NM from mbr_prtl where MBR_PRTL_LST_NM = 'new'");
		while (rs.next()) {
			String lastName = rs.getString("MBR_PRTL_FST_NM");
			list.add(lastName);
			System.out.println(lastName);
		}
		return list;
	}*/

}
