package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class MailInator_InboxPage extends PageObjectBase {

	@FindBy(how = How.ID, using = "public_maildirdiv")
	private WebElement inboxMailDirectory;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'row') and contains(.,'Live and Work Well - please confirm your email address to complete your HealthSafe ID registration')]/div[2]/div[5]")
	private WebElement confirmEmailAddressMail;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'row') and contains(.,'Live and Work Well - your HealthSafe ID registration is complete')]/div[2]/div[5]")
	private WebElement registrationCompletedMail;
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			mediumWait.get().until(ExpectedConditions.visibilityOf(inboxMailDirectory));
			return inboxMailDirectory.isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	public boolean verifyForConfirmEmailAddressMail()
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailAddressMail));
		return confirmEmailAddressMail.isDisplayed();
	}
	
	public void clickOnConfirmEmailAddressMail()
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailAddressMail));
		confirmEmailAddressMail.click();
	}
	
	public boolean verifyForRegistrationCompletedMail()
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(registrationCompletedMail));
		return registrationCompletedMail.isDisplayed();
	}
	
	public void clickOnRegistrationCompletedMail()
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(registrationCompletedMail));
		registrationCompletedMail.click();
	}
	
}
