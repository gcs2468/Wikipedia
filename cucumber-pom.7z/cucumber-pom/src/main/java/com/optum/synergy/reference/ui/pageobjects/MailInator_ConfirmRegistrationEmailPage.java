package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class MailInator_ConfirmRegistrationEmailPage extends PageObjectBase{

	@FindBy(how = How.ID, using = "publicshowmaildivcontent")
	private WebElement emailBodyFrame;
	
	@FindBy(how = How.LINK_TEXT, using = "Confirm your email address >")
	private WebElement confirmEmailAddressLink;
	
	public boolean verifyIfPageLoaded()	{
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(emailBodyFrame)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void switchToEmailContentFrame()
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(emailBodyFrame));
		driver.switchTo().frame(emailBodyFrame);
	}
	
	public void clickConfirmEmailAddressLink()
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailAddressLink));
		confirmEmailAddressLink.click();
	}
	
	public void switchToDefaultContent(){
		driver.switchTo().defaultContent();
	}
}
