package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HealthSafeIDLearnMorePage extends PageObjectBase{
	
	@FindBy(how = How.CLASS_NAME, using = "learnmore__content")
	private WebElement learnMoreForm;
	
	public boolean verifyIfPageLoaded()	{
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(learnMoreForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
}