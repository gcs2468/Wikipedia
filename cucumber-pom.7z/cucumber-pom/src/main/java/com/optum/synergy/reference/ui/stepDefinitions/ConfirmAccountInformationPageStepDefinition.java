package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ConfirmAccountInformationPage;
import com.optum.synergy.reference.ui.pageobjects.Hooks;

import cucumber.api.java.en.Then;

public class ConfirmAccountInformationPageStepDefinition {
	
	private ConfirmAccountInformationPage page;
	public ConfirmAccountInformationPageStepDefinition() {		
		page = new ConfirmAccountInformationPage();
	}

	@Then("^I should be at Confirm account information page$")
	public void i_should_be_at_Confirm_account_information_page() throws Throwable {
	   Assert.assertTrue("Issue while loading the Confirm account information page", page.verifyIfPageLoaded());
	}

	@Then("^I should see the Confirm account information form contains the text \"([^\"]*)\"$")
	public void i_should_see_the_Confirm_account_information_form_contains_the_text(String text) throws Throwable {
		Thread.sleep(1000);
	   Assert.assertTrue("\""+text+"\" text is not displaying on the Confirm account information form", page.verifyFormContent(text));
	}
	@Then("^I enter confirm email2 with \"([^\"]*)\" from excel$")
	public void i_enter_confirm_email_with_from_excel(String newEmail) throws Throwable {
	//	page.enterConfirmEmail2(newEmail);
	    page.enterConfirmEmail2(new Hooks().getNewEmailId());
	}
	@Then("^I should see the Confirm account information form contains the email \"([^\"]*)\"$")
	public void i_should_see_the_Confirm_account_information_form_contains_the_email(String email) throws Throwable {
		Thread.sleep(2000);
		email=new Hooks().getNewEmailId();
		   Assert.assertTrue("\""+email+"\" mail is not displaying on the Confirm account information form", page.verifyFormContent(email));
	}
	
	@Then("^I should see the \"([^\"]*)\" label on Confirm account information screen$")
	public void I_should_see_the_label_on_Confirm_account_information(String label) throws Throwable {
		String lblText = "";
		if (label.toUpperCase().contains("EMAIL")){
			lblText = page.getLabelforEmail();
			
		} else if (label.toUpperCase().contains("CALL")){
			lblText = page.getLabelforCall();
		} else if (label.toUpperCase().contains("TEXT")){
			lblText = page.getLabelforSMS();
		} else {
			Assert.fail("Unknown label type [" + label
					+ "] for Confirm account information screen");
		}
		Assert.assertNotNull("Failed to find expected [" + label
				+ "], found null", lblText);
		Assert.assertTrue("Failed to find expected [" + label
				+ "], found [" + lblText
				+ "]", lblText.contains(label));
		
		   
	}
	@Then("^I should see the mobile number \"([^\"]*)\"on Confirm account information screen$")
	public void I_should_see_the_mobile_number_on_Confirm_account_information_screen(String number) throws Throwable {
		
		Assert.assertEquals(number, page.getMobileNumber());
		   
	}
	
	
	
}

