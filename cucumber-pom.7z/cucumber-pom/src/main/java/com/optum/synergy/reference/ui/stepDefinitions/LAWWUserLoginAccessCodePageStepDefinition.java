package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.LAWWUserLoginAccessCodePage;
import cucumber.api.java.en.When;

public class LAWWUserLoginAccessCodePageStepDefinition {
	private LAWWUserLoginAccessCodePage page;

	public LAWWUserLoginAccessCodePageStepDefinition() {
		page = new LAWWUserLoginAccessCodePage();
	}

	@When("^I manage the LAWW Access code page with provider benefit \"([^\"]*)\"$")
	public void iManageTheLAWWAccessCodePageWithProviderBenefit(String accessCode) throws Throwable {
		boolean isPageDisplayed = false;
		try {
			 isPageDisplayed=page.verifyIfPageLoaded();
			 }
			 catch (Exception e) {
				}
			if (isPageDisplayed == true) {
				page.selectProviderFromMyBenefitsAreProvidedThroughList(accessCode);
				page.clickOnContinueButton();
			
		}
	}
}
