package com.optum.synergy.reference.ui.utility;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

/**
 * @author rtripa1
 *
 */
public class readXMLdata {
	public static String getTestData(String SectionName, String NodeName) {
		String env= System.getProperty("ExecutionEnv");
//		String env="Stage";
		
		SectionName = "Project/"+env+"/"+ SectionName+ "/" + NodeName;				
		File fXmlFile = new File("TestData.xml");
		String foundData = null;
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		NodeList nodeList;
		Document doc;

		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			javax.xml.xpath.XPath xPath = XPathFactory.newInstance().newXPath();			
			nodeList = (NodeList) xPath.compile(SectionName).evaluate(doc, XPathConstants.NODESET);
		} catch (Exception e) {
			Assert.fail("Exception reading TestData.xml [" + e.getMessage()
					+ "]");
			return null;
		}
		for (int temp = 0; temp < nodeList.getLength(); temp++) {

			org.w3c.dom.Node nNode = nodeList.item(temp);
			if (nNode.getNodeName().equals(NodeName)) {
				foundData = nNode.getTextContent().trim();
			}
		}
		Assert.assertNotNull("Failed to find data in TestData.xml for [" + SectionName + "]", foundData);
		return foundData;
	}

	/**
	 * Returns list of nodes matching NodeName within SectionName
	 * 
	 * @param SectionName
	 * @param NodeName
	 * @return
	 */
	public static List<String> getTestDataList(String SectionName, String NodeName) {
		
		SectionName = "Project/" + SectionName+ "/" + NodeName;				
		File fXmlFile = new File("TestData.xml");
		List<String> returnedList = new ArrayList<String>();
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		NodeList nodeList;
		Document doc;
	
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			javax.xml.xpath.XPath xPath = XPathFactory.newInstance().newXPath();			
			nodeList = (NodeList) xPath.compile(SectionName).evaluate(doc, XPathConstants.NODESET);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		for (int temp = 0; temp < nodeList.getLength(); temp++) {
	
			org.w3c.dom.Node nNode = nodeList.item(temp);
			if (nNode.getNodeName().equals(NodeName)) {
				returnedList.add( nNode.getTextContent().trim() );
			}
		}
		return returnedList;
	}
}
