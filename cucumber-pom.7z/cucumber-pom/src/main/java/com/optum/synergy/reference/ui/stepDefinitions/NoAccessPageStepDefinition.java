package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.NoAccessPage;

import cucumber.api.java.en.Then;

public class NoAccessPageStepDefinition {
	private NoAccessPage page;

	public NoAccessPageStepDefinition() {
		page = new NoAccessPage();
	}

	@Then("^I should be at No-Access page$")
	public void iShouldBeAtNoAccessPage() throws Throwable {
		Assert.assertTrue("Failed to load No Access Page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should see the following error messages in No-Access page$")
	public void iShouldSeeTheFollowingErrorMessagesInNoAccessPage(List<String> errMsgs) throws Throwable {
		String errorMessage = "";
		boolean firstIteration=true;
		for (String errMsg : errMsgs) {
			if (firstIteration){
			errorMessage =  errMsg;
			firstIteration=false;
			}else{
				errorMessage = errorMessage + "\n"+ errMsg;
			}
		}		
		Assert.assertEquals(errorMessage, page.getErrorMsg());
	}
	
	@Then("^I should see the page heading as \"([^\"]*)\" in No-Access page$")
	public void iShouldSeeThePageHeadingAsInNoAccessPage(String expectedHeading) throws Throwable {
	    Assert.assertEquals(expectedHeading, page.getContentPageHeading());
	}

	@Then("^I should see an optum logo in No-Access page content$")
	public void iShouldSeeAnOptumLogoInNoAccessPageContent() throws Throwable {
	    Assert.assertTrue(page.verifyIfContentLogoDispalyed());
	}
	
	@Then("^I should see heading as \"([^\"]*)\" on No-Access page after Sign in$")
	public void iShouldSeeTheHeadingAsOnNoAccessPage(String expectedHeading) throws Throwable {
	    Assert.assertEquals(expectedHeading, page.getNoAccessPageHeadingElementAfterSignin().getText());
	}

	@Then("^I should see the following error messages on No-Access page after Sign in$")
	public void iShouldSeeTheFollowingErrorMessagesOnNoAccessPageAfterSignIn(List<String> errMsgs) throws Throwable {
		String errorMessage = "";
		boolean firstIteration=true;
		for (String errMsg : errMsgs) {
			if (firstIteration){
			errorMessage =  errMsg;
			firstIteration=false;
			}else{
				errorMessage = errorMessage + "\n"+ errMsg;
			}
		}		
		Assert.assertEquals(errorMessage, page.getNoAccessPageErrorMessageElementAfterSignin().getText());
	}
}
