package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.CreateOptumIdPage;
import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readXMLdata;
import cucumber.api.java.en.Given;

public class CreateOptumIdPageStepDefinition {
	private CreateOptumIdPage page;
	
	public CreateOptumIdPageStepDefinition() {
		page = new CreateOptumIdPage();
	}
	
	@Given("^I should create the Optum ID for member \"([^\"]*)\" without recovery options$")
	public void I_Should_create_the_Optum_ID_withOut_recovery_Options(String arg1) throws InterruptedException {
		String FirstName = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "FirstName");
		String LastName = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "LastName");
		String DOB = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "DOB");
		String userName=dataStorage.getUserName();
		dataStorage.setCustomErrmsg("username:::"+dataStorage.getUserName());
		String email=dataStorage.getEmailId();	
		String password="Password@1";
		String memberId = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "SubscriberID");
		String gender= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "Gender");
		String addressLine= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "AddressLine");
		String city= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "City");
		String state= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "State");
		String zipCode= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "Zip");
		String phone= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "Phone");
	
		page.createOptumIdNoAuth(FirstName,LastName,DOB,userName,email,password,memberId, 
				gender,addressLine,city,state,zipCode,phone);
	}
	
	@Given("^I should create the Optum ID for member \"([^\"]*)\" with SQA recovery options$")
	public void I_Should_create_the_Optum_ID_with_SQA_recovery_Options(String arg1) throws InterruptedException {
		String FirstName = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "FirstName");
		String LastName = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "LastName");
		String DOB = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "DOB");
		String userName=dataStorage.getUserName();
		dataStorage.setCustomErrmsg("username:::"+dataStorage.getUserName());
		String email=dataStorage.getEmailId();
		String password="Password@1";
		String memberId = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "SubscriberID");
		String gender= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "Gender");
		String addressLine= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "AddressLine");
		String city= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "City");
		String state= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "State");
		String zipCode= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "Zip");
		String phone= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "Phone");
		page.createOptumIdSqaAuth(FirstName,LastName,DOB,userName,email,password,memberId, 
				gender,addressLine,city,state,zipCode,phone);
	
	}
	
	@Given("^I should create the Optum ID for member \"([^\"]*)\" with phone recovery options$")
	public void I_Should_create_the_Optum_ID_with_phone_recovery_Options(String arg1) throws InterruptedException {
		String FirstName = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "FirstName");
		String LastName = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "LastName");
		String DOB = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "DOB");
		String userName=dataStorage.getUserName();
		dataStorage.setCustomErrmsg("username:::"+dataStorage.getUserName());
		String email=dataStorage.getEmailId();
		String password="Password@1";
		String memberId = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "SubscriberID");
		String gender= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "Gender");
		String addressLine= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "AddressLine");
		String city= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "City");
		String state= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "State");
		String zipCode= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "Zip");
		String phone= readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "Phone");
		page.createOptumIdPhoneAuth(FirstName,LastName,DOB,userName,email,password,memberId, 
				gender,addressLine,city,state,zipCode,phone);
	
		}
}

