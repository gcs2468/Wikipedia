package com.optum.synergy.reference.ui.pageobjects;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.optum.synergy.reference.ui.utility.dbOperation;

public class DB_ProvisionalDataBase extends PageObjectBase {
	private static PreparedStatement stmt;
	private static ResultSet rs;
	private static Connection con;
	private static int rowcount;


	public void connectToDataBase() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(getEnvVariable("PDBDetails.DBConnectionString"),
				getEnvVariable("PDBDetails.user"), getEnvVariable("PDBDetails.password"));
	}

	public void closeConnectionToDataBase() throws SQLException {
		stmt.close();
		con.close();
	}

	public int returnRecordsFromMBRTable(String firstName, String lastName) throws SQLException {
//		stmt = con.prepareStatement("SELECT COUNT(*) FROM mbr where MDM_FST_NM =? and MDM_LST_NM =?");
//		stmt.setString(1, firstName);
//		stmt.setString(2, lastName);
//		rs = stmt.executeQuery();
//		while (rs.next()) {
//			rowcount = rs.getInt(1);
//		}
//		return rowcount;
		return dbOperation.recordcountFromMmberTable(firstName, lastName);
		
	}

	public int returnRecordsFromMBRTablewithubcriberID(String firstName, String lastName,String subscriberid) throws SQLException {
//		stmt = con.prepareStatement("SELECT COUNT(*) FROM mbr where MDM_FST_NM =? and MDM_LST_NM =?");
//		stmt.setString(1, firstName);
//		stmt.setString(2, lastName);
//		rs = stmt.executeQuery();
//		while (rs.next()) {
//			rowcount = rs.getInt(1);
//		}
//		return rowcount;
		return dbOperation.recordcountFromMmberTablewithSubscriberid(firstName, lastName, subscriberid);
		
	}
	
	
	
	public int returnRecordsFromMBR_PRTLTable(String firstName, String lastName) throws SQLException {
		return dbOperation.recordcountFromMmberPortalTable(firstName, lastName);
	}
	public int returnRecordsFromMBR_EXTRM_SCL_DTTable(String firstName, String lastName) throws SQLException {
		stmt = con.prepareStatement("SELECT COUNT(*) FROM mbr_extrm_scl_dtl where HLTHSF_ID =(select HLTHSF_ID from mbr where MDM_FST_NM =?  and MDM_LST_NM =?)");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		stmt.addBatch();
		rs = stmt.executeQuery();
		while (rs.next()) {
			rowcount = rs.getInt(1);
		}
		return rowcount;
	}
	
	public int setValueToINDV_ASUM_CCD_RGST_DT_inINDVTable(String firstName, String lastName) throws SQLException {
		stmt = con.prepareStatement("SELECT COUNT(*) FROM mbr_extrm_scl_dtl where HLTHSF_ID =(select HLTHSF_ID from mbr where MDM_FST_NM =?  and MDM_LST_NM =?)");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		stmt.addBatch();
		rs = stmt.executeQuery();
		while (rs.next()) {
			rowcount = rs.getInt(1);
		}
		return rowcount;
	}
	
	public int returnRecordsFromMBRTable(String firstName, String lastName, String subscriberId) throws SQLException {
		stmt = con.prepareStatement("SELECT COUNT(*) FROM mbr where MDM_FST_NM =? and MDM_LST_NM =? and MDM_MBR_SBSCR_ID =? ");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		stmt.setString(3, subscriberId);
		rs = stmt.executeQuery();
		while (rs.next()) {
			rowcount = rs.getInt(1);
		}
		return rowcount;
	}
	
	public int returnRecordsFromMBR_PRTLTable(String firstName, String lastName,String subscriberId) throws SQLException {
		stmt = con.prepareStatement("SELECT COUNT(*) FROM mbr_prtl where MBR_PRTL_FST_NM =? and MBR_PRTL_LST_NM =? and MBR_PRTL_SBSCR_ID =?");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		stmt.setString(3, subscriberId);
		rs = stmt.executeQuery();
		while (rs.next()) {
			rowcount = rs.getInt(1);
		}
		return rowcount;
	}

	public int updateTERM_AND_COND_ACPT_DTinMBRTableWithDate(String date,String firstName, String lastName) throws SQLException {
		stmt = con.prepareStatement("UPDATE mbr set TERM_AND_COND_ACPT_DT =? where MDM_FST_NM =? and MDM_LST_NM =?");
		stmt.setString(1, date);
		stmt.setString(2, firstName);
		stmt.setString(3, lastName);
		
		int updatedRows = stmt.executeUpdate();
		System.out.println(updatedRows);
		return updatedRows;
		
	}

	public boolean verifyIfTERM_AND_COND_ACPT_DTisUpdatedToCurrentDate(String firstName, String lastName) throws SQLException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String todaysDate = sdf.format(date);
		stmt = con.prepareStatement("SELECT TERM_AND_COND_ACPT_DT from mbr where MDM_FST_NM=? and MDM_LST_NM=?");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		rs = stmt.executeQuery();
		String value=null;
		if ( rs.last() ) {
			 value = rs.getString("TERM_AND_COND_ACPT_DT");
		}
		return todaysDate.equals(value);
	}
	
}
