package com.optum.synergy.reference.ui.pageobjects;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DB_Sugar extends PageObjectBase{
	private static PreparedStatement stmt;
	private static ResultSet rs;
	private static Connection con;
	private static int rowcount;
	

	public void connectToDataBase() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(getEnvVariable("SugarDBDetails.DBConnectionString"),
				getEnvVariable("SugarDBDetails.user"), getEnvVariable("SugarDBDetails.password"));
	}

	public void closeConnectionToDataBase() throws SQLException {
		stmt.close();
		con.close();
	}
	
	public boolean deleteUserFromSugarDB(String firstName, String lastName) throws SQLException
	{
		int expectedRowCount=1;
		
		stmt = con.prepareStatement("update indv set INDV_ASUM_CCD_RGST_DT=null where fst_nm=? and lst_nm=?");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		stmt.executeUpdate();
		
		stmt = con.prepareStatement("update addr set ONBRDG_CNFM_IND='0' ,onbrdg_ovrwrt_dt=null where addr_id in ('"+returnADDR_IDFromAddrTable(firstName,lastName)+"')");
		stmt.executeUpdate();
		
		stmt = con.prepareStatement("delete from indv_goal_txt where indv_id in ('"+returnINDV_IDFromIndvTable(firstName,lastName)+"')");
		stmt.executeUpdate();
		
		stmt = con.prepareStatement("select * from indv where fst_nm=? and lst_nm=?");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		
		rs = stmt.executeQuery();
		while (rs.next()) {
			expectedRowCount = rs.getInt(1);
		}
	
		return expectedRowCount==0;
	}
	
	public int returnUserRecords(String firstName, String lastName) throws SQLException
	{
		stmt = con.prepareStatement("select * from indv where fst_nm=? and lst_nm=?");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		rs = stmt.executeQuery();
		while (rs.next()) {
			rowcount = rs.getInt(1);
		}
		return rowcount;
	}
	
	public int returnADDR_IDFromAddrTable(String firstName, String lastName) throws SQLException{
		stmt = con.prepareStatement("select a.ADDR_ID from indv_addr a,indv i where a.INDV_ID=i.indv_id and (i.fst_nm=? and i.lst_nm=?)");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		int addr_id=0;
		rs = stmt.executeQuery();
		while (rs.next()) {
			addr_id = rs.getInt("ADDR_ID");
		}
		return addr_id;
	}
	
	public int returnINDV_IDFromIndvTable(String firstName, String lastName) throws SQLException{
		stmt = con.prepareStatement("select indv_id from indv where fst_nm=? and lst_nm=?");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		int indv_id = 0;
		rs = stmt.executeQuery();
		while (rs.next()) {
			indv_id = rs.getInt("indv_id");
		}
		return indv_id;
	}
}