package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class NoAccessPage extends PageObjectBase {
	@FindBy(how = How.CLASS_NAME, using = "form__step1--noaccess")	
	private WebElement noAccessForm;
	
	@FindBy(how = How.ID, using = "header")
	private WebElement contentPageHeading;
	
	@FindBy(how = How.ID, using = "Logo")
	private WebElement contentLogo;
	
	@FindBy(how = How.XPATH, using = "//*[starts-with(@ng-bind-html,'formHeader')]")
	private WebElement afterSigninNoAccessPageHeadingElement;
	
	@FindBy(how = How.XPATH, using = "//*[@class='center-align learnmore__content']/div")
	private WebElement afterSigninNoAccessPageErrorMessageElement;
	
	public boolean verifyIfPageLoaded()
	{
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(noAccessForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	
	public String getErrorMsg(){
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(noAccessForm)).getText().trim();
		}catch(Exception e){
			return null;
		}
		
	}
	
	public String getContentPageHeading()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(contentPageHeading)).getText();
	}
	
	public boolean verifyIfContentLogoDispalyed()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(contentLogo)).isDisplayed();
	}
	
	public WebElement getNoAccessPageHeadingElementAfterSignin(){
			return mediumWait.get().until(ExpectedConditions.visibilityOf(afterSigninNoAccessPageHeadingElement));
	}
	
	public WebElement getNoAccessPageErrorMessageElementAfterSignin(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(afterSigninNoAccessPageErrorMessageElement));
}
	
}
