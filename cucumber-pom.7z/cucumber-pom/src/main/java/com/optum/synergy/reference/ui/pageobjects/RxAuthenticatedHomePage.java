package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class RxAuthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.CSS, using = "div.has-member-tools")
	private WebElement homePageContent;

	@FindBy(how = How.ID, using = "idbacktodashb")
	private WebElement continueToOptumRxButton;
	
	@FindBy(how = How.CSS, using = "div.uioverlay")
	private WebElement customHomeModal;

	
	public boolean verifyIfHomePageContentIsDisplayed() {
		waitForPageLoad(driver);
		longWait.get().until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div.uioverlay")));
		return longWait.get().until(ExpectedConditions.visibilityOf(homePageContent)).isDisplayed();
	}

	public boolean verifyContinueToOptumRxButtonDisplayed() {

		waitForPageLoad(driver);
		try {
			return longWait.get().until(ExpectedConditions.visibilityOf(continueToOptumRxButton)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}

	}

	public void continueToOptumRxAuthenticatedHomePage() {
		continueToOptumRxButton.click();
		// Wait for pop-up modal to go away
		
		//smallWait.get().until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(".//div[@class='hasmembertools section']")));
		longWait.get().until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div.uioverlay")));
	}
}