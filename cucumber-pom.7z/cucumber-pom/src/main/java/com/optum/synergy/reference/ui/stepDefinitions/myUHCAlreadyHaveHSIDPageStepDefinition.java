package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.myUHCAlreadyHaveHSIDPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class myUHCAlreadyHaveHSIDPageStepDefinition {
	private myUHCAlreadyHaveHSIDPage page;
	
	public myUHCAlreadyHaveHSIDPageStepDefinition() {
		page = new myUHCAlreadyHaveHSIDPage();
	}

	@Given("^I should be at Already have HSID sign in page$")
	public void iAmAtAlreadyhaveHSIDMyUHCUnauthenticatedSignInPage() throws Throwable {
		Assert.assertTrue("Issue while loading the myUHC unauthenticated page", page.verifyIfAlreadyhaveHSIDPageLoaded());
	}
	
	@Then("^I should see Auto populated HSID username \"([^\"]*)\" on Already Have an HealthSafe ID Page$")
	public void i_should_validate_Username_Autopopulated(String expectedUsername) throws Throwable {
		Assert.assertEquals("Username is not Auto Populated on Already Have HSID page", 
				expectedUsername, page.getAutoPopulatedUsernameFromAlreadyHaveHSIDPage());
	}
	
	@When("^I enter valid HSID password \"([^\"]*)\" into Password field in Alreadyhave HSID Signin page$")
    public void iEnterValidHSIDPasswordIntoPasswordFieldInLegacySignInPage(String password) throws Throwable {
		page.enterPassword(password);
    }
	
	@Then("^I should see the \"([^\"]*)\" label in Already Have HSID Page$")
	public void i_should_see_the_label(String arg1) throws Throwable {
		iAmAtAlreadyhaveHSIDMyUHCUnauthenticatedSignInPage();
		Assert.assertTrue(page.getContentLabels().getText().contains(arg1));
	}
}
