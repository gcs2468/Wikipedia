package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.TextingTermsAndConditionsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class TextingTermsAndConditionsPageStepDefinition {

	private TextingTermsAndConditionsPage page;
	public static final String URL = "https://healthsafeid.optum.com/content/pages/default/TextingTerms?HTTP_LANGUAGE=EN";

	TextingTermsAndConditionsPage textingPage = new TextingTermsAndConditionsPage();

	public TextingTermsAndConditionsPageStepDefinition() {
		page = new TextingTermsAndConditionsPage();
	}

	@Given("^I am on the TextingTermsPage")
	public void open_url() {
		page.openPage(URL);

	}

	@Then("^I should see the \"([^\"]*)\" header in the Texting Terms and Conditions page$")
	public void i_should_see_header_in_the_page(String header) throws Throwable {
		Assert.assertTrue("\"" + header + "\" heading is not displaying on the Texting Terms & Conditions Page",
				page.verifyHeader(header));
	}

	@Then("^I should see the following content in the Texting Terms and Conditions page$")
	public void iShouldSeeTheFollowingContentInTheTextingTermsAndConditionsPage(List<String> contentList)
			throws Throwable {
		String pgContent = "";
		for (String content : contentList) {
			pgContent = pgContent + " " + content;
		}
		pgContent = pgContent.replaceAll("\\s+", "");
		Assert.assertTrue("\"" + pgContent + "\" content is not displaying on the Texting Terms & Conditions Page",
				page.verifyPgContent(pgContent));
	}
}
