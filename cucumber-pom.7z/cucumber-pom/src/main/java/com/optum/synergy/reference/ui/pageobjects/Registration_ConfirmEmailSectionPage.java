package com.optum.synergy.reference.ui.pageobjects;

import java.util.List;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;


public class Registration_ConfirmEmailSectionPage extends PageObjectBase {

	@FindBy(how = How.CLASS_NAME, using = "form__step3")
	public WebElement confirmEmailSection;

	@FindBy(how = How.ID, using = "step3ConfirmEditedEmail")
	public WebElement confirmEmail2Field;
	
	@FindBy(how = How.CLASS_NAME, using = "success-text")
	public WebElement phoneNumberSuccessConfirmation;
	
	@FindBy(how = How.CLASS_NAME, using = "error-text")
	public WebElement errorText;
	
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'please click the confirmation')]/../../p/a/span[text()='Edit']|//p[@class='text-center ng-scope']/a/span[2]")
	public WebElement editlink;
	
	@FindBy(how = How.ID, using = "step3ConfirmEditedEmail")
	public WebElement confirmEditedEmail;
	
	@FindBy(how = How.XPATH, using = "//*[@id='step3ConfirmEditedPhoneNumber']|//*[@class='ng-scope']/div/input")
	public WebElement confirmEditedPhoneNumber;
	
	@FindBy(how = How.ID, using = "confirmCode")
	public WebElement txtConfirmationCode;

	@FindBy(how=How.XPATH, using="//*[@class='ng-binding ng-scope']")
	private WebElement onlyOneMoreStepLeftConfirmation; 
		
	@FindBy(how=How.CLASS_NAME, using="tb-padding")
	private WebElement tbPadding;	


	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailSection));
			return confirmEmailSection.isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean verifyFormContent(String message) throws InterruptedException {
		Thread.sleep(2000);
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailSection));
		return confirmEmailSection.getText().contains(message);
	}

	public void enterConfirmEmail2(String confirmEmailAddress) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmail2Field));
		confirmEmail2Field.sendKeys(confirmEmailAddress);
	}

	public boolean verifyErrorMessageOnConfirmEmail2(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'error') and contains(.,'" + message + "')]"))).isDisplayed();
	}

	public boolean verifyNoErrorMessageOnConfirmEmail2() {
		boolean noMessage = false;
		try {

		if( smallWait.get().until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(@class,'error')"))) == null)
			noMessage = true;
		} catch (TimeoutException e) {
			noMessage = true;

		}
		return noMessage;
	}

	public void clickOnConfirmEmailForm() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailSection));
		confirmEmailSection.click();
	}

	public void clearConfirmEmail2Field() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmail2Field));
		confirmEmail2Field.clear();
	}
	
	public boolean verifyPhoneConfirmationSuccessMessage(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(phoneNumberSuccessConfirmation));
		return phoneNumberSuccessConfirmation.getText().contains(message);
	}
	
	public boolean verifyTheErrorText(String text)
	{
		Assert.assertTrue("", smallWait.get().until(ExpectedConditions.visibilityOf(errorText)).isDisplayed()==true);
		try{
		smallWait.get().until(ExpectedConditions.visibilityOf(errorText));
		return errorText.getText().contains(text);
		}
		catch(TimeoutException e )
		{
			return false;
		}
	}
	
	
	public void clickOnEditEmaillink()
	{
		mediumWait.get().until(ExpectedConditions.elementToBeClickable(editlink)).click();
	}
	
	public String getMessageOnStep3PageOfRegisteration() {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//div[@class='form__step3 ng-scope']/p/p"))).getText().trim();
	}

	public boolean verifyConfirmEmail2Textbox() {
		 return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmail2Field)).isDisplayed();
	}
	
	public void enterEditedEmail(String emailText) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEditedEmail));
		confirmEditedEmail.clear();
		confirmEditedEmail.sendKeys(emailText);
	}
	
	public void clickOnConfirmEditedEmailButton(String buttonName) {
		 mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[@class='tb-margin']/*[contains(.,'"+buttonName + "')]"))).click();
		
	}
	
	public void clickOnTextOnConfirmEmailPage(String buttonName) throws InterruptedException {
		
		 mediumWait.get().until(ExpectedConditions.elementToBeClickable(
				By.xpath("//p[@class='text-center step-three-option']/a[contains(.,'"+buttonName + "')]/span[2]"))).click();
		
	}
	
	public boolean clickElementByClassNameAndText(String className, String text) {
		
		boolean isClicked = false;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			List<WebElement> elems = mediumWait.get().until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className(className)));
			for (WebElement elem : elems) {
				if (elem.getText().contains(text)) {		
					js.executeScript("arguments[0].click();", elem);
					isClicked = true;
					break;
				}
				
			}
		} catch (Exception e) {
			isClicked = false;
		}
		return isClicked;
	}
	
	public boolean verifytextOnEmailConfirmPage(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//div[@class='ng-scope']/p[contains(.,'"+message + "')]|//span[contains(.,'"+message + "')]|//button[contains(.,'"+message + "')]|//h4[@class='font-weight--regular ng-scope']/strong[contains(.,'"+message + "')]"))).isDisplayed();
	}
	
	public void enterEditedPhoneNumberField(String phoneText) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEditedPhoneNumber));
		confirmEditedPhoneNumber.clear();
		confirmEditedPhoneNumber.sendKeys(phoneText);
	}

	public void clickOnConfirmEditedPhoneNumberButton(String buttonName) throws InterruptedException {
		
		mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[@class='tb-margin']/*[contains(.,'"+buttonName + "')]"))).click();
		Thread.sleep(1000);
	}
	public void enterConfirmationCode(String code) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(txtConfirmationCode));
		txtConfirmationCode.clear();
		txtConfirmationCode.sendKeys(code);

	}
	public String getPaddingContent() { 
		return mediumWait.get().until(ExpectedConditions.visibilityOf(tbPadding)).getText();
		}
	public String getPersonalInfoDescription() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(onlyOneMoreStepLeftConfirmation)).getText();
		}
	}	