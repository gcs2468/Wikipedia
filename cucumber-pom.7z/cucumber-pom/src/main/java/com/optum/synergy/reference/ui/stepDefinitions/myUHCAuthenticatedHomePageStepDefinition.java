package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.myUHCAuthenticatedHomePage;

import cucumber.api.java.en.Then;
import org.junit.Assert;

public class myUHCAuthenticatedHomePageStepDefinition {
	
	private myUHCAuthenticatedHomePage page;
	
	public myUHCAuthenticatedHomePageStepDefinition(){
		page= new myUHCAuthenticatedHomePage();
	}
		
	@Then("^I should be at myUHC authenticated home page$")
	public void iShouldBeAtMyUHCAuthenticatedHomePage() throws Throwable {
		Assert.assertTrue("Issue while loading the myUHC authenticated page", page.verifyIfHomePageContentIsDisplayed());
		//TODO: Page title sometimes returns as "Welcome to myuhc.com", allowing either for now.
		//Assert.assertEquals("myuhc Home", page.getMyUHCAuthenticatedPageTitle());
		String pageTitle = page.getPageTitle();
		Assert.assertTrue("Unexpected page title [" + pageTitle + "]", 
				pageTitle.equals("myuhc Home") || pageTitle.equals("Welcome to myuhc.com"));
	}

	@Then("^I should be at myUHC myHealthCareView authenticated home page$")
	public void iShouldBeAtMyUHCMyHealthCareViewAuthenticatedHomePage() throws Throwable {     
	    Assert.assertTrue("Issue while loading the myUHC myHealthCareView authenticated page", page.verifyIfHomePageContentIsDisplayed());
	    // 2017-09-18 Per Anshul, "MyHealthCareReview Home" is being deprecated, replaced with "myuhc Home"
	    //Assert.assertEquals("myhealthcareview Home", page.getMyUHCAuthenticatedPageTitle());
	    Assert.assertEquals("myuhc Home", page.getMyUHCAuthenticatedPageTitle());
	}
	
	@Then("^I should be at myUHC community plan home authenticated home page$")
    public void iShouldBeAtMyUHCCommunityPlanHomeAuthenticatedHomePage() throws Throwable {     
	    Assert.assertTrue("Issue while loading the myUHC community plan home authenticated page", page.verifyIfHomePageContentIsDisplayed());
	    Assert.assertEquals("myuhc Community Plan Home", page.getMyUHCAuthenticatedPageTitle());
	}

	@Then("^I should be at myUHC health select home authenticated home page$")
	public void iShouldBeAtMyUHCHealthSelectHomeAuthenticatedHomePage() throws Throwable {     
	    Assert.assertTrue("Issue while loading the myUHC health select home authenticated page", page.verifyIfHomePageContentIsDisplayed());
	    Assert.assertEquals("myuhc Home", page.getMyUHCAuthenticatedPageTitle());
	}
	
	@Then("^I manage the rally popup at myUHC authenticated home page$")
	public void iManageRallyPopupAtMyUHCAuthenticatedHomePage() throws Throwable {
	    
		if(page.verifyIfRallyPopUpDisplayedAtMyUhcAuthenticatedHomePage())
			{
			page.closeRallyPopUpMyUhcAuthenticatedHomePage();			
			page.switchToDefaultContent();
			}
		
	}
}