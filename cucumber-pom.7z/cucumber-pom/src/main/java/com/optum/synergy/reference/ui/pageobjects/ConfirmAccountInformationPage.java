package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ConfirmAccountInformationPage extends PageObjectBase {
	
	@FindBy(how = How.ID, using = "header")
	private WebElement formHeader;
	
	@FindBy(how = How.CLASS_NAME, using = "form__content")
	private WebElement formContent;
	
	@FindBy(how = How.ID, using = "confirmEmail2")
	public WebElement confirmEmail2Field;
	
	@FindBy(how = How.XPATH, using = "//span[@class='step-three-option__icon icon-email']/../span[2]")
	public WebElement emailLabel;
	
	@FindBy(how = How.XPATH, using = "//span[@class='step-three-option__icon icon-phone']/../span[2]")
	public WebElement phoneLabel;
	
	@FindBy(how = How.XPATH, using = "//span[@class='step-three-option__icon icon-sms_text']/../span[2]")
	public WebElement smstextLabel;
	
	@FindBy(how = How.XPATH, using = "//h4/strong")
	public WebElement numberPlaceHolder;
	
	public boolean verifyIfPageLoaded()	{
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.form__step3"))).isDisplayed();
//			return longWait.get().until(ExpectedConditions.textToBePresentInElement(formHeader, "onfirm account information"));
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyFormContent(String content)
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(formContent)).getText().contains(content);
	}
	
	public boolean verifyFormHeading(String heading)
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(formHeader)).getText().contains(heading);
	}
	public void enterConfirmEmail2(String confirmEmailAddress) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmail2Field));
		confirmEmail2Field.clear();
		confirmEmail2Field.sendKeys(confirmEmailAddress);
	}
	public String getLabelforEmail()
	{
		try{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(emailLabel)).getText().trim();
		}catch(Exception e){
			return null;
		}
		
	}
	
	public String getLabelforCall()
	{
		try{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneLabel)).getText().trim();
		}catch(Exception e){
			return null;
		}
		
	}
	
	public String getLabelforSMS()
	{
		try{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(smstextLabel)).getText().trim();
		}catch(Exception e){
			return null;
		}
		
	}
	
	public String getMobileNumber()
	{
		try{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(numberPlaceHolder)).getText().trim();
		}catch(Exception e){
			return null;
		}
		
	}
}
