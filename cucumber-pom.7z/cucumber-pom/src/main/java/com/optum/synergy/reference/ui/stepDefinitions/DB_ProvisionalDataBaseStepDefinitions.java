package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.Map;

import org.json.JSONObject;
import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.DB_ProvisionalDataBase;
import com.optum.synergy.reference.ui.pageobjects.ExtremeScaleServicesPage;
import com.optum.synergy.reference.ui.pageobjects.Hooks;
import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.dbOperation;
import com.optum.synergy.reference.ui.utility.readXMLdata;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DB_ProvisionalDataBaseStepDefinitions {
    private DB_ProvisionalDataBase page;

    public DB_ProvisionalDataBaseStepDefinitions() {
        page = new DB_ProvisionalDataBase();
    }

	@When("^I connected to Provisional data base$")
	public void i_connected_to_Provisional_data_base() throws Throwable {
	    page.connectToDataBase();
	}

	@Then("^I should not see any records found in MBR table for the tier1 user with the following details$")
	public void i_should_not_see_any_records_found_in_MBR_table_for_the_tier1_user_with_the_following_details(Map<String, String> tableData) throws Throwable {
		String Firstname=tableData.get("MDM_FST_NM");
		String Lastname=tableData.get("MDM_LST_NM");	
		Assert.assertEquals(0, page.returnRecordsFromMBRTable(Firstname, Lastname));
//		Assert.assertTrue(page.returnRecordsFromMBRTable(new Hooks().getFirstName(), new Hooks().getLastName())==0);
	}

	@Then("^I should not see any records found in MBR_PRTL table for the tier1 user with the following details$")
	public void i_should_not_see_any_records_found_in_MBR_PRTL_table_for_the_tier1_user_with_the_following_details(Map<String, String> tableData) throws Throwable {
		String Firstname=tableData.get("MBR_PRTL_FST_NM");
		String Lastname=tableData.get("MBR_PRTL_LST_NM");
		Assert.assertEquals(0, page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname));
//		Assert.assertTrue(page.returnRecordsFromMBRTable(tableData.get("MBR_PRTL_FST_NM"), tableData.get("MBR_PRTL_LST_NM"))==0);//		
//		Assert.assertTrue(page.returnRecordsFromMBRTable(new Hooks().getFirstName(), new Hooks().getLastName())==0);
	}
	
	@Then("^I should not see any records found in MBR table for the tier2 user with the following details$")
	public void i_should_not_see_any_records_found_in_MBR_table_for_the_tier2_user_with_the_following_details() throws Throwable {
		String Firstname=dataStorage.getFirstName();
		String Lastname=dataStorage.getLastName();	
		Assert.assertEquals(0, page.returnRecordsFromMBRTable(Firstname, Lastname));
//		Assert.assertTrue(page.returnRecordsFromMBRTable(new Hooks().getFirstName(), new Hooks().getLastName())==0);
	}

	@Then("^I should not see any records found in MBR_PRTL table for the tier2 user with the following details$")
	public void i_should_not_see_any_records_found_in_MBR_PRTL_table_for_the_tier2_user_with_the_following_details() throws Throwable {
		String Firstname=dataStorage.getFirstName();
		String Lastname=dataStorage.getLastName();
		Assert.assertEquals(0, page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname));
//		Assert.assertTrue(page.returnRecordsFromMBRTable(tableData.get("MBR_PRTL_FST_NM"), tableData.get("MBR_PRTL_LST_NM"))==0);//		
//		Assert.assertTrue(page.returnRecordsFromMBRTable(new Hooks().getFirstName(), new Hooks().getLastName())==0);
	}
	
	@Given("^I should see a record found in MBR_EXTRM_SCL_DTL table for the tier(\\d+) user with the following details$")
	public void i_should_see_a_record_found_in_MBR_EXTRM_SCL_DTL_table_for_the_tier_user_with_the_following_details(int arg1, Map<String, String> tableData) throws Throwable {
		Assert.assertTrue(tableData.containsKey("MDM_FST_NM"));
		Assert.assertTrue(tableData.containsKey("MDM_LST_NM"));
	//	Assert.assertTrue(page.returnRecordsFromMBR_EXTRM_SCL_DTTable(tableData.get("MDM_FST_NM"), tableData.get("MDM_LST_NM"))==1);
		
		Assert.assertTrue(page.returnRecordsFromMBR_EXTRM_SCL_DTTable(new Hooks().getFirstName(), new Hooks().getLastName())==1);
	}
	
	@Then("^I should see a record in MBR table with the following details for tier2 user subscriber id eligibilty check$")
	public void i_should_see_a_record_in_MBR_table_with_the_following_details_for_tier_user_subscriber_id_eligibilty_check() throws Throwable {
//		Assert.assertTrue(userDetails.containsKey("MDM_FST_NM"));
//		Assert.assertTrue(userDetails.containsKey("MDM_LST_NM"));
//		Assert.assertTrue(userDetails.containsKey("MDM_MBR_SBSCR_ID"));
//	//	Assert.assertTrue(page.returnRecordsFromMBRTable(userDetails.get("MDM_FST_NM"), userDetails.get("MDM_LST_NM"),userDetails.get("MDM_MBR_SBSCR_ID"))==1);
//		
//		Assert.assertTrue(page.returnRecordsFromMBRTable(new Hooks().getFirstName(),new Hooks().getLastName(),new Hooks().getSubscriberId())==1);
		
		
	}

	@Then("^I should see a record in MBR_PRTL table with the following details for tier2 user subscriber id eligibilty check$")
	public void i_should_see_a_record_in_MBR_PRTL_table_with_the_following_details_for_tier_user_subscriber_id_eligibilty_check(Map<String, String> userDetails) throws Throwable {
		Assert.assertTrue(userDetails.containsKey("MBR_PRTL_FST_NM"));
		Assert.assertTrue(userDetails.containsKey("MBR_PRTL_LST_NM"));
		Assert.assertTrue(userDetails.containsKey("MBR_PRTL_SBSCR_ID"));
//		Assert.assertTrue(page.returnRecordsFromMBR_PRTLTable(userDetails.get("MBR_PRTL_FST_NM"), userDetails.get("MBR_PRTL_LST_NM"), userDetails.get("MBR_PRTL_SBSCR_ID"))==1);
		
		Assert.assertTrue(page.returnRecordsFromMBR_PRTLTable(new Hooks().getFirstName(),new Hooks().getLastName(),new Hooks().getSubscriberId())==1);
	}

	@Then("^I closed the connection to provisional data base$")
	public void i_closed_the_connection_to_provisional_data_base() throws Throwable {
	    page.closeConnectionToDataBase();
	}
	
	@Then("^I should see the record added in member portal table in PDB database$")
	public void I_should_see_the_record_added_in_member_portal_table_for_member() throws Throwable {
		String Firstname=dataStorage.getFirstName();
		String Lastname=dataStorage.getLastName();
		Assert.assertEquals(true, page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname)>0);
		
	}
	
	@Given("^I should see that Portal specific Member ID is same as Alt number in PDB database$")
	public void member_does_exist_in_PDB_having_Portal_SpecificNumberAs_Alt_Number() {
		String FirstName = dataStorage.getFirstName();
		String LastName = dataStorage.getLastName();
		String altID= dataStorage.getAltId();
		try {
            Assert.assertEquals("Incorrect PortalSpecificMemberID in PDB for user ["
            		+ FirstName +" " + LastName + "] in PDB", altID, 
            		dbOperation.getPortalSpecificMemberIDFromPDB(FirstName, LastName));
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("Exception getting altID from PDB Data Base::" + e.toString());
			Assert.fail("Exception getting altID from PDB Data Base::" + e.toString());
		}
	}
	
	
	@Then("^I should see only one record added in member portal table in PDB database$")
	public void I_should_see_only_one_record_added_in_member_portal_table_for_member() throws Throwable {
		String Firstname=dataStorage.getFirstName();
		String Lastname=dataStorage.getLastName();
		Assert.assertEquals(1, page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname));
		
	}
	
	
	@Then("^I should see the more than one record added in member portal table in PDB database$")
	public void iShouldSeeMoreThanOneRecordAddedInMemberPortalTableInPDBDatabase() throws Throwable {
		String Firstname=dataStorage.getFirstName();
		String Lastname=dataStorage.getLastName();
		System.out.println(page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname)+" records added in mbr_prtl table");
		Assert.assertTrue(1< page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname));
	}
	
	@Then("^I should see the record added in member table in PDB database$")
	public void I_should_see_the_record_added_in_member_table_for_member() throws Throwable {
		String Firstname=dataStorage.getFirstName();
		String Lastname=dataStorage.getLastName();
		Assert.assertEquals(1, page.returnRecordsFromMBRTable(Firstname, Lastname));		

	}
	
	
	@Then("^I should see the record added in member table in PDB database with newSubscriberid$")
	public void I_should_see_the_record_added_in_member_table_for_memberwithsubscriberid() throws Throwable {
		String Firstname=dataStorage.getFirstName();
		String Lastname=dataStorage.getLastName();
		String Subscriberid=dataStorage.getNewSubscriberID();
		Assert.assertEquals(1, page.returnRecordsFromMBRTablewithubcriberID(Firstname, Lastname, Subscriberid));		

	}
	
	@Then("^I should see \"([^\"]*)\" records added in member portal table in PDB database$")
	public void I_should_see_all_records_added_in_member_portal_table_for_member(int numberOfRecords) throws Throwable {
	String Firstname=dataStorage.getFirstName();
	String Lastname=dataStorage.getLastName();
	Assert.assertEquals(numberOfRecords, page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname));
	}
	
	@Then("^I updated the terms and conditions accepted date to \"([^\"]*)\" in PDB$")
	public void i_updated_the_terms_and_conditions_accepted_date_in_PDB(String newDate) throws Throwable {
		String Firstname=dataStorage.getFirstName();
		String Lastname=dataStorage.getLastName();
		Assert.assertEquals(page.updateTERM_AND_COND_ACPT_DTinMBRTableWithDate(newDate,Firstname, Lastname),1);
    }

	
	@Then("^I should see the terms and conditions accepted date to today's date in PDB$")
	public void i_should_see_the_terms_and_conditions_accepted_date_to_today_s_date_in_PDB() throws Throwable {
		String Firstname=dataStorage.getFirstName();
		String Lastname=dataStorage.getLastName();
		Assert.assertTrue(page.verifyIfTERM_AND_COND_ACPT_DTisUpdatedToCurrentDate(Firstname,Lastname));
	}

	@Given("^member \"([^\"]*)\" does not pre-exist in MyUHC backend system$")
	public void member_does_not_preexist_in_MyUHC_backend_system(String arg1) {
		String FirstName = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "FirstName");
		String LastName = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "LastName");
		String DOB = readXMLdata.getTestData(dataStorage.getPortalName() + "/Users/" + arg1, "DOB");
		try {
			dbOperation.cleanupMyUHCmember(FirstName, LastName, DOB);
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("Error in deleting the record  :" + e.toString());
			Assert.fail("Failed to delete the member for firstname: " + FirstName + " and lastname: " + LastName
					+ ":    " + e.toString());
	
		}
	
	}

	@Given("^(member|login) \"([^\"]*)\" does not pre-exist in PDB and Extremescale$")
	public void member_does_not_preexist_in_PDB_Extremescale(String userDataType, String arg1) {
		String xmlNode = "";
		if ( userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if ( userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}
		String FirstName = readXMLdata.getTestData(dataStorage.getPortalName() + xmlNode + arg1, "FirstName");
		String LastName = readXMLdata.getTestData(dataStorage.getPortalName() + xmlNode + arg1, "LastName");
		try {
			dbOperation.deleterecordFromPDB(FirstName, LastName);
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());
	
		}
	
	}
	
	@Given("^I should see a LAWW user record created in extreme scales with that UUID for the following details$")
	public void i_should_see_a_LAWW_user_record_created_in_extreme_scales_with_that_UUID_for_the_following_details(
			Map<String, String> userDetails) throws Throwable {
		ExtremeScaleServicesPage extremeScalesPage = new ExtremeScaleServicesPage();
		String auth_token = extremeScalesPage.getAccessTokenUsingClientTokenService();
		if (!auth_token.isEmpty()) {
			JSONObject jobj = extremeScalesPage.returnUserDetailsInJsonObjectForm();
			// Assert.assertTrue(jobj.getString("rectype")+" is not the expcted
			// rectype",jobj.getString("rectype").equals("F"));
			Assert.assertTrue(jobj.getString("rectype") + " is not the expcted rectype",
					jobj.getString("rectype").equals("P"));
			Assert.assertTrue(jobj.get("healthSafeIdFlag").toString().equals("true"));
			/*
			 * Assert.assertTrue(jobj.getJSONObject("optumId").getString(
			 * "firstName") .equalsIgnoreCase(userDetails.get("firstName")));
			 * Assert.assertTrue(
			 * jobj.getJSONObject("optumId").getString("lastName").
			 * equalsIgnoreCase(userDetails.get("lastName")));
			 */
	
			Assert.assertTrue(
					jobj.getJSONObject("optumId").getString("firstName").equalsIgnoreCase(new Hooks().getFirstName()));
			Assert.assertTrue(
					jobj.getJSONObject("optumId").getString("lastName").equalsIgnoreCase(new Hooks().getLastName()));
		}
	
	}

	@Given("^I should see a LAWW user record created in extreme scales with that UUID for the following details for tier1 member$")
	public void i_should_see_a_LAWW_user_record_created_in_extreme_scales_with_that_UUID_for_the_following_details_for_tier1_member(
			Map<String, String> userDetails) throws Throwable {
		String frstname = userDetails.get("FirstName");
		String lastname = userDetails.get("LastName");
		ExtremeScaleServicesPage extremeScalesPage = new ExtremeScaleServicesPage();
		String auth_token = extremeScalesPage.getAccessTokenUsingClientTokenService();
		dataStorage.setCustomErrmsg("authToken from Layer 7 service:" + auth_token);
		if (!auth_token.isEmpty()) {
			JSONObject jobj = extremeScalesPage.returnUserDetailsInJsonObjectForm();
	
			Assert.assertTrue(jobj.getString("rectype") + " is not the expcted rectype",
					jobj.getString("rectype").equals("P"));
			Assert.assertTrue(jobj.get("healthSafeIdFlag").toString().equals("true"));
	
			Assert.assertTrue(jobj.getJSONObject("optumId").getString("firstName").equalsIgnoreCase(frstname));
			Assert.assertTrue(jobj.getJSONObject("optumId").getString("lastName").equalsIgnoreCase(lastname));
		}
	
	}
}
