package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAdminPortalUserDeletePage extends PageObjectBase {

	@FindBy(how = How.ID, using = "userSearchBean")
	private WebElement userSearchSection;

	@FindBy(how = How.ID, using = "userId")
	private WebElement userIdTextBox;
	
	@FindBy(how = How.ID, using = "optumId")
	private WebElement optumUserIdTextBox;

	@FindBy(how = How.LINK_TEXT, using = "Back")
	private WebElement topBackButton;

	@FindBy(how = How.XPATH, using = "//input[@class='btnprimary' and @value='Search User to Delete']")
	private WebElement searchUserToDeleteButton;
	
	@FindBy(how = How.ID, using = "actionmessge")
	private WebElement noSearchResultsErrorMessage;
	


	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(userSearchSection)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void enterUserId(String uuid) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userIdTextBox));
		userIdTextBox.sendKeys(uuid);
	}
	
	public void enterOptumUserId(String optumId) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(optumUserIdTextBox));
		optumUserIdTextBox.sendKeys(optumId);
	}
	
	public void clickTopBackButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(topBackButton));
		topBackButton.click();
	}

	public void clickSearchUserToDeleteButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(searchUserToDeleteButton));
		searchUserToDeleteButton.click();
	}
	
	public boolean verifyIfErrorMessageDisplayed()
	{
		try{
		smallWait.get().until(ExpectedConditions.visibilityOf(noSearchResultsErrorMessage));
		return true;
		}
		catch(TimeoutException e)
		{
			return false;
		}
		
	}

}
