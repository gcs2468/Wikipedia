package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.WCPUnauthenticatedHomePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WCPUnauthenticatedHomePageStepDefinition {
	private WCPUnauthenticatedHomePage page;

	public WCPUnauthenticatedHomePageStepDefinition() {
		page = new WCPUnauthenticatedHomePage();
	}

    @Given("^I am at WCP unauthenticated home page$")
    public void iAmAtWCPUnathenticatedHomePage() throws Throwable {
    	page.openPage();
		Assert.assertTrue("Issue while loading WCP unauthenticated page", page.verifyIfPageLoaded());       
    }
    
    @When("^I click on Sign In button in WCP unauthenticated home page$")
    public void iClickOnSignInButtonInWCPUnauthenticatedHomePage() throws Throwable {
        page.clickOnSignInButton();
    }

    @Given("^I should see valid WCP brand logo in WCP On Step3 page of Registeration$")
	public void i_should_see_valid_WCP_brand_logo_in_LAWW() throws Throwable {
		Assert.assertTrue(page.verifyWCPBrandLogoIsDisplayed());
	}
    
    @Given("^I should see WCP Title as \"([^\"]*)\" On Step3 page of registeration$")
	public void i_should_see_WCP_Title_On_Step3_Page_Registeration(String titleWCP) throws Throwable {
		Assert.assertTrue(page.verifyWCPTitleOnStep3RegisterationPage(titleWCP));
	}
 
    @Then("^I should see WCP unauthenticated home page$")
	public void I_should_see_WCP_unauthenticated_home_page() throws Throwable {
    	Assert.assertTrue(page.verifyWCPaunthenticatedHomePage());
		
    }
    
    @Then("^I should be at WCP unauthenticated page$")
	public void i_should_be_at_WCP_unauthenticated_page() throws Throwable {
		Assert.assertTrue("Issue while loading WCP Unauthenticated page", page.verifyIfPageLoaded());

	}
}
