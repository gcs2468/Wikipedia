package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class MailInator_HomePage extends PageObjectBase {

	@FindBy(how = How.ID, using = "inboxfield")
	private WebElement inboxField;
	
	@FindBy(how = How.XPATH, using = "//button[@class='btn btn-dark' and contains(.,'Go!')]")
	private WebElement goButton;
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			mediumWait.get().until(ExpectedConditions.visibilityOf(inboxField));
			return inboxField.isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void enterEmail(String emailWithoutExtention)
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(inboxField));
		inboxField.clear();
		inboxField.sendKeys(emailWithoutExtention);
	}
	
	public void clickGoButton()
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(goButton));
		goButton.click();
	}
	

}
