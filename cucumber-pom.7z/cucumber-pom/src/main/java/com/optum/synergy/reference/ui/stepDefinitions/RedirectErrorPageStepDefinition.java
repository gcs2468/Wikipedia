package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.RedirectErrorPage;

import cucumber.api.java.en.Then;

public class RedirectErrorPageStepDefinition {
	private RedirectErrorPage page;
	
	public RedirectErrorPageStepDefinition() {
		page = new RedirectErrorPage();
	}
	
	@Then("^I should see the message \"([^\"]*)\" on the redirect error page$")
	public void iShouldSeeTheMessageOnTheRedirectErrorPage(String message) throws Throwable {
	    Assert.assertTrue(page.GetMessage().getText().trim().equals(message));
	}
}
