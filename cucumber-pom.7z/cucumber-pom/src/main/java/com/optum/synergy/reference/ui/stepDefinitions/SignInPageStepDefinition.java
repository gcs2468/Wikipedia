package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import com.optum.synergy.reference.ui.pageobjects.SignInPage;
import com.optum.synergy.reference.ui.utility.dataStorage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignInPageStepDefinition {

	private SignInPage page;

	public SignInPageStepDefinition() {
		page = new SignInPage();
	}

	@Then("^I should be at Sign In page$")
	public void i_should_be_at_Sign_In_page() throws Throwable {
		page.verifyIfPageLoaded();
	}

	@Then("^I should see the Sign In page header as \"([^\"]*)\"$")
	public void i_should_see_the_sign_in_page_header_as(String pageHeading) throws Throwable {
		Assert.assertTrue("\"" + pageHeading + "\" is not displaying as Sign in page header",
				page.verifyForPageHeading(pageHeading));
	}
	
	@Then("^I should see \"([^\"]*)\" message on top of SignIn Page$")
	public void i_should_see_message_on_top_of_SignIn_Page(String message) throws Throwable {
		String personalInfoText = page.getMessageOnSignInPage();
		Assert.assertTrue("Did not find expected text [" + message + "]\nFound: [" + personalInfoText + "]",
				personalInfoText.contains(message));
	}

	@Then("^I enter valid \"([^\"]*)\" into Username or email address field in Sign In page$")
	public void i_enter_valid_into_Username_or_email_address_field_in_Login_section(String username) throws Throwable {
		page.enterUserName(username);
		
	}
	
	@Then("^I enter invalid \"([^\"]*)\" into Username or email address field in Sign In page$")
	public void i_enter_invalid_into_Username_or_email_address_field_in_Login_section(String username) throws Throwable {
		page.enterUserName(username);
		
	}
	@Then("^I enter valid username into Username or email address field in Sign In page$")
	public void i_enter_valid_username_into_Username_or_email_address_field_in_Login_section() throws Throwable {
		page.enterUserName(dataStorage.getUserName());
	}

	@Then("^I enter valid emailId into Username or email address field in Sign In page$")
	public void i_enter_valid_emailId_into_Username_or_email_address_field_in_Login_section() throws Throwable {
		page.enterUserName(dataStorage.getEmailId());
	}

	@Then("^I enter valid \"([^\"]*)\" into Password field in Sign In page$")
	public void i_enter_valid_into_Password_field_in_Login_section(String password) throws Throwable {
		page.enterPassword(password);
		// page.enterPassword(new Hooks().getPassword());
	}
	
    @Then("^I enter valid password into Password field in Sign In page$")
    public void iEnterValidPasswordIntoPasswordFieldInSignInPage() throws Throwable {
    	page.enterPassword(dataStorage.getPassword());
    }

	@Then("^I should be at LAWW sign in page$")
	public void i_should_be_at_LAWW_sign_in_page() throws Throwable {
		Assert.assertTrue(page.verifyIfPageLoaded());
	}

	@Then("^I should see the \"([^\"]*)\" label$")
	public void i_should_see_the_label(String arg1) throws Throwable {
		Assert.assertTrue(page.verifyContentLabel(arg1));
	}
		
	@Then("^I click on Live and work well image$")
	public void i_click_on_Live_and_work_well_image() throws Throwable {
		page.clickImg();
	}

	@Then("I click on User menu$")
	public void I_click_on_User_menu() throws Throwable {
		page.userMenuClick();
	}

	@Then("I click on SignInSecurity link$")
	public void I_click_on_SignInSecurity_link() throws Throwable {
		page.SignInSecurityClick();
		Thread.sleep(3000);
	}
	
	@Then("^I click on the Sign in button on SignIn page$")
	public void clickOnSignInButtonOnSignInPage() throws Throwable {
		page.clickSignInButton();
	}

	@Then("I enter \"([^\"]*)\" access code$")
	public void I_enter_access_code(String text) throws Throwable {
		page.enterAccessCode(text);
	}

	@Then("I should see confirmIdentity \"([^\"]*)\" message$")
	public void I_should_see_confirmIdentity_message(String text) throws Throwable {
		Assert.assertTrue(text + " does not exist in confirmIdentity message ", page.verifyConfirmIdentity(text));
	}

	@Then("I should see confirmIdentity \"([^\"]*)\" alert message$")
	public void I_should_see_confirmIdentity_alert_message(String text) throws Throwable {
		Assert.assertTrue(text + " does not exist in alert message ", page.verifyAlertMessage(text));
	}

	@Then("I should see confirmIdentity \"([^\"]*)\" secure message$")
	public void I_should_see_confirmIdentity_secure_message(String text) throws Throwable {
		Assert.assertTrue(text + " does not exist in secure message ", page.verifysecureMessage(text));
	}

	@Then("I should see automated phone call radio button$")
	public void I_should_see_automated_phone_call_radio_button() throws Throwable {
		Assert.assertTrue("automated phone call label", page.automatedPhoneCalldisplay());
	}

	@Then("I should see the Security answer text field$")
	public void I_should_see_the_Security_answer_text_field() throws Throwable {
		Assert.assertTrue("Security text field", page.securityAnswerTextField());
	}

	@Then("I should see security question$")
	public void I_should_see_security_question() throws Throwable {
		Assert.assertTrue("Security text label does not exist", page.securityAnswerLabel());
	}

	@Then("I should see confirmIdentity \"([^\"]*)\" question message$")
	public void I_should_see_confirmIdentity_question_message(String text) throws Throwable {
		Assert.assertTrue(text + " confirm identity text does not exist ", page.verifyConfirmIdentity(text));
	}

	@Then("^I should see the email confirmation message \"([^\"]*)\" in Sign In form$")
	public void i_should_see_the_email_confirmation_message_in_Sign_In_form(String message) throws Throwable {
		Assert.assertTrue(message + " is not displaying on the sign in page",
				page.verifyForConfimationMessage(message));
	}

	@Then("^I should see a Username or email address label with textbox in Sign In page$")
	public void i_should_see_a_Username_or_email_address_label_with_textbox_in_Sign_In_page() throws Throwable {
		Assert.assertTrue("Issue in displaying the Username or email address label with textbox",
				page.verifyIfUsernameOrEmailAddressLabelExistWithTextbox());
	}

	@Then("^I should see a Password label with textbox Sign In page$")
	public void i_should_see_a_Password_label_with_textbox_Sign_In_page() throws Throwable {
		Assert.assertTrue("Issue in displaying the Password label with textbox",
				page.verifyPasswordLableExistWithTextbox());
	}

	@Then("^I should see a Live and Work Well Logo in Sign In page$")
	public void iShouldSeeALiveAndWorkWellLogoInSignInPage() throws Throwable {
		Assert.assertEquals(page.getcontentLogoSourceUrl(),
				PageObjectBase.getEnvVariable("pageLinks.LAWWUnauthenticatedHomePage"));
	}
	
	@Then("^I should see a Sign In error message \"(.*)\"$")
	public void iShouldSeeAnErrorMessage(String expectedMsg ) {
		Assert.assertEquals("FAIL: Did not find expected error message", expectedMsg, page.getErrorMessage());
	}

	@When("^I click on Live and Work Well Logo in Sign In page$")
	public void iClickOnLiveAndWorkWellLogoInSignInPage() throws Throwable {

	}
	
	@Then("^I should not see alert message for username as \"[^\"]*\"$")
	public void ishouldnotseealertmsgforusername(){
		Assert.assertEquals(page.getErrorMsgForUserNamefield(), null);
	}
	
	@Then("^I should not see alert message for password as \"[^\"]*\"$")
	public void ishouldnotseealertmsgforpwd(){
		Assert.assertEquals(page.getErrorMsgForPasswordfield(), null);
	}
	
	@Then("^I should see alert message for username as \"([^\"]*)\"$")
	public void ishouldseealertmsgforusername(String arg1){
		Assert.assertEquals( arg1,page.getErrorMsgForUserNamefield());
	}
	
	@Then("^I should see alert message for password as \"([^\"]*)\"$")
	public void ishouldseealertmsgforpwd(String arg1){
		Assert.assertEquals(arg1,page.getErrorMsgForPasswordfield());
	}
	
	@Then("^I click on HealthSafe ID Link$")
	public void i_click_on_HealthSafeIdLink() throws Throwable {
		page.clickHealthSafeIdLink();
	}
	@Then("^I click on Sign In Link On Global Nav$")
	public void i_click_on_SignInLinkOnGlobalNav() throws Throwable {
		page.clickGlobalNavSignInLink();
	}
}
