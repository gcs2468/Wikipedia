package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.common.ui.controller.WebController;
import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import com.optum.synergy.reference.ui.pageobjects.Registration_CreateAccountSectionPage;
import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;
import com.optum.synergy.reference.ui.utility.dataStorage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registration_PersonalInformationSectionPageStepDefinitions {

	private Registration_PersonalInformationSectionPage page;

	public Registration_PersonalInformationSectionPageStepDefinitions() {
		page = new Registration_PersonalInformationSectionPage();
	}

	@When("^I enter Date of birth with \"([^\"]*)\"$")
	public void i_enter_Date_of_birth_with(String dateOfBirth) throws Throwable {
		page.enterDateOfBirth(dateOfBirth);
		page.clickTab();

	}

	@When("^I enter Zip code with \"([^\"]*)\"$")
	public void i_enter_Zip_code_with(String zipCode) throws Throwable {
		page.enterZipCode(zipCode);
		page.clickTab();
	}

	@When("^I enter first name with \"([^\"]*)\"$")
	public void i_enter_first_name_with(String firstName) throws Throwable {
		page.enterFirstName(firstName);
		page.clickTab();
	}

	@When("^I enter Member ID with \"([^\"]*)\"$")
	public void i_enter_Member_ID_with(String memberId) throws Throwable {
		page.enterMemberID(memberId);
		page.clickTab();
	}

	@When("^I enter Group number with \"([^\"]*)\"$")
	public void i_enter_Group_Number_with(String groupNum) throws Throwable {
		page.enterGroupNumber(groupNum);
		page.clickTab();
	}

	@When("^I enter last name with \"([^\"]*)\"$")
	public void i_enter_last_name_with(String lastName) throws Throwable {
		page.enterLastName(lastName);
		page.clickTab();
	}

	@When("^I enter SSN with \"([^\"]*)\"$")
	public void iEnterSSNWith(String ssn) throws Throwable {
		page.enterSSN(ssn);
		page.clickTab();
	}
	
	@When("^I Click on \"([^\"]*)\" toolTip for Member Id$")
	public void iclickonToolTipForMemberId(String arg1)
			throws Throwable {
		page.ClickOnMemberIdToolTip();
	}

	@When("^I mouse hover over on \"([^\"]*)\" toolTip for Member Id$")
	public void iMouseHoverOverOnToolTipForMemberId(String arg1) throws Throwable {

		page.mouseHoverOnLabel(arg1);

	}

	@Then("I manage the personal information page with member information")
	public void i_manage_personal_information_page() throws Throwable {
		if (page.verifyIfPageLoaded()) {
			// For now, assume that only Zip, MemberID and GroupID will require
			// data and that dataStorage contains necessary information
			i_enter_valid_Zipcode_into_Zip_code_field();
			i_enter_valid_memberid_into_Member_ID_field();
			i_enter_valid_group_number_into_Group_Number_field();

			// These steps use functions from other classes
			Registration_CreateAccountSectionPage createAccountSection = new Registration_CreateAccountSectionPage();
			createAccountSection.clicktermsOfUseCheckBox();
			page.clickButtonBySubmitTypeAndName("Continue");

		}
	}

	@Then("^I should see an error message \"([^\"]*)\" for Date of birth$")
	public void i_should_see_an_error_message_for_Date_of_birth(String errorMessage) throws Throwable {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnDateofBirth());

	}

	@Then("^I should see an error message \"([^\"]*)\" for Do you have your member ID card radio button$")
	public void i_should_see_an_error_message_for_Do_you_have_your_member_ID_card_radio_button(String errorMessage)
			throws Throwable {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnDoYouHaveMemberIDCardRadioButton());

	}

	@Then("^I should not see any error message for Date of birth$")
	public void i_should_not_see_any_error_message_for_Date_of_birth() throws Throwable {
		// Assert.assertTrue(page.verifyNoErrorMessageOnDateofBirth());
		// Assert.assertTrue(page.getErrorMessageOnDateofBirth().isEmpty());
		Assert.assertEquals("Found DoB Error message when expected none", "", page.getErrorMessageOnDateofBirth());
	}

	@Then("^I should see an error message \"([^\"]*)\" for Zip code$")
	public void i_should_see_an_error_message_for_Zip_code(String errorMessage) throws Throwable {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnZipcode());

	}

	@Then("^I should not see any error message for Zip code$")
	public void i_should_not_see_any_error_message_for_Zip_code() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnZipcode());
	}

	@Then("^I should see an error message \"([^\"]*)\" for first name$")
	public void i_should_see_an_error_message_for_first_name(String errorMessage) throws Throwable {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnFirstName());
	}

	@Then("^I should not see any error message for first name$")
	public void i_should_not_see_any_error_message_for_first_name() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnFirstName());
	}

	@Then("^I should see an error message \"([^\"]*)\" for Member ID$")
	public void i_should_see_an_error_message_for_Member_ID(String errorMessage) throws Throwable {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnMemberId());
	}

	@Then("^I should not see any error message for Member ID$")
	public void i_should_not_see_any_error_message_for_Member_ID() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnMemberId());
	}

	@Then("^I should see an error message \"([^\"]*)\" for Group number$")
	public void i_should_see_an_error_message_for_Group_number(String errorMessage) throws Throwable {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnGroupNumber());

	}

	@Then("^I should see an error message \"([^\"]*)\" for last name$")
	public void i_should_see_an_error_message_for_last_name(String errorMessage) throws Throwable {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnLastName());

	}

	@Then("^I should not see any error message for last name$")
	public void i_should_not_see_any_error_message_for_last_name() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnLastName());
	}

	@Then("^I should be at Enter personal information section page$")
	public void i_should_be_at_Enter_personal_information_section_page() throws Throwable {
		Assert.assertTrue("Failed to load Personal Information Page", page.verifyIfPageLoaded());
	}

	@Then("^I enter valid \"([^\"]*)\" into First name field$")
	public void i_enter_valid_into_First_name_field(String firstName) throws Throwable {
		page.enterFirstName(firstName);
	}

	@Then("^I enter valid FirstName into First name field$")
	public void i_enter_valid_FirstName_into_First_name_field() throws Throwable {
		page.enterFirstName(dataStorage.getFirstName());
	}

	@Then("^I enter valid \"([^\"]*)\" into Last name field$")
	public void i_enter_valid_into_Last_name_field(String lastName) throws Throwable {
		page.enterLastName(lastName);
	}

	@Then("^I enter valid LastName into Last name field$")
	public void i_enter_valid_LastName_into_Last_name_field() throws Throwable {
		page.enterLastName(dataStorage.getLastName());
	}

	@Then("^I enter valid \"([^\"]*)\" into Date of birth field$")
	public void i_enter_valid_into_Date_of_birth_field(String dateOfBirth) throws Throwable {
		page.enterDateOfBirth(dateOfBirth);
		page.clickTab();
	}

	@Then("^I enter valid DOB into Date of birth field$")
	public void i_enter_valid_DOB_into_Date_of_birth_field() throws Throwable {
		page.enterDateOfBirth(dataStorage.getDOB());
	}

	@Then("^I enter valid \"([^\"]*)\" into Zip code field$")
	public void i_enter_valid_into_Zip_code_field(String zipcode) throws Throwable {
		page.enterZipCode(zipcode);
		page.clickTab();
	}

	@Then("^I enter valid Zip into Zip code field$")
	public void i_enter_valid_Zipcode_into_Zip_code_field() throws Throwable {
		page.enterZipCode(dataStorage.getZip());
	}

	@Then("^I enter valid \"([^\"]*)\" into Member ID field$")
	public void i_enter_valid_into_Member_ID_field(String memberId) throws Throwable {
		page.enterMemberID(memberId);
	}

	@Then("^I enter valid memberid into Member ID field$")
	public void i_enter_valid_memberid_into_Member_ID_field() throws Throwable {
		page.enterMemberID(dataStorage.getSubscriberID());

	}

	@Then("^I enter valid \"([^\"]*)\" into Group Number field$")
	public void i_enter_valid_into_Group_Number_field(String groupNum) throws Throwable {
		page.enterGroupNumber(groupNum);
	}

	@Then("^I enter valid groupnum into Group Number field$")
	public void i_enter_valid_group_number_into_Group_Number_field() throws Throwable {
		page.enterGroupNumber(dataStorage.getUserDetails("GroupNumber"));

	}

	@Then("^I enter valid altid into Member ID field$")
	public void i_enter_valid_altid_into_Member_ID_field() throws Throwable {
		page.enterMemberID(dataStorage.getAltId());

	}

	@Then("^I enter newvalid memberid into Member ID field$")
	public void i_enter_valid_newmemberid_into_Member_ID_field() throws Throwable {
		page.enterMemberID(dataStorage.getNewSubscriberID());

	}

	@Then("^I enter invalid subscriberid \"([^\"]*)\" into Member ID field$")
	public void i_enter_invalid_subscriberid_into_Member_ID_field(String memberId) throws Throwable {
		page.enterMemberID(memberId);
	}

	@Then("^I enter valid \"([^\"]*)\" into SSN field$")
	public void i_enter_valid_into_SSN_field(String ssn) throws Throwable {
		page.enterSSN(ssn);
	}

	@Then("^I enter invalid \"([^\"]*)\" into SSN field$")
	public void i_enter_invalid_into_SSN_field(String ssn) throws Throwable {
		page.enterSSN(ssn);
	}

	@Then("^I enter valid SSN into SSN field$")
	public void i_enter_validSSN_into_SSN_field() throws Throwable {
		page.enterSSN(dataStorage.getSSN());
	}

	@Then("^I enter invalid ssnnumber \"([^\"]*)\" into SSN field$")
	public void i_enter_invalid_ssnnumber_into_SSN_field(String ssn) throws Throwable {
		page.enterSSN(ssn);
		page.clickTab();
	}

	@Then("^I should not see any error message for SSN$")
	public void iShouldNotSeeAnyErrorMessageForSSN() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnSSN());
	}

	@Then("^I should see an error message \"([^\"]*)\" for SSN$")
	public void iShouldSeeAnErrorMessageForSSN(String message) throws Throwable {
		Assert.assertEquals(message, page.getErrorMessageOnSSN());
	}

	@Then("^I should see \"([^\"]*)\" toolTip for Member Id$")
	public void iShouldSeeToolTipForMemberId(String toolTipName) throws Throwable {
		Assert.assertTrue(page.verifyToolTipOnMemberIDField(toolTipName));
	}

	@Then("^I should see tooltip message \"([^\"]*)\" for Member Id$")
	public void iShouldSeeTooltipMessageForMemberId(String message) throws Throwable {
		Assert.assertTrue(page.verifyForMemberIdToolTipMessage(message));
	}

	@Given("^I should see an Optum Bank Logo$")
	public void i_should_see_an_Optum_Bank_logo() throws Throwable {
		Assert.assertTrue(page.VerifyOptumLogo());

	}

	@Given("^I should see a UHC Logo$")
	public void iShouldSeeAUHCLogo() throws Throwable {
		Assert.assertTrue("Issue displaying UHC Logo", page.verifyUhcLogo());
	}

	@Given("^I should see a MyUHC Logo$")
	public void iShouldSeeAMyUHCLogo() throws Throwable {
		Assert.assertTrue("Issue displaying MyUHC Logo", page.verifyMyUhcLogo());
	}

	@Then("^I should see a MyUHCHealthSelect Logo$")
	public void iShouldSeeAMyUHCHealthSelectLogo() throws Throwable {
		Assert.assertTrue("Issue displaying MyUHCHealthSelect Logo", page.verifyMyUhcHealthSelectLogo());
	}

	@Then("^I should see a MyUHCMyHealthCareView Logo$")
	public void iShouldSeeAMyUHCMyHealthCareViewLogo() throws Throwable {
		Assert.assertTrue("Issue displaying MyUHCMyHealthCareView Logo", page.verifyMyUhcMyHealthCareViewLogo());
	}

	@Given("^I should see a Medica Logo$")
	public void iShouldSeeAMedicaLogo() throws Throwable {
		Assert.assertTrue("Issue displaying Medica Logo", page.verifyMyUhcMedicaLogo());
	}

	@Given("^I should see the \"([^\"]*)\" as form header description in Personal Info page$")
	public void i_should_see_the_in_Personal_Info_page(String Content) throws Throwable {
		Assert.assertEquals(Content, page.getPersonalInfoDescription());
	}

	@Given("^I should see an LAWW Logo$")
	public void i_should_see_an_LAWW_logo() throws Throwable {
		Assert.assertTrue(page.verifyLAWWlogo());
	}

	@Then("^I should see a Member Id Card label with Radiobutton$")
	public void i_should_see_a_Member_Id_Card_label_with_Radiobutton() throws Throwable {
		Assert.assertTrue("Issue in displaying the Member Id card label with radiobutton",
				page.verifyIfMemberIdCardLabelWithRadiobuttonExist());
	}

	@Then("^I should see a GroupOrPolicy number label with text box$")
	public void i_should_see_a_GroupOrPolicy_number_label_with_text_box() throws Throwable {
		Assert.assertTrue("Issue in displaying the Group/Policy number label with text box",
				page.verifyIfGroupOrPolicyNumberLabelWithTextboxExist());
	}

	@Then("^I should see a Social Security Number label with text box$")
	public void i_should_see_a_Social_Security_Number_label_with_text_box() throws Throwable {
		Assert.assertTrue("Issue in displaying the Social Security Number label with text box",
				page.verifyIfSocialSecurityNumberLabelWithTextboxExist());
	}

	@Given("^I should see ssn field is displayed$")
	public void i_should_see_ssn_field_is_displayed() throws Throwable {
		Assert.assertTrue(page.verifyIfSSNFieldIsDisplayed());
	}

	@Given("^I should see memberid field is disabled$")
	public void i_should_see_memberid_field_is_disabled() throws Throwable {
		Assert.assertFalse(page.memberidisenabled());
	}

	@Given("^I should see ssn field is disabled$")
	public void i_should_see_ssn_field_is_disabled() throws Throwable {
		Assert.assertFalse(page.SSNisEnabled());
	}

	@Given("^I should see memberid field is enabled$")
	public void i_should_see_memberid_field_is_enabled() throws Throwable {
		Assert.assertTrue(page.memberidisenabled());
	}

	@Given("^I should see ssn field is not displayed$")
	public void i_should_see_ssn_field_is_not_displayed() throws Throwable {
		Thread.sleep(3000);
		Assert.assertTrue("Issue while not displaying the SSN field", page.verifyIfSSNIsNotDisplayed());
	}

	@Then("^I should see the Enter personal information form header as \"([^\"]*)\"$")
	public void i_should_see_the_Enter_personal_information_form_header_as(String header) throws Throwable {
		Assert.assertTrue("\"" + header + "\" heading is not displaying on the Enter personal information form",
				page.verifyFormHeader(header));
		Thread.sleep(1000);
	}

	@Then("^I should see a First name label with text box$")
	public void i_should_see_a_First_name_label_with_text_box() throws Throwable {
		Assert.assertTrue("Issue in displaying the First name label with text box",
				page.verifyIfFirstnameLabelWithTextboxExist());
	}

	@Then("^I should see a Last name label with text box$")
	public void i_should_see_a_Last_name_label_with_text_box() throws Throwable {
		Assert.assertTrue("Issue in displaying the Last name label with text box",
				page.verifyIfLastnameLabelWithTextboxExist());
	}

	@Then("^I should see a Date of birth label with text box$")
	public void i_should_see_a_Date_of_birth_label_with_text_box() throws Throwable {
		Assert.assertTrue("Issue in displaying the Date of birth label with text box",
				page.verifyIfDOBLabelWithTextboxExist());
	}

	@Then("^I should see a Zip code label with text box$")
	public void i_should_see_a_Zip_code_label_with_text_box() throws Throwable {
		Assert.assertTrue("Issue in displaying the Zip code label with text box",
				page.verifyIfZipcodeLabelWithTextboxExist());
	}

	@Then("^I should see a Member ID label with text box$")
	public void i_should_see_a_Member_ID_label_with_text_box() throws Throwable {
		Assert.assertTrue("Issue in displaying the Member ID label with text box",
				page.verifyIfMemberIdLabelWithTextboxExist());
	}

	@When("^I click on Optum Bank logo$")
	public void i_click_on_Optum_Bank_logo() throws Throwable {
		page.clickOptumLogo();
	}

	@Then("^I should see the \"([^\"]*)\" center content$")
	public void i_should_see_the_center_content(String pageContent) throws Throwable {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying as personal info center content",
				page.verifyForPersonalinfocontent(pageContent));
	}

	@Then("^I should see the \"([^\"]*)\" content header$")
	public void i_should_see_the_center_content_header(String pageContent) throws Throwable {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying as personal info content",
				page.verifycontenHeader(pageContent));
	}

	@Then("^I should see the \"([^\"]*)\" header in step complete$")
	public void i_should_see_the_header_in_step_complete(String pageContent) throws Throwable {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying as personal info form label",
				page.verifytheSubHeadingByH3Tag(pageContent));
	}

	@Then("^I should see the \"([^\"]*)\" form label$")
	public void i_should_see_the_form_label(String pageContent) throws Throwable {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying as personal info form label",
				page.verifyForLabelMain(pageContent));
	}

	@Then("^I should see the Username label$")
	public void i_should_see_the_Username_label() throws Throwable {
		Assert.assertTrue("\"" + "\" is not displaying as personal info form label", page.verifyUsernameLabel());
	}

	@Then("^I should see the Password label$")
	public void i_should_see_the_Password_label() throws Throwable {
		Assert.assertTrue("\"" + "\" is not displaying as personal info form label", page.verifyPasswordLabel());
	}

	@Then("^I should see the Confirm Password label$")
	public void i_should_see_the_Confirm_Password_label() throws Throwable {
		Assert.assertTrue("\"" + "\" is not displaying as personal info form label", page.verifyConfPasswordLabel());
	}

	@Then("^I should see the \"([^\"]*)\" hidden label$")
	public void i_should_see_the_hidden_label(String pageContent) throws Throwable {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying as personal info hidden label",
				page.verifyForHiddenLabel(pageContent));
	}

	@Then("^I should see the \"([^\"]*)\" form right content$")
	public void i_should_see_the_form_right_content(String pageContent) throws Throwable {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying as form right content",
				page.verifyRightViewContent(pageContent));
	}

	@Then("^I should see the \"([^\"]*)\" form left content$")
	public void i_should_see_the_form_left_content(String pageContent) throws Throwable {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying as form lefts content",
				page.verifyFormleftcontent(pageContent));
	}

	@Then("^I should see the \"([^\"]*)\" link in Sign In page routed to correct page url$")
	public void iShouldSeeTheLinkInSignInPageRoutedToCorrectPageUrl(String link) throws Throwable {
		Assert.assertEquals(PageObjectBase.getEnvVariable("pageLinks.signInPage." + link),
				WebController.returnCurrentURL());
		Assert.assertEquals(PageObjectBase.getEnvVariable("pageLinks.signInPage." + link),
				WebController.returnCurrentURL());

	}

	@Then("^I should see the \"([^\"]*)\" form section heading$")
	public void i_should_see_the_form_section_heading(String arg1) throws Throwable {
		Assert.assertTrue("\"" + arg1 + "\" is not displaying as form lefts content", page.verifypageSection(arg1));
	}

	@Then("^I should see the \"([^\"]*)\" form section heading confirm$")
	public void i_should_see_the_form_section_heading_confirm(String arg1) throws Throwable {
		Assert.assertTrue("\"" + arg1 + "\" is not displaying as form lefts content",
				page.verifypageSectionConfirm(arg1));
	}

	@Then("^I should see the \"([^\"]*)\" form section heading create$")
	public void i_should_see_the_form_section_heading_create(String arg1) throws Throwable {
		Assert.assertTrue("\"" + arg1 + "\" is not displaying as form lefts content",
				page.verifypageSectionCreate(arg1));
	}

	@Given("^I should see the page routed to valid url from \"([^\"]*)\" and \"([^\"]*)\" link$")
	public void i_should_see_the_page_routed_to_valid_url_from_and_link(String pageName, String linkName)
			throws Throwable {
		Assert.assertEquals("Failed to navigate to expected page URL", page.getPagelinkFromTestDataXMLFile(pageName, linkName), page.getCurrentPageUrl());

	}

	@Then("^I should see the First name field is not empty$")
	public void iShouldSeeTheFirstNameFieldIsNotEmpty() throws Throwable {
		Assert.assertNotEquals("", page.getFirstNameValue());
	}

	@Then("^I should see the Last name field is not empty$")
	public void iShouldSeeTheLastNameFieldIsNotEmpty() throws Throwable {
		Assert.assertNotEquals("", page.getLastNameValue());
	}

	@Then("^I should see the Last name field is empty$")
	public void iShouldSeeTheLastNameFieldIsEmpty() throws Throwable {
		Assert.assertEquals("", page.getLastNameValue());
	}

	@Then("^I should see the First name field is empty$")
	public void iShouldSeeTheFirstnameFieldIsEmpty() throws Throwable {
		Assert.assertEquals("", page.getFirstNameValue());
	}

	@Then("^I should see the Date of birth field is empty$")
	public void iShouldSeeTheDateOfBirthFieldIsEmpty() throws Throwable {
		Assert.assertEquals("", page.getDateofBirthValue());
	}

	@Then("^I should see the Zip code field is empty$")
	public void iShouldSeeTheZipCodeFieldIsEmpty() throws Throwable {
		Assert.assertEquals("", page.getZipCodeValue() );
	}

	@Then("^I should see the Member ID field is empty$")
	public void iShouldSeeTheMemberIDFieldIsEmpty() throws Throwable {
		Assert.assertEquals("", page.getMemberIdValue());
	}
	
	@Then("^I should see the Group/Policy field is empty$")
	public void iShouldSeeTheGroupPolicyFieldIsEmpty() throws Throwable {
		Assert.assertEquals("",  page.getGroupNumberValue());
	}

	@Then("^I enter valid first name from below list and should not get any error message$")
	public void iEnterValidFirstNameFromBelowListAndShouldNotGetAnyErrorMessage(List<String> arg1) throws Throwable {

		for (String inStr : arg1) {
			String FistName = "First" + inStr + "Name";
			page.enterFirstName(FistName);
			page.clickTab();
			Assert.assertTrue("Unexpected Error displayed on FirstName field validation for special character " + inStr, 
					page.verifyNoErrorMessageOnFirstName());
		}

	}

	@Then("^I enter valid last name from below list and should not get any error message$")
	public void iEnterValidLastNameFromBelowListAndShouldNotGetAnyErrorMessage(List<String> arg1) throws Throwable {

		for (String inStr : arg1) {
			String LastName = "Last" + inStr + "Name";
			page.enterLastName(LastName);
			page.clickTab();
			Assert.assertTrue("Unexpected Error displayed on LastName field validation for special character " + inStr, 
					page.verifyNoErrorMessageOnLastName());
		}

	}

	@Given("^I should see a Home Icon in breadcrumb$")
	public void iShouldSeeAHomeIconInBreadcrumb() throws Throwable {
		Assert.assertTrue("Issue displaying Home Icon in breadcrumb", page.verifyElementByClassName("icon-home"));
	}

	@Given("^I should see a > icon in breadcrumb$")
	public void iShouldSeeAIconInBreadcrumb() throws Throwable {
		Assert.assertTrue("Issue displaying > icon in breadcrumb", page.verifyElementByClassName("fa-angle-right"));
	}

	@Given("^I should see the text \"([^\"]*)\" in breadcrumb$")
	public void iShouldSeeTheTextInBreadcrumb(String arg1) throws Throwable {
		Assert.assertTrue("Issue displaying expected breadcrumb text [" + arg1 + "]",
				page.verifyBreadCrumbContains(arg1));
	}

	@When("^I enter Date of birth with \"([^\"]*)\" for field validation$")
	public void i_enter_Date_of_birth_with_for_field_validation(String dateOfBirth) throws Throwable {
		page.clearAndenterDateOfBirth(dateOfBirth);
		page.clickTab();
	}

	@Then("^I should see auto populated \"([^\"]*)\" first name$")
	public void i_should_see_an_auto_populated_first_name(String firstName) throws Throwable {
		//Force both to all lower before compare
		String value = page.getFirstNameValue();
		if ( value == null ) { value = "NULL_VALUE"; }
		Assert.assertEquals(firstName.toLowerCase(), value.toLowerCase());
	}

	@Then("^I should see auto populated \"([^\"]*)\" last name$")
	public void i_should_see_an_auto_populated_last_name(String lastName) throws Throwable {
		//Force both to all uppercase before compare
		Assert.assertEquals(lastName.toLowerCase(), page.getLastNameValue().toLowerCase());
	}

	@Then("^I should see auto populated \"([^\"]*)\" date of birth$")
	public void i_should_see_an_auto_populated_dob(String DOB) throws Throwable {
		Assert.assertEquals(DOB, page.getDateofBirthValue());
	}

	@Then("^I should see error message \"([^\"]*)\" for Terms and conditions accepted checkbox when not selected$")
	public void i_should_see_error_message_for_Terms_and_conditions_accepted_checkbox_when_not_selected(String message)
			throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnTermConditionsAcceptedcheckbox(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" on top of personal information page$")
	public void iShouldSeeAnErrorMessageOnTopOfPersonalInformationPage(String errMsg) throws Throwable {
		Assert.assertEquals("\"" + errMsg + "\"" + " error message is not displaying on personal information page",
				errMsg, page.getErrorMessage());
	}

	@Then("^I should see an error message \"([^\"]*)\" on personal information page$")
	public void iShouldSeeAnErrorMessageOnPersonalInformationPage(String errMsg) throws Throwable {
		Assert.assertEquals("Expected error message is not displaying on personal information page",
				errMsg, page.PersonalInfoTopErrorMessage());
	}

	@Then("^I enter invalid \"([^\"]*)\" into Zip code field$")
	public void iEnterInvalidIntoZipCodeField(String zip) throws Throwable {
		page.enterZipCode(zip);
		page.clickTab();
	}

	@When("^I enter invalid \"([^\"]*)\" into Date of birth field$")
	public void iEnterInvalidIntoDateOfBirthField(String dob) throws Throwable {
		page.enterDateOfBirth(dob);
		page.clickTab();
	}

	@Then("^I enter invalid \"([^\"]*)\" into First name field$")
	public void iEnterInvalidIntoFirstNameField(String firstName) throws Throwable {
		page.enterFirstName(firstName);
	}

	@When("^I enter invalid \"([^\"]*)\" into Last name field$")
	public void iEnterInvalidIntoLastNameField(String lastName) throws Throwable {
		page.enterLastName(lastName);
	}

	@When("^I enter invalid \"([^\"]*)\" into Group Number field$")
	public void iEnterInvalidIntoGroupNumberField(String groupNumber) throws Throwable {
		page.enterGroupNumber(groupNumber);
	}

	@When("^I select \"([^\"]*)\" for having member ID card$")
	public void IselectforhavingmemberIDcard(String option) throws Throwable {
		page.selectOptionForHavingMemberIDcard(option);
	}

	@When("^I mouse hover on the \"([^\"]*)\" label$")
	public void i_mousehover_on_the_label(String message) throws Throwable {
		page.mouseHoverOnLabel(message);
	}

	@Then("^I should see \"([^\"]*)\" message$")
	public void i_should_see_message_on_ToolTip(String message) throws Throwable {
		Assert.assertTrue(page.validateToolTipMessage(message));
	}

	@When("^I click on \"([^\"]*)\" link under Already Have Health Safe ID$")
	public void i_click_link_under_Already_Have_Health_Safe_ID(String link) throws Throwable {

		page.clickLinkunderAlreadyHaveHealthSafeID(link);
	}

	@When("^I should wait for page load of Link \"([^\"]*)\"$")
	public void i_should_wait_for_PageLoad(String message) throws Throwable {
		page.waitForPageLoadforLink(message);
	}

	@Given("^I should see step \"([^\"]*)\" of registration with heading \"([^\"]*)\"$")
	public void iShouldSeeStepOfRegistrationWithHeading(String arg1, String arg2) throws Throwable {
		Assert.assertTrue(page.verifyStepNumberAndHeading(arg1, arg2));
	}
	
	@Given("^I should not see step \"([^\"]*)\" of registration with heading \"([^\"]*)\"$")
	public void iShouldNotSeeStepOfRegistrationWithHeading(String arg1, String arg2) throws Throwable {
		Assert.assertFalse(page.verifyStepNumberAndHeading(arg1, arg2));
	}

	@Then("^I should see the following content in MemberID PopUp Window$")
	public void iShouldSeeTheFollowingContentInTooltip(List<String> contentList) throws Throwable {
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" content is not displaying on the PopUp",
					page.getMemberIdPopUpWindowContent().contains(content));
		}
	}
	
	@Then("^I should see the Member ID Card images in Member ID PopUp Window$")
    public void iShouldSeeTheMemberIDCardImagesInMemberIDPopUpWindow() throws Throwable {
        Assert.assertTrue("Member ID card images not displayed", page.verifyMemberIdCardImages());
    }

	@Then("^I should see \"([^\"]*)\" button in MemberID PopUp Window$")
	public void iShouldSeeButtoninMemberIDPopUpWindow(String buttonname) throws Throwable {
		Assert.assertEquals("Button not displayed", buttonname, page.getDoneButtonInMemberIdPopUpWindow().getText());
	}

	@When("^I click on close icon in MemberID PopUp Window$")
	public void IclickoncloseIconinMemberIDPopUpWindow() throws Throwable {
		page.clickCloseIconInMemberIdPopupWindow();
	}

	@When("^I should see \"([^\"]*)\" label beside the DOB field$")
	public void iShouldSeeLabelBesideTheDOBField(String message) throws Throwable {
		Assert.assertEquals("Label is not displaying", message, page.getDOBLabel());
	}

	@Then("^I should see \"([^\"]*)\" message on top of Personal Information Page$")
	public void i_should_see_message_on_top_of_Personal_Information_Page(String message) throws Throwable {
		String personalInfoText = page.getMessageOnPersonalInformationPage();
		Assert.assertTrue("Did not find expected text [" + message + "]\nFound: [" + personalInfoText + "]",
				personalInfoText.contains(message));
	}

	@Then("^I should see a MyUHCCommunityPlan Logo$")
	public void iShouldSeeAMyUHCCommunityPlanLogo() throws Throwable {
		Assert.assertTrue("Issue displaying MyUHCCommunityPlan Logo", page.verifyMyUhcCommunityPlanLogo());

	}

	@Then("^I should see a MyUHCMedica Logo$")
	public void iShouldSeeAMyUHCMedicaLogo() throws Throwable {
		Assert.assertTrue("Issue displaying MyUHCMedica Logo", page.verifyMyUhcMedicaLogo());
	}

	@Then("^I should see the following required field messages in the Personal Information Page$")
	public void iShouldSeeTheFollowingRequiredFieldMessagesInThePersonalInformationPage(List<String> contentList)
			throws Throwable {
		String actualPageContent = page.getPersonalInfoRequiredMessage();
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\"" + " content is not displaying in the multiple plan sector page",
					actualPageContent.contains(content));
		}

	}
	
	@When("^I select to register with \"([^\"]*)\"$")
	public void iSelectToRegisterWith(String registerWith) {
		page.selectRegisterWith(registerWith);
	}


}
