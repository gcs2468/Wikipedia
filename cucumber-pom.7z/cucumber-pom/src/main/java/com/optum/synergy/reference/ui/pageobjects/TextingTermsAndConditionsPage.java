package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class TextingTermsAndConditionsPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Texting Terms and Conditions')]")
	private WebElement headerText;

	@FindBy(how = How.ID, using = "decode")
	private WebElement textingTermsConditionsPgContent;

	public boolean verifyHeader(String header) throws InterruptedException {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(headerText)).getText().contains(header);

	}

	public boolean verifyPgContent(String pgContent) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(textingTermsConditionsPgContent)).getText()
				.replaceAll("\\s+", "").contains(pgContent);
	}
}
