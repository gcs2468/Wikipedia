package com.optum.synergy.reference.ui.pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationCompletedEmailPageForLAWW extends PageObjectBase {

	
	@FindBy(how = How.XPATH, using = "html/body/p")
	private List<WebElement> contentList;
	
	public void switchToMailContentInFrame()
	{
		switchToFrameByNameOrId("publicshowmaildivcontent");
	}
	
	public boolean verifyForContent(String content)
	{
		for(WebElement para: contentList)
		{
			if(para.getText().contains(content))
			{
				return true;
			}
			break;
		}
		return false;
	}
	
	public void switchToMailDefaultContent()
	{
		switchToDefaultContent();
	}
}
