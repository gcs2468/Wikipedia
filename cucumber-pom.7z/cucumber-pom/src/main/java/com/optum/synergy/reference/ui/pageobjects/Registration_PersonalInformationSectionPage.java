package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.optum.synergy.reference.ui.utility.dataStorage;

public class Registration_PersonalInformationSectionPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[@ui-view='rightView']/div[@class='ng-binding ng-scope']/p|//div[@ui-view='rightView']/div[@class='ng-scope']")
	private WebElement rightViewContent;

	@FindBy(how = How.NAME, using = "personalInfo")
	private WebElement personalInfoSection;

	@FindBy(how = How.CLASS_NAME, using = "mb30")
	private WebElement personalInfoDescription;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'First name')]/following-sibling::input[@id='piFirstName']|//span[contains(@class,'strong') and contains(.,'First name')]/following-sibling::div[@class='tooltip']/input[@id='piFirstName']")
	private WebElement firstNameLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Last name')]/following-sibling::input[@id='piLastName']|//span[contains(@class,'strong') and contains(.,'Last name')]/following-sibling::div[@class='tooltip']/input[@id='piLastName']")
	private WebElement lastNameLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Date of birth')]/following-sibling::input[@id='piDoB']")
	private WebElement dobLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Zip code')]/following-sibling::input[@id='piZipCode']")
	private WebElement zipCodeLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Member ID')]/following-sibling::input[@id='piMemberId']|//span[contains(@class,'strong') and contains(.,'Member ID')]/following-sibling::input[@name='memberId']")
	private WebElement memberIdLabelWithTextBox;

	@FindBy(how = How.XPATH, using = ".//span[contains(text(),'Do you have your Member ID card?')]/parent::label/following-sibling::div[@class='radio']")
	private WebElement memberIdCardLabelWithRadiobutton;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Group/Policy number')]/following-sibling::input[@id='piGroupNum4Myuhc']")
	private WebElement groupOrPolicyNumberLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Social Security Number')]/following-sibling::input[@id='piSSN']")
	private WebElement ssnLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'form__step1')]/p[contains(@class,'ng-scope')]|//div[@ng-show='pageError']/p")
	private WebElement PersonalInfoTopError;

	@FindBy(how = How.ID, using = "piFirstName")
	private WebElement firstNameTextBox;
	
	@FindBy(how = How.ID, using = "piLastName")
	private WebElement lastNameTextBox;

	@FindBy(how = How.ID, using = "piDoB")
	private WebElement dateOfBirthTextBox;

	@FindBy(how = How.ID, using = "piZipCode")
	private WebElement zipCodeTextBox;

	@FindBy(how = How.XPATH, using = "//*[@id='memberIdModal']//*[contains(@class,'memberId-modal-content')]")
	private WebElement memberIdPopUpWindow;
	
	@FindBy(how = How.XPATH, using = "//div[@class='modal-footer']/button")
	private WebElement doneButtonInMemberIdPopUp;
	
	@FindBy(how = How.XPATH, using = "//*[@id='memberIdModal']//*[@class='icon-close']")
	private WebElement closeIconInMemberIdPopUp;

	@FindBy(how = How.XPATH, using = "//select[starts-with(@id,'registerWith')]")
	private WebElement registerWithDropdown;
	
	// All portals should have the textbox with a "piMemberId" prefix
	@FindBy(how = How.XPATH, using = "//input[starts-with(@id,'piMemberId')]")
	private WebElement memberIdTextBox;

	@FindBy(how = How.XPATH, using = "//input[starts-with(@id,'piGroupNum')]")
	private WebElement groupNumberTextBox;

	@FindBy(how = How.XPATH, using = "//input[starts-with(@id, 'piSSN')]")
	private WebElement ssnTextBox;

	@FindBy(how = How.ID, using = "header")
	private WebElement formHeader;

	@FindBy(how = How.XPATH, using = "//button[@class='button button--primary ng-scope' and contains(.,'Continue')]")
	private WebElement continueButton;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'optum-logo.png')]")
	private WebElement optumLogo;

	@FindBy(how = How.XPATH, using = "//img[@src='https://myoptum-stage.optum.com/content/dam/OptumDashboard/ad-box/logos/uhc_logo.gif']")
	private WebElement uhcLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/logo_myuhc.gif')]|//img[contains(@src,'logos/myuhc.gif')]")
	private WebElement myUhcLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/Lockup_HealthSelect.gif')]|//img[contains(@src,'logos/txers_prelogin.jpg')]")
	private WebElement uhcHealthSelectLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/logo_myhealthcareview.gif')]")
	private WebElement uhcMyHealthCareViewLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/Lockup_Medica.gif')]")
	private WebElement uhcMedicaLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/logo_UHC_CommunityPlan.gif')]")
	private WebElement uhcCommunityPlanLogo;

	@FindBy(how = How.XPATH, using = "//*[@id='pageContent']//img[contains(@src,'optum.com/content/dam/OptumDashboard/ad-box/logos/logo_laww.gif')]")
	private WebElement LAWWLogo;

	@FindBy(how = How.XPATH, using = "//img[@src='https://myoptum-stage.optum.com/content/dam/OptumDashboard/ad-box/logos/logo_laww.gif']")
	private WebElement optumBrandLogo;

	@FindBy(how = How.CLASS_NAME, using = "brandlogo")
	private WebElement GNbrand;

	@FindBy(how = How.XPATH, using = "//p[@class='micro']")
	private WebElement allfieldslabel;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'form__step1')]/div[@class='ng-binding']/p")
	private WebElement centerViewText;

	@FindBy(how = How.XPATH, using = "//flex-content[2]/h2")
	private WebElement contentHeader;

	@FindBy(how = How.XPATH, using = "//flex-content[2]/div//p")
	private WebElement formRightContent;

	@FindBy(how = How.CSS, using = ".strong.ng-binding")
	private WebElement labelMain;

	@FindBy(how = How.CLASS_NAME, using = "ng-pristine")
	private WebElement Stepuplabel;

	@FindBy(how = How.XPATH, using = "//label[contains(@class,'tooltip')]/span[@class='']/span")
	private WebElement hiddenLabel;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'form__step1')]/div[@class='ng-binding']/p")
	private WebElement pageHeaderContent;

	@FindBy(how = How.XPATH, using = "//div[@ui-view='rightView']/div[]")
	private WebElement page;

	@FindBy(how = How.XPATH, using = "//h2[@class='delta ng-binding']")
	private WebElement pageSectionHeading;

	@FindBy(how = How.XPATH, using = "//flex[@class='grey']/h2[@class='delta ng-binding']")
	private WebElement pageSectionHeadingCreate;

	@FindBy(how = How.XPATH, using = "//h2[@class='delta']/span[@class='ng-binding']")
	private WebElement pageSectionHeadingconfirm;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Username')]")
	private WebElement usernameLabel;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Password')]")
	private WebElement passwordLabel;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Confirm password')]")
	private WebElement confirmPasswordLabel;

	@FindBy(how = How.XPATH, using = "//input[@id='registerWithMember' and @ng-value='regOptions.yes']")
	private WebElement optionYesForMemberIDcard;

	@FindBy(how = How.XPATH, using = "//input[@id='registerWithMember' and @ng-value='regOptions.no']")
	private WebElement optionNoForMemberIDcard;

	@FindBy(how = How.XPATH, using = "//label[@for='piFirstName']/span[@class='error']")
	private WebElement firstNameErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[@for='piLastName']/span[@class='error']")
	private WebElement lastNameErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[@for='piDoB']//span[contains(@class,'error') and not(contains(@class,'ng-hide'))]")
	private WebElement dateOfBirthErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[@for='piZipCode']/span[starts-with(@class,'error')]")
	
	private WebElement zipcodeErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'piSSN')]/span[@class='error']")
	private WebElement ssnErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'piMemberId')]//*[@ng-bind-html='piMemberIdError']|//label[@for='piMemberId']/span[@class='error']")
	private WebElement memberIdErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'piGroupNum')]//*[starts-with(@ng-bind-html,'piGroup')]|//label[@for='piGroupNumMyuhc']/span[@class='error']")
	private WebElement groupNumberErrorMsg;

	@FindBy(how = How.XPATH, using = "//input[@id='registerWithMember']/../../p[contains(@class,'error')]")
	private WebElement doYouHaveMemberIdCardErrorMsg;

	@FindBy(how = How.XPATH, using = "//flex-content[@id='header']/h1")
	private WebElement myUhcBreadCrumbContainer;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'form__step1')]/p[contains(@class,'milli ng-binding')]")
	private WebElement personalInfoRequiredMessage;
	
	@FindBy(how = How.XPATH, using = "//*[@id='memberIdModal']/flex//div/img[contains(@src,'rx-card1.png')]")
	private WebElement memberIdCardImage1;
	
	@FindBy(how = How.XPATH, using = "//*[@id='memberIdModal']/flex//div/img[contains(@src,'rx-card2.png')]")
	private WebElement memberIdCardImage2;
    
	public boolean verifyUsernameLabel() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(usernameLabel));
		return usernameLabel.isDisplayed();
	}

	public boolean verifyPasswordLabel() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordLabel));
		return passwordLabel.isDisplayed();
	}

	public boolean verifyConfPasswordLabel() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordLabel));
		return confirmPasswordLabel.isDisplayed();
	}

	public boolean verifypageStepuplabel(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(Stepuplabel));
		System.out.println(Stepuplabel.getText());
		return Stepuplabel.getText().contains(heading);
	}

	@FindBy(how = How.XPATH, using = "//span[contains(@ng-if,\"personalInfoTopError.id===''\")]")
	private WebElement errorText;

	public boolean verifypageSectionCreate(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(pageSectionHeadingCreate));
		System.out.println(pageSectionHeadingCreate.getText());
		return pageSectionHeadingCreate.getText().contains(heading);
	}

	public boolean verifypageSectionConfirm(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(pageSectionHeadingconfirm));
		System.out.println(pageSectionHeadingconfirm.getText());
		return pageSectionHeadingconfirm.getText().contains(heading);
	}

	public boolean verifypageSection(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(pageSectionHeading));
		System.out.println(pageSectionHeading.getText());
		return pageSectionHeading.getText().contains(heading);
	}

	public boolean verifyFormleftcontent(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(pageHeaderContent));
		System.out.println(pageHeaderContent.getText());
		return pageHeaderContent.getText().contains(heading);
	}

	public boolean verifyFormRightcontent(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(formRightContent));
		System.out.println(formRightContent.getText());
		return formRightContent.getText().equals(heading);
	}

	public boolean verifyForPersonalinfocontent(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(centerViewText));
		System.out.println(centerViewText.getText());
		return centerViewText.getText().contains(heading);
	}

	public String getPersonalInfoDescription() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(personalInfoDescription)).getText().trim();
	}

	public boolean verifyForHiddenLabel(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(hiddenLabel));
		System.out.println(hiddenLabel.getText());
		return hiddenLabel.getText().trim().equals(heading);
	}

	public boolean verifyForLabelMain(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(labelMain));
		System.out.println(labelMain.getText());
		return labelMain.getText().contains(heading);
	}

	// public boolean verifyForLabel1Main(String heading){
	// mediumWait.get().until(ExpectedConditions.visibilityOf(label1Main));
	// System.out.println(labelMain.getText());
	// return labelMain.getText().trim().equals(heading);
	// }

	public boolean verifycontenHeader(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(contentHeader));
		System.out.println(contentHeader.getText());
		return contentHeader.getText().trim().equals(heading);
	}

	public boolean verifyForPagecontent(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(rightViewContent));
		System.out.println(rightViewContent.getText());
		return rightViewContent.getText().trim().equals(heading);
	}

	public boolean verifyAllfieldslabel(String message) {
		return allfieldslabel.getText().contains(message);
	}

	public void clickOptumLogo() {
		optumLogo.click();
	}

	public boolean verifyLAWWlogo() {
		return LAWWLogo.isDisplayed();
	}

	public boolean verifyGNBrand() {
		return GNbrand.isDisplayed();
	}

	public boolean verifyMemberid() {
		return memberIdTextBox.isEnabled();
	}

	public boolean verifyOptumBrand() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(optumBrandLogo)).isDisplayed();
	}

	// label[@for='piMemberId']/a[contains(.,'Help me find this number')]

	public boolean VerifyOptumLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(optumLogo)).isDisplayed();
	}

	public boolean verifyUhcLogo() {
		return uhcLogo.isDisplayed();
	}

	public boolean verifyMyUhcLogo() {
		return myUhcLogo.isDisplayed();
	}

	public boolean verifyMyUhcHealthSelectLogo() {
		return uhcHealthSelectLogo.isDisplayed();
	}

	public boolean verifyMyUhcMyHealthCareViewLogo() {
		return uhcMyHealthCareViewLogo.isDisplayed();
	}

	public boolean verifyMyUhcMedicaLogo() {
		return uhcMedicaLogo.isDisplayed();
	}

	public boolean verifyMyUhcCommunityPlanLogo() {
		return uhcCommunityPlanLogo.isDisplayed();
	}

	public boolean verifyIfPageLoaded() {
		try {
			longWait.get().until(ExpectedConditions.visibilityOf(personalInfoSection));
			waitForPageLoad(driver);
			return true;
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void enterFirstName(String firstName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(firstNameTextBox));
		firstNameTextBox.clear();
		firstNameTextBox.sendKeys(firstName);
	}

	public void enterLastName(String lastName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(lastNameTextBox));
		lastNameTextBox.clear();
		lastNameTextBox.sendKeys(lastName);
	}

	public void enterDateOfBirth(String dateOfBirth) throws InterruptedException {
		mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthTextBox));
		dateOfBirthTextBox.clear();
		dateOfBirthTextBox.sendKeys(Keys.BACK_SPACE);
		dateOfBirthTextBox.sendKeys(dateOfBirth.replace("/", ""));
	}

	public void enterZipCode(String zipCode) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(zipCodeTextBox));
		zipCodeTextBox.clear();
		zipCodeTextBox.sendKeys(zipCode);
	}

	public void enterMemberID(String memberId) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdTextBox));
		memberIdTextBox.clear();
		memberIdTextBox.sendKeys(memberId);
	}

	public void enterGroupNumber(String groupNum) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(groupNumberTextBox));
		groupNumberTextBox.clear();
		groupNumberTextBox.sendKeys(groupNum);
	}

	public void enterSSN(String ssn) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(ssnTextBox));
		ssnTextBox.clear();
		ssnTextBox.sendKeys(ssn);
	}

	public boolean SSNisEnabled() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(ssnTextBox));
		return ssnTextBox.isEnabled();
	}

	public boolean SSNisDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(ssnTextBox)).isDisplayed();

	}

	public boolean verifyIfSSNFieldIsDisplayed() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(ssnTextBox));
			return true;
		} catch (TimeoutException e) {
			return false;
		}

	}

	public boolean verifyIfSSNIsNotDisplayed() throws InterruptedException {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(ssnTextBox)) == null;
		} catch (TimeoutException e) {
			return true;
		}
	}

	public boolean memberidisenabled() {
		return memberIdTextBox.isEnabled();
	}

	public void clickContinueButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(continueButton));
		continueButton.click();
	}

	public boolean verifyRightViewContent(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(rightViewContent));
		return rightViewContent.getText().contains(message);
	}

	public String getErrorMessageOnFirstName() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(firstNameErrorMsg));
			return firstNameErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public String getErrorMessageOnLastName() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(lastNameErrorMsg));
			return lastNameErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyNoErrorMessageOnFirstName() {

		try {
			return firstNameErrorMsg.isDisplayed() == false;
		} catch (Exception e ) {
			return true;
		}
		
	}

	public boolean verifyNoErrorMessageOnLastName() {

		try {
			return lastNameErrorMsg.isDisplayed() == false;
		} catch (Exception e ) {
			return true;
		}
		
	}

	public String getErrorMessageOnDateofBirth() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthErrorMsg));
			return dateOfBirthErrorMsg.getText().trim();
		} catch (Exception e) {
			return "";
		}
	}

	public boolean verifyNoErrorMessageOnDateofBirth() {

		try {
			return dateOfBirthErrorMsg.isDisplayed() == false;
		} catch (Exception e ) {
			return true;
		}
	
	}

	public String getErrorMessageOnZipcode() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(zipcodeErrorMsg));
			return zipcodeErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyNoErrorMessageOnZipcode() {
		try {
			return dateOfBirthErrorMsg.isDisplayed() == false;
		} catch (Exception e ) {
			return true;
		}
	}

	public String getErrorMessageOnMemberId() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(memberIdErrorMsg));
			return memberIdErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public String getErrorMessageOnGroupNumber() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(groupNumberErrorMsg));
			return groupNumberErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyNoErrorMessageOnMemberId() {

		try {
			return (memberIdErrorMsg.isDisplayed() == false);
		} catch (Exception e ) {
			return true;
		}
	}

	public String getErrorMessageOnSSN() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(ssnErrorMsg));
			return ssnErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyNoErrorMessageOnSSN() {

		try {
			return (ssnErrorMsg.isDisplayed() == false);
		} catch (Exception e ) {
			return true;
		}
	}

	public void clickPersonalInfoForm() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(personalInfoSection));
		personalInfoSection.click();
	}

	public String getErrorMessageOnDoYouHaveMemberIDCardRadioButton() {
		try {
			mediumWait.get().until(ExpectedConditions.visibilityOf(doYouHaveMemberIdCardErrorMsg));
			return doYouHaveMemberIdCardErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyToolTipOnMemberIDField(String toolTipName) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//label[@for='piMemberId']/a[contains(.,'" + toolTipName + "')]")))
				.isDisplayed() == true;
	}

	public void ClickOnMemberIdToolTip() {
		mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//label[starts-with(@for,'piMemberId')]/a"))).click();							  
	}
	
	public boolean verifyForMemberIdToolTipMessage(String message) {
		return verifyTextByClassName("memberId__tooltip", message);
	}

	public boolean verifyForClassname(String name) {
		return verifyElementByClassName(name);
	}

	public boolean verifyFormHeader(String headerName) {
		smallWait.get().until(ExpectedConditions.visibilityOf(formHeader));
		return formHeader.getText().equals(headerName);
	}

	public boolean verifyIfFirstnameLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(firstNameLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfLastnameLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(lastNameLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfDOBLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(dobLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfZipcodeLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(zipCodeLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfMemberIdLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(memberIdLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfMemberIdCardLabelWithRadiobuttonExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(memberIdCardLabelWithRadiobutton)).isDisplayed();
	}

	public boolean verifyIfGroupOrPolicyNumberLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(groupOrPolicyNumberLabelWithTextBox))
				.isDisplayed();
	}

	public boolean verifyIfSocialSecurityNumberLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(ssnLabelWithTextBox)).isDisplayed();
	}

	public void clearAndenterDateOfBirth(String dateOfBirth) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthTextBox));
		dateOfBirthTextBox.clear();
		dateOfBirthTextBox.sendKeys(dateOfBirth.replace("/", ""));
	}

	public String getFirstNameValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(firstNameTextBox)).getAttribute("value");
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("Exception getting PersonalInfo::FirstName [" + e + "]");
			return null;
		}
	}

	public String getLastNameValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(lastNameTextBox)).getAttribute("value");
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("Exception getting PersonalInfo::LastName [" + e.getMessage() + "]");
			return null;
		}
	}

	public String getDateofBirthValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthTextBox)).getAttribute("value");
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("Exception getting PersonalInfo::DoB [" + e.getMessage() + "]");
			return null;
		}
	}
	
	public String getZipCodeValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(zipCodeTextBox)).getAttribute("value");
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("Exception getting PersonalInfo::ZipCode [" + e.getMessage() + "]");
			return null;
		}
	}
	
	public String getMemberIdValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdTextBox)).getAttribute("value");
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("Exception getting PersonalInfo::MemberId [" + e.getMessage() + "]");
			return null;
		}
	}
	
	public String getGroupNumberValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(groupNumberTextBox)).getAttribute("value");
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("Exception getting PersonalInfo::GroupNum [" + e.getMessage() + "]");
			return null;
		}
	}

	public boolean verifyErrorMessageOnTermConditionsAcceptedcheckbox(String message) {

		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//div[@ng-show='submitted && !login.termsAndConditionsAccepted']/*[contains(.,'"
								+ message + "')]")))
				.isDisplayed();
	}

	public boolean verifyErrorMessageOnMemberID(String message) {

		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By
						.xpath("//input[@id='piDoB']/following-sibling::span[contains(@class,'error') and contains(.,'"
								+ message + "')]")))
				.isDisplayed();
	}

	public String getErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(errorText)).getText();
	}

	public String PersonalInfoTopErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(PersonalInfoTopError)).getText();
	}

	public void selectOptionForHavingMemberIDcard(String arg) {
		if (arg.equalsIgnoreCase("YES")) {
			optionYesForMemberIDcard.click();
		} else {
			optionNoForMemberIDcard.click();
		}

	}

	public boolean verifyPersonalInfoDescription(String personalInfoContent) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(personalInfoDescription)).getText()
				.replaceAll("\\s+", "").contains(personalInfoContent);
	}

	public void mouseHoverOnLabel(String message) {

		WebElement elem = mediumWait.get().until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//*[@class='tooltip']/*[contains(.,'" + message + "')]/i")));

		mouseHoverOnElement(elem);

	}

	public boolean validateToolTipMessage(String message) {
		return mediumWait.get()
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[@class='tooltip']/*[contains(.,'" + message + "')]")))
				.isDisplayed();
	}

	public void clickLinkunderAlreadyHaveHealthSafeID(String linkName) {
		mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[@class='ng-binding ng-scope']/p[contains(.,'" + linkName + "')]/b"))).click();
	}

	public void waitForPageLoadforLink(String linkName) {
		longWait.get().until(
				ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='ng-binding ng-scope']/b[contains(.,'"
						+ linkName + "')]|//*[@id='Login']/*[contains(.,'" + linkName + "')]")));
	}

	public String getMessageOnPersonalInformationPage() {
		return longWait.get()
				.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//*[@id='Login']/div[@class='form__step1--haveaccess']")))
				.getText();
	}

	public boolean verifyBreadCrumbContains(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(myUhcBreadCrumbContainer));
		return myUhcBreadCrumbContainer.getText().contains(heading);
	}

	public boolean verifyStepNumberAndHeading(String stepNumber, String stepLabel) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[contains(@class,'circle') and contains(text(),'" + stepNumber
								+ "')]/parent::p/parent::flex-content/following-sibling::flex-content/h2")))
				.getText().trim().contains(stepLabel);
	}

	public String getDOBLabel() {
		return smallWait.get().until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//label[@for='piDoB']/p/span")))
				.getText();
	}

	public boolean verifyMessageOnPersonalInformationPage(String message) {
		return longWait.get()
				.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//*[@id='Login']/*[contains(.,'" + message + "')]")))
				.isDisplayed();
	}

	public String getMemberIdPopUpWindowContent() {
			String memderIdPopUpWindowContent = mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdPopUpWindow)).getText();
			return memderIdPopUpWindowContent;
	}
	
	public WebElement getDoneButtonInMemberIdPopUpWindow() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(doneButtonInMemberIdPopUp));
	}
	
	public void clickCloseIconInMemberIdPopupWindow() {
		 mediumWait.get().until(ExpectedConditions.visibilityOf(closeIconInMemberIdPopUp)).click();
		 //small wait to ensure modal closes
		 try {	Thread.sleep(500); } catch (InterruptedException e) {}
	}
	
	public String getPersonalInfoRequiredMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(personalInfoRequiredMessage)).getText().trim();
	}
	
	public boolean verifyMemberIdCardImages(){
        return mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdCardImage1)).isDisplayed() &&
                   mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdCardImage2)).isDisplayed();        
	}

	public void selectRegisterWith(String registerType) {
		mediumWait.get().until(
				ExpectedConditions.textToBePresentInElement(registerWithDropdown, registerType));
		Select dropdown = new Select(registerWithDropdown);
		dropdown.selectByVisibleText(registerType);
	}
}
