package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class WCPAuthenticatedPage extends PageObjectBase{

	@FindBy(how = How.ID, using = "usermenu")
	private WebElement globalNavUserMenu;
	@FindBy(how = How.ID, using = "hero-header")
	private WebElement ContentPageHeading;
	
	public boolean verifyIfUserMenuDisplayedOnGlobalNav()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(globalNavUserMenu)).isDisplayed();
	}
	
	public String getPageHeading()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(ContentPageHeading)).getText();
	}

}
