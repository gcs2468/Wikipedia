package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.LAWWUnauthenticatedHomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LAWWUnauthenticatedHomePageStepDefinition {
	
	private LAWWUnauthenticatedHomePage page;

	public LAWWUnauthenticatedHomePageStepDefinition() {
		page = new LAWWUnauthenticatedHomePage();
	}

	@Given("^I am at LAWW unauthenticated home page$")
	public void i_am_at_unauthenticated_home_page() throws Throwable {
		
		page.openPage();
		Assert.assertTrue("Issue while loading unauthenticated page", page.verifyIfPageLoaded());
	}

	@When("^I click on Register link$")
	public void i_click_on_Register_link() throws Throwable {
		page.clickRegisterLink();
	}
	
	@When("^I click on Sign In link$")
	public void i_click_on_SignIn_link() throws Throwable {
		page.clickSignInLink();
	}

	@Given("^I should see valid global nav brand logo in LAWW home page$")
	public void i_should_see_valid_optum_brand_logo() throws Throwable {
		Assert.assertTrue(page.verifyIfBrandLogoIsDisplayed());
	}

	@Then("^I should be at [^ ]* unathenticated page$")
	public void i_should_be_at_LAWW_unathenticated_page() throws Throwable {
		Assert.assertTrue("Issue while loading LAWW Unathenticated page", page.verifyIfPageLoaded());
	}

	@Then("^I should be at [^ ]* unathenticated page with signed out message \"([^\"]*)\"$")
	public void i_should_be_at_LAWW_unathenticated_page_with_signed_out_message(String message) throws Throwable {
		Assert.assertTrue("Issue while displaying the signed out message " + message,
				page.verifyForSignedOutMessage(message));
	}

	@Given("^I should see valid Optum brand logo in LAWW On Step3 page of Registeration$")
	public void i_should_see_valid_optum_brand_logo_in_LAWW() throws Throwable {
		Assert.assertTrue(page.verifyOptumBrandLogoIsDisplayed());
	}
	
	@Given("^I should see LAWW Title as \"([^\"]*)\" On Step3 page of registeration$")
	public void i_should_see_LAWW_Title_On_Step3_Page_Registeration(String titleLAWW) throws Throwable {
		Assert.assertTrue(page.verifyLAWWTitleOnStep3RegisterationPage(titleLAWW));
	}

	@Then("^I click on authentication popup to exit the registeration process on Registeration Step3 Page$")
	public void I_Click_On_Link_RegisterationStep3() throws Throwable {
		page.clickOnSignInStep3RegisterationPage();
	}
	
	@Then("^I should see LAWW unauthenticated home page$")
	public void I_should_see_LAWW_unauthenticated_home_page() throws Throwable {
		Assert.assertTrue(page.verifyLAWWaunthenticatedHomePage());
	}

	
}
