package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.ConfirmPhoneNumberModelPage;
import cucumber.api.java.en.Then;

public class ConfirmPhoneNumberModelPageStepDefinition {
	private ConfirmPhoneNumberModelPage page;

	public ConfirmPhoneNumberModelPageStepDefinition() {
		page = new ConfirmPhoneNumberModelPage();
	}
	
    @Then("^I enter the confirmation code into Confirmation code field$")
    public void iEnterTheConfirmationCodeIntoConfirmationCodeField() throws Throwable {
     //   page.verifyIfPageLoaded();
        page.enterConfirmationCode();
        
    }
}
