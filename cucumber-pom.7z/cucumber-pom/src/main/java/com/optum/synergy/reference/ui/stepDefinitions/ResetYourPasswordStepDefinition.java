package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ResetYourPasswordPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ResetYourPasswordStepDefinition {
	private ResetYourPasswordPage page;
	private String captchaImageUrl = "";

	public ResetYourPasswordStepDefinition() {
		page = new ResetYourPasswordPage();
	}

	@Then("^I should be at Reset your password page$")
	public void i_should_be_at_Reset_your_password_page() throws Throwable {
			Assert.assertTrue("Issue while loading Reset your password page",page.verifyIfPageLoaded());
	}
	
	@Then("^I should see the Reset your password page header as \"([^\"]*)\"$")
	public void i_should_see_the_Reset_your_password_page_header_as(String pageHeader) throws Throwable {
	 Assert.assertTrue("\""+pageHeader+"\" heading is not displaying on the Reset your password page", page.verifyForPageHeader(pageHeader));
	}

	@Then("^I should see a \"([^\"]*)\" return link on return header bar$")
	public void i_should_see_a_return_link_on_return_header_bar(String link) throws Throwable {
		Assert.assertTrue(link + " does not exist on return header bar", page.verifyReturnLinkOnHeaderBar(link));
	}

	@When("^I click on \"([^\"]*)\" return link on return header bar$")
	public void i_click_on_return_link_on_return_header_bar(String link) throws Throwable {
		page.clickReturnLinkOnHeaderBar(link);
	}

	@Then("^I stored the captcha image url into a variable$")
	public void i_stored_the_captcha_image_url_into_a_variable() throws Throwable {
		captchaImageUrl = page.getCaptchaImageSourceUrl();
	}

	@Then("^I should see a new captha image url$")
	public void i_should_see_a_new_captha_image_url() throws Throwable {
		Assert.assertTrue("no new captcha image displayed", captchaImageUrl == page.getCaptchaImageSourceUrl());
	}

	@Then("^I should see a captcha audio player$")
	public void i_should_see_a_captcha_audio_player() throws Throwable {
		Assert.assertTrue("Audio captcha is not displayed", page.verifyIfAudioPlayerDisplayed());
	}

	@Then("^I should see a register again link in right view content$")
	public void i_should_see_a_register_again_link_in_right_view_content() throws Throwable {
		Assert.assertTrue("Register again link is not displayed in right view section",
				page.verifyIfRegisterAgainLinkInRightViewIsDisplayed());
	}

	@Then("^I should see the following header content on Reset your password form$")
	public void i_should_see_the_following_header_content_on_Reset_your_password_form(List<String> contents)
			throws Throwable {
		for (String content : contents) {
			Assert.assertTrue(content + " does not exist on Reset your password form", page.verifyFormContent(content));
		}
	}

	@Then("^I should see a label for username field with heading \"([^\"]*)\"$")
	public void i_should_see_a_label_for_username_field_with_heading(String userNameLabel) throws Throwable {
		Assert.assertTrue(userNameLabel + " label with text box doesn't exist",
				page.verifyForUserNameTextBoxWithHeading(userNameLabel));
	}

	@Then("^I should see a label for captcha field with heading \"([^\"]*)\"$")
	public void i_should_see_a_label_for_captcha_field_with_heading(String captchaLabel) throws Throwable {
		Assert.assertTrue(captchaLabel + " label with text box doesn't exist",
				page.verifyForCaptchaTextBoxWithHeading(captchaLabel));
	}

	@Then("^I should see the following right view content in Reset your password page$")
	public void i_should_see_the_following_right_view_content_in_reset_your_password_page(List<String> contents)
			throws Throwable {
		for (String content : contents) {
			Assert.assertTrue(content + " does not exist on Reset your password form",
					page.verifyRightViewFormContent(content));
		}
	}

	@Given("^I should see the optum logo with valid image source url$")
	public void i_should_see_the_optum_logo_with_valid_image_source_url() throws Throwable {
		Assert.assertTrue("optum logo is not displaying", page.verifyForTheOptumLogo());
	}

	@Then("^I should see header with heading \"([^\"]*)\" on step \"([^\"]*)\"$")
	public void iShouldSeeStepOfWithHeading(String headingName, String stepNumber) throws Throwable {
	Assert.assertEquals(headingName, page.getHeaderTextOfHeadingsAlongWithSteps(stepNumber));
	}
	
	@Then("^I should see header with heading \"([^\"]*)\" is bold on step \"([^\"]*)\"$")
	public void iShouldSeeStepOfWithHeadingisBold(String headingName, String stepNumber) throws Throwable {
		//Value 700 means text is in bold
		Assert.assertEquals("700", page.getCSSValueIfHeaderBoldOrNotOfHeadingsAlongWithSteps(stepNumber));
		}
	@Then("^I should see header with heading \"([^\"]*)\" is not bold on step \"([^\"]*)\"$")
	public void iShouldSeeStepOfWithHeadingisNotBold(String headingName, String stepNumber) throws Throwable {
		//Value 700 means text is in bold
		Assert.assertNotEquals("700", page.getCSSValueIfHeaderBoldOrNotOfHeadingsAlongWithSteps(stepNumber));
		}
}
