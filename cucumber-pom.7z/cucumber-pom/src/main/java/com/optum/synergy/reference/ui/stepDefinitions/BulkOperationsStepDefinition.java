package com.optum.synergy.reference.ui.stepDefinitions;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.optum.synergy.reference.ui.pageobjects.Hooks;
import com.optum.synergy.reference.ui.pageobjects.LAWWAuthenticatedPage;
import com.optum.synergy.reference.ui.pageobjects.LAWWUnauthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.MailInator_ConfirmRegistrationEmailPage;
import com.optum.synergy.reference.ui.pageobjects.MailInator_HomePage;
import com.optum.synergy.reference.ui.pageobjects.MailInator_InboxPage;
import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import com.optum.synergy.reference.ui.pageobjects.Registration_ConfirmEmailSectionPage;
import com.optum.synergy.reference.ui.pageobjects.Registration_CreateAccountSectionPage;
import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;
import com.optum.synergy.reference.ui.pageobjects.SignInPage;
import com.optum.synergy.reference.ui.pageobjects.TestDataExcelPage;
import com.optum.synergy.reference.ui.utility.DriverFactory;

import cucumber.api.java.en.Given;

public class BulkOperationsStepDefinition {
	
	PageObjectBase page = new PageObjectBase();

	@Given("^I should be able to register bulk tier1 users with the following details and confirm the registration from email$")
	public void i_should_be_able_to_register_bulk_tier1_users_with_the_following_details_and_confirm_the_registration_from_email(
			List<String> userDetails) throws Throwable {
		int registrationCompletedCount = 0;
		WebDriver driver = DriverFactory.getDeviceDriver();
		Assert.assertTrue(userDetails.contains("FirstName"));
		Assert.assertTrue(userDetails.contains("LastName"));
		Assert.assertTrue(userDetails.contains("DOB"));
		Assert.assertTrue(userDetails.contains("Zip"));
		Assert.assertTrue(userDetails.contains("UserName"));
		Assert.assertTrue(userDetails.contains("Email"));
		TestDataExcelPage testDataWorkbook = new TestDataExcelPage();
		XSSFSheet lawwUsersSheet = testDataWorkbook
				.getSheetFromExcelWorkbook(PageObjectBase.getSystemVariable("bulk_usernames_sheet"));
		Map<String, Integer> columnNamesWithIndices = testDataWorkbook
				.getColumnIndicesBasedOnColumnNamesFromASheet(lawwUsersSheet, userDetails);
		System.out.println(columnNamesWithIndices);
		Integer resultColumnIndex = null;
		Row firstRow = lawwUsersSheet.getRow(0);
		for (Cell cell : firstRow) {
			if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
				if (cell.getStringCellValue().trim().equals("Registered?")) {
					resultColumnIndex = cell.getColumnIndex();
					System.out.println(resultColumnIndex);
					break;
	
				}
			}
		}
		for (int i = 1; i < lawwUsersSheet.getPhysicalNumberOfRows(); i++) {
			String result = "";
			String firstName = null;
			String lastName = null;
			String dob = null;
			String zip = null;
			String username = null;
			String email = null;
			String password = "Password@1";
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "FirstName Column shouldn't be blank";
						/*
						 * firstName = ""; System.out.println("");
						 */
					} else {
						System.out.println(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName")).toString());
						firstName = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName"))
								.toString();
					}
				} catch (NullPointerException e) {
					result = "FirstName Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "LastName Column shouldn't be blank";
						/*
						 * lastName = ""; System.out.println("");
						 */
					} else {
						System.out.println(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName")).toString());
						lastName = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName")).toString();
					}
				} catch (NullPointerException e) {
					result = "LastName Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("DOB"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "DOB Column shouldn't be blank";
						/*
						 * dob = ""; System.out.println("");
						 */
					} else {
						System.out.println(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("DOB")).getRawValue());
						dob = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("DOB")).getRawValue();
					}
				} catch (NullPointerException e) {
					result = "DOB Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Zip"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "Zip Column shouldn't be blank";
						/*
						 * zip = ""; System.out.println("");
						 */
					} else {
						System.out.println(new DataFormatter()
								.formatCellValue(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Zip"))));
						zip = new DataFormatter()
								.formatCellValue(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Zip")));
					}
				} catch (NullPointerException e) {
					result = "Zip Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("UserName"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "UserName Column shouldn't be blank";
						/*
						 * username = ""; System.out.println("");
						 */
					} else {
						System.out.println(new DataFormatter().formatCellValue(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("UserName"))));
						username = new DataFormatter().formatCellValue(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("UserName")));
					}
				} catch (NullPointerException e) {
					result = "UserName Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Email"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "Email Column shouldn't be blank";
						// email = "";
						// System.out.println("");
					} else {
						System.out.println(new DataFormatter().formatCellValue(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Email"))));
						email = new DataFormatter()
								.formatCellValue(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Email")));
					}
				} catch (NullPointerException e) {
					result = "Email Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					LAWWUnauthenticatedHomePage homePage = new LAWWUnauthenticatedHomePage();
					homePage.openPage();
					// refreshPage();
					// driver.switchTo().defaultContent();
					homePage.clickRegisterLink();
				} catch (Exception e) {
					result = "Issue in LAWW Unauthentication page, please find screenshot";
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					// Now you can do whatever you need to do with it, for
					// example copy
					// somewhere
	
					FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
				}
			}
			if (result == "") {
				try {
	
					Registration_PersonalInformationSectionPage personalInfoPage = new Registration_PersonalInformationSectionPage();
					personalInfoPage.verifyIfPageLoaded();
					// Filling the personal Information section info
					personalInfoPage.enterFirstName(firstName);
					personalInfoPage.enterLastName(lastName);
					personalInfoPage.enterDateOfBirth(dob);
					personalInfoPage.enterZipCode(zip);
					personalInfoPage.clickContinueButton();
					Registration_CreateAccountSectionPage createAccountPage = new Registration_CreateAccountSectionPage();
					Assert.assertTrue(createAccountPage.verifyIfPageLoaded());
				} catch (Exception e) {
					result = "Issue in personal Information section, please find screenshot";
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					// Now you can do whatever you need to do with it, for
					// example copy
					// somewhere
	
					FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
				}
			}
			if (result == "") {
				try {
					Registration_CreateAccountSectionPage createAccountPage = new Registration_CreateAccountSectionPage();
					createAccountPage.enterUserName(username);
					createAccountPage.enterPassword(password);
					createAccountPage.enterConfirmPassword(password);
					createAccountPage.clickContinueButton();
					createAccountPage.enterEmail(email);
					createAccountPage.confirmEmail(email);
					createAccountPage.selectSecurityType("Security questions");
					createAccountPage.selectSecurityQuestion1("What was your first phone number?");
					createAccountPage.enterSecurityAnswer1("number1");
					createAccountPage.selectSecurityQuestion2("What is your best friend's name?");
					createAccountPage.enterSecurityAnswer2("name1");
					createAccountPage.selectSecurityQuestion3("What is your favorite color?");
					createAccountPage.enterSecurityAnswer3("color1");
					createAccountPage.clickContinueButton();
					createAccountPage.clickRememberThisDeviceCheckBox();
					createAccountPage.clickContinueButton();
					createAccountPage.clicktermsOfUseCheckBox();
					createAccountPage.clickContinueButton();
					Registration_ConfirmEmailSectionPage confirmEmailPage = new Registration_ConfirmEmailSectionPage();
					confirmEmailPage = new Registration_ConfirmEmailSectionPage();
					Assert.assertTrue(confirmEmailPage.verifyIfPageLoaded());
	
					registrationCompletedCount = registrationCompletedCount++;
					Thread.sleep(3000);
				} catch (Exception e) {
					result = "Issue in Create account section, please find screenshot";
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
				}
	
				if (result == "") {
					try {
						Registration_ConfirmEmailSectionPage confirmEmailPage = new Registration_ConfirmEmailSectionPage();
						confirmEmailPage
								.verifyFormContent("To continue, please click the confirmation link in the email.");
					} catch (Exception e) {
						result = "Issue in Email confirmation section, please find screenshot";
						File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
					}
				}
				if (result == "") {
					try {
						// ArrayList<String> tabs = new
						// ArrayList<String>(driver.getWindowHandles());
						/*
						 * if (registrationCompletedCount == 0) {
						 * driver.findElement(By.cssSelector("body")).
						 * sendKeys(Keys.CONTROL + "t"); } else {
						 * driver.findElement(By.cssSelector("body")).
						 * sendKeys(Keys.CONTROL, Keys.TAB);
						 * 
						 * confirmEmailPage.confirmEmailSection.sendKeys(
						 * Keys.TAB);
						 * confirmEmailPage.confirmEmailSection.sendKeys(
						 * Keys.ENTER);
						 * 
						 * }
						 */
	
						/*
						 * tabs = new
						 * ArrayList<String>(driver.getWindowHandles());
						 * driver.switchTo().window(tabs.get(0));
						 */
	
						driver.get("https://www.mailinator.com");
						driver.switchTo().defaultContent();
						try {
							page.verifyElementById("inboxfield");
						} catch (Exception e) {
							Assert.assertTrue(page.clickOnALinkByhrefPartialText("https://www.mailinator.com"));
							page.verifyElementById("inboxfield");
						}
						MailInator_HomePage mailHomePage = new MailInator_HomePage();
						Assert.assertTrue(mailHomePage.verifyIfPageLoaded());
	
						String[] emailElems = email.split("@");
						mailHomePage.enterEmail(emailElems[0]);
						mailHomePage.clickGoButton();
						MailInator_InboxPage mailInbox = new MailInator_InboxPage();
						mailInbox.verifyForConfirmEmailAddressMail();
						mailInbox.clickOnConfirmEmailAddressMail();
	
						// driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL,Keys.SHIFT,Keys.TAB);
						/*
						 * driver.findElement(By.id("header-1")).sendKeys
						 * (Keys.TAB);
						 * driver.findElement(By.id("header-1")).sendKeys
						 * (Keys.ENTER);
						 */
					} catch (Exception e) {
						result = "Issue in recieving the email in mailinator, please find screenshot";
						File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
					} finally {
						// driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL,
						// Keys.SHIFT, Keys.TAB);
						/*
						 * ArrayList<String> tabs2 = new ArrayList<String>
						 * (driver.getWindowHandles());
						 * driver.switchTo().window(tabs2.get(0));
						 */
						/*
						 * driver.findElement(By.id("header-1")).sendKeys
						 * (Keys.TAB);
						 * driver.findElement(By.id("header-1")).sendKeys
						 * (Keys.ENTER);
						 */
					}
	
				}
				if (result == "") {
					try {
						MailInator_ConfirmRegistrationEmailPage confirmRegistrationPage = new MailInator_ConfirmRegistrationEmailPage();
						confirmRegistrationPage.verifyIfPageLoaded();
						confirmRegistrationPage.switchToEmailContentFrame();
						confirmRegistrationPage.clickConfirmEmailAddressLink();
						confirmRegistrationPage.switchToDefaultContent();
						result = "Pass";
						ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
						if (tabs2.size() == 2) {
							driver.switchTo().window(tabs2.get(1));
							/*
							 * driver.switchTo().defaultContent(); SignInPage
							 * signinPage = new SignInPage();
							 * 
							 * try {
							 * Assert.assertTrue(signinPage.verifyIfPageLoaded()
							 * ); Assert.assertTrue(signinPage.
							 * verifyForConfimationMessage(
							 * "Thank you. We’ve confirmed your email address. Please sign in to continue."
							 * )); } catch (AssertionError e) {
							 * e.printStackTrace(); }
							 */
							driver.close();
							driver.switchTo().window(tabs2.get(0));
							driver.switchTo().defaultContent();
						}
	
					} catch (Exception e) {
						result = "Issue while confirming the registration, please find screenshot";
						File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
					}
				}
			}
			System.out.println("result is : " + result);
			Cell cell = null;
			try {
				cell = lawwUsersSheet.getRow(i).getCell(resultColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (result == "Pass") {
					cell.removeCellComment();
					cell.setCellValue(result);
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.removeCellComment();
					cell.setCellValue(result);
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
	
			} catch (NullPointerException e) {
				cell = lawwUsersSheet.getRow(i).createCell(resultColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (result == "Pass") {
					cell.removeCellComment();
					cell.setCellValue(result);
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.removeCellComment();
					cell.setCellValue(result);
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
			}
	
			testDataWorkbook.fileIn.close();
			FileOutputStream output_file = new FileOutputStream(
					new File(PageObjectBase.getSystemVariable("test_data_Workbook_location")));
			testDataWorkbook.workbook.write(output_file);
			output_file.close();
	
		}
	}

	@Given("^I should be able to register bulk tier1 users with the following details$")
	public void i_should_be_able_to_register_new_users(List<String> userDetails) throws Throwable {
		int registrationCompletedCount = 0;
		WebDriver driver = DriverFactory.getDeviceDriver();
		Assert.assertTrue(userDetails.contains("FirstName"));
		Assert.assertTrue(userDetails.contains("LastName"));
		Assert.assertTrue(userDetails.contains("DOB"));
		Assert.assertTrue(userDetails.contains("Zip"));
		Assert.assertTrue(userDetails.contains("UserName"));
		Assert.assertTrue(userDetails.contains("Email"));
		TestDataExcelPage testDataWorkbook = new TestDataExcelPage();
		XSSFSheet lawwUsersSheet = testDataWorkbook
				.getSheetFromExcelWorkbook(PageObjectBase.getSystemVariable("laww_users_sheet"));
		Map<String, Integer> columnNamesWithIndices = testDataWorkbook
				.getColumnIndicesBasedOnColumnNamesFromASheet(lawwUsersSheet, userDetails);
		System.out.println(columnNamesWithIndices);
		Integer resultColumnIndex = null;
		Row firstRow = lawwUsersSheet.getRow(0);
		for (Cell cell : firstRow) {
			if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
				if (cell.getStringCellValue().trim().equals("Result")) {
					resultColumnIndex = cell.getColumnIndex();
					System.out.println(resultColumnIndex);
					break;
	
				}
			}
		}
		for (int i = 1; i < lawwUsersSheet.getPhysicalNumberOfRows(); i++) {
			String result = "";
			String firstName = null;
			String lastName = null;
			String dob = null;
			String zip = null;
			String username = null;
			String email = null;
			String password = "Password@1";
	
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "FirstName Column shouldn't be blank";
						/*
						 * firstName = ""; System.out.println("");
						 */
					} else {
						System.out.println(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName")).toString());
						firstName = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("FirstName"))
								.toString();
					}
				} catch (NullPointerException e) {
					result = "FirstName Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "LastName Column shouldn't be blank";
						/*
						 * lastName = ""; System.out.println("");
						 */
					} else {
						System.out.println(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName")).toString());
						lastName = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("LastName")).toString();
					}
				} catch (NullPointerException e) {
					result = "LastName Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("DOB"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "DOB Column shouldn't be blank";
						/*
						 * dob = ""; System.out.println("");
						 */
					} else {
						System.out.println(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("DOB")).getRawValue());
						dob = lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("DOB")).getRawValue();
					}
				} catch (NullPointerException e) {
					result = "DOB Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Zip"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "Zip Column shouldn't be blank";
						/*
						 * zip = ""; System.out.println("");
						 */
					} else {
						System.out.println(new DataFormatter()
								.formatCellValue(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Zip"))));
						zip = new DataFormatter()
								.formatCellValue(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Zip")));
					}
				} catch (NullPointerException e) {
					result = "Zip Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("UserName"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "UserName Column shouldn't be blank";
						/*
						 * username = ""; System.out.println("");
						 */
					} else {
						System.out.println(new DataFormatter().formatCellValue(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("UserName"))));
						username = new DataFormatter().formatCellValue(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("UserName")));
					}
				} catch (NullPointerException e) {
					result = "UserName Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					if (lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Email"))
							.getCellType() == Cell.CELL_TYPE_BLANK) {
						result = "Email Column shouldn't be blank";
						// email = "";
						// System.out.println("");
					} else {
						System.out.println(new DataFormatter().formatCellValue(
								lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Email"))));
						email = new DataFormatter()
								.formatCellValue(lawwUsersSheet.getRow(i).getCell(columnNamesWithIndices.get("Email")));
					}
				} catch (NullPointerException e) {
					result = "Email Column shouldn't be blank";
					// System.out.println("result is : " + result);
				}
			}
			if (result == "") {
				try {
					LAWWUnauthenticatedHomePage homePage = new LAWWUnauthenticatedHomePage();
					homePage.openPage();
					// refreshPage();
					// driver.switchTo().defaultContent();
					homePage.clickRegisterLink();
				} catch (Exception e) {
					result = "Issue in LAWW Unauthentication page, please find screenshot";
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					// Now you can do whatever you need to do with it, for
					// example copy
					// somewhere
	
					FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
				}
			}
			if (result == "") {
				try {
	
					Registration_PersonalInformationSectionPage personalInfoPage = new Registration_PersonalInformationSectionPage();
					personalInfoPage.verifyIfPageLoaded();
					// Filling the personal Information section info
					personalInfoPage.enterFirstName(firstName);
					personalInfoPage.enterLastName(lastName);
					personalInfoPage.enterDateOfBirth(dob);
					personalInfoPage.enterZipCode(zip);
					personalInfoPage.clickContinueButton();
					Registration_CreateAccountSectionPage createAccountPage = new Registration_CreateAccountSectionPage();
					Assert.assertTrue(createAccountPage.verifyIfPageLoaded());
				} catch (Exception e) {
					result = "Issue in personal Information section, please find screenshot";
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					// Now you can do whatever you need to do with it, for
					// example copy
					// somewhere
	
					FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
				}
			}
			if (result == "") {
				try {
					Registration_CreateAccountSectionPage createAccountPage = new Registration_CreateAccountSectionPage();
					createAccountPage.enterUserName(username);
					createAccountPage.enterPassword(password);
					createAccountPage.enterConfirmPassword(password);
					createAccountPage.clickContinueButton();
					createAccountPage.enterEmail(email);
					createAccountPage.confirmEmail(email);
					// createAccountPage.selectSecurityRadioButton("Security
					// questions");
					createAccountPage.selectSecurityType("Security questions");
					createAccountPage.selectSecurityQuestion1("What was your first phone number?");
					createAccountPage.enterSecurityAnswer1("number1");
					createAccountPage.selectSecurityQuestion2("What is your best friend's name?");
					createAccountPage.enterSecurityAnswer2("name1");
					createAccountPage.selectSecurityQuestion3("What is your favorite color?");
					createAccountPage.enterSecurityAnswer3("color1");
					createAccountPage.clickContinueButton();
					createAccountPage.clickRememberThisDeviceCheckBox();
					createAccountPage.clickContinueButton();
					createAccountPage.clicktermsOfUseCheckBox();
					createAccountPage.clickContinueButton();
					Registration_ConfirmEmailSectionPage confirmEmailPage = new Registration_ConfirmEmailSectionPage();
					confirmEmailPage = new Registration_ConfirmEmailSectionPage();
					Assert.assertTrue(confirmEmailPage.verifyIfPageLoaded());
	
					registrationCompletedCount = registrationCompletedCount++;
					Thread.sleep(3000);
				} catch (Exception e) {
					result = "Issue in Create account section, please find screenshot";
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
				}
	
				if (result == "") {
					try {
						Registration_ConfirmEmailSectionPage confirmEmailPage = new Registration_ConfirmEmailSectionPage();
						confirmEmailPage
								.verifyFormContent("To continue, please click the confirmation link in the email.");
					} catch (Exception e) {
						result = "Issue in Email confirmation section, please find screenshot";
						File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
					}
				}
				if (result == "") {
					try {
						// ArrayList<String> tabs = new
						// ArrayList<String>(driver.getWindowHandles());
						/*
						 * if (registrationCompletedCount == 0) {
						 * driver.findElement(By.cssSelector("body")).
						 * sendKeys(Keys.CONTROL + "t"); } else {
						 * driver.findElement(By.cssSelector("body")).
						 * sendKeys(Keys.CONTROL, Keys.TAB);
						 * 
						 * confirmEmailPage.confirmEmailSection.sendKeys(
						 * Keys.TAB);
						 * confirmEmailPage.confirmEmailSection.sendKeys(
						 * Keys.ENTER);
						 * 
						 * }
						 */
	
						/*
						 * tabs = new
						 * ArrayList<String>(driver.getWindowHandles());
						 * driver.switchTo().window(tabs.get(0));
						 */
	
						driver.get("https://www.mailinator.com");
						driver.switchTo().defaultContent();
						try {
							page.verifyElementById("inboxfield");
						} catch (Exception e) {
							Assert.assertTrue(page.clickOnALinkByhrefPartialText("https://www.mailinator.com"));
							page.verifyElementById("inboxfield");
						}
						MailInator_HomePage mailHomePage = new MailInator_HomePage();
						Assert.assertTrue(mailHomePage.verifyIfPageLoaded());
	
						String[] emailElems = email.split("@");
						mailHomePage.enterEmail(emailElems[0]);
						mailHomePage.clickGoButton();
						MailInator_InboxPage mailInbox = new MailInator_InboxPage();
						mailInbox.verifyForConfirmEmailAddressMail();
						result = "Pass";
	
						// driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL,Keys.SHIFT,Keys.TAB);
						/*
						 * driver.findElement(By.id("header-1")).sendKeys
						 * (Keys.TAB);
						 * driver.findElement(By.id("header-1")).sendKeys
						 * (Keys.ENTER);
						 */
					} catch (Exception e) {
						result = "Issue in confirming email from mailinator, please find screenshot";
						File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(scrFile, new File("target\\screenshots\\row" + i + ".png"));
					} finally {
						// driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL,
						// Keys.SHIFT, Keys.TAB);
						/*
						 * ArrayList<String> tabs2 = new ArrayList<String>
						 * (driver.getWindowHandles());
						 * driver.switchTo().window(tabs2.get(0));
						 */
						/*
						 * driver.findElement(By.id("header-1")).sendKeys
						 * (Keys.TAB);
						 * driver.findElement(By.id("header-1")).sendKeys
						 * (Keys.ENTER);
						 */
					}
	
				}
			}
			System.out.println("result is : " + result);
			Cell cell = null;
			try {
				cell = lawwUsersSheet.getRow(i).getCell(resultColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (result == "Pass") {
					cell.setCellValue(result);
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.setCellValue(result);
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
	
			} catch (NullPointerException e) {
				cell = lawwUsersSheet.getRow(i).createCell(resultColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (result == "Pass") {
					cell.setCellValue(result);
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.setCellValue(result);
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
			}
	
			testDataWorkbook.fileIn.close();
			FileOutputStream output_file = new FileOutputStream(
					new File(PageObjectBase.getSystemVariable("test_data_Workbook_location")));
			testDataWorkbook.workbook.write(output_file);
			output_file.close();
	
		}
	
	}

	@Given("^I should be able to successfully login into laww portal with all tier1 users$")
	public void i_should_be_able_to_successfully_login_into_laww_portal_with_all_tier1_users() throws Throwable {
		TestDataExcelPage testDataWorkbook = new TestDataExcelPage();
		XSSFSheet lawwUsersSheet = testDataWorkbook
				.getSheetFromExcelWorkbook(PageObjectBase.getSystemVariable("bulk_usernames_sheet"));
		Integer registrationSuccessColumnIndex = null;
		Integer userNameColumnIndex = null;
		Integer signInResultColumnIndex = null;
		Row firstRow = lawwUsersSheet.getRow(0);
		for (Cell cell : firstRow) {
			if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
				if (cell.getStringCellValue().trim().equals("Registered?")) {
					registrationSuccessColumnIndex = cell.getColumnIndex();
					System.out.println(registrationSuccessColumnIndex);
				}
				if (cell.getStringCellValue().trim().equals("UserName")) {
					userNameColumnIndex = cell.getColumnIndex();
					System.out.println(userNameColumnIndex);
	
				}
				if (cell.getStringCellValue().trim().equals("SignedIn?")) {
					signInResultColumnIndex = cell.getColumnIndex();
					System.out.println(signInResultColumnIndex);
	
				}
			}
		}
		for (int i = 1; i < lawwUsersSheet.getPhysicalNumberOfRows(); i++) {
			String registrationResult = "";
			String signInResult = "";
			String username = "";
			String password = "Password@1";
	
			try {
				if (lawwUsersSheet.getRow(i).getCell(registrationSuccessColumnIndex)
						.getCellType() == Cell.CELL_TYPE_BLANK) {
					registrationResult = "";
					/*
					 * firstName = ""; System.out.println("");
					 */
				} else {
					System.out.println(lawwUsersSheet.getRow(i).getCell(registrationSuccessColumnIndex).toString());
					registrationResult = lawwUsersSheet.getRow(i).getCell(registrationSuccessColumnIndex).toString()
							.trim();
				}
			} catch (NullPointerException e) {
				registrationResult = "";
				// System.out.println("result is : " + result);
			}
	
			try {
				if (lawwUsersSheet.getRow(i).getCell(registrationSuccessColumnIndex)
						.getCellType() == Cell.CELL_TYPE_BLANK) {
					username = "";
					/*
					 * firstName = ""; System.out.println("");
					 */
				} else {
					System.out.println(lawwUsersSheet.getRow(i).getCell(registrationSuccessColumnIndex).toString());
					username = lawwUsersSheet.getRow(i).getCell(userNameColumnIndex).toString().trim();
				}
			} catch (NullPointerException e) {
				username = "";
				// System.out.println("result is : " + result);
			}
	
			if (registrationResult.equals("Pass")) {
				if (signInResult.equals("")) {
					try {
	
						LAWWUnauthenticatedHomePage homePage = new LAWWUnauthenticatedHomePage();
						homePage.openPage();
						homePage.clickSignInLink();
					} catch (Exception e) {
						signInResult = "Issue in LAWW Unathenticated page or landing into sign in page, please find screenshot";
					}
				}
				if (signInResult.equals("")) {
					try {
						SignInPage signinPage = new SignInPage();
						signinPage.enterUserName(username);
						signinPage.enterPassword(password);
						signinPage.clickSignInButton();
					} catch (Exception e) {
						signInResult = "Issue in Sign In page or while landing into security answer page, please find screenshot";
					}
				}
				if (signInResult.equals("")) {
					try {
						page.handleSecurityQuestionWithAnswer();
					} catch (Exception e) {
						signInResult = "Issue in security answer page, please find screenshot";
					}
				}
				if (signInResult.equals("")) {
					try {
						LAWWAuthenticatedPage authenticatedPage = new LAWWAuthenticatedPage();
						authenticatedPage.verifyIfUserMenuDisplayedOnGlobalNav();
						signInResult = "Pass";
					} catch (Exception e) {
						signInResult = "Issue while landing into authenticated page, please find screenshot";
					}
				}
	
			} else {
				signInResult = "SignIn can't performed as registration failed";
			}
			Cell cell = null;
			try {
				cell = lawwUsersSheet.getRow(i).getCell(signInResultColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (signInResult == "Pass") {
					cell.removeCellComment();
					cell.setCellValue(signInResult);
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.removeCellComment();
					cell.setCellValue(signInResult);
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
	
			} catch (NullPointerException e) {
				cell = lawwUsersSheet.getRow(i).createCell(signInResultColumnIndex);
				CellStyle style = testDataWorkbook.workbook.createCellStyle();
				Font font = testDataWorkbook.workbook.createFont();
				if (signInResult == "Pass") {
					cell.removeCellComment();
					cell.setCellValue(signInResult);
					font.setColor(HSSFColor.GREEN.index);
					style.setFont(font);
					cell.setCellStyle(style);
				} else {
					cell.removeCellComment();
					cell.setCellValue(signInResult);
					font.setColor(HSSFColor.RED.index);
					style.setFont(font);
					cell.setCellStyle(style);
				}
			}
	
			testDataWorkbook.fileIn.close();
			FileOutputStream output_file = new FileOutputStream(
					new File(PageObjectBase.getSystemVariable("test_data_Workbook_location")));
			testDataWorkbook.workbook.write(output_file);
			output_file.close();
	
		}
	
	}

	@Given("^I registered as a LAWW tier(\\d+) member with the following details$")
	public void i_registered_as_a_LAWW_tier_member_with_the_following_details(int arg1, Map<String, String> tableData)
			throws Throwable {
		LAWWUnauthenticatedHomePage homePage = new LAWWUnauthenticatedHomePage();
		homePage.openPage();
		homePage.clickRegisterLink();
		Registration_PersonalInformationSectionPage personalInfoPage = new Registration_PersonalInformationSectionPage();
		personalInfoPage.verifyIfPageLoaded();
		// Filling the personal Information section info
		Assert.assertTrue(tableData.containsKey("First Name"));
		// personalInfoPage.enterFirstName(tableData.get("First Name"));
		personalInfoPage.enterFirstName(new Hooks().getFirstName());
	
		Assert.assertTrue(tableData.containsKey("Last Name"));
		// personalInfoPage.enterLastName(tableData.get("Last Name"));
		personalInfoPage.enterLastName(new Hooks().getLastName());
	
		Assert.assertTrue(tableData.containsKey("Date of Birth"));
		// personalInfoPage.enterDateOfBirth(tableData.get("Date of Birth"));
		personalInfoPage.enterDateOfBirth(new Hooks().getDOB());
	
		Assert.assertTrue(tableData.containsKey("Zipcode"));
		// personalInfoPage.enterZipCode(tableData.get("Zipcode"));
		personalInfoPage.enterZipCode(new Hooks().getZipcode());
	
		personalInfoPage.clickContinueButton();
		Registration_CreateAccountSectionPage createAccountPage = new Registration_CreateAccountSectionPage();
		Assert.assertTrue(createAccountPage.verifyIfPageLoaded());
	
		// Filling the create account section info
		/* try{ */
		Assert.assertTrue(tableData.containsKey("Username"));
		// createAccountPage.enterUserName(tableData.get("Username"));
		createAccountPage.enterUserName(new Hooks().getUserName());
		Thread.sleep(2000);
	
		Assert.assertTrue(tableData.containsKey("Password"));
		// createAccountPage.enterPassword(tableData.get("Password"));
		createAccountPage.enterPassword(new Hooks().getPassword());
	
		// createAccountPage.enterConfirmPassword(tableData.get("Password"));
		createAccountPage.enterConfirmPassword(new Hooks().getPassword());
	
		createAccountPage.clickContinueButton();
		Thread.sleep(2000);
		/*
		 * } catch(Exception e){ Thread.sleep(2000);
		 * if(createAccountPage.verifyIfErrorMessageDisplayed()) {
		 * System.out.println(createAccountPage.returnErrorMessage());
		 * //e.printStackTrace(); } else e.printStackTrace(); }
		 */
	
		Assert.assertTrue(tableData.containsKey("Email"));
		// createAccountPage.enterEmail(tableData.get("Email"));
		createAccountPage.enterEmail(new Hooks().getEmailId());
	
		// createAccountPage.confirmEmail(tableData.get("Email"));
		createAccountPage.confirmEmail(new Hooks().getEmailId());
	
		// createAccountPage.selectSecurityRadioButton("Security questions");
		createAccountPage.selectSecurityType("Security questions");
	
		createAccountPage.selectSecurityQuestion1("What was your first phone number?");
		createAccountPage.enterSecurityAnswer1("number1");
	
		createAccountPage.selectSecurityQuestion2("What is your best friend's name?");
		createAccountPage.enterSecurityAnswer2("name1");
	
		createAccountPage.selectSecurityQuestion3("What is your favorite color?");
		createAccountPage.enterSecurityAnswer3("color1");
	
		createAccountPage.clickContinueButton();
	
		createAccountPage.clickRememberThisDeviceCheckBox();
		createAccountPage.clickContinueButton();
	
		createAccountPage.clicktermsOfUseCheckBox();
		createAccountPage.clickContinueButton();
	
		Registration_ConfirmEmailSectionPage confirmEmailPage = new Registration_ConfirmEmailSectionPage();
		Assert.assertTrue(confirmEmailPage.verifyIfPageLoaded());
	
	}

}
