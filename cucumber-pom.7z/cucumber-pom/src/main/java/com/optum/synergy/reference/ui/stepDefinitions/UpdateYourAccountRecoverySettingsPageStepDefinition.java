package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.Hooks;
import com.optum.synergy.reference.ui.pageobjects.UpdateYourAccountRecoverySettingsPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UpdateYourAccountRecoverySettingsPageStepDefinition {

	private UpdateYourAccountRecoverySettingsPage page;

	public UpdateYourAccountRecoverySettingsPageStepDefinition() {
		page = new UpdateYourAccountRecoverySettingsPage();
	}

	@Then("^I should see \"([^\"]*)\" on global nav bar$")
	public void i_should_see_on_global_nav_bar(String arg1) throws Throwable {
		page.verifyUserNameMenuDropDownDisplayed();
	}

	@When("^I click on \"([^\"]*)\" on global nav bar link$")
	public void i_click_on_on_global_nav_bar_link(String arg1) throws Throwable {
		page.clickOnUserMenuDropDown();
	}

	@When("^I click on \"([^\"]*)\" link in username dropdown$")
	public void i_click_on_link_in_username_dropdown(String arg1) throws Throwable {
		page.submitSignInSecurity();
	}

	@Then("^I should land on HealthSafe ID security settings page$")
	public void i_should_land_on_HealthSafe_ID_security_settings_page() throws Throwable {
		Assert.assertTrue("Issue while loading the HealthSafe ID security settings page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should be at HealthSafe ID security settings page$")
	public void i_should_be_at_HealthSafe_ID_security_settings_page() throws Throwable {
		Assert.assertTrue("Issue while loading the HealthSafe ID security settings page", page.verifyIfPageLoaded());
	}

	@Then("^I should see an error message \"([^\"]*)\" for question1$")
	public void i_should_see_an_error_message_for_question1(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityQuestion1(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for answer1$")
	public void i_should_see_an_error_message_for_answer1(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityAnswer1(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for question2$")
	public void i_should_see_an_error_message_for_question2(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityQuestion2(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for answer2$")
	public void i_should_see_an_error_message_for_answer2(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityAnswer2(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for question3$")
	public void i_should_see_an_error_message_for_question3(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityQuestion3(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for answer3$")
	public void i_should_see_an_error_message_for_answer3(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityAnswer3(message));
	}

	@When("^I enter New email with \"([^\"]*)\"$")
	public void iEnterNewEmailWith(String email) throws Throwable {
		if(!email.contains("<")){
			page.updateNewEmail(email);
		}
		else{
	//	page.updateNewEmail(email);
		page.updateNewEmail(new Hooks().getNewEmailId());
		}
	}

	@Then("^I should see an error message \"([^\"]*)\" for New email$")
	public void iShouldSeeAnErrorMessageForNewEmail(String message) throws Throwable {
		Thread.sleep(4000);
		Assert.assertTrue(page.verifyErrorMessageOnUpdateNewEmail(message));
	}

	@Then("^I should see New email field disappeared$")
	public void i_should_see_New_email_field_disappeared() throws Throwable {
		Assert.assertTrue(page.verifyNewEmailFieldIsNotDisplayed());
	}

	@Then("^I should not see the \"([^\"]*)\" link$")
	public void i_should_not_see_the_link(String message) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Assert.assertTrue(page.verifyLinkIsNotDisplayed(message));
	}

	@Then("^I check the noPhone checkbox$")
	public void I_check_the_noPhone_checkbox() throws Throwable {
		page.clickPhoneCheckbox();
		Thread.sleep(3000);
	}

	@Then("^I enter password with \"([^\"]*)\" into current password field$")
	public void i_enter_password_with_into_current_password_field(String currentPassword) throws Throwable {
		page.enterCurrentPassword(currentPassword);
	}

	@Then("^I enter password with \"([^\"]*)\" into New password field$")
	public void i_enter_password_with_into_New_password_field(String newpassword) throws Throwable {
		page.enterNewPassword(newpassword);

	}

	@Then("^I enter password with \"([^\"]*)\" into confirm Password field$")
	public void i_enter_password_with_into_confirm_Password_field(String confirmPassword) throws Throwable {
		page.enterConfirmNewPassword(confirmPassword);
	}

	@Then("^I should see an error message \"([^\"]*)\" at the top of Change your password section$")
	public void iShouldSeeAnErrorMessageAtTheTopOfChangeYourPasswordSection(String message) throws Throwable {

		Assert.assertTrue(page.verifyErrForOldPwdWrong(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for password field$")
	public void i_should_see_an_error_message_for_password_field(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorInvalidNewPwd(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for New password field$")
	public void iShouldSeeAnErrorMessageForNewPasswordField(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorInvalidNewPwd(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for Confirm password field$")
	public void iShouldSeeAnErrorMessageForConfirmPasswordField(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorInvalidConfirmPwd(message));
	}

	@Then("^I should see a heading \"([^\"]*)\" with following password guidelines$")
	public void i_should_see_a_heading_with_following_password_guidelines(String heading, List<String> passGuidelines)
			throws Throwable {
		Assert.assertTrue(page.verifyRuleTipMessage(heading));
		for (String msg : passGuidelines) {
			Assert.assertTrue(page.verifyRuleTipMessage(msg));
		}
	}

	@Then("^I should see success icon with \"([^\"]*)\" text beside password$")
	public void i_should_see_success_icon_with_text_beside_password(String message) throws Throwable {
		Assert.assertTrue(page.verifyUpdatedVIsualq(message));
	}

	@Then("^I should see username header with \"([^\"]*)\" and password with \"([^\"]*)\" text$")
	public void iShouldSeeUsernameHeaderWithAndPasswordWithText(String username, String password) throws Throwable {
		Assert.assertTrue(page.verifyErrForOldPwdWrong(username));
		Assert.assertTrue(page.verifyErrForOldPwdWrong(password));
	}

	@Then("^I should see a checkbox with \"([^\"]*)\" icon$")
	public void i_should_see_a_checkbox_with_icon(String message) throws Throwable {
		Assert.assertTrue(page.verifyNoPhoneCheckboxDisplayed());
	}

	@Then("^I should see an error message \"([^\"]*)\" for phone number field$")
	public void i_should_see_an_error_message_for_phone_number_field(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorNewPhoneNo(message));
	}

	@Given("^I should see error visual queue \"([^\"]*)\"$")
	public void i_should_see_error_visual_queue(String message) throws Throwable {
		try {
			Assert.assertTrue(page.verifyPhoneErrorConfirmation(message));
		} catch (AssertionError e) {
			e.printStackTrace();
		}

	}

	@Then("^I should see the Confirm your phone number with option \"([^\"]*)\"$")
	public void i_should_see_the_Confirm_your_phone_number_with_option(String message) throws Throwable {
		Assert.assertTrue(page.verifyConfirmPhoneRadio(message));
	}

	@Then("^I should see email \"([^\"]*)\" with \"([^\"]*)\" link$")
	public void iShouldSeeEmailWithLink(String email, String link) throws Throwable {
		try {
			Assert.assertTrue(page.verifyEmailWithLink(email, link));
		} catch (AssertionError e) {
			e.printStackTrace();
		}

	}

	@Then("^I Should see New email \"([^\"]*)\" in read-only$")
	public void i_Should_see_New_email_in_read_only(String mail) throws Throwable {
		mail=new Hooks().getNewEmailId();
		Assert.assertTrue("Issue in diplaying new email", page.verifyIfNewEmailDisplayedInReadOnly(mail));
	}

	@Then("^I should see an \"([^\"]*)\" link for new email$")
	public void i_should_see_an_link_for_new_email(String link) throws Throwable {
		Assert.assertTrue(link + " is not dispalyed for New Email", page.verifyLinkForNewEmail(link));
	}

	@Then("^I should see \"([^\"]*)\" visual queue for new email$")
	public void iShouldSeePVisualQueueForNewEmail(String status) throws Throwable {
		Assert.assertTrue(status + " is not displaying for new email",
				page.verifyConfirmationStatusForNewEmail(status));
	}

	@Given("^I should see success visual queue \"([^\"]*)\"$")
	public void i_should_see_success_visual_queue(String arg1) throws Throwable {
		throw new PendingException();
	}

	@Given("^I should not see a label with \"([^\"]*)\" heading and \"([^\"]*)\" text box$")
	public void iShouldNotSeeALabelWithHeadingAndTextBox(String arg1, String arg2) throws Throwable {
		throw new PendingException();
	}

	@Given("^I should not see a checkbox with \"([^\"]*)\" icon$")
	public void iShouldNotSeeACheckboxWithIcon(String arg1) throws Throwable {
		throw new PendingException();
	}

	@Given("^I should not see a \"([^\"]*)\" link$")
	public void iShouldNotSeeALink(String arg1) throws Throwable {
		throw new PendingException();
	}

	@Given("^I should not see \"([^\"]*)\" link enabled$")
	public void iShouldNotSeeLinkEnabled(String arg1) throws Throwable {
		throw new PendingException();
	}

	@Then("^I should see a New phone number label with text box$")
	public void i_should_see_a_New_phone_number_label_with_text_box() throws Throwable {
		Assert.assertTrue("Issue in displaying the First name label with text box",
				page.verifyIfNewPhoneNumberLabelWithTextboxExist());
	}

	@Then("^I should see the HealthSafe ID security settings page header as \"([^\"]*)\"$")
	public void i_should_see_the_HealthSafe_ID_security_settings_page_header_as(String pageHeading) throws Throwable {
		Assert.assertTrue(
				"\"" + pageHeading
						+ "\" header is not displaying on the Update your HealthSafe ID security settings page",
				page.verifyPageHeader(pageHeading));
	}

	@Then("^I should see a Enter your current password label with textbox$")
	public void i_should_see_a_Enter_your_current_password_label_with_textbox() throws Throwable {
		Assert.assertTrue("Issue in displaying Enter your current password label with textbox",
				page.verifyIfEnteryourcurrentpasswordLabelWithTextboxExist());
	}

	@Then("^I should see a New password label with textbox$")
	public void i_should_see_a_New_password_label_with_textbox() throws Throwable {
		Assert.assertTrue("Issue in displaying New password label with textbox",
				page.verifyIfNewpasswordLabelWithTextboxExist());
	}

	@Then("^I should see a Confirm new password label with textbox$")
	public void i_should_see_a_Confirm_new_password_label_with_textbox() throws Throwable {
		Assert.assertTrue("Issue in displaying Confirm new password label with textbox",
				page.verifyIfConfirmnewpasswordLabelWithTextboxExist());
	}
	@Then("^I should see the success text \"([^\"]*)\" in security settings page$")
	public void i_should_see_the_success_text_in_security_settings_page(String status) throws Throwable {
	   Assert.assertTrue("\""+status+"\" is not displaying on the security settings page", page.verifyForSuccessText(status)); 
	}
	
	@Then("^I enter valid \"([^\"]*)\" into Current password field$")
	public void i_enter_valid_into_Current_password_field(String password) throws Throwable {
	//	page.enterCurrentPassword(password);
		page.enterCurrentPassword(new Hooks().getPassword());
	}
	
	@Then("^I enter valid \"([^\"]*)\" into New Password field$")
	public void i_enter_valid_into_New_Password_field(String password) throws Throwable {
	 //  page.enterNewPassword(password);
		page.enterNewPassword(new Hooks().getNewPassword());
	   
	}

	@Then("^I enter valid \"([^\"]*)\" into Confirm new password field$")
	public void i_enter_valid_into_Confirm_new_password_field(String password) throws Throwable {
	//  page.enterNewPassword(password);
			page.enterConfirmNewPassword(new Hooks().getNewPassword());
	}
	
	@Given("^I enter \"([^\"]*)\" in New phone number field$")
	public void i_enter_in_New_phone_number_field(String text) throws Throwable {
	//	page.enterPhoneNumber(text);
		page.enterPhoneNumber(new Hooks().getPhoneNumber());
	}
	
	@Given("^I select \"([^\"]*)\" as phone type$")
	public void i_select_as_phone_type(String text) throws Throwable {
			page.selectPhoneType(text);
	}
	
	

	@Then("^I should see \"([^\"]*)\" visual queue for Phone number$")
	public void i_should_see_visual_queue_for_Phone_number(String status) throws Throwable {
	    Assert.assertTrue("\""+status+"\" status is not displaying in the UI screen", page.verifyPhoneNumberVisualQueueStatus(status));
	}
	
	@Given("^I should see a I'd rather not provide a phone number Checkbox$")
	public void i_should_see_a_I_d_rather_not_provide_a_phone_number_Checkbox() throws Throwable {
	  Assert.assertTrue("Issue in displaying the I'd rather not provide a phone number Checkbox", page.verifyIfIWouldNotProvideAPhoneNumberCheckBoxIsDisplayed());
	}
	
	@Then("^I should see a security questions recovery form$")
	public void i_should_see_a_security_questions_recovery_form() throws Throwable {
	    Assert.assertTrue("Issue in displaying the security questions recovery form", page.verifyIfSecurityQuestionsRecoveryFormDisplayed());
	}
}
