package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.OptumOutlookLoggedInPage;
import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readEmail;

import cucumber.api.java.en.Then;

public class OptumOutlookLoggedInPageStepDefinition {

	private OptumOutlookLoggedInPage page;
	
	public OptumOutlookLoggedInPageStepDefinition() {
		page = new OptumOutlookLoggedInPage();
	}
	
	@Then("^I click on latest email from \"([^\"]*)\"$")
	public void iClickOnLatestEmailFrom(String emailSubject) throws Throwable {
	   page.verifyIfPageLoaded();
	   Thread.sleep(10000);
	   page.clickOnAnFirstEmailContainsTheSubject(emailSubject);
	   
	}
	
	@Then("^I get the phone confirmation code from optum outlook mail body$")
	public void i_get_the_phone_confirmation_code_from_optum_outlook_mail_body() throws Throwable {
		Thread.sleep(5000);
		page.getPhoneConfirmationCode();
		
	}
	
	@Then("^I click on registration confirmation link \"([^\"]*)\"$")
	public void iClickOnRegistrationConfirmationLink(String link) throws Throwable {
		page.clickOnRegistrationConfirmationLink();
	}
	
	@Then("^I should see a registration confirmation link \"([^\"]*)\" in email body$")
	public void iShouldSeeARegistrationConfirmationLinkInEmailBody() throws Throwable {
		page.clickOnRegistrationConfirmationLink();
	}
	
	@Then("^I should see the mail sender as \"([^\"]*)\"$")
	public void i_should_see_the_mail_sender_as(String mailSender) throws Throwable {
	  Assert.assertTrue("\""+mailSender+"\" is not displaying as mail sender", page.verifyForMailSender(mailSender));
	}

	@Then("^I should see the mail subject as \"([^\"]*)\"$")
	public void i_should_see_the_mail_subject_as(String mailSubject) throws Throwable {
		Assert.assertTrue("\""+mailSubject+"\" is not displaying as mail subject",page.verifyForMailSubject(mailSubject));
	}
	
	@Then("^I should see an email from \"([^\"]*)\"$")
	public void i_should_see_an_email_from(String subject) throws Throwable {
	    Assert.assertTrue("Couldn't find first mail with subject "+subject,page.verifyFirstEmailContainsTheSubject(subject));
	}
	
	@Then("^I should see a latest unread mail recieved from \"([^\"]*)\" in Inbox folder$")
	public void i_should_see_a_latest_unread_mail_recieved_from_in_Inbox_folder(String mailSubject) throws Throwable {
		Thread.sleep(8000);
	    Assert.assertTrue("Not able to find the inbox mail with subject "+mailSubject, page.verifyInboxUnreadMailwithSubject(mailSubject));
	}

	@Then("^I click on the latest unread mail recieved from \"([^\"]*)\" in Inbox folder$")
	public void i_click_on_the_latest_unread_mail_recieved_from_in_Inbox_folder(String mailSubject) throws Throwable {
		Thread.sleep(8000);
		page.clickInboxUnreadMailwithSubject(mailSubject);
	}
	
	
	@Then("^I read the latest unread mail recieved from \"([^\"]*)\" in Inbox folder$")
	public void i_read_latest_unread_mail_recieved_from_in_Inbox_folder(String mailSubject) throws Throwable {
		
		page.clickInboxUnreadMailwithSubject(mailSubject);
	}
	@Then("^I should see a latest unread mail recieved from \"([^\"]*)\" in mail server$")
	public void i_received_the_email_from_server(String mailSubject){
		page.refreshemail();
		page.verifyEmailSubject(mailSubject);
		
	}
	
	@Then("^I should see the following content in the mail body$")
	public void iShouldSeeTheFollowingContentInTheMailBody(List<String> contentList) throws Throwable {
		String emailcontent = "";
		
		for(String content:contentList)
		{
			emailcontent=emailcontent+content;
		}
		emailcontent=emailcontent.replace("\"", "");
		page.verifyForMailContent(emailcontent);
	}
	
	@Then("^I should see the following content in the mail body along with the username$")
	public void iShouldSeeTheFollowingContentInTheMailBodyAlongWithTheUsername(List<String> contentList) throws Throwable {
		String emailcontent = "";
		
		for(String content:contentList)
		{
			if(content.equals("<AUTO_GENERATED_USERNAME>")){
				emailcontent=emailcontent+" "+dataStorage.getUserName();
			}
			else{
			emailcontent=emailcontent+" "+content;
			}
		}
		emailcontent=emailcontent.replace("\"", "");
		emailcontent=emailcontent.trim();
		System.out.println(emailcontent);
		page.verifyForMailContent(emailcontent);
	}
	
	@Then("^I should see a latest unread mail recieved from \"([^\"]*)\" in mail server with the following content body for new email$")
	public void iShouldSeeALatestUnreadMailRecievedFromInMailServerWithTheFollowingContentBody(String arg1, List<String> contentList) throws Throwable {
        String newEmailAddress = dataStorage.getEmailId().replace("@", "_new@");
        String msgContent = readEmail.getEmailContent(newEmailAddress);
        Assert.assertNotNull(msgContent);
	String emailcontent = "";
		
		for(String content:contentList)
		{
			if(content.equals("<AUTO_GENERATED_USERNAME>")){
				emailcontent=emailcontent+" "+dataStorage.getUserName();
			}
			else{
			emailcontent=emailcontent+" "+content;
			}
		}
		emailcontent=emailcontent.replace("\"", "");
		emailcontent=emailcontent.trim();
		System.out.println(emailcontent);
		Assert.assertEquals(emailcontent, msgContent);
	}

	@Then("^I should see \"([^\"]*)\" in the confirmation email body$")
	public void iShouldSeeTheInTheMailBody(String emailcontent) throws Throwable {		
		Assert.assertTrue("True, mail content verified", page.verifyMailContent(emailcontent));
	}
}
