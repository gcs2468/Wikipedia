package com.optum.synergy.reference.ui.pageobjects;

import java.io.IOException;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class OptumOutlookLoginPage extends PageObjectBase {

	String page_url = "https://owa.uhc.com";
	
	@FindBy(how = How.NAME, using = "logonForm")
	private WebElement outlookLoginForm;

	@FindBy(how = How.ID, using = "username")
	private WebElement domain_or_username;
	
	@FindBy(how = How.ID, using = "imgLiveLogo")
	private WebElement outLooklogo;

	@FindBy(how = How.ID, using = "password")
	private WebElement password;

	@FindBy(how = How.XPATH, using = "//input[@class='btn' and @value='Sign in']")
	private WebElement signInButton;

	public void openPage() throws IOException {
		openPage(page_url);
	}
	
	public void closePage() throws IOException{
		driver.close();
	}

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(outlookLoginForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyIfLogoLoaded() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(outLooklogo)).isDisplayed();
	}

	public void enterDomainAndUsername() throws IOException {
		mediumWait.get().until(ExpectedConditions.visibilityOf(domain_or_username));
		domain_or_username.sendKeys("ms\\"+getSystemVariable("web_outlook_username"));
	}

	public void enterPassword() throws IOException {
		mediumWait.get().until(ExpectedConditions.visibilityOf(password));
		password.sendKeys(getSystemVariable("web_outlook_password"));
	}
	
	public void enterDomainAndUsername2() throws IOException {
		mediumWait.get().until(ExpectedConditions.visibilityOf(domain_or_username));
		domain_or_username.sendKeys("ms\\"+getSystemVariable("web_outlook_username2"));
	}

	public void enterPassword2() throws IOException {
		mediumWait.get().until(ExpectedConditions.visibilityOf(password));
		password.sendKeys(getSystemVariable("web_outlook_password2"));
	}

	public void clickSignInButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(signInButton));
		signInButton.click();
	}
}
