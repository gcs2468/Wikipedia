package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;
import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.Registration_ConfirmEmailSectionPage;
import com.optum.synergy.reference.ui.utility.dataStorage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registration_ConfirmEmailSectionPageStepDefinition {
	private Registration_ConfirmEmailSectionPage page;
	public Registration_ConfirmEmailSectionPageStepDefinition() {
		page = new Registration_ConfirmEmailSectionPage();
	}

	@Then("^I should be at Confirm email section page$")
	public void i_should_be_at_Confirm_email_section_page() throws Throwable {
		Assert.assertTrue("Issue while loading the Confirm email section page", page.verifyIfPageLoaded());
	}

	@When("^I enter confirm email2 with \"(.*)\"$")
	public void i_enter_confirm_email2_with(String emailAddress) throws Throwable {
		page.clearConfirmEmail2Field();
		page.enterConfirmEmail2(emailAddress.trim());
		page.clickOnConfirmEmailForm();
	}
	
	@Then("^I enter confirm email2 with <NEW_EMAIL_FOR_AUTO_GENERATED_USERNAME>$")
	public void iEnterConfirmEmailWithNEW_EMAIL_FOR_AUTO_GENERATED_USERNAME() throws Throwable {
		page.clearConfirmEmail2Field();
		page.enterConfirmEmail2(dataStorage.getEmailId().replace("@", "_new@"));
		page.clickOnConfirmEmailForm();
	}
	
	@Then("^I should not see the error message \"([^\"]*)\" in Confirm email section$")
	public void i_should_not_see_the_error_message_in_Confirm_email_section(String errorMessage) throws Throwable {
		Thread.sleep(6000);
	    Assert.assertTrue("\""+errorMessage+"\" error message should not be displayed", !page.verifyTheErrorText(errorMessage));
	}

	@Then("^I should not see any error message for confirm email2$")
	public void i_should_not_see_any_error_message_for_confirm_email2() throws Throwable {
		Assert.assertTrue(page.verifyNoErrorMessageOnConfirmEmail2());
	}

	@Then("^I should see an error message \"([^\"]*)\" for confirm email2$")
	public void i_should_see_an_error_message_for_confirm_email2(String message) throws Throwable {
		Assert.assertTrue(page.verifyErrorMessageOnConfirmEmail2(message));
	}
	
    @Then("^I should see success text \"([^\"]*)\"$")
    public void iShouldSeeSuccessText(String message) throws Throwable {
    	Assert.assertTrue(page.verifyPhoneConfirmationSuccessMessage(message));
    }
    
	@Then("^I should see Email confirmation section contains \"([^\"]*)\" message$")
	public void i_should_see_Email_confirmation_section_contains_message(String message) throws Throwable {
	    Assert.assertTrue("\""+message+"\" message is not diplaying on the Email confirmation form", page.verifyFormContent(message));
	}
	
	@Then("^I click on Edit email link$")
	public void iclickoneditemaillink() throws Throwable {
		page.clickOnEditEmaillink();
	}
	
	@Then("^I should see a message \"([^\"]*)\" on the Step3 page of registration$")
	public void I_should_see_a_message_on_Step3Page_of_registeration(String message) throws Throwable {
		Assert.assertEquals(message.toUpperCase(), page.getMessageOnStep3PageOfRegisteration().toUpperCase());
	}
	
	@Then("^I should be at Confirm email Textbox$")
	public void i_should_be_at_Confirm_email_Textbox() throws Throwable {
		 Assert.assertTrue(page.verifyConfirmEmail2Textbox());
	}
	@When("^I enter email on edited email field \"(.*)\"$")
	public void i_enter_email_on_EditedemailField (String emailAddress) throws Throwable {
		page.enterEditedEmail(emailAddress);
		page.clickTab();
	}
	
	@When("^I enter valid email on edited email field$")
	public void iEnterValidEmailOnEditedEmailField() throws Throwable {
			page.enterEditedEmail(dataStorage.getEmailId());
	}
	
	@Then("^I click on \"([^\"]*)\" Button$")
	public void iclickoneConfirmEditedButton(String buttonName) throws Throwable {
		page.clickOnConfirmEditedEmailButton(buttonName);
	}
	@Then("^I click on \"([^\"]*)\" Text on confirm email page$")
	public void iclickonTextOnConfirmEmailPage(String text) throws Throwable {
		page.clickOnTextOnConfirmEmailPage(text);
	}
	@Then("^I should see \"([^\"]*)\" on Confirm Email page$")
	public void i_should_see_the_text_on_Confirm_Email_Page(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Confirm Email Page", page.verifytextOnEmailConfirmPage(arg1));
	}
	@When("^I enter phone number on confirm edited phone number field \"(.*)\"$")
	public void i_enter_email_on_confirmeditedphonenumberfield (String emailAddress) throws Throwable {
		page.enterEditedPhoneNumberField(emailAddress);
	}
	@Then("^I click on \"([^\"]*)\" button for confirm edited phone number field page$")
	public void iclickoneConfirmEditedButton_forconfirmeditedphonenumberfieldpage(String buttonName) throws Throwable {
		page.clickOnConfirmEditedPhoneNumberButton(buttonName);
	}
	@When("^I enter confirmation code \"([^\"]*)\" on the Confirm Email page$")
	public void i_enter_confirmationcode (String emailAddress) throws Throwable {
		page.enterEditedPhoneNumberField(emailAddress);
	}
	@When("^I enter confirmation code \"([^\"]*)\" on the Confirm Email page for mobile$")
	public void i_enter_confirmationcode_on_the_Confirm_Email_page_for_mobile (String code) throws Throwable {
		page.enterConfirmationCode(code);
	}
	@When("^I click on \"([^\"]*)\" link button on the Confirm Email page for mobile$")
	public void i_click_on_link_button_on_the_Confirm_Email_page_for_mobile(String link) throws Throwable {
		page.clickElementByClassNameAndText("button",link);
	}
	@Then("^I should see a message \"([^\"]*)\" on top of form in confirm information page$")
	public void i_should_see_a_message_on_top_of_form_in_confirm_information_page(String message) throws Throwable {
		Assert.assertEquals(message, page.getPersonalInfoDescription());
	}
	@Then("^I should see the following padding content in confirmation page$")
	public void i_should_see_the_following_padding_content_in_confirmation_page(List<String> contentList) throws Throwable {
		String actualPageContent = page.getPaddingContent();
		for (String content : contentList) {			
			content = content.trim();
			Assert.assertTrue("\""+content+"\""+ " padding content is not displaying in the confirm email page",actualPageContent.contains(content));
		}		
	}
}
