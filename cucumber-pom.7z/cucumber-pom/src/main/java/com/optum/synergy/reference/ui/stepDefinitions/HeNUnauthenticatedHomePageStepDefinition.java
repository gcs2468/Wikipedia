package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.HeNUnauthenticatedHomePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HeNUnauthenticatedHomePageStepDefinition {
	private HeNUnauthenticatedHomePage page;
	public HeNUnauthenticatedHomePageStepDefinition() {
		page = new HeNUnauthenticatedHomePage();
	}

	@Given("^I am at HeN unauthenticated home page$")
	public void iAmAtHeNUnauthenticatedHomePage() throws Throwable {
		page.openPage();
		Assert.assertTrue("Issue while loading HeN unauthenticated page", page.verifyIfPageLoaded());
	}

	@When("^I click on Sign In button in HeN unauthenticated home page$")
	public void iClickOnSignInButtonInHeNUnauthenticatedHomePage() throws Throwable {
		page.clickOnSignInButton();
	}

	@When("^I click on Hen logo$")
	public void i_click_on_Hen_logo() throws Throwable {
		Thread.sleep(4000);
		page.clickHenLogo();
	}

	@Given("^I should see valid HeN brand logo in HeN On Step3 page of Registeration$")
	public void i_should_see_valid_WCP_brand_logo_in_HeN() throws Throwable {
		Assert.assertTrue(page.verifyHeNBrandLogoIsDisplayed());
	}

	@Given("^I should see HeN Title as \"([^\"]*)\" On Step3 page of registeration$")
	public void i_should_see_HeN_Title_On_Step3_Page_Registeration(String titleHeN) throws Throwable {
		Assert.assertTrue(page.verifyHeNTitleOnStep3RegisterationPage(titleHeN));
	}

	@Then("^I should see HeN unauthenticated home page$")
	public void I_should_see_WCP_unauthenticated_home_page() throws Throwable {
		Assert.assertTrue(page.verifyHeNaunthenticatedHomePage());
	}

	@Then("^I should be at HeN unauthenticated page$")
	public void i_should_be_at_HeN_unauthenticated_page() throws Throwable {
		Assert.assertTrue("Issue while loading HeN Unauthenticated page", page.verifyIfPageLoaded());
	}

}
