package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.optum.synergy.reference.ui.pageobjects.OptumOutlookLoggedInPage;
import com.optum.synergy.reference.ui.pageobjects.OptumOutlookLoginPage;
import com.optum.synergy.reference.ui.utility.DriverFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class OptumOutlookLoginPageStepDefinition {
	private OptumOutlookLoginPage page;

	public OptumOutlookLoginPageStepDefinition() {
		page = new OptumOutlookLoginPage();
	}
	
    @Then("^I open the optum outlook mail$")
    public void iOpenTheOutlookMailAndGetTheConfirmationCode() throws Throwable {
    page.openPage();
    page.verifyIfPageLoaded();
    page.enterDomainAndUsername();
    page.enterPassword();
    page.clickSignInButton();
    
    }
    
    @Then("^I open the optum outlook mail2$")
    public void iOpenTheOutlookMail2AndGetTheConfirmationCode() throws Throwable {
    page.openPage();
    page.verifyIfPageLoaded();
    page.enterDomainAndUsername2();
    page.enterPassword2();
    page.clickSignInButton();
    
    }

	@Given("^I open the optum outlook for new email with valid MS domain credentials$")
	public void i_open_the_optum_outlook_for_secondary_email_with_valid_MS_domain_credentials() throws Throwable {
		page.openPage();
		Assert.assertTrue("Issue while loading the optum outlook login page", page.verifyIfPageLoaded());
		page.enterDomainAndUsername2();
		page.enterPassword2();
		page.clickSignInButton();
		OptumOutlookLoggedInPage outlookLoggedInPage = new OptumOutlookLoggedInPage();
		Assert.assertTrue("Issue while loading the optum outlook loggedin page",
				outlookLoggedInPage.verifyIfPageLoaded());
	}

	/**
	 * ------- New Steps------------
	 */
	
	@Given("^I open the optum outlook with valid MS domain credentials$")
	public void i_open_the_optum_outlook_with_valid_MS_domain_credentials() throws Throwable {
		page.openPage();
		WebDriver driver = DriverFactory.getDeviceDriver();
		boolean iselementpresent = driver.findElements(By.id("username")).size() != 0;
	
		if (iselementpresent == true) {
	
			Assert.assertTrue("Issue while loading the optum outlook login page",
					page.verifyIfPageLoaded());
			page.enterDomainAndUsername();
			page.enterPassword();
			page.clickSignInButton();
			OptumOutlookLoggedInPage outlookLoggedInPage = new OptumOutlookLoggedInPage();
			Assert.assertTrue("Issue while loading the optum outlook loggedin page",
					outlookLoggedInPage.verifyIfPageLoaded());
		} else {
			System.out.println("Page logged in");
		}
	
	}
}
