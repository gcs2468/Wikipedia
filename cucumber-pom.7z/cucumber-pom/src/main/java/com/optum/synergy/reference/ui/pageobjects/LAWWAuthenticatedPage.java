package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAuthenticatedPage extends PageObjectBase{

	@FindBy(how = How.ID, using = "usermenu")
	private WebElement globalNavUserMenu;
	
	@FindBy(how = How.ID, using = "transtitle")
	private WebElement pageHeading;
	
	@FindBy(how = How.XPATH, using = "//*[@class='ogn__title']//*[contains(text(),'Behavioral Health Coverage')]")
	private WebElement BehavioralHealthCoverage;

	
	public boolean verifyIfUserMenuDisplayedOnGlobalNav()
	{
		return longWait.get().until(ExpectedConditions.visibilityOf(globalNavUserMenu)).isDisplayed();
	}

	public boolean VerifyViewClaiminfoDisplaying()
	{
		waitForPageLoad(driver);
		return longWait.get().until(ExpectedConditions.visibilityOf(pageHeading)).getText().trim().equals("View claim status");
	}
	
	public boolean VerifybehavioralHealthCoverageDisplaying()
	{
		return longWait.get().until(ExpectedConditions.visibilityOf(BehavioralHealthCoverage)).isDisplayed();
	}
	
	public String getPageHeader()
	{
		return longWait.get().until(ExpectedConditions.visibilityOf(pageHeading)).getText();
	}
	
}
