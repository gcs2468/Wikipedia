package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.readXMLdata;

public class LAWWUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.CSS, using = "a.register")
	private WebElement registerLink;

	@FindBy(how = How.CSS, using = "a.signin")
	private WebElement signInLink;

	@FindBy(how = How.CLASS_NAME, using = "accessCodeLogin")
	private WebElement unathenticatedForm;

	@FindBy(how = How.XPATH, using = "//div[@id='ognheader' and contains(@modeldata,'brandlogo') and contains(@modeldata,'http://webet0265.ms.ds.uhc.com:8082/images/member/shell/logo_6.gif')]")
	private WebElement optumBrandLogo;

	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo']")
	private WebElement brandLogoforOptum;


	public void clickRegisterLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(registerLink));
		registerLink.click();
	}

	public void clickSignInLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(signInLink));
		signInLink.click();
	}

	public void openPage() {
		String page_url=readXMLdata.getTestData("LAWW", "AppURL");
		openPage(page_url);
		
		// LAWW page has an odd triggered refresh that occasionally causes StaleElementException
		// Haven't found any solution besides a hard sleep
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {		}
		
	}

	public boolean verifyForBrandLogoUrl(String url) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath(
				"//div[@id='ognheader' and contains(@modeldata,'brandlogo') and contains(@modeldata,'" + url + "')]")))
				.isDisplayed();

	}

	public boolean verifyIfBrandLogoIsDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(optumBrandLogo)).isDisplayed();
	}

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(signInLink)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
		
	}

	public boolean verifyForSignedOutMessage(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.className("ogn__title"))).getText()
				.contains(message);
	}
	public boolean verifyOptumBrandLogoIsDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(brandLogoforOptum)).isDisplayed();
	}
	
	public boolean verifyLAWWTitleOnStep3RegisterationPage(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//div[@class='navbar-header optum-logo']/h1[contains(.,'"+message + "')]"))).getText().equalsIgnoreCase(message);
	}
	
	public void clickOnSignInStep3RegisterationPage() {
		mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='button button--primary ng-binding']"))).click();
	}
	
	public boolean verifyLAWWaunthenticatedHomePage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(registerLink)).isDisplayed();
	}
	
}
