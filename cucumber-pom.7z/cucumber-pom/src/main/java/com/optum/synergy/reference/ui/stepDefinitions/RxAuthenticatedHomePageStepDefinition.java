package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.RxAuthenticatedHomePage;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class RxAuthenticatedHomePageStepDefinition {

	private RxAuthenticatedHomePage page;

	public RxAuthenticatedHomePageStepDefinition() {
		page = new RxAuthenticatedHomePage();
	}

	@Then("^I should be at OptumRx authenticated home page$")
	public void iShouldBeAtOptumRxAuthenticatedHomePage() throws Throwable {
		Assert.assertTrue("Issue while loading the myUHC myHealthCareView authenticated page",
				page.verifyIfHomePageContentIsDisplayed());

	}

	@Then("^I manage the client custom landing page at OptumRx authenticated home page$")
	public void iManageClientCustomLandingPageAtMyUHCAuthenticatedHomePage() throws Throwable {
		if (page.verifyContinueToOptumRxButtonDisplayed()) {
			page.continueToOptumRxAuthenticatedHomePage();
		}

	}
}