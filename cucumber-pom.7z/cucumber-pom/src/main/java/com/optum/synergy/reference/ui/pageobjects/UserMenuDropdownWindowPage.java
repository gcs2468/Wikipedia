package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class UserMenuDropdownWindowPage extends PageObjectBase {

	@FindBy(how = How.CLASS_NAME, using = "usermenu")
	private WebElement userMenuDropdown;

	@FindBy(how = How.PARTIAL_LINK_TEXT, using = "Sign In & Security")
	private WebElement signInSecurityLink;

	@FindBy(how = How.PARTIAL_LINK_TEXT, using = "Live and Work Well Preferences")
	private WebElement lawwPreferencesLink;

	@FindBy(how = How.XPATH, using = "//a[contains(@class,'signout') and contains(.,'Sign out')]")
	private WebElement signOutButton;

	public boolean verifyIfDropdownWindowLoaded() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(userMenuDropdown)).isDisplayed();
	}

	public void clickSignInSecurityLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(signInSecurityLink));
		signInSecurityLink.click();
	}

	public void clickLAWWPreferencesLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(lawwPreferencesLink));
		lawwPreferencesLink.click();
	}

	public boolean verifyIfSignoutButtonIsDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(signOutButton)).isDisplayed();

	}

	public void clickSignoutButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(signOutButton));
		signOutButton.click();
	}
}
