package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class RecoverYourUsernamePage extends PageObjectBase{
	
	@FindBy(how = How.NAME, using = "personalInfo")
	private WebElement recoverYourUsernameForm;
	
	@FindBy(how = How.ID, using = "header")
	private WebElement formHeader;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Email associated with your account')]/following-sibling::input[@id='email']")
	private WebElement emailassociatedwithyouraccountLabelWithTextBox;
	
	@FindBy(how=How.XPATH, using="//div[@class='grecaptcha-logo']/iframe[@title='recaptcha widget']")
	private WebElement recaptchaawidget;
	
	@FindBy(how=How.XPATH, using="//span[@class='icon-alert_filled error']/parent::div[contains(@ng-show,'personalInfoTopError')]")
	private WebElement recoverYourUsernameTopError;
	
	@FindBy(how=How.XPATH, using="//button[@type='submit'][@aria-hidden='false']")
	private WebElement recoverYourUsernameContinueButton;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header']/h1")
	private WebElement formHeaderOnRecoverUserName;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header']/following-sibling::*")
	private WebElement formSubHeaderOnRecoverUserName;
	
	@FindBy(how = How.XPATH, using = "//i[@class='icon-home']")
	private WebElement homeIcon;
	
	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/logo_myuhc.gif')]|//img[contains(@src,'logos/myuhc.gif')]")
	private WebElement myUhcLogo;
	
	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/logo_myhealthcareview.gif')]")
	private WebElement uhcMyHealthCareViewLogo;
	
	@FindBy(how = How.XPATH, using ="//flex-content[contains(@class,'left-divider')]//div[contains(@ng-bind-html,'needHelp')]")
	private WebElement needHelpSection;
	
	public boolean verifyIfPageLoaded(){
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(recoverYourUsernameForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyForFormHeader(String heading){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(formHeader)).getText().contains(heading);
	}
	
	public boolean verifyIfemailassociatedwithyouraccountLabelWithTextBoxExist()
	{
		return smallWait.get().until(ExpectedConditions.visibilityOf(emailassociatedwithyouraccountLabelWithTextBox)).isDisplayed();
	}
	
	public boolean verifyifrecaptchawidgetexist(){
		try {
		return smallWait.get().until(ExpectedConditions.visibilityOf(recaptchaawidget)).isDisplayed();}
		catch(Exception e){ return false;}
	}
	
	public String recoverYourUsernameTopErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(recoverYourUsernameTopError)).getText();
	}	
		
	public void clickButtonInRecoverYourUsernamePage(String buttonName) {
		WebElement elem = mediumWait.get().until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//button[@type='submit' and contains(.,'" + buttonName + "')][@aria-hidden='false']")));
		scrollElementIntoView(elem);
		elem.click();
	}
	public String getFormHeaderOnRecoverUserNamePage(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(formHeaderOnRecoverUserName)).getText();
	}
	
	public String getFormSubHeaderOnRecoverUserNamePage(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(formSubHeaderOnRecoverUserName)).getText();
	}
	
	public WebElement getWebElementforHomeIcon(){
		return smallWait.get().until(ExpectedConditions.visibilityOf(homeIcon));
	}
	
	public boolean verifyMyUhcLogoNotDisplayed(){
		 try{
            if(myUhcLogo.isDisplayed()) {
            return false;
            }
            return false;
         } catch(Exception e){
             return true;
         }
	}
	
	public void clickMyUHCLogo() {
		smallWait.get().until(ExpectedConditions.visibilityOf(myUhcLogo)).click();
	}
	
	public void clickMyHealthCareLogo() {
		smallWait.get().until(ExpectedConditions.visibilityOf(uhcMyHealthCareViewLogo)).click();
	}
	
	public String getNeedHelpContent(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(needHelpSection)).getText();
	}
	
}
