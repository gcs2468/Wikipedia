package com.optum.synergy.reference.ui.stepDefinitions;
import com.optum.synergy.reference.ui.pageobjects.OptumRXsigninSecuritySettingsPage;
import com.optum.synergy.reference.ui.utility.dataStorage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

public class OptumRXsigninSecuritySettingsStepDefinition {

	
private OptumRXsigninSecuritySettingsPage page;
	
	public OptumRXsigninSecuritySettingsStepDefinition() {
		page = new OptumRXsigninSecuritySettingsPage();
	}
	
	@When("^I should be navigated to Security and Settings page$")
	public void iShouldBeNavigatedToSecurityAndSettingsPage() throws Throwable {
		Assert.assertTrue("Failed to navigate to Signin & Security page", page.verifyIfPageLoaded());
	}

	@Then("^I should see username as logged in user$")
	public void iShouldSeeUsernameAsLoggedInUser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(dataStorage.getUserName(), page.getdisplayedusername());
	}

	@When("^I click on Edit password link$")
	public void iClickOnEditPasswordLink() throws Throwable {
	    page.clickOnEditPassword();
	}

	@When("^I enter current password as \"([^\"]*)\"$")
	public void iEnterCurrentPasswordAs(String arg1) throws Throwable {
	    page.enterCurrentPwd(arg1);
	}

	@When("^I enter new password as \"([^\"]*)\"$")
	public void iEnterNewPasswordAs(String arg1) throws Throwable {
	    page.enterNewPwd(arg1);
	}

	@When("^I enter re-enter new password as \"([^\"]*)\"$")
	public void iEnterReEnterNewPasswordAs(String arg1) throws Throwable {
	    page.enterConfirmNewPwd(arg1);
	}

	@When("^I click on Cancel button on password update section$")
	public void iClickOnCancelButtonOnPasswordUpdateSection() throws Throwable {
	   page.clickonCancelButtonForPWd();
	}

	@When("^I click on Save button on password update section$")
	public void iClickOnSaveButtonOnPasswordUpdateSection() throws Throwable {
	   page.clickonSaveButtontoSavepwd();
	}

	@Then("^I should see the error message as \"([^\"]*)\" for current password$")
	public void iShouldSeeTheErrorMessageAsForCurrentPassword(String arg1) throws Throwable {
	  Assert.assertEquals(arg1, page.getErrorMsgForCurrentPwd());
	}

	@Then("^I should see the error message as \"([^\"]*)\" for New password$")
	public void iShouldSeeTheErrorMessageAsForNewPassword(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getErrorMsgForNewPwd());
	}

	@Then("^I should see the error message as \"([^\"]*)\" for Re-enter password$")
	public void iShouldSeeTheErrorMessageAsForReEnterPassword(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getErrorMsgForConfirmPwd());
	}

	@Then("^I should see the top message as \"([^\"]*)\" for password update$")
	public void iShouldSeeTheTopMessageAsForPasswordUpdate(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I should see the tip for password as \"([^\"]*)\"$")
	public void iShouldSeeTheTipForPasswordAs(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getPasswordRuletip());
	}

	@When("^I click on Edit Recovery email link$")
	public void iClickOnEditRecoveryEmailLink() throws Throwable {
	    page.clickonEditRecoveryEmail();
	}

	@When("^I enter new email id as \"([^\"]*)\"$")
	public void iEnterNewEmailIdAs(String arg1) throws Throwable {
	   page.enterNewEmail(arg1);
	}

	@When("^I click on Cancel button on Recovery email section$")
	public void iClickOnCancelButtonOnRecoveryEmailSection() throws Throwable {
	    page.clickOnCancelBtnForEmailRecovery();
	}

	@When("^I click on Save button on Recovery email section$")
	public void iClickOnSaveButtonOnRecoveryEmailSection() throws Throwable {
	   page.clickOnSaveBtnForEmailRecovery();
	}

	@Then("^I should see the error message as \"([^\"]*)\" for New email$")
	public void iShouldSeeTheErrorMessageAsForNewEmail(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getErrorMsgForEmail());
	}

	@When("^I click on Edit Account Recovery link$")
	public void iClickOnEditAccountRecoveryLink() throws Throwable {
	    page.clickonEditAccountRecoverylink();
	}

	@When("^I Select security options as \"([^\"]*)\"$")
	public void iSelectSecurityOptionsAs(String arg1) throws Throwable {
	   page.selectAccountRecoveryOption(arg1);
	}

	@When("^I Select security question one as \"([^\"]*)\"$")
	public void iSelectSecurityQuestionOneAs(String arg1) throws Throwable {
	   page.selectSecurityQuestionOne(arg1);
	}

	@When("^I Select security question two as \"([^\"]*)\"$")
	public void iSelectSecurityQuestionTwoAs(String arg1) throws Throwable {
		page.selectSecurityQuestionTwo(arg1);
	}

	@When("^I Select security question three as \"([^\"]*)\"$")
	public void iSelectSecurityQuestionThreeAs(String arg1) throws Throwable {
		page.selectSecurityQuestionThree(arg1);
	}

	@When("^I enter answer for security question one as \"([^\"]*)\"$")
	public void iEnterAnswerForSecurityQuestionOneAs(String arg1) throws Throwable {
	    page.enterAnswerOne(arg1);
	}

	@When("^I enter answer for security question two as \"([^\"]*)\"$")
	public void iEnterAnswerForSecurityQuestionTwoAs(String arg1) throws Throwable {
		page.enterAnswerTwo(arg1);
	}

	@When("^I enter answer for security question three as \"([^\"]*)\"$")
	public void iEnterAnswerForSecurityQuestionThreeAs(String arg1) throws Throwable {
		page.enterAnswerThree(arg1);
	}

	@Then("^I should see the error message for security answer one as \"([^\"]*)\"$")
	public void iShouldSeeTheErrorMessageForSecurityAnswerOneAs(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getErrMsgForAnswerOne());
	}

	@Then("^I should see the error message for security answer two as \"([^\"]*)\"$")
	public void iShouldSeeTheErrorMessageForSecurityAnswerTwoAs(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getErrMsgForAnswerTwo());
	}

	@Then("^I should see the error message for security answer three as \"([^\"]*)\"$")
	public void iShouldSeeTheErrorMessageForSecurityAnswerThreeAs(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getErrMsgForAnswerThree());
	}

	@Then("^I should see the top error message as \"([^\"]*)\" for security questions update$")
	public void iShouldSeeTheTopErrorMessageAsForSecurityQuestionsUpdate(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getTopErrorForAccountRecoveryThroughSecurityQuestion());
	}

	@When("^I click on Cancel button on Security Question-Answer update section$")
	public void iClickOnCancelButtonOnSecurityQuestionAnswerUpdateSection() throws Throwable {
	    page.clickOnCancelButtonAnswerUpdate();
	    
	}

	@When("^I click on Save button on Security Question-Answer update section$")
	public void iClickOnSaveButtonOnSecurityQuestionAnswerUpdateSection() throws Throwable {
		page.clickOnSaveButtonAnswerUpdate();
	}

	@When("^I enter phone number as \"([^\"]*)\"$")
	public void iEnterPhoneNumberAs(String arg1) throws Throwable {
	   page.enterPhoneNumber(arg1);
	}

	@When("^I select phone type as \"([^\"]*)\"$")
	public void iSelectPhoneTypeAs(String arg1) throws Throwable {
	    page.selectPhoneType(arg1);
	}

	@Then("^I should error message as \"([^\"]*)\" for phone number$")
	public void iShouldErrorMessageAsForPhoneNumber(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getErrMsgForPhoneNumber());
	}

	@Then("^I should error message as \"([^\"]*)\" for phone type$")
	public void iShouldErrorMessageAsForPhoneType(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getErrMsgForPhoneType());
	}

	@When("^I click on Cancel button on phonenumber update section$")
	public void iClickOnCancelButtonOnPhonenumberUpdateSection() throws Throwable {
	  page.clickOnCancelButtonPhoneNumber();
	}

	@When("^I click on Save button on phonenumber update section$")
	public void iClickOnSaveButtonOnPhonenumberUpdateSection() throws Throwable {
	    page.clickOnSaveButtonPhoneNumber();
	}

	@When("^I click on Consumer Communication Notice link$")
	public void iClickOnConsumerCommunicationNoticeLink() throws Throwable {
	   page.clickOnConsumerCommunicationNotice();
	}

	@When("^I click on Textting terms and Conditions link$")
	public void iClickOnTexttingTermsAndConditionsLink() throws Throwable {
	    page.clickOnTextingTermsConditions();
	}

	@Then("^I should see the content as \"([^\"]*)\" for Consumer Communication Notice$")
	public void iShouldSeeTheContentAsForConsumerCommunicationNotice(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getContentForConsumerCommunicationNotice());
	}

	@Then("^I should see the content as \"([^\"]*)\" for Textting terms and Conditions$")
	public void iShouldSeeTheContentAsForTexttingTermsAndConditions(String arg1) throws Throwable {
		Assert.assertEquals(arg1, page.getContentForTextingTermsConditions());
	}

	@When("^I click on Close button on model view$")
	public void iClickOnCloseButtonOnModelView() throws Throwable {
	  page.clickOnCloseButton();
	}

}
