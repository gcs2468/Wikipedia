package com.optum.synergy.reference.ui.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import org.junit.Assert;

/**
 * @author rtripa1
 *
 */
public class dataStorage {
	private static ThreadLocal<String> portalName = new ThreadLocal<String>();
	private static ThreadLocal<String> UserName = new ThreadLocal<String>();
	private static ThreadLocal<String> confirmregistrationurl = new ThreadLocal<String>();
	private static ThreadLocal<String> EmailSubject = new ThreadLocal<String>();
	private static ThreadLocal<String> customErrmsg = new ThreadLocal<String>();
	private static ThreadLocal<String> EmailContent = new ThreadLocal<String>();
	private static ThreadLocal<String> emailid = new ThreadLocal<String>();
	private static ThreadLocal<String> ScenarioName = new ThreadLocal<String>();
	private static ResourcePool<String> emailIdPool = new ResourcePool<String>(
			readXMLdata.getTestDataList("emailAddresses", "emailAddress"));
	private static ThreadLocal<HashMap<String, String>> userdetails = new ThreadLocal<HashMap<String, String>>() {
		@Override
		protected HashMap<String, String> initialValue() {
			return new HashMap<>();
		}
	};

	public static void setEmailId(String newEmailId) {
		emailid.set(newEmailId);
	}

	public static String getEmailId() {
		String currEmail = emailid.get();
		if (currEmail == null) {
			currEmail = emailIdPool.getResource();
			if (currEmail == null) {
				setCustomErrmsg("ERROR::dataStorage::No available email ID in resource pool");
				Assert.fail("ERROR::dataStorage::No available email ID in resource pool");
			}
			String currUsername = UserName.get();
			if (currUsername != null) {
				emailIdPool.returnResource(currEmail);
				currEmail = currEmail.replaceAll("@", "+" + stripEmailSpecialChars(currUsername) + "@");
				setCustomErrmsg("Unique tagged email address [" + currEmail + "]");

			}
			emailid.set(currEmail);
		}
		return currEmail;
	}

	private static String stripEmailSpecialChars(String input) {
		String strippedString = input;
		// List of characters that may be in username but are not valid for an
		// email address
		String[] specialChars = { "@", "!", "%", "=", ">", "<", "/" };
		// List of regular expression characters that need to be escaped during
		// replaceAll
		String[] regexSpecial = { "{", "}", "+", "$", "[", "]", "?", "^", "." };
		for (String i : specialChars) {
			strippedString = strippedString.replaceAll(i, "");
		}

		for (String j : regexSpecial) {
			strippedString = strippedString.replaceAll("\\" + j, "");
		}

		return strippedString;
	}

	public static void resetEmailId() {

		String currEmailId = emailid.get();
		String emailRegex = "HSIDAUTO[0-9]*@GMAIL.COM";
		// Only return email to pool IF:
		// * not null
		// * does not have the "unique tagging" with "+{UserID}"
		// * matches regular expression of pooled addresses
		// * not already in the pool
		if (currEmailId != null && !currEmailId.contains("+") && currEmailId.toUpperCase().matches(emailRegex)
				&& !emailIdPool.contains(currEmailId)) {
			System.out.println("DEBUG::dataStorage:: returning [" + currEmailId + "] to emailid Pool");
			emailIdPool.returnResource(currEmailId);
		}
		emailid.set(null);
	}

	public static void resetAllDataStorage() {
		resetCustomErrmsg();
		resetEmail();
		resetEmailId();
		resetPortalName();
		resetuserdetails();
		resetusername();
		resetScenarioName();

	}

	public static void resetuserdetails() {
		userdetails.get().clear();
	}

	/**
	 * Generic storage function into userdetails Map
	 * 
	 * @param key
	 * @param value
	 */
	public static void setUserDetails(String key, String value) {
		userdetails.get().put(key, value);
	}

	/**
	 * Generic retrieval function into userdetails Map WARNING: Will return null
	 * if 'key' has not been previously stored
	 * 
	 * @param key
	 */
	public static String getUserDetails(String key) {
		return userdetails.get().get(key);
	}

	public static void setFirstName(String frstname) {
		setUserDetails("FirstName", frstname);
	}

	public static void setLastName(String lastname) {
		setUserDetails("LastName", lastname);
	}

	public static void setDOB(String dob) {
		setUserDetails("DOB", dob);
	}

	public static void setSSN(String ssn) {
		setUserDetails("SSN", ssn);
	}

	public static void setSubscriberID(String subscriberid) {
		setUserDetails("SubscriberID", subscriberid);
	}
	
	public static void setGender(String Gender) {
		setUserDetails("Gender", Gender);
	}
	
	public static void setAddressLine(String AddressLine) {
		setUserDetails("AddressLine", AddressLine);
	}
	public static void setCity(String City) {
		setUserDetails("City", City);
	}
	public static void setState(String State) {
		setUserDetails("State", State);
	}
	public static void setPhone(String Phone) {
		setUserDetails("Phone", Phone);
	}

	public static void setGroupNumber(String groupNum) {
		setUserDetails("GroupNumber", groupNum);
	}

	public static void setAltId(String altid) {
		userdetails.get().put("AltId", altid);
	}

	public static void setUUID(String uuid) {
		setUserDetails("UUID", uuid);
	}

	public static void setZip(String zip) {
		setUserDetails("Zip", zip);
	}

	public static String getFirstName() {
		return userdetails.get().get("FirstName");
	}

	public static String getLastName() {
		return userdetails.get().get("LastName");
	}

	public static String getDOB() {
		return userdetails.get().get("DOB");
	}

	public static String getSSN() {
		return userdetails.get().get("SSN");
	}

	public static String getSubscriberID() {
		return userdetails.get().get("SubscriberID");
	}
	
	public static String getGender() {
		return userdetails.get().get("Gender");
	}
	
	public static String getAddressLine() {
		return userdetails.get().get("AddressLine");
	}
	
	public static String getCity() {
		return userdetails.get().get("City");
	}
	
	public static String getState() {
		return userdetails.get().get("State");
	}
	
	public static String getPhone() {
		return userdetails.get().get("Phone");
	}

	public static String getAltId() {
		return userdetails.get().get("AltId");
	}

	public static String getGroupNumber() {
		return userdetails.get().get("GroupNumber");
	}

	public static String getZip() {
		return userdetails.get().get("Zip");
	}

	public static String getUUID() {
		return userdetails.get().get("UUID");
	}

	public static void setNewSubscriberID(String newsubscriberID) {
		setUserDetails("NewSubscriberID", newsubscriberID);
	}

	public static String getNewSubscriberID() {
		return userdetails.get().get("NewSubscriberID");
	}

	public static String getUserName() {

		if (UserName.get() != null) {
			return UserName.get();
		}

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();

		// For multithreaded execution, timestamp with seconds is not granular
		// enough. Include random suffix
		String rndSuffix = Integer.toString(new Random().nextInt(1000));
		String appndTxt = dateFormat.format(date) + "_" + rndSuffix;

		UserName.set("Auto" + appndTxt);
		return UserName.get();

	}

	public static void setCustomErrmsg(String customErrmsg) {
		if (dataStorage.customErrmsg.get() != null) {
			dataStorage.customErrmsg.set(dataStorage.customErrmsg.get() + "\n" + customErrmsg);
		} else {
			dataStorage.customErrmsg.set(customErrmsg);
		}
	}

	public static void resetCustomErrmsg() {
		dataStorage.customErrmsg.set("");
	}

	public static String getCustomErrmsg() {
		return dataStorage.customErrmsg.get();
	}

	public static String getEmailSubject() {
		if (EmailSubject.get() != null) {
			return EmailSubject.get();
		}
		try {
			String[] tmparr = readEmail.getConfirmRegistrationURLWithSubjectandEmailContent();
			confirmregistrationurl.set(tmparr[0]);
			EmailSubject.set(tmparr[1]);
			EmailContent.set(tmparr[2]);
		} catch (IndexOutOfBoundsException e ) {
			dataStorage.setCustomErrmsg("No emails found in getEmailSubject::for [" + emailid.get() + "]  " + e);
			Assert.fail("No emails found in getEmailSubject::for [" + emailid.get() + "]  " + e);
		}
		catch (Exception e) {
			dataStorage.setCustomErrmsg("EXCEPTION [" + e + "] IN getEmailSubject::for [" + emailid.get() + "]");
			Assert.fail("EXCEPTION [" + e + "] IN getEmailSubject::for [" + emailid.get() + "]");
		}

		return EmailSubject.get();
	}

	public static String getEmailContent() {
		return EmailContent.get();
	}

	public static void setUserName(String username) {
		UserName.set(username);
	}

	public static void resetusername() {

		UserName.set(null);

	}

	public static String getConfirmregistrationurl() {

		if (confirmregistrationurl.get() != null) {
			return confirmregistrationurl.get();
		}
		try {
			String[] tmparr = readEmail.getConfirmRegistrationURLWithSubjectandEmailContent();
			confirmregistrationurl.set(tmparr[0]);
			EmailSubject.set(tmparr[1]);
			EmailContent.set(tmparr[2]);
		} catch (Exception e) {

		}

		return confirmregistrationurl.get();

	}

	public static void setConfirmregistrationurl(String Confirmregistrationurl) {
		confirmregistrationurl.set(Confirmregistrationurl);
	}

	public static void resetEmail() {
		confirmregistrationurl.set(null);
		EmailSubject.set(null);
		EmailContent.set(null);

	}

	public static String getPortalName() {
		return portalName.get();
	}

	public static void setPortalName(String portalname) {
		dataStorage.portalName.set(portalname);
	}

	public static void resetPortalName() {
		dataStorage.portalName.set(null);
	}

	/** ------------- Below methods related to Optum Id ------------------ */
	public static void setYearOfBirth(String yoB) {
		userdetails.get().put("YearOfBirth", yoB);
	}

	public static String getYearOfBirth() {
		return userdetails.get().get("YearOfBirth");
	}

	public static void setEmail(String email) {
		userdetails.get().put("Email", email);
	}

	public static String getEmail() {
		return userdetails.get().get("Email");
	}

	public static void setPassword(String pwd) {
		userdetails.get().put("Password", pwd);
	}

	public static String getPassword() {
		return userdetails.get().get("Password");
	}

	/** ------------- above methods related to Optum Id ------------------ */
	public static String getScenarioName() {
		return dataStorage.ScenarioName.get();
	}

	public static void setScenarioName(String name) {
		dataStorage.ScenarioName.set(name);
	}

	public static void resetScenarioName() {
		dataStorage.ScenarioName.set(null);
	}
}
