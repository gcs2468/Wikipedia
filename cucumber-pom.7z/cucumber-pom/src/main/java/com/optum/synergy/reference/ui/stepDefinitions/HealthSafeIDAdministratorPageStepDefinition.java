package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.HealthSafeIDAdministratorPage;
import com.optum.synergy.reference.ui.pageobjects.Hooks;
import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readXMLdata;

import cucumber.api.java.en.Then;

public class HealthSafeIDAdministratorPageStepDefinition {
	private HealthSafeIDAdministratorPage page;
	public HealthSafeIDAdministratorPageStepDefinition() {
		page = new HealthSafeIDAdministratorPage();
		
	}
	
	@Then("^I should get UUID for \"([^\"]*)\" user using the HealthSafe ID Administrator portal$")
	public void i_should_get_UUID_for_user_using_the_HealthSafe_ID_Administrator_portal(String username)
			throws Throwable {
		page.openPage();
		Assert.assertTrue(page.verifyIfPageLoaded());
		// page.click_Username_UUID_or_Email_address_radio_Button();
		// username = new Hooks().getUserName();//
		username = dataStorage.getUserName();

		readXMLdata.getTestData("HSIDAdmin", "URL");
		page.enterValueIntoSearchBox(username);
		page.clickSearchButton();
		new Hooks().setUUID(page.getUUID());
		System.out.println(page.getUUID());
	}

	@Then("^I should get UUID for registered user using the HealthSafe ID Administrator portal$")
	public void i_should_get_UUID_for_registered_user_using_the_HealthSafe_ID_Administrator_portal() throws Throwable {
		page.openPage();
		Assert.assertTrue(page.verifyIfPageLoaded());
		// page.click_Username_UUID_or_Email_address_radio_Button();
		// username = new Hooks().getUserName();//
		String userEmail = dataStorage.getEmailId();
		dataStorage.setCustomErrmsg("User Email::" + userEmail);
		readXMLdata.getTestData("HSIDAdmin", "URL");
		page.enterValueIntoSearchBox(userEmail);
		page.clickSearchButton();
		// new Hooks().setUUID(page.getUUID());
		String UUID = page.getUUID();
		dataStorage.setUUID(UUID);
		dataStorage.setCustomErrmsg("UUID::" + UUID);
	}
	
}
