package com.optum.synergy.reference.ui.pageobjects;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.dataStorage;

public class OptumOutlookLoggedInPage extends PageObjectBase {

	@FindBy(how = How.ID, using = "divMainPage")
	private WebElement outlookMainPage;

	@FindBy(how = How.LINK_TEXT, using = "Confirm  your email address >")
	private WebElement confirmEmailAddressLink;

	@FindBy(how = How.CSS, using = "div#divBdy table table:nth-of-type(2)")
	private WebElement phoneConfirmationMessage;

	@FindBy(how = How.ID, using = "divBdy")
	private WebElement mailBody;
	
	@FindBy(how = How.ID, using = "spnFrom")
	private WebElement mailSender;
	
	@FindBy(how = How.ID, using = "divConvTopic")
	private WebElement mailSubject;

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(outlookMainPage)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void clickInboxFolder() {
		mediumWait.get().until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@id='spnFldrNm' and text()='Inbox']")))
				.click();
	}

	public boolean verifyInboxUnreadMailwithSubject(String mailSubject) {

		List<WebElement> mails=mediumWait.get().until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@id='divSubject' and contains(.,'"+mailSubject+"')]/preceding-sibling::div[@class='cData']")));
		return new Integer(mails.get(0).getAttribute("read"))==0;
		/*return mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//div[@class='cData' and @read='0']/following-sibling::div[@id='divSubject' and contains(.,'"
						+ mailSubject + "')]")))
				.isDisplayed();*/

	}

	public void clickInboxUnreadMailwithSubject(String mailSubject) {

		/*List<WebElement> mails=mediumWait.get().until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@id='divSubject' and contains(.,'"+mailSubject+"')]/preceding-sibling::div[@class='cData']")));
	
		Assert.assertTrue("first unread email with subject "+"\""+mailSubject+"\" doesn't exist",new Integer(mails.get(0).getAttribute("read"))== 0);
		mails.get(0).click();*/
				
		 mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated( By.xpath("//div[@id='divSubject' and contains(.,'"+ mailSubject + "')]"))) .click();
		
	}
	
	public void getlatestemailfromserver(String mailSubject){
		Assert.assertEquals(dataStorage.getEmailSubject(),mailSubject);
	}

	public boolean verifyFirstEmailContainsTheSubject(String subject) {
		List<WebElement> emails = mediumWait.get().until(ExpectedConditions.presenceOfAllElementsLocatedBy(
				By.xpath("//div/div[@id='divSenderList' and contains(.,'" + subject + "')]")));
		WebElement required = null;
		if (emails.isEmpty() == false) {
			required = emails.get(0);
		}
		return required.getText().contains(subject);
	}

	public boolean clickOnAnFirstEmailContainsTheSubject(String subject) {
		List<WebElement> emails = mediumWait.get().until(ExpectedConditions.presenceOfAllElementsLocatedBy(
				By.xpath("//div/div[@id='divSenderList' and contains(.,'" + subject + "')]")));
		if (emails.isEmpty() == false) {
			emails.get(0).click();
			return true;
		} else
			return false;
	}

	public void clickOnRegistrationConfirmationLink() {
		switchToFrameByNameOrId("ifBdy");
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailAddressLink));
		confirmEmailAddressLink.click();
	}

	public void getPhoneConfirmationCode() {
		switchToDefaultContent();
		mediumWait.get().until(ExpectedConditions.visibilityOf(phoneConfirmationMessage));

		System.out.println("phoneConfirmationMessage-------------------------");

		String message = phoneConfirmationMessage.getText();
		System.out.println(message);
		System.out.println();
		message = message.replaceAll("\\r\\n|\\r|\\n", " ");
		String[] messageWords = message.split(" ");
		System.out.println(message);
		System.out.println("Confirmation code is : " + messageWords[7]);
		System.out.println();
		new Hooks().setPhoneConfirmatioCode(messageWords[7]);
		switchToDefaultContent();

	}

	public boolean verifyForMailBodyContent(String content) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(mailBody));
		return mailBody.getText().contains(content);
	}
	
	public boolean verifyForMailSender(String sender)
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(mailSender	));
		return mailSender.getText().equals(sender);
	}
	
	public boolean verifyForMailSubject(String subject)
	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(mailSubject));
		return mailSubject.getText().equals(subject);
	}

	
	public void verifyForMailContent(String emailcontent)
	{
		Assert.assertEquals(emailcontent, dataStorage.getEmailContent().trim());
	}
	
	public boolean verifyMailContent(String emailcontent)
	{
		String actualEmailContent=dataStorage.getEmailContent().trim();
		return actualEmailContent.contains(emailcontent);
	}
	public void verifyEmailSubject(String mailSubject){
		Assert.assertEquals(mailSubject, dataStorage.getEmailSubject());
	}
	
	public void refreshemail(){
		dataStorage.resetEmail();
	}
}
