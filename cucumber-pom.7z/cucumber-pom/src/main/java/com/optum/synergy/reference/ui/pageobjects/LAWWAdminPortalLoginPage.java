package com.optum.synergy.reference.ui.pageobjects;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.readXMLdata;

public class LAWWAdminPortalLoginPage extends PageObjectBase {

	@FindBy(how = How.ID, using = "username")
	private WebElement userIdTextBox;

	@FindBy(how = How.ID, using = "password")
	private WebElement passwordTextBox;

	@FindBy(how = How.NAME, using = "Submit")
	private WebElement loginButton;

	public static String page_url;
	
	public void openPage() {
	//	page_url = getEnvVariable("LAWWAdminDetails.loginUrl");
		page_url = readXMLdata.getTestData("LAWW/AdminPortal", "url");
		openPage(page_url);
	}
	
	public void enterUserID(String userName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userIdTextBox));
		userIdTextBox.sendKeys(userName);
	}

	public void enterPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
		passwordTextBox.sendKeys(password);
	}
	
	public void clickLoginButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(loginButton));
		loginButton.click();
	}
	
}
