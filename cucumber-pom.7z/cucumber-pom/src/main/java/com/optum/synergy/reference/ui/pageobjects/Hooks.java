package com.optum.synergy.reference.ui.pageobjects;


public class Hooks {
	protected static final String BROWSER_CONFIG_FILE_RELATIVE_PATH = "src/main/resources/ui/config/browser_config.json";

	
	private static String uuid = "";
	private static String phoneConfirmationCode = "";
	
	private static String firstName_US = "";
	private static String lastName_US = "";
	private static String dob_US = "";
	private static String ssn_US = "";
	private static String subscriberId_US = "";
	private static String zip_US = "";
	private static String userName_US = "";
	private static String password_US = "";
	private static String newPassword_US="";
	private static String email_US = "";
	private static String newEmail_US = "";
	private static String phoneNumber_US = "";


	public void setUUID(String uuid) {
		Hooks.uuid = uuid;
	}

	public String getUUID() {
		return uuid;
	}
	
	public void setPhoneConfirmatioCode(String phoneCode) {
		Hooks.phoneConfirmationCode = phoneCode;
	}

	public String getPhoneConfirmatioCode() {
		return phoneConfirmationCode;
	}

	public void setFirstName(String firstName) {
		Hooks.firstName_US = firstName;
	}

	public String getFirstName() {
		return firstName_US;
	}

	public void setLastName(String lastName) {
		Hooks.lastName_US = lastName;
	}

	public String getLastName() {
		return lastName_US;
	}

	public void setDOB(String dob) {
		Hooks.dob_US = dob;
	}

	public String getDOB() {
		return dob_US;
	}

	public void setSSN(String ssn) {
		Hooks.ssn_US = ssn;
	}

	public String getSSN() {
		return ssn_US;
	}

	public void setSubscriberId(String subscriberId) {
		Hooks.subscriberId_US = subscriberId;
	}

	public String getSubscriberId() {
		return subscriberId_US;
	}

	public void setZipcode(String zip) {
		Hooks.zip_US = zip;
	}

	public String getZipcode() {
		return zip_US;
	}

	public void setUserName(String userName) {
		Hooks.userName_US = userName;
	}
	
	public String getUserName() {
		return userName_US;
	}
	
	public void setPassword(String password) {
		Hooks.password_US = password;
	}
	
	public String getPassword() {
		return password_US;
	}
	
	public void setNewPassword(String password) {
		Hooks.newPassword_US = password;
	}
	
	public String getNewPassword() {
		return newPassword_US;
	}

	public void setEmailId(String email) {
		Hooks.email_US = email;
	}

	public String getEmailId() {
		return email_US;
	}
	
	public void setNewEmailId(String email) {
		Hooks.newEmail_US = email;
	}

	public String getNewEmailId() {
		return newEmail_US;
	}
	
	public void setPhoneNumber(String email) {
		Hooks.phoneNumber_US = email;
	}

	public String getPhoneNumber() {
		return phoneNumber_US;
	}
}
