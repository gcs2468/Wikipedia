package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readXMLdata;

public class myUHCUnathenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.ID, using = "myuhcLoginForm")
	private WebElement loginForm;

	@FindBy(how = How.XPATH, using = "//*[@ng-if='alreadyHaveId && isHSIDUser']")
	private WebElement AlreadyHaveHSIDForm;
	
	@FindBy(how = How.ID, using = "hsid-username")
	private WebElement userNameTextBox;

	@FindBy(how = How.ID, using = "hsid-password")
	private WebElement passwordTextBox;
	
	@FindBy(how = How.ID, using = "hsid-submit")
	private WebElement signInButton;
	
	@FindBy(how = How.XPATH, using = "//div[@id='hsid-commonError']/p")
	private WebElement errorMsg;
	
	@FindBy(how = How.XPATH, using = "//img[contains(@src,'optum.com/content/dam/OptumDashboard/ad-box/logos/Lockup_HealthSelect.gif')]|//img[contains(@ng-src,'optum.com/content/dam/OptumDashboard/ad-box/logos/Lockup_HealthSelect.gif')]")
    private WebElement uhcHealthSelectLogo;
    
    @FindBy(how = How.XPATH, using = "//img[contains(@src,'optum.com/content/dam/OptumDashboard/ad-box/logos/logo_myhealthcareview.gif')]|//img[contains(@ng-src,'optum.com/content/dam/OptumDashboard/ad-box/logos/logo_myhealthcareview.gif')]")
    private WebElement uhcMyHealthCareViewLogo;
    
    @FindBy(how = How.XPATH, using = "//img[contains(@src,'optum.com/content/dam/OptumDashboard/ad-box/logos/Lockup_Medica.gif')]|//img[contains(@ng-src,'optum.com/content/dam/OptumDashboard/ad-box/logos/Lockup_Medica.gif')]")
    private WebElement uhcMedicaLogo;
    
    @FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/logo_UHC_CommunityPlan.gif')]|//img[contains(@ng-src,'optum.com/content/dam/OptumDashboard/ad-box/logos/logo_UHC_CommunityPlan.gif')]")
    private WebElement uhcCommunityPlanLogo;

	
	public void enterUserName(String userName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
		userNameTextBox.clear();
		userNameTextBox.sendKeys(userName);
	}
	public void enterPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
		passwordTextBox.clear();
		passwordTextBox.sendKeys(password);
	}
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOf((loginForm))).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void openMyHealthOverViewHomePage() {
		String page_url=readXMLdata.getTestData(dataStorage.getPortalName(), "MyHealthOverViewURL");
		openPage(page_url);
	}
	public void openHealthSelectPortalHomePage() {
		String page_url=readXMLdata.getTestData(dataStorage.getPortalName(), "HealthSelectPortalURL");
		openPage(page_url);
	}
	public void openCommunityAndStateURLHomePage() {
		String page_url=readXMLdata.getTestData(dataStorage.getPortalName(), "CommunityAndStateURL");
		openPage(page_url);
	}
	public void openmyUHCHomePage() {
		String page_url=readXMLdata.getTestData(dataStorage.getPortalName(), "AppURL");
		openPage(page_url);
	}
	
	public void clickOnSignInButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(signInButton)).click();
	}
	
	public String getErrorMessageOnmyUHCUnauthenticatedHomePage() {
	 String message=mediumWait.get().until(ExpectedConditions.visibilityOf(errorMsg)).getText();
	 String arrEle[]=message.split("Error: ");
		  return arrEle[1].replaceAll("\\s+", "");
		  
	}

}
