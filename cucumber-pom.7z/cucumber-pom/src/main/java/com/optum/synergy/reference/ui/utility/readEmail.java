package com.optum.synergy.reference.ui.utility;

import java.io.IOException;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;
import javax.mail.Message.RecipientType;
import javax.mail.search.AndTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.SearchTerm;

import org.jsoup.Jsoup;

public class readEmail {
	private static final long EMAIL_SLEEP = 30000;

	public static String[] getConfirmRegistrationURLWithSubjectandEmailContent()
			throws MessagingException, IOException, InterruptedException {
		String pwd = "test123$";
		// String username = System.getProperty("Emailid");
		// String username = "hsidauto.1@gmail.com";
		String username = dataStorage.getEmailId();


		// Hack to resolve current issue with hsidauto1 account/password
		//TODO Need to consolidate account passwords.  Made difficult
		// by UHC's network policy blocking gmail.com...
		if ( username.toUpperCase().startsWith("HSIDAUTO1")) {
			pwd = "test1234$";
		}
		Thread.sleep(EMAIL_SLEEP);// just to make sure that email reached to
									// inbox so
		// 30 seconds time gap
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");
		Session session = Session.getDefaultInstance(props, null);
		Store store = session.getStore("imaps");
		store.connect("imap.gmail.com", username, pwd);
		Folder inbox = store.getFolder("Inbox");
		inbox.open(Folder.READ_ONLY);

		// Filter inbox messages by "UNSEEN" and "TO={username}"
		FlagTerm ft_unseen = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
		RecipientStringTerm ft_toEmail = new RecipientStringTerm(RecipientType.TO, username);
		SearchTerm st = new AndTerm(ft_unseen, ft_toEmail);
		Message msg[] = inbox.search(st);
		System.out.println("MAILS for [" + username + "]: " + msg.length);

		Object emailcontent = msg[msg.length - 1].getContent();
		String toberemoved = "This e-mail, including attachments, may include confidential and/or proprietary information, and may be used only by the person or entity to which it is addressed. If the reader of this e-mail is not the intended recipient or his or her authorized agent, the reader is hereby notified that any dissemination, distribution or copying of this e-mail is prohibited. If you have received this e-mail in error, please notify the sender by replying to this message and delete this e-mail immediately.";

		String linkurl;
		try {
			String[] tmparr_2;
			String[] tmparray = ((String) emailcontent).split("href=\"");
			if (dataStorage.getPortalName().contains("MyUHC")) {
				tmparr_2 = tmparray[1].split("\"><b>");
			} else {
				if (tmparray[1].contains("Confirme su direcci")) {
					tmparr_2 = tmparray[1].split("\"><b>");
				}

				else {
					tmparr_2 = tmparray[1].split("\"><b></b></a>");
				}
			}

			linkurl = tmparr_2[0];
		} catch (Exception e) {
			linkurl = " ";
		}

		String[] rtrnrarr = new String[] { linkurl, msg[msg.length - 1].getSubject().toString(),
				Jsoup.parse(emailcontent.toString()).text().replace(toberemoved, "") };
		store.close();
		session = null;
		return rtrnrarr;
	}

	public static String getEmailContent() {
		return getEmailContent(dataStorage.getEmailId());
	}

	public static String getEmailContent(String mailBoxUsername) {
		Session session;
		Store store = null;
		String returnedContent = null;
		try {

			String pwd = "test123$";
			// String username = System.getProperty("Emailid");
			// String username = "hsidauto.1@gmail.com";
			// String username = dataStorage.getEmailId();

			// Hack to resolve current issue with hsidauto1 account/password
			//TODO Need to consolidate account passwords.  Made difficult
			// by UHC's network policy blocking gmail.com...
			if ( mailBoxUsername.toUpperCase().startsWith("HSIDAUTO1")) {
				pwd = "test1234$";
			}
			
			Thread.sleep(EMAIL_SLEEP);// just to make sure that email reached to
										// inbox
			// so 30 seconds time gap
			Properties props = System.getProperties();
			props.setProperty("mail.store.protocol", "imaps");
			props.setProperty("mail.imap.ssl.enable", "true");

			session = Session.getInstance(props, null);
			store = session.getStore("imaps");
			store.connect("imap.gmail.com", mailBoxUsername, pwd);
			Folder inbox = store.getFolder("Inbox");
			inbox.open(Folder.READ_ONLY);

			// Filter inbox messages by "UNSEEN" and "TO={username}"
			FlagTerm ft_unseen = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
			RecipientStringTerm ft_toEmail = new RecipientStringTerm(RecipientType.TO, mailBoxUsername);
			SearchTerm st = new AndTerm(ft_unseen, ft_toEmail);
			Message msg[] = inbox.search(st);
			System.out.println("MAILS for [" + mailBoxUsername + "]: " + msg.length);

			if (msg.length > 0) {
				Object emailcontent = msg[msg.length - 1].getContent();

				String toberemoved = "This e-mail, including attachments, may include confidential and/or proprietary information, and may be used only by the person or entity to which it is addressed. If the reader of this e-mail is not the intended recipient or his or her authorized agent, the reader is hereby notified that any dissemination, distribution or copying of this e-mail is prohibited. If you have received this e-mail in error, please notify the sender by replying to this message and delete this e-mail immediately.";
				returnedContent = Jsoup.parse(emailcontent.toString()).text().replace(toberemoved, "");
			} else {
				// No messages in mailbox, return null
				returnedContent = null;
			}
		} catch (Exception e) {
			System.out.println(e.toString());
			returnedContent = null;
		} finally {
			try {
				store.close();
				session = null;
			} catch (Exception e) {
				// no-op
			}
		}

		return returnedContent;
	}

	public static String getAccesscodeForLegacyID(String userid)
			throws MessagingException, IOException, InterruptedException {
		String accesscode=null;
		String pwd = "test123$";
		String username = "hsidauto1+" + userid + "@gmail.com";

		// Hack to resolve current issue with hsidauto1 account/password
		//TODO Need to consolidate account passwords.  Made difficult
		// by UHC's network policy blocking gmail.com...
		if ( username.toUpperCase().startsWith("HSIDAUTO1")) {
			pwd = "test1234$";
		}
		
		Thread.sleep(EMAIL_SLEEP);// just to make sure that email reached to
									// inbox so
		// 30 seconds time gap
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");
		Session session = Session.getDefaultInstance(props, null);
		Store store = session.getStore("imaps");
		store.connect("imap.gmail.com", username, pwd);
		Folder inbox = store.getFolder("Inbox");
		inbox.open(Folder.READ_WRITE);// READ_WRITE flag will mark the email as
										// read once we read through the code

		// Filter inbox messages by "UNSEEN" and "TO={username}"
		FlagTerm ft_unseen = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
		RecipientStringTerm ft_toEmail = new RecipientStringTerm(RecipientType.TO, username);
		SearchTerm st = new AndTerm(ft_unseen, ft_toEmail);
		Message msg[] = inbox.search(st);
		Object emailcontent = msg[msg.length - 1].getContent();

		if (emailcontent instanceof MimeMultipart) {
			MimeMultipart multipart = (MimeMultipart) emailcontent;
			String tmpstring = getTextFromMimeMultipart(multipart);// will return the entire content of email body by recursively going through various bodypart of MIME message 
			String[] tmparr = tmpstring.split("one-time passcode");
			String[] tmparr_two = tmparr[1].split("to access your account");

			accesscode=tmparr_two[0].trim();
		}
		store.close();
		session = null;
		return accesscode;
	}

	private static String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws MessagingException, IOException {
		String result = "";
		int count = mimeMultipart.getCount();
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
				break; // without break same text appears twice in my tests
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent();
				result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
			} else if (bodyPart.getContent() instanceof MimeMultipart) {
				result = result + getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent());
			}
		}
		return result;
	}

}
