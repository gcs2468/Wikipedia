package com.optum.synergy.reference.ui.pageobjects;


import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class OptumRXsigninSecuritySettingsPage extends PageObjectBase {
	
	
	@FindBy(how=How.XPATH, using ="//h1[text()='Sign in and security settings']")
	private WebElement signInSecurityHeader;
	
	@FindBy(how=How.XPATH, using ="//span[text()='Username']/../following-sibling::flex-content/p")
	private WebElement userName;
	
	@FindBy(how=How.XPATH, using ="//a[contains(@ng-if,'passwordView')]/span[text()='Edit']")
	private WebElement lnkEditPwd;
	
	@FindBy(how=How.ID, using ="currentPassword")
	private WebElement txtcurrentPassword;
	
	@FindBy(how=How.ID, using ="password")
	private WebElement txtNewPassword;
	
	@FindBy(how=How.ID, using ="confirmPassword")
	private WebElement txtCnfrmNewPassword;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-show='!passwordLoading']/a[text()='Cancel']")
	private WebElement btnCancelPwd;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-show='!passwordLoading']/button[text()='Save']")
	private WebElement btnSavePwd;
	
	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='currentPasswordError']")
	private WebElement errMsgCurrentPwd;
	
	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='newPasswordError']")
	private WebElement errMsgNewPwd;
	
	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='confirmPasswordError']")
	private WebElement errMsgConfrmNewPwd;

	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='passwordErrorX']")
	private WebElement errMsgForWrongCurrentPwd;
	
	@FindBy(how=How.XPATH, using ="//div[@class='tooltip-content ruletip' and @aria-hidden='false']")
	private WebElement ruleTip;
	
	@FindBy(how=How.XPATH, using ="//a[contains(@ng-if,'emailView')]/span[text()='Edit']")
	private WebElement lnkEditEmailRecovery;
	
	@FindBy(how=How.ID, using ="newEamil")
	private WebElement txtNewEmail;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-show='!emailLoading']/a[text()='Cancel']")
	private WebElement btnCancelEamilUpdate;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-show='!emailLoading']/button[text()='Save']")
	private WebElement btnSaveEamilUpdate;
	
	@FindBy(how=How.XPATH, using ="//span[@class='error']/span[@ng-bind-html='emailErrorX']")
	private WebElement errMsgForEmail;
	
	@FindBy(how=How.XPATH, using ="//a[contains(@ng-if,'recoveryView')]/span[text()='Edit']")
	private WebElement lnkEditAccountRecovery;
	
	@FindBy(how=How.ID, using ="secOption")
	private WebElement slctSecurityOption;
	
	@FindBy(how=How.ID, using ="q0")
	private WebElement slctSecurityQuestionOne;
	
	@FindBy(how=How.ID, using ="q1")
	private WebElement slctSecurityQuestionTwo;
	
	@FindBy(how=How.ID, using ="q2")
	private WebElement slctSecurityQuestionThree;
	
	@FindBy(how=How.ID, using ="a0")
	private WebElement txtAnswerOne;
	
	@FindBy(how=How.ID, using ="a1")
	private WebElement txtAnswerTwo;
	
	@FindBy(how=How.ID, using ="a3")
	private WebElement txtAnswerThree;
	
	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='answer0Error']")
	private WebElement errMsgForAnswerOne;
	
	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='answer1Error']")
	private WebElement errMsgForAnswerTwo;
	
	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='answer2Error']")
	private WebElement errMsgForAnswerThree;
	
	@FindBy(how=How.XPATH, using ="//a[contains(@ng-if,'recoveryTopError')]")
	private WebElement topErrMsgForSecurityAnswer;
	
	
	@FindBy(how=How.XPATH, using ="//div[contains(@ng-show,'questions') and @aria-hidden='false']//a[text()='Cancel']")
	private WebElement btnCancelSecurityAnswer;
	
	@FindBy(how=How.XPATH, using ="//div[contains(@ng-show,'questions') and @aria-hidden='false']//button[text()='Save']")
	private WebElement btnSaveSecurityAnswer;
	
	@FindBy(how=How.XPATH, using ="//div[contains(@ng-show,'phone') and @aria-hidden='false']//a[text()='Cancel']")
	private WebElement btnCancelPhoneNumberUpdate;
	
	@FindBy(how=How.XPATH, using ="//div[contains(@ng-show,'phone') and @aria-hidden='false']//button[text()='Save']")
	private WebElement btnSavePhoneNumberUpdate;
	
	@FindBy(how=How.ID, using ="phoneNo")
	private WebElement phoneNumber;
	
	@FindBy(how=How.ID, using ="phoneType")
	private WebElement slctPhoneType;
	
	
	@FindBy(how=How.XPATH, using ="//p[@ng-bind-html='phoneNumberError']")
	private WebElement errMsgForPhoneNumber;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-bind-html='phoneTypeError']")
	private WebElement errMsgForPhoneType;
	
	@FindBy(how=How.XPATH, using ="//u[text()='Consumer Communications Notice']")
	private WebElement lnkConsumerCommunicationNotice;
	
	@FindBy(how=How.XPATH, using ="//a[text()='Close']")
	private WebElement btnCloseModelDialog;
	
	@FindBy(how=How.XPATH, using ="//u[text()='Texting Terms and Conditions']")
	private WebElement lnkTextingTermsConditions;
	
	@FindBy(how=How.XPATH, using ="//h1[text()='Texting Terms and Conditions']/../p[2]")
	private WebElement modelViewTextingTermsConditions;
	
	
	@FindBy(how=How.XPATH, using ="//h1[text()='Consumer Communications Notice']/../p[3]")
	private WebElement modelViewConsumerCommunicationsNotice;
	
	
	public boolean verifyIfPageLoaded(){
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(signInSecurityHeader)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	//***********************UserName Validation******************************************************
	public String getdisplayedusername() {		
		return mediumWait.get().until(ExpectedConditions.visibilityOf(userName)).getText();
	}
	
	
	
	// ***********************Password-Update******************************************************
	public void clickOnEditPassword() {
		longWait.get().until(ExpectedConditions.elementToBeClickable(lnkEditPwd)).click();
	}

	public void enterCurrentPwd(String pwd) {
         mediumWait.get().until(ExpectedConditions.visibilityOf(txtcurrentPassword)).clear();
         txtcurrentPassword.sendKeys(pwd);
	}

	public void enterNewPwd(String newpwd) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(txtNewPassword)).clear();
		txtNewPassword.sendKeys(newpwd);
	}

	public void enterConfirmNewPwd(String cnfrmNewPwd) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(txtCnfrmNewPassword)).clear();
		txtCnfrmNewPassword.sendKeys(cnfrmNewPwd);
	}

	public void clickonSaveButtontoSavepwd() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(btnSavePwd)).click();
	}

	public void clickonCancelButtonForPWd() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(btnCancelPwd)).click();
	}
	
	public String getPasswordRuletip() {
		smallWait.get().until(ExpectedConditions.visibilityOf(ruleTip));
		return ruleTip.getText();
	}
	
	public String getErrorMsgForConfirmPwd(){
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgConfrmNewPwd)).getText();
		}catch(Exception e){
			
		}
		return null;
	} 
	
	public String getErrorMsgForNewPwd(){
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgNewPwd)).getText();
		}catch(Exception e){
			
		}
		return null;
	}
	
	public String getErrorMsgForCurrentPwd(){
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgCurrentPwd)).getText();
		}catch(Exception e){
			
		}
		return null;
	}
	
	public String getErrorMsgForWrongCurrentPassword(){
		
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForWrongCurrentPwd)).getText();
		}catch(Exception e){
			
		}
		return null;
	}

	// ***********************EmailRecovery******************************************************
	public void clickonEditRecoveryEmail() {
		mediumWait.get().until(ExpectedConditions.elementToBeClickable(lnkEditEmailRecovery)).click();
	}
	
	public void enterNewEmail(String emailid){
		 smallWait.get().until(ExpectedConditions.visibilityOf(txtNewEmail)).clear();
		 txtNewEmail.sendKeys(emailid);
	}
	
	public void clickOnSaveBtnForEmailRecovery(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(btnSaveEamilUpdate)).click();
	}
	
    public void clickOnCancelBtnForEmailRecovery(){
    	mediumWait.get().until(ExpectedConditions.visibilityOf(btnCancelEamilUpdate)).click();
	}
	
	public String getErrorMsgForEmail() {

		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForEmail)).getText();
		} catch (Exception e) {}
		return null;
	}
	

	// ***********************AccountRecovery******************************************************
	public void clickonEditAccountRecoverylink() {
		longWait.get().until(ExpectedConditions.elementToBeClickable(lnkEditAccountRecovery)).click();
	}
	
	public void selectAccountRecoveryOption(String option){
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(slctSecurityOption, option));
		Select dropdown = new Select(slctSecurityOption);
		dropdown.selectByVisibleText(option);
	}
	
	public void selectSecurityQuestionOne(String question){
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(slctSecurityQuestionOne, question));
		Select dropdown = new Select(slctSecurityQuestionOne);
		dropdown.selectByVisibleText(question);
	}

	public void selectSecurityQuestionTwo(String question) {
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(slctSecurityQuestionTwo, question));
		Select dropdown = new Select(slctSecurityQuestionTwo);
		dropdown.selectByVisibleText(question);
	}

	public void selectSecurityQuestionThree(String question) {
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(slctSecurityQuestionThree, question));
		Select dropdown = new Select(slctSecurityQuestionThree);
		dropdown.selectByVisibleText(question);
	}
	
	public void enterAnswerOne(String ans){
		smallWait.get().until(ExpectedConditions.visibilityOf(txtAnswerOne)).clear();
		txtAnswerOne.sendKeys(ans);
	}

	public void enterAnswerTwo(String ans) {
		smallWait.get().until(ExpectedConditions.visibilityOf(txtAnswerTwo)).clear();
		txtAnswerTwo.sendKeys(ans);
	}

	public void enterAnswerThree(String ans) {
		smallWait.get().until(ExpectedConditions.visibilityOf(txtAnswerThree)).clear();
		txtAnswerThree.sendKeys(ans);
	}
	
	public String getTopErrorForAccountRecoveryThroughSecurityQuestion(){
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(topErrMsgForSecurityAnswer)).getText();
		} catch (Exception e) {}
		return null;
	}
	
	public String getErrMsgForAnswerOne() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForAnswerOne)).getText();
		} catch (Exception e) {}
		return null;
	}

	public String getErrMsgForAnswerTwo() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForAnswerTwo)).getText();
		} catch (Exception e) {}
		return null;
	}

	public String getErrMsgForAnswerThree() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForAnswerThree)).getText();
		} catch (Exception e) {}
		return null;
	}
	
	public void clickOnSaveButtonAnswerUpdate(){
		smallWait.get().until(ExpectedConditions.visibilityOf(btnSaveSecurityAnswer)).click();
	}
	
	public void clickOnCancelButtonAnswerUpdate(){
		smallWait.get().until(ExpectedConditions.visibilityOf(btnCancelSecurityAnswer)).click();
	}
	
	public void enterPhoneNumber(String number) {

		smallWait.get().until(ExpectedConditions.visibilityOf(phoneNumber)).clear();
		phoneNumber.sendKeys(number);
	}

	public void selectPhoneType(String phonetype) {

		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(slctPhoneType, phonetype));
		Select dropdown = new Select(slctPhoneType);
		dropdown.selectByVisibleText(phonetype);
	}

	public String getErrMsgForPhoneNumber() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForPhoneNumber)).getText();
		} catch (Exception e) {
		}
		return null;
	}

	public String getErrMsgForPhoneType() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForPhoneType)).getText();
		} catch (Exception e) {
		}
		return null;
	}
	
	public void clickOnSaveButtonPhoneNumber(){
		smallWait.get().until(ExpectedConditions.visibilityOf(btnSavePhoneNumberUpdate)).click();
	}
	
	public void clickOnCancelButtonPhoneNumber(){
		smallWait.get().until(ExpectedConditions.visibilityOf(btnCancelPhoneNumberUpdate)).click();
	}
	
	
	public void clickOnConsumerCommunicationNotice(){
		smallWait.get().until(ExpectedConditions.visibilityOf(lnkConsumerCommunicationNotice)).click();
	}
	public void clickOnTextingTermsConditions(){
		smallWait.get().until(ExpectedConditions.visibilityOf(lnkTextingTermsConditions)).click();
	}
	
	public void clickOnCloseButton(){
		smallWait.get().until(ExpectedConditions.visibilityOf(btnCloseModelDialog)).click();
	}
	
	public String getContentForConsumerCommunicationNotice(){
		return smallWait.get().until(ExpectedConditions.visibilityOf(modelViewConsumerCommunicationsNotice)).getText();
	}
	
	public String getContentForTextingTermsConditions(){
		return smallWait.get().until(ExpectedConditions.visibilityOf(modelViewTextingTermsConditions)).getText();
	}
	
}
