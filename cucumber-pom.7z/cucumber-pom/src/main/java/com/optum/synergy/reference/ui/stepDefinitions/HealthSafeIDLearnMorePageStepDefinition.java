package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.HealthSafeIDLearnMorePage;

import cucumber.api.java.en.Then;

public class HealthSafeIDLearnMorePageStepDefinition {
	private HealthSafeIDLearnMorePage page;
	public HealthSafeIDLearnMorePageStepDefinition() {
		page = new HealthSafeIDLearnMorePage();
	}

	@Then("^I should be at HealthSafe ID learn more page$")
	public void i_should_be_at_HealthSafe_ID_learn_more_page() throws Throwable {
		Assert.assertTrue("Issue while loading learn more about HealthSafe ID page",page.verifyIfPageLoaded());
	}
}
