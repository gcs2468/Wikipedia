package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HealthSafeIDPrivacyPolicyPage extends PageObjectBase{
	
	@FindBy(how = How.CLASS_NAME, using = "rtetext")
	private WebElement privacyPolicyForm;
	
	public boolean verifyIfPageLoaded(){
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(privacyPolicyForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
}
