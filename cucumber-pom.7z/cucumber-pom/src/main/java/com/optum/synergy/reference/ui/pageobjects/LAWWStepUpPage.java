package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class LAWWStepUpPage extends PageObjectBase{
	
	@FindBy(how = How.XPATH, using = "//a[contains(@class,'nav-link') and contains(.,'Benefits & Claims')]")
	private WebElement benefitsAndClaims;
	
	@FindBy(how = How.XPATH, using = "//a[contains(@class,'nav-sublink') and contains(.,'View Claim Status')]")
	private WebElement viewClaimStatus;
	
	@FindBy(how = How.XPATH, using = "//a[contains(@class,'nav-sublink') and contains(.,'Behavioral Health Coverage')]")
	private WebElement behavioralHealthCoverage;
	
	@FindBy(how = How.NAME, using = "personalInfo")
	private WebElement verifyYourInfoSection;
	
	@FindBy(how=How.CLASS_NAME, using = "error-text")
	private WebElement accessNotConfirmed;
	
	@FindBy(how = How.XPATH, using = "//*[@id='accesscode--company--selection']")
	private WebElement benefitsAccesCode;
	
	@FindBy(how = How.ID, using = "accesscode--button")
	private WebElement accessCodeCOntinueBtn;
	
	@FindBy(how = How.XPATH, using = "//*[@id='desc']/p")
	private WebElement mdmErrorMsg;
	
	@FindBy(how = How.ID, using = "usermenu")
	private WebElement globalNavUserMenu;
	
	@FindBy(how = How.ID, using = "transtitle")
	private WebElement viewClaimStatusLabel;
	
	
	

	public boolean verifyIfUserMenuDisplayedOnGlobalNav()
	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(globalNavUserMenu)).isDisplayed();
	}
	
	
	public void clickOnBenefitProviderDropDown(){
		smallWait.get().until(ExpectedConditions.visibilityOf(benefitsAccesCode));
		benefitsAccesCode.click();
	
	}
	
	
	public boolean verifyErrorMessageOnAccessNotConfirmed(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[contains(@class,'error-text') and contains(.,'"+message+"')]")))
				.isDisplayed();	
	
	}

	public void clickOnAccessCodeContinuBtn(){
		waitForPageLoad(driver);
	mediumWait.get().until(ExpectedConditions.visibilityOf(accessCodeCOntinueBtn)).click();
	}

	public boolean verifyMDMErrorMessage(String message) {
	return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
			By.xpath("//p[contains(@class,'error-text') and contains(.,'"+message+"')]")))
			.isDisplayed();	
	//----//*[@id='desc']/p
	}

	public String getMDMErrorMessage() {
	return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
			By.className("error-text"))).getText();

	}
	
	public void benefitsAndClaimsClick(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(benefitsAndClaims)).click();
	}
	
	public void viewClaimsStatusClick(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(viewClaimStatus)).click();
	}
	
	public void behaviouralHealthCoverageClick(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(behavioralHealthCoverage)).click();
	}
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(verifyYourInfoSection)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyViewClaimStatusLabel() {
		return longWait.get().until(ExpectedConditions.visibilityOf(viewClaimStatusLabel)).isDisplayed();
	}
	
	
	public void selectBenefitProvider(String providerName) {
		Select dropdown = new Select(mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id("accesscode--company--selection"))));
		dropdown.selectByVisibleText(providerName);

	}





}