package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.TestHarnessPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class TestHarnessStepDefinition {
		
	private TestHarnessPage page;

	public TestHarnessStepDefinition()  {
		page = new TestHarnessPage();
		
	}

	@Given("^I am on Test Harness Page$")
	public void i_am_on_Test_Harness_Page() throws Throwable {
		page.openPage();
		
	}

	@When("^I select \"([^\"]*)\" as TARGETPORTAL$")
	public void i_select_As_TARGETPORTAL(String arg1) throws Throwable {
		page.enterTargetPortal(arg1);
		
	}

	@Given("^I select \"([^\"]*)\" as ACTION$")
	public void i_select_As_ACTION(String arg1) throws Throwable {
		page.enterTargetAction(arg1);
	    
	}

	@Given("^I select \"([^\"]*)\" as ELIGIBILITY$")
	public void i_select_As_ELIGIBILITY(String arg1) throws Throwable {
		page.enterEligibility(arg1);
	    
	}

	@Given("^I select \"([^\"]*)\" as LANGUAGE$")
	public void i_select_As_LANGUAGE(String arg1) throws Throwable {
		page.enterLanguage(arg1);
	    
	}

	@Given("^I select \"([^\"]*)\" as ACCESSTYPE$")
	public void i_select_As_ACCESSTYPE(String arg1) throws Throwable {
		page.enterAccessType(arg1);
	    
	}
	
	@When("^I click on \"([^\"]*)\" button in Test Harness Page$")
	public void i_click_on_button_in_Test_Harness_Page(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		page.submitTestHarness();
	}


	

}




