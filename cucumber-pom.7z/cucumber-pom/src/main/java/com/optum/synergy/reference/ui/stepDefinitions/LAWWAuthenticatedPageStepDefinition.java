package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ConfirmYourIdentityPage_securityQuestions;
import com.optum.synergy.reference.ui.pageobjects.LAWWAuthenticatedPage;

import cucumber.api.java.en.Then;

public class LAWWAuthenticatedPageStepDefinition {
	private LAWWAuthenticatedPage page;
	
	public LAWWAuthenticatedPageStepDefinition() {
		page = new LAWWAuthenticatedPage();
	}
	
	@Then("^I should see usermenu dropdown on global nav bar$")
	public void i_should_see_usermenu_dropdown_on_global_nav_bar() throws Throwable {
		Assert.assertTrue("Usermenu on Global Nav bar has not displayed", page.verifyIfUserMenuDisplayedOnGlobalNav());
		
	}
	
	@Then("^I should be at LAWW Authenticated page$")
	public void i_should_be_at_LAWW_Authenticated_page() throws Throwable {
		Assert.assertTrue("Issue while loading the authenticated page", page.verifyIfUserMenuDisplayedOnGlobalNav());
	}

	@Then("^I should see Claim Status Info on ViewClaimStatus Page$")
	public void i_should_see_Claim_Status_Info_on_ViewClaimStatus_Page() throws Throwable	{
		Assert.assertTrue("View Claim info not displaying on View claim page", page.VerifyViewClaiminfoDisplaying());
	}
	
	@Then("^I should see the Claims Page with header \"([^\"]*)\"$")
	public void iShouldSeeTheClaimsPageWithHeader(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals("\""+arg1+"\"" +" heading is not displayed", page.getPageHeader(),arg1);
	}
	
	@Then("^I should see behavioral Health Coverage Info on Page$")
	public void i_should_see_behavioral_Health_Coverage_Page() throws Throwable	{
		Assert.assertTrue("View Claim info not displaying on View claim page", page.VerifybehavioralHealthCoverageDisplaying());
	}

	@Then("^I should landed into Authenticated LAWW Home Page$")
	public void i_should_landed_into_Authenticated_LAWW_Home_Page() throws Throwable {
		//NOTE: Moved from CommonStepDefinitions
		
		//TODO: Should eventually remove this step Def and have feature files explicitly handle 
		//  potential landing on security question page.  For now, keep (for backward compatibility 
		//	with existing feature files) with simpler handling
		ConfirmYourIdentityPage_securityQuestions confirmIdentityPage = new ConfirmYourIdentityPage_securityQuestions();
		if ( confirmIdentityPage.verifyIfPageLoadedSQA() ) {
			confirmIdentityPage.handleSecurityQuestionWithAnswer();	// Fill in default security question answer, click continue			
		}

		Assert.assertTrue("Issue while loading the LAWW authenticated page", page.verifyIfUserMenuDisplayedOnGlobalNav());
	}


}
