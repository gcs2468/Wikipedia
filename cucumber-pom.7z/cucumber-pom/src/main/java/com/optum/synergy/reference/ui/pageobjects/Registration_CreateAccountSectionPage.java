package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class Registration_CreateAccountSectionPage extends PageObjectBase {
	
	@FindBy(how = How.ID, using = "header")
	private WebElement formHeader;

	@FindBy(how = How.ID, using = "confirmEmail2")
	private WebElement updateEmail;

	@FindBy(how = How.CLASS_NAME, using = "form__step2")
	private WebElement createAccountSection;

	@FindBy(how = How.NAME, using = "recovery")
	private WebElement recoverySection;

	@FindBy(how = How.ID, using = "username")
	private WebElement userNameTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Username')]/following-sibling::input[@id='username']")
	private WebElement userNameLabelWithTextBox;

	@FindBy(how = How.ID, using = "password")
	private WebElement passwordTextBox;

	@FindBy(how = How.ID, using = "confirmPassword")
	private WebElement confirmPasswordTextBox;

	@FindBy(how = How.ID, using = "email")
	private WebElement emailTextBox;

	@FindBy(how = How.ID, using = "confirmEmail")
	private WebElement confirmEmailTextBox;

	@FindBy(how = How.XPATH, using = "//span[text()='Security question one']/../select")
	private WebElement securityQuestion1Select;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Security question two']/../select")
	private WebElement securityQuestion2Select;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Security question three']/../select")
	private WebElement securityQuestion3Select;
	
	@FindBy(how = How.ID, using = "q0")
	private WebElement securityQuestion1TextBox;
	
	@FindBy(how = How.ID, using = "q1")
	private WebElement securityQuestion2TextBox;
	
	@FindBy(how = How.ID, using = "q2")
	private WebElement securityQuestion3TextBox;
	
	@FindBy(how = How.XPATH, using = "//label[@for='q0']/span[1]")
	private WebElement securityQuestion1Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='q1']/span[1]")
	private WebElement securityQuestion2Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='q2']/span[1]")
	private WebElement securityQuestion3Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='a0']/span[1]")
	private WebElement securityAnswer1Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='a1']/span[1]")
	private WebElement securityAnswer2Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='a2']/span[1]")
	private WebElement securityAnswer3Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='remember']/span[1]")
	private WebElement rememberMeLabel;
	
	@FindBy(how = How.XPATH, using = "//label[@for='terms']")
	private WebElement termsOfUseLabel;
	
	@FindBy(how = How.XPATH, using = "//div[@id='securityOptions']/div/div[2]/p")
	private WebElement phoneDisclaimerLabel;

	@FindBy(how = How.XPATH, using = "//span[text()='Security question one']/../../following-sibling::div[1]/label/input")
	private WebElement answer1TextBox;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Security question one']/../../following-sibling::div[1]/label/input[contains(@class,'ng-not-empty')]")
	private WebElement answer1TextBoxmasked;

	@FindBy(how = How.XPATH, using = "//span[text()='Security question two']/../../following-sibling::div[1]/label/input")
	private WebElement answer2TextBox;

	@FindBy(how = How.XPATH, using = "//span[text()='Security question three']/../../following-sibling::div[1]/label/input")
	private WebElement answer3TextBox;
	
	@FindBy(how = How.ID, using = "phoneNo")
	private WebElement phoneNumberTextBox;

	@FindBy(how = How.ID, using = "remember")
	private WebElement rememberDeviceCheckBox;

	@FindBy(how = How.ID, using = "terms")
	private WebElement termsOfUseCheckBox;

	@FindBy(how = How.XPATH, using = "//button[contains(@class,'button') and contains(.,'Continue')]")
	private WebElement continueButton;

	@FindBy(how = How.XPATH, using = "//div[@class='ruletip']")
	private WebElement ruleTip;

	@FindBy(how = How.XPATH, using = "//p[@class='micro']")
	private WebElement Requiredfield;
	
	@FindBy(how = How.XPATH, using = "//h2[@class='delta ng-binding' and contains(.,'Create account')]")
	private WebElement CreateAccHeader;	
	
	@FindBy(how = How.ID, using = "secOption")
	private WebElement securityTypeDropdown;
	

	@FindBy(how = How.ID, using = "confirmPhoneno")
	private WebElement confirmPhoneno;
	
	@FindBy(how = How.ID, using = "code")
	private WebElement PhoneCode;
	
	
	@FindBy(how = How.XPATH, using = "//form/div/p[2]/a/i")
	private WebElement editlink;
	
	@FindBy(how = How.XPATH, using = "//a/span[contains(@ng-bind-html,'Save ')]")
	private WebElement saveLink;
	
	@FindBy(how = How.XPATH, using = "//div[@ng-bind-html='Phone']")
	private WebElement phoneNumberLabel;
	
	@FindBy(how = How.LINK_TEXT, using = "Texting Terms & Conditions")
	private WebElement textingTermsAndConditionsLink;

	@FindBy(how = How.LINK_TEXT, using = "Terms of Use")
	private WebElement termsOfUseLink;
	
	@FindBy(how = How.LINK_TEXT, using = "Privacy Policy")
	private WebElement privacyPolicyLink;
	
	@FindBy(how = How.LINK_TEXT, using = "Consumer Communications Notice")
	private WebElement consumerCommunicationsNoticeLink;
	
	@FindBy(how = How.XPATH, using = "//h3[1]/a[@class='milli edit-link ng-scope']")
	private WebElement credentialsEditLink;
	
	@FindBy(how = How.XPATH, using = "//h3[2]/a[@class='milli edit-link ng-scope']")
	private WebElement recoveryEditLink;
		
	@FindBy(how = How.XPATH, using = "//div[@class='ng-binding ng-scope']/*[contains(.,'We’re sorry. This username is not available. Please choose a different one, or use one of our suggestions.')]|//*[@class='error']/span[contains(.,'Username already exists')]|//p[@class='ng-scope']/*[contains(.,'We’re sorry. This username is not available. Please choose a different one, or use one of our suggestions.')]")
	private WebElement verifyExistingUsernameLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmPassword']/..//span[@ng-bind-html='errorsMsg.EMPasswordInvalid | trusted']")
	private WebElement invalidConfirmPasswordLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmPassword']/..//span[@ng-bind-html='clientConfirmPasswordError | trusted']")
	private WebElement specialConfirmPasswordLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmPassword']/..//span[@ng-bind-html='errorsMsg.EMPasswordsDontMatch | trusted']|//label[@for='confirmPassword']/span[@class='error']")
	private WebElement differentConfirmPasswordLabel;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Phone number is required')]|//*[@id='phoneNo']/..//p[@class='error mr20 ng-binding ng-scope']")
	private WebElement securityPhoneNumberLabel;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Phone type is required')]|//*[@id='phoneType']/..//p[@class='error ng-binding ng-scope']")
	private WebElement securityPhoneTypeLabel;
	
	@FindBy(how = How.XPATH, using = "//span[@ng-bind-html='errorsMsg.EMPhoneInvalid | trusted']")
	private WebElement invalidSecurityPhoneNumberLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='q1']/..//span[@class='ng-binding']|//*[@class='error']/span[contains(.,'Security question 1 is required')]")
	private WebElement question1Label; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='q2']/..//span[@class='ng-binding']|//*[@class='error']/span[contains(.,'Security question 2 is required')]")
	private WebElement question2Label; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='q3']/..//span[@class='ng-binding']|//*[@class='error']/span[contains(.,'Security question 3 is required')]")
	private WebElement question3Label; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='a1']/..//span[@ng-bind-html='answerErrors[0] | trusted']|//label[@for='a0']/span[@class='error']")
	private WebElement ans1; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='a2']/..//span[@ng-bind-html='answerErrors[1] | trusted']|//label[@for='a1']/span[@class='error']")
	private WebElement ans2; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='a3']/..//span[@ng-bind-html='answerErrors[2] | trusted']|//label[@for='a2']/span[@class='error']")
	private WebElement ans3; 
	
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'You must check the box indicating that you agree to the updated policies.')]|//span[@class='error']//span[@ng-bind-html='termsAndConditionsError']")
	private WebElement agreeTermsAndValidation; 
	
	@FindBy(how = How.XPATH, using = "//label[@for='username']/span[@class='error']")
	WebElement myUhcUsernameError;
	
	@FindBy(how = How.XPATH, using = "//p[@class='ng-scope']/*[contains(.,'We’re sorry. This username is not available. Please choose a different one, or use one of our suggestions.')]")
	private WebElement myUhcExistingUsernameMessage;
	
	@FindBy(how = How.XPATH, using = "//label[@for='password']/span[@class='error']")
	WebElement myUhcPasswordError; 
	
	@FindBy(how = How.XPATH, using = "//p[@class='ng-scope']//span[@class='ng-binding ng-scope']")
	WebElement whiteSectionError;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'mb30')]/p")
	private WebElement createYourHsidHeader;
		
	@FindBy(how = How.XPATH, using = "//label[@for='username']//div[contains(@class,'tooltip-content')]")
	private WebElement userNameTooltip;
	
	@FindBy(how = How.XPATH, using = "//label[@for='password']//div[contains(@class,'tooltip-content')]")
	private WebElement passwordTooltip;
	
	@FindBy(how = How.XPATH, using = "//label[@for='email']//*[contains(@ng-mouseover,'toolTipOn')]")
	private WebElement emailTooltipLink;
	
	@FindBy(how = How.XPATH, using = "//label[@for='email']//*[contains(@ng-mouseover,'toolTipOn')]/following-sibling::div/p")
	private WebElement emailTooltipContent;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'phone-disclaimer')]")
	private WebElement phoneMsg;

	@FindBy(how = How.XPATH, using = "//*[@id='username']/..//span[@class='ng-binding']")
	private WebElement userNameError;  
	
	@FindBy(how = How.XPATH, using = "//*[@id='password']/..//span[@class='ng-binding']")
	private WebElement passwordError;  
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmPassword']/..//span[@class='ng-binding']")
	private WebElement confirmPasswordError;
	
	@FindBy(how = How.XPATH, using = "//label[@for='username']/span[1]")
	private WebElement usernameLabel; 
	
	@FindBy(how = How.XPATH, using = "//label[@for='password']/span[1]")
	private WebElement passwordLabel;
	
	@FindBy(how = How.XPATH, using = "//label[@for='confirmPassword']/span[1]")
	private WebElement confirmPasswordLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='email']/..//span[@class='ng-binding']")
	private WebElement emailError; 
	
	@FindBy(how = How.XPATH, using = "//label[@for='email']/span[1]")
	private WebElement emailLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmEmail']/..//span[@class='ng-binding']")
	private WebElement confirmEmailError;
	
	@FindBy(how = How.XPATH, using = "//label[@for='confirmEmail']/span[1]")
	private WebElement confirmEmailLabel;
	
	@FindBy(how = How.XPATH, using = "//div[@id='securityOptions']//span[@class='error ng-binding ng-scope']|//span[@ng-bind-html='selectSecurityOptionError']")
	private WebElement securityDropdownError; 
	
	@FindBy(how = How.XPATH, using = "//div[@id='securityOptions']/preceding-sibling::*[1]")
	private WebElement securityDropdownLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@for='phoneNo']/span")
	private WebElement phoneNoLabel;

	@FindBy(how = How.XPATH, using = "//button[contains(.,'Create my ID')]")
	private WebElement createMyIDButton;
	
	@FindBy(how = How.XPATH, using = "//a[contains(.,'Go to myhealthcareview.com now')]")
	private WebElement goToMyHealthcareViewLink;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'mb30')]")
	private WebElement upgradeToHsidHeader;
	
	@FindBy(how = How.XPATH, using = "//*[contains(@class,'modal__dialog')]//*[contains(@class,'modal__content')]")
	private WebElement HealthSafeIDTMPopUpWindow;
	
	@FindBy(how = How.XPATH, using = "//*[contains(@class,'modal__dialog')]//*[@class='icon-close']")
	private WebElement CloseICONinPopUp;
	
	
	public void savelinkClick(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(saveLink));
		saveLink.click();
	}
	
	
	public void editlinkClick(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(editlink));
		editlink.click();
	}
	
	public void enterConfirmPhoneNumber(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPhoneno));
		confirmPhoneno.clear();
		confirmPhoneno.sendKeys(password);
	}
	
	public void enterCode(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(PhoneCode));
		PhoneCode.clear();
		PhoneCode.sendKeys(password);
	}
	
	public boolean verifyConfirmphoneNo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPhoneno)).isDisplayed();
	}
	
	public boolean verifyRequiredField(String message) {
		return Requiredfield.getText().contains(message);
	}
	
	public boolean verifyCreateHeader() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(CreateAccHeader));
		return CreateAccHeader.isDisplayed();
	}
	
	
	public boolean verifyRuleTip(String message) {
		return ruleTip.getText().contains(message);
	}

	@FindBy(how = How.ID, using = "errorsBoxCredentials")
	private WebElement errorMessageBox;

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOf(createAccountSection)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean verifyIfRecoverySectionDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(recoverySection)).isDisplayed();
	}
	
	public boolean verifyRecoverySectionlabel(String label) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(recoverySection));
		return recoverySection.getText().contains(label);
	}
	
	public boolean verifyIfUserNameFieldisEmpty() {
		return userNameTextBox.getAttribute("class").contains("ng-empty");
	}
	
	public boolean verifyIfPasswordFieldisEmpty() {
		return passwordTextBox.getAttribute("class").contains("ng-empty");
	}
	
	public boolean verifyIfReEnterPasswordFieldisEmpty() {
		return confirmPasswordTextBox.getAttribute("class").contains("ng-empty");				
	}
	
	public boolean verifyIfEmailFieldisEmpty() {
		return emailTextBox.getAttribute("class").contains("ng-empty");
	}
	
	public boolean verifyIfReEnterEmailFieldisEmpty() {
		return confirmEmailTextBox.getAttribute("class").contains("ng-empty");
	}

	public void enterUserName(String userName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
		userNameTextBox.clear();
		userNameTextBox.sendKeys(userName);
	}

	public void updateEmail(String text) {
		updateEmail.clear();
		updateEmail.sendKeys(text);
	}

	public void enterPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
		passwordTextBox.clear();
		passwordTextBox.sendKeys(password);
	}

	public void enterConfirmPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordTextBox));
		confirmPasswordTextBox.clear();
		confirmPasswordTextBox.sendKeys(password);
	}

	public void enterEmail(String email) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(emailTextBox));
		emailTextBox.clear();
		emailTextBox.sendKeys(email);
	}
	

	public void confirmEmail(String email) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailTextBox));
		confirmEmailTextBox.clear();
		confirmEmailTextBox.sendKeys(email);
	}

	public void clickContinueButton() {
		longWait.get().until(ExpectedConditions.visibilityOf(continueButton));
		continueButton.click();

	}
	
	public void selectSecurityType(String securityType) {
		mediumWait.get().until(
				ExpectedConditions.textToBePresentInElement(securityTypeDropdown, securityType));
		Select dropdown = new Select(securityTypeDropdown);
		dropdown.selectByVisibleText(securityType);
	}

	public void selectSecurityQuestion1(String questionName) {		 
		mediumWait.get().until(
				ExpectedConditions.textToBePresentInElement(securityQuestion1Select, questionName));
		Select dropdown = new Select(securityQuestion1Select);
		dropdown.selectByVisibleText(questionName);
		
	}
	
	public void selectSecurityQuestion2(String questionName) {
		mediumWait.get().until(
				ExpectedConditions.textToBePresentInElement(securityQuestion2Select, questionName));
		Select dropdown = new Select(securityQuestion2Select);
		dropdown.selectByVisibleText(questionName);
		
	}

	public void selectSecurityQuestion3(String questionName) {
		mediumWait.get().until(
				ExpectedConditions.textToBePresentInElement(securityQuestion3Select, questionName));
		Select dropdown = new Select(securityQuestion3Select);
		dropdown.selectByVisibleText(questionName);
		
	}

	public void selectPhoneType(String phoneType) {
		Select dropdown = new Select(mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id("phoneType"))));
		dropdown.selectByVisibleText(phoneType);
	}

	public void clickConfirmYourPhoneNumberWithRadioButton(String optionName) {
		mediumWait.get().until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//div[@class='radio' and contains(.,'" + optionName + "')]/input")))
				.click();

	}

	public void enterSecurityAnswer1(String securityAnswer) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(answer1TextBox));
		answer1TextBox.clear();
		answer1TextBox.sendKeys(securityAnswer);
	}

	public void enterSecurityAnswer2(String securityAnswer) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(answer2TextBox));
		answer2TextBox.clear();
		answer2TextBox.sendKeys(securityAnswer);
	}

	public void enterSecurityAnswer3(String securityAnswer) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(answer3TextBox));
		answer3TextBox.clear();
		answer3TextBox.sendKeys(securityAnswer);
	}

	public void enterPhoneNumber(String phoneNumber) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(phoneNumberTextBox));
		phoneNumberTextBox.clear();
		phoneNumberTextBox.sendKeys(phoneNumber);
	}

	public boolean verifyForRememberThisDeviceCheckBox() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(rememberDeviceCheckBox)).isDisplayed();
	}

	public void clickRememberThisDeviceCheckBox() {
		longWait.get().until(ExpectedConditions.visibilityOf(rememberDeviceCheckBox));
		rememberDeviceCheckBox.click();
	}

	public void clicktermsOfUseCheckBox() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(termsOfUseCheckBox));
		termsOfUseCheckBox.click();
	}

	public boolean verifyIfErrorMessageDisplayed() {
		smallWait.get().until(ExpectedConditions.visibilityOf(errorMessageBox));
		return errorMessageBox.isDisplayed();
	}

	public boolean verifyFormHeader(String headerName) {
		smallWait.get().until(ExpectedConditions.visibilityOf(formHeader));
		return formHeader.getText().equals(headerName);
	}

	public String returnErrorMessage() {
		smallWait.get().until(ExpectedConditions.visibilityOf(errorMessageBox));
		return errorMessageBox.getText();
	}

	public boolean verifyErrorMessageOnUserName(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='username']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnConfirmPhoneNumber(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'ng-binding') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnCode(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'ng-binding') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnConfirmationOption(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'ng-binding') and contains(.,'" + message + "')]")))
				.isDisplayed();
	}

	public boolean verifyErrorMessageInErrorBox(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(errorMessageBox));
		return errorMessageBox.getText().contains(message);
	}

	public boolean verifyIfUsernameLabelExistWithTextbox() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(userNameLabelWithTextBox)).isDisplayed();

	}
	
	public WebElement getPhoneNumberLabel() {
		return phoneNumberLabel;
	}
	
	public WebElement getTextingTermsAndConditionsLink() {
		return textingTermsAndConditionsLink;
	}
	
	public WebElement getTermsOfUseLink() {
		return termsOfUseLink;
	}
	
	public WebElement getPrivacyPolicyLink() {
		return privacyPolicyLink;
	}
	
	public WebElement getConsumerCommunicationsNoticeLink() {
		return consumerCommunicationsNoticeLink;
	}
	
	public void clickCredentialsEditLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(credentialsEditLink));
		credentialsEditLink.click();
	}
	
	public void clickRecoveryEditLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(recoveryEditLink));
		recoveryEditLink.click();
	}
	
	
	public boolean verifyExistingUsernameLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(verifyExistingUsernameLabel)).getText().contains(message);
	}

	public boolean verifyusernameLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(userNameError)).getText().contains(message);
	}

	public boolean verifyPasswordLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordError)).getText().contains(message);
	}

	public boolean verifyConfirmpasswordLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordError)).getText().contains(message);
	}

	public boolean verifyEmailLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(emailError)).getText().contains(message);
	}

	public boolean verifyConfirmEmailLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailError)).getText().contains(message);
	}

	public boolean verifyinvalidConfirmpasswordLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(invalidConfirmPasswordLabel)).getText().contains(message);
	}

	public boolean verifyspecialConfirmpasswordLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(specialConfirmPasswordLabel)).getText().contains(message);
	}

	public boolean verifyDifferentConfirmpasswordLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(differentConfirmPasswordLabel)).getText().contains(message);
	}
	
	public String getSecurityDropdownError() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(securityDropdownError)).getText().trim();
	}
	
	public boolean verifySecurityPhoneNumberLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(securityPhoneNumberLabel)).getText().contains(message);
	} 
	
	public boolean verifySecurityPhoneTypeLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(securityPhoneTypeLabel)).getText().contains(message);
	}
	
	public boolean verifyInvalidSecurityPhoneNumberLabel(String message) {
		return longWait.get().until(ExpectedConditions.visibilityOf(invalidSecurityPhoneNumberLabel)).getText().contains(message);
	}

	public boolean verifyquestion1(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(question1Label)).getText().contains(message);
	}
	
	public boolean verifyquestion2(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(question2Label)).getText().contains(message);
	}
	
	public boolean verifyquestion3(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(question3Label)).getText().contains(message);
	}

	public boolean verifyAnswer1(String message) {
		return longWait.get().until(ExpectedConditions.visibilityOf(ans1)).getText().contains(message);
	}
	
	public boolean verifyAnswer2(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(ans2)).getText().contains(message);
	}
	
	public boolean verifyAnswer3(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(ans3)).getText().contains(message);
	}

	public boolean verifyAgreeTermsOfValidations(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(agreeTermsAndValidation)).getText().contains(message);
	}

	public String getUsernameErrorText() {
		smallWait.get().until(ExpectedConditions.visibilityOf(myUhcUsernameError));
        return myUhcUsernameError.getText();
    }
	
	public boolean verifyMyUhcExistingUsernameMessage(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(myUhcExistingUsernameMessage)).getText().contains(message);
	}

	public String getPasswordErrorText() {
		smallWait.get().until(ExpectedConditions.visibilityOf(myUhcPasswordError));
        return myUhcPasswordError.getText();
    }
	

	public Object getWhiteSectionErrorText() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(whiteSectionError));
        return whiteSectionError.getText();
	}


	public boolean verifyCreateHsidHeaderContent(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(createYourHsidHeader)).getText().contains(message);
	}
	
	public boolean verifyUpgradeToHsidHeaderContent(String content) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(upgradeToHsidHeader)).getText().contains(content);
	}


	public String getPhoneMsg() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneMsg)).getText();
	}


	public void mouseHoverOnEmailIdToolTip() {
		mouseHoverOnElement(mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='tooltip']/*[contains(.,'Why we need your email')]/a"))));
		
	}


	public boolean validateEmailToolTipMessage(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[@class='tooltip']/*[contains(.,'"+message + "')]"))).isDisplayed();

	}



	
	public boolean verifyTooltipContent(String tooltipType, String pgContent) {
		if(tooltipType.equalsIgnoreCase("username")){
			String usernameTooltipContent = mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTooltip)).getText();
			return usernameTooltipContent.contains(pgContent);
		}
		else if(tooltipType.equalsIgnoreCase("password")){
			String passwordTooltipContent = mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTooltip)).getText();
			return passwordTooltipContent.contains(pgContent);
		}
		else if(tooltipType.equalsIgnoreCase("email")){
			String actualEmailTooltipContent = mediumWait.get().until(ExpectedConditions.visibilityOf(emailTooltipContent)).getText();
			//System.out.println("Actual:" + actualEmailTooltipContent);
			return actualEmailTooltipContent.contains(pgContent);
		}
		else
			return false;
		}
	
	public boolean verifySecurityOptionLabel(String message){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(securityDropdownLabel)).getText().contains(message);
		
	}
	
	public WebElement getUsernameLabel(){
		return usernameLabel;
	}
	
	public WebElement getPasswordLabel(){
		return passwordLabel;
	}
	
	public WebElement getConfirmPasswordLabel(){
		return confirmPasswordLabel;
	}
	
	public WebElement getEmailLabel(){
		return emailLabel;
	}
	
	public WebElement getConfirmEmailLabel(){
		return confirmEmailLabel;
	}
	
	public WebElement getSecurityDropdownLabel(){
		return securityDropdownLabel;
	}
	
	public String verifyLabels(String field){
		switch(field) {
		case "username": if(userNameTextBox.isDisplayed()) return  mediumWait.get().until(ExpectedConditions.visibilityOf(usernameLabel)).getText();
		case "password": if(passwordTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordLabel)).getText();
		case "confirmpassword": if(confirmPasswordTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordLabel)).getText();
		case "email": if(emailTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(emailLabel)).getText();
		case "confirmemail": if(confirmEmailTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailLabel)).getText();
		case "securityoption": if(securityTypeDropdown.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityDropdownLabel)).getText();
		case "securityquestion1": if(mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion1TextBox)).isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion1Label)).getText();
		case "securityquestion2": if(securityQuestion2TextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion2Label)).getText();
		case "securityquestion3": if(securityQuestion3TextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion3Label)).getText();
		case "securityanswer1": if(answer1TextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer1Label)).getText();
		case "securityanswer2": if(answer2TextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer2Label)).getText();
		case "securityanswer3": if(answer3TextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer3Label)).getText();
		case "phonenumber":  if(phoneNumberTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneNoLabel)).getText();
		case "remember":  if(rememberDeviceCheckBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(rememberMeLabel)).getText();
		case "termsofuse": if(termsOfUseCheckBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(termsOfUseLabel)).getText();
		case "phonedisclaimer":return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneDisclaimerLabel)).getText();
		default: return "Either field or label not present.";
		}
	}
	
	public boolean verifyCreateMyIDButtonPresent(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(createMyIDButton)).isDisplayed();
	}
	
	/* public void clickCreateMyIDButton(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(createMyIDButton));
		createMyIDButton.click();
	}	*/
	
	public String verifyUsernameAutoPopulated() {
		try {
			mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
			String elementval = userNameTextBox.getAttribute("value");

			return elementval;
		} catch (Exception e) {
			return null;
		}
	}
	
	public String getHealthSafeIdPopUpWindowContent() {
		String HealthSafeIdPopUpWindowContent = mediumWait.get().until(ExpectedConditions.visibilityOf(HealthSafeIDTMPopUpWindow)).getText();
		return HealthSafeIdPopUpWindowContent;
	}
	
	public void CloseICONinPopUPClick(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(CloseICONinPopUp)).click();
	}
	
	public boolean VerifySecurityAnswerismaskedandeditable() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(answer1TextBoxmasked));
		return answer1TextBoxmasked.getAttribute("class").contains("ng-not-empty");
	}
}
