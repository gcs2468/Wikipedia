package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readXMLdata;

public class RxUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Welcome to OptumRx')]")
	private WebElement WelcometoOptumRx;
	
	@FindBy(how = How.XPATH, using = "//a[@class='btn btn--primary regBtn']")
	private WebElement signinLink;
	
	@FindBy(how = How.XPATH, using = "//a[@class='btn btn--secondary'][contains(.,'Register')]")
	private WebElement registerLink;

	
	public void openRXHomePage() {
		String page_url=readXMLdata.getTestData(dataStorage.getPortalName(), "AppURL");
		openPage(page_url);
	}
    
	public WebElement getOptumRxUnauthenticatedPageelement() {
		return longWait.get().until(ExpectedConditions.visibilityOf((WelcometoOptumRx)));
	}
	
	public void clickSigninLink() {
		longWait.get().until(ExpectedConditions.elementToBeClickable(signinLink)).click();
	}
	
	public void clickRegisterLink() {
		longWait.get().until(ExpectedConditions.elementToBeClickable(registerLink)).click();
	}
	
}

