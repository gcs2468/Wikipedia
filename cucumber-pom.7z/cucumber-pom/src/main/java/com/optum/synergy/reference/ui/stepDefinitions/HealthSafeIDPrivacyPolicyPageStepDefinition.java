package com.optum.synergy.reference.ui.stepDefinitions;

 import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.HealthSafeIDPrivacyPolicyPage;

import cucumber.api.java.en.Then;

public class HealthSafeIDPrivacyPolicyPageStepDefinition {
	
	private HealthSafeIDPrivacyPolicyPage page;
    public HealthSafeIDPrivacyPolicyPageStepDefinition() {
        page = new HealthSafeIDPrivacyPolicyPage();
    }
    
    @Then("^I should be at HealthSafe ID Privacy Policy page$")
    public void iShouldBeAtHealthSafeIDPrivacyPolicyPage() throws Throwable {
    	   Assert.assertTrue("Failed to load HSID Privacy Policy Page", page.verifyIfPageLoaded());
    }
}
