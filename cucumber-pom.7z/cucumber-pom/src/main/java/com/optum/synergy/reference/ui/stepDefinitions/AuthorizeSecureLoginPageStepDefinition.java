package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.AuthorizeSecureLoginPage;
import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readEmail;

import cucumber.api.java.en.Given;

public class AuthorizeSecureLoginPageStepDefinition {
	private AuthorizeSecureLoginPage page;

	public AuthorizeSecureLoginPageStepDefinition() {
		page = new AuthorizeSecureLoginPage();
	}

	@Given("^I manage the Authorize Secure Login page with Access code$")
	public void iManageTheAuthorizeSecureLoginPageWithAccessCode() throws Throwable {
		if (page.verifyAuthorizeSecurityPageLoaded()) {
			page.switchToFrameByNameOrId(page.getSecureLoginFrameID());
			page.clickAlternateEmailButton();
			String secureCode = readEmail.getAccesscodeForLegacyID(dataStorage.getUserName());
			if (secureCode != null) {
				page.enterSecureCodeInput(secureCode);
				page.clickAuthSubmitButton();
			} else
				System.out.println("Secure code not received in 30 seconds.");
		}
	}
}
