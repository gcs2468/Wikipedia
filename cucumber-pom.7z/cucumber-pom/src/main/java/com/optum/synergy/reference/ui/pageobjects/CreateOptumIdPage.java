package com.optum.synergy.reference.ui.pageobjects;

import java.text.DateFormatSymbols;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readXMLdata;

import cucumber.api.PendingException;

public class CreateOptumIdPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[@aria-label='Create an Optum ID']")
	private WebElement createOptumIdPage;
	
	@FindBy(how = How.ID, using = "firstNameId_input")
	private WebElement firstNameTextBox;
	
	@FindBy(how = How.ID, using = "lastNameId_input")
	private WebElement lastNameTextBox;

	@FindBy(how = How.ID, using = "dob_id_dob")
	private WebElement dateOfBirthTextBox;
	
	@FindBy(how = How.ID, using = "pwdId_input")
	private WebElement passwordTextBox;

	@FindBy(how = How.ID, using = "confirmPwdId_input")
	private WebElement confirmPasswordTextBox;

	@FindBy(how = How.ID, using = "emailAddressId_input")
	private WebElement emailTextBox;
	
	@FindBy(how = How.ID, using = "userNameId_input")
	private WebElement userNameTextBox;

	@FindBy(how = How.XPATH, using = "//*[@id='agreeButtonId']")
	private WebElement clickButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='sharedEmailContinueButtonId']")
	private WebElement SharedEmailPopUpContinueButton;
	
	@FindBy(how = How.XPATH, using = "//*[@class='registration section']")
	private WebElement registerationPage;
	
	@FindBy(how = How.XPATH, using = "//input[starts-with(@id,'memberId')]")
	private WebElement memberIdTextBox;
	
	@FindBy(how = How.XPATH, using = "//*[@id='bdayMonth']")
	private WebElement selectMonthDropdown;
	
	@FindBy(how = How.XPATH, using = "//*[@id='bdayDay']")
	private WebElement selectDayDropdown;
	
	@FindBy(how = How.XPATH, using = "//*[@id='bdayYear']")
	private WebElement selectYearDropdown;
	
	@FindBy(how = How.XPATH, using = "//*[@id='address1']")
	private WebElement addressLineTextBox;
	
	@FindBy(how = How.XPATH, using = "//*[@id='city']")
	private WebElement cityTextBox;
	
	@FindBy(how = How.XPATH, using = "//*[@id='state']")
	private WebElement stateDropdown;
	
	@FindBy(how = How.XPATH, using = "//*[@id='zipCode']")
	private WebElement zipCodeTextBox;
	
	@FindBy(how = How.XPATH, using = "//*[@id='phone1']")
	private WebElement phone1TextBox;
	
	@FindBy(how = How.XPATH, using = "//*[@data-ng-model='phone2']")
	private WebElement phone2TextBox;
	
	@FindBy(how = How.XPATH, using = "//*[@name='phone3']")
	private WebElement phone3TextBox;
	
	@FindBy(how = How.XPATH, using = "//*[@class='field-block']//input[@id='iagree']")
	private WebElement agreeCheckbox;
	
	@FindBy(how = How.XPATH, using = "//*[@class='btn-group']/button")
	private WebElement submitButton;
	
	public void createOptumIdNoAuth(String firstName,String lastName, String dateOfBirth, String userName, 
			String email, String password, String memberId, String gender, String addressLine, String city, 
			String state, String zipCode, String phone) {
		
		openOptumIdHomePage();
		verifyOptumIdCreatePage();
		enterFirstName(firstName);
		enterLastName(lastName);
		enterDateOfBirth(dateOfBirth);
		enterUserName(userName);
		enterEmail(email);
		enterPassword(password);
		enterConfirmPassword(password);
		clickOnIAgreeButton();
		verifyOptumIdRegisterationPage();
		enterMemberID(memberId);
		selectGender(gender);
		selectDOB(dateOfBirth);
		enterAddressLine(addressLine);
		enterCity(city);
		selectState(state);
		enterZipCode(zipCode);
		enterPhoneNumber(phone); 
		clickOnIAgreeCheckbox();
		clickOnSubmitButton();
		
	}
	
	public void createOptumIdSqaAuth(String firstName,String lastName, String dateOfBirth, String userName, 
			String email, String password, String memberId, String gender, String addressLine, String city, 
			String state, String zipCode, String phone) {
		//TODO Fill in steps
		throw new PendingException();
	}
	
	public void createOptumIdPhoneAuth(String firstName,String lastName, String dateOfBirth, String userName, 
			String email, String password, String memberId, String gender, String addressLine, String city, 
			String state, String zipCode, String phone) {
		//TODO Fill in steps
		throw new PendingException();
	}
	
	public void openOptumIdHomePage() {
		String page_url=readXMLdata.getTestData(dataStorage.getPortalName(), "OptumIdURL");
		openPage(page_url);
	}
	
	public boolean verifyOptumIdCreatePage() {
		return longWait.get().until(ExpectedConditions.visibilityOf(createOptumIdPage)).isDisplayed();

	}
	
	public void verifyOptumIdRegisterationPage() {
		 WebDriverWait waitForElement = new WebDriverWait(driver, 120);
		 waitForElement.until(ExpectedConditions.elementToBeClickable(registerationPage));
	}
	
	public void enterFirstName(String firstName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(firstNameTextBox));
		firstNameTextBox.clear();
		firstNameTextBox.sendKeys(firstName);
	}
	
	public void enterMemberID(String memberId) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdTextBox));
		memberIdTextBox.clear();
		memberIdTextBox.sendKeys(memberId);
	}

	public void enterLastName(String lastName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(lastNameTextBox));
		lastNameTextBox.clear();
		lastNameTextBox.sendKeys(lastName);
	}

	public void enterDateOfBirth(String dateOfBirth) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthTextBox));
		dateOfBirthTextBox.clear();
		dateOfBirthTextBox.sendKeys(Keys.BACK_SPACE);
		dateOfBirthTextBox.sendKeys(dateOfBirth.replace("/", "-"));
	}
	
	public void enterEmail(String email) {
		String emailId=email.replace("+", "");
		mediumWait.get().until(ExpectedConditions.visibilityOf(emailTextBox));
		emailTextBox.clear();
		emailTextBox.sendKeys(emailId);
	}
	
	public void enterPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
		passwordTextBox.clear();
		passwordTextBox.sendKeys(password);
	}

	public void enterConfirmPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordTextBox));
		confirmPasswordTextBox.clear();
		confirmPasswordTextBox.sendKeys(password);
	}
	
	public void enterUserName(String userName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
		userNameTextBox.clear();
		userNameTextBox.sendKeys(userName);
	}
	
	public void clickOnIAgreeButton() {
		WebElement elem = mediumWait.get().until(ExpectedConditions.visibilityOf(clickButton));
		scrollElementIntoView(elem);
		elem.click();
	}
	
	public void selectGender(String gender) {
		mediumWait.get().until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='fieldset--align-controls radios']//*[contains(.,'" + gender + "')]/label"))).click();	
	}
	
	public void selectDOB(String dateOfBirth) {
		String[] date=dateOfBirth.split("/");
		Object monthString = new DateFormatSymbols().getMonths()[Integer.parseInt(date[0])-1];
		
		//Select Month
		WebElement element= mediumWait.get().until(ExpectedConditions.visibilityOf(selectMonthDropdown));
		Select se=new Select(element);
		se.selectByVisibleText(monthString.toString());
		
		//Select day
		 element= mediumWait.get().until(ExpectedConditions.visibilityOf(selectDayDropdown));
		se=new Select(element);
		se.selectByVisibleText(date[1]);
		
		//Select Year
		element= mediumWait.get().until(ExpectedConditions.visibilityOf(selectYearDropdown));
		se=new Select(element);
		se.selectByVisibleText(date[2]);
	}
	
	public void enterAddressLine(String addressLine) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(addressLineTextBox));
		addressLineTextBox.clear();
		addressLineTextBox.sendKeys(addressLine);
		
	}
	
	public void enterCity(String city) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(cityTextBox));
		cityTextBox.clear();
		cityTextBox.sendKeys(city);
	}
	
	public void selectState(String state) {
		WebElement element1= mediumWait.get().until(ExpectedConditions.visibilityOf(stateDropdown));
		Select select=new Select(element1);
		select.selectByVisibleText(state);
		}
	public void enterZipCode(String zipCode) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(zipCodeTextBox));
		zipCodeTextBox.clear();
		zipCodeTextBox.sendKeys(zipCode);
	}
	
	public void enterPhoneNumber(String phone) {
		String[] phoneNumber= phone.split("-");
		mediumWait.get().until(ExpectedConditions.visibilityOf(phone1TextBox));
		phone1TextBox.clear();
		phone1TextBox.sendKeys(phoneNumber[0]);
		
		//phone Number2
		mediumWait.get().until(ExpectedConditions.visibilityOf(phone2TextBox));
		phone2TextBox.clear();
		phone2TextBox.sendKeys(phoneNumber[1]);
		
		//phone Number 3
		mediumWait.get().until(ExpectedConditions.visibilityOf(phone3TextBox));
		phone3TextBox.clear();
		phone3TextBox.sendKeys(phoneNumber[2]);
	}
	
	public void clickOnIAgreeCheckbox() {
		WebElement elem = mediumWait.get().until(ExpectedConditions.visibilityOf(agreeCheckbox));
		scrollElementIntoView(elem);
		elem.click();
	}
	
	public void clickOnSubmitButton() {
		WebElement elem = mediumWait.get().until(ExpectedConditions.visibilityOf(submitButton));
		scrollElementIntoView(elem);
		elem.click();
	}
	
}