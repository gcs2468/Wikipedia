package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.pageobjects.MailInatorEmailPage;
import com.optum.synergy.reference.ui.pageobjects.MailInator_HomePage;
import com.optum.synergy.reference.ui.pageobjects.MailInator_InboxPage;
import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MailInatorEmailPageStepDefinition {

	private MailInatorEmailPage page;

	public MailInatorEmailPageStepDefinition() {
		page = new MailInatorEmailPage();
	}

	@Given("^I am at mailinator email page with url \"([^\"]*)\"$")
	public void i_am_at_mailinator_email_page_with_url(String mailInatorUrl) throws Throwable {
		//Assert.assertTrue();
		page.openMailInatorPage(mailInatorUrl);
	}

	@Then("^I open mailinator email with url \"([^\"]*)\" in new tab$")
	public void i_open_mailinator_email_with_url_in_new_tab(String mailInatorUrl) throws Throwable {
		//Assert.assertTrue();
		
	    Assert.assertTrue(page.openMailInatorPageInNewTab(mailInatorUrl));
	}

	@Then("^I set valid \"([^\"]*)\" email$")
	public void i_set_valid_email_in_field(String email) throws Throwable {
		Thread.sleep(3000);
		String[] emailElems=email.split("@");
	    Assert.assertTrue(page.setEmail(emailElems[0]));
	    Thread.sleep(3000);
	}
	
	@Then("^I click on a mail contains \"([^\"]*)\"$")
	public void i_click_on_a_contains(String mailText) throws Throwable {
		
	    Assert.assertTrue(page.clickOnAMailRow(mailText));
	}
	
	@Then("^I click on email confirmation link \"([^\"]*)\"$")
	public void i_click_on_email_confirmation_link(String link) throws Throwable {
		
	    Assert.assertTrue(page.clickOnEmailLink(link));
	    Thread.sleep(3000);
	    Thread.sleep(3000);
	}

	@Then("^I should see a page with \"([^\"]*)\" section in new tab along with \"([^\"]*)\" message$")
	public void i_should_see_a_page_with_section_in_new_tab_along_with_message(String loginSectionId, String message) throws Throwable {
	    
		Assert.assertTrue(page.verifyIfLoginSectionAndThankYouMessageAppearedInNewTab(message));
	    
	}
	
	@Then("^I should see a page with \"([^\"]*)\" section in new tab along with the \"([^\"]*)\" message$")
	public void i_should_see_a_page_with_section_in_new_tab_along_with_the_message(String loginSectionId, String message) throws Throwable {
	    
		Assert.assertTrue(page.verifyIfLoginSectionAndThankYouMessageAppearedInNewTabAndContinue(message));
	    
	}

	@Then("^I should get an email says \"([^\"]*)\"$")
	public void i_should_get_an_email_says(String text) throws Throwable {
		Thread.sleep(3000);
		Assert.assertTrue(page.verifyForAnEmailWithText(text));
	}
	
/*	@Given("^I should see a mail content \"([^\"]*)\"$")
	public void i_should_see_a_mail_content(String mailContent) throws Throwable {
		//Assert.assertTrue(page.VerifyEmailBodyContent(mailContent));
	   
	}*/

/*	@Given("^I should see the following mail content$")
	public void i_should_see_the_following_mail_content(List<String> contents) throws Throwable {
		page.switchToMailContentInFrame();
		Thread.sleep(4000);
		for(String content:contents)
		{
			Assert.assertTrue(page.verifyForContent(content));
		}
		page.switchToMailDefaultContent();
	   }*/
/*	@Given("^I should see an email link \"([^\"]*)\"$")
	public void i_should_see_am_emial_link(String link) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertTrue(link+" doesn't exist in the email body",page.VerifyEmailLink(link));

	}*/
/*	@Then("^I should see the mail is from \"([^\"]*)\"$")
	public void i_should_see_the_mail_is_from(String text) throws Throwable {
		Assert.assertTrue(page.verifyTheEmailMetaDataContents("From", text));
	}

	@Then("^I should see the mail subject as \"([^\"]*)\"$")
	public void i_should_see_the_mail_subject_as(String text) throws Throwable {
		Assert.assertTrue(page.verifyTheEmailMetaDataContents("Subject", text));
	}*/
/*
	@Then("^I should see a mail content has link \"([^\"]*)\"$")
	public void i_should_see_a_mail_content_has_link(String arg1) throws Throwable {
	    
	}

	@Then("^I should see a mail content has username \"([^\"]*)\"$")
	public void i_should_see_a_mail_content_has_username(String arg1) throws Throwable {
	    
	}*/
	@When("^I click on request new confirmation link \"([^\"]*)\"$")
	public void i_click_on_request_new_confirmation_link(String link) throws Throwable {
		 Assert.assertTrue(page.clickOnEmailLink(link));
	}
	@Given("^I click on email \"([^\"]*)\" link$")
	public void i_click_on_email_link(String link) throws Throwable {
		 Assert.assertTrue(page.clickOnEmailLink(link));
	}
	
	@Then("^I should get a registration completed email to the mail \"([^\"]*)\"$")
	public void i_should_get_a_registration_completed_email_to_the_mail(String arg1) throws Throwable {
		MailInator_InboxPage mailInbox = new MailInator_InboxPage();
		try {
			page.refreshPage();
			mailInbox.verifyIfPageLoaded();
		} catch (Exception e) {
			List<WebElement> elems = PageObjectBase.mediumWait.get()
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("a")));
			for (WebElement elem : elems) {
				if (elem.getAttribute("href").contains("https://www.mailinator.com")) {
					elem.click();
				}
				break;
			}
		}
		mailInbox.verifyForRegistrationCompletedMail();
	}
	
	@Given("^I should get a registration confirmation email to the mail \"([^\"]*)\"$")
	public void i_should_get_a_registration_confirmation_email_to_the_mail(String email) throws Throwable {

		MailInator_HomePage mailHomePage = new MailInator_HomePage();
		Assert.assertTrue(mailHomePage.verifyIfPageLoaded());
	
		String[] emailElems = email.split("@");
		mailHomePage.enterEmail(emailElems[0]);
		mailHomePage.clickGoButton();
		MailInator_InboxPage mailInbox = new MailInator_InboxPage();
		mailInbox.verifyForConfirmEmailAddressMail();
		// mailInbox.clickOnConfirmEmailAddressMail();
	}
	
}
