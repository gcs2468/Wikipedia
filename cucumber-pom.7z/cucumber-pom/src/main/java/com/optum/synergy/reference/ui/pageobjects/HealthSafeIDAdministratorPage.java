package com.optum.synergy.reference.ui.pageobjects;

import java.io.IOException;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HealthSafeIDAdministratorPage extends PageObjectBase {

	@FindBy(how = How.ID, using = "searchTextBox")
	private WebElement searchTextBox;

	@FindBy(how = How.ID, using = "userNameRadioBtn")
	private WebElement Username_UUID_or_Email_address;
	
	@FindBy(how = How.ID, using = "searchButton")
	private WebElement searchButton;	

	@FindBy(how = How.XPATH, using = "//form[@class='ng-pristine ng-valid']")
	private WebElement searchForm;
	
	@FindBy(how = How.ID, using = "uuidValue")
	private WebElement uuidValue;

	public void openPage() throws IOException
	{
		openPage(getEnvVariable("HSIDAdminDetails.pageUrl"));
	}
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(searchForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void click_Username_UUID_or_Email_address_radio_Button() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(Username_UUID_or_Email_address));
		Username_UUID_or_Email_address.click();
	}

	public void enterValueIntoSearchBox(String searchValue) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(searchTextBox));
		searchTextBox.sendKeys(searchValue);
	}
	
	public void clickSearchButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(searchButton));
		searchButton.click();
	}
	
	public String getUUID() {
		new Hooks().setUUID(mediumWait.get().until(ExpectedConditions.visibilityOf(uuidValue)).getText());
		return mediumWait.get().until(ExpectedConditions.visibilityOf(uuidValue)).getText();
		
	}
}
