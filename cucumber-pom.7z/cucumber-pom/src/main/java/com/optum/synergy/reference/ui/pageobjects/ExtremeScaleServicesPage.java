package com.optum.synergy.reference.ui.pageobjects;

import java.io.IOException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.MediaType;

import org.json.JSONObject;
import org.junit.Assert;

import com.optum.synergy.reference.ui.utility.dataStorage;
import com.optum.synergy.reference.ui.utility.readXMLdata;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class ExtremeScaleServicesPage extends PageObjectBase {

	private Client client;

	public void initiateClient() {
		client = Client.create();
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} };

		// Install the all-trusting trust manager
		try {
//			SSLContext sc = SSLContext.getInstance("TLS");
			SSLContext sc = SSLContext.getInstance("TLSv1.2");
			sc.init(null, trustAllCerts, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
			;
		}
	}

	public String getAccessTokenUsingClientTokenService() throws IOException {
//		initiateClient();
//		WebResource webResource_clientToken = client.resource(getEnvVariable("Layer7Services.endPoint"));
//		String clientId = getEnvVariable("Layer7Services.getAuthTokenService.Headers.client_id");
//		String grantType = getEnvVariable("Layer7Services.getAuthTokenService.Headers.grant_type");
//		String clientSecrete = getEnvVariable("Layer7Services.getAuthTokenService.Headers.client_secret");
//
//		String path = getEnvVariable("Layer7Services.getAuthTokenService.path");
//		System.out.println(clientId + "    " + grantType + "    " + clientSecrete);
//		String data = "grant_type=" + grantType + "&client_id=" + clientId + "&client_secret=" + clientSecrete;
//		ClientResponse response_clientToken = webResource_clientToken.path(path)
//				.type("application/x-www-form-urlencoded").accept("application/json").post(ClientResponse.class, data);
//		System.out.println(webResource_clientToken.getProperties());
//		int status_clientToken = response_clientToken.getStatus();
//		Assert.assertEquals(status_clientToken+" is not the expected status",200,status_clientToken);
//		String output_clientToken = response_clientToken.getEntity(String.class);
//		System.out.println(output_clientToken);
//		JSONObject jobj_clientToken = new JSONObject(output_clientToken);
//		String auth_token = jobj_clientToken.getString("access_token");
//		return auth_token;
		initiateClient();
		WebResource webResource_clientToken = client.resource(readXMLdata.getTestData("Services/Layer7Services", "endPoint"));
		String clientId = readXMLdata.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "client_id");
		String grantType = readXMLdata.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "grant_type");
		String clientSecrete = readXMLdata.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "client_secret");

		String path =readXMLdata.getTestData("Services/Layer7Services/getAuthTokenService","path");
		System.out.println(clientId + "    " + grantType + "    " + clientSecrete);
		String data = "grant_type=" + grantType + "&client_id=" + clientId + "&client_secret=" + clientSecrete;
		ClientResponse response_clientToken = webResource_clientToken.path(path)
				.type("application/x-www-form-urlencoded").accept("application/json").post(ClientResponse.class, data);
		System.out.println(webResource_clientToken.getProperties());
		int status_clientToken = response_clientToken.getStatus();
		Assert.assertEquals(status_clientToken+" is not the expected status",200,status_clientToken);
		String output_clientToken = response_clientToken.getEntity(String.class);
		System.out.println(output_clientToken);
		JSONObject jobj_clientToken = new JSONObject(output_clientToken);
		String auth_token = jobj_clientToken.getString("access_token");
		return auth_token;
	}

	public JSONObject returnUserDetailsInJsonObjectForm() throws Exception {
		initiateClient();
		String accessToken = getAccessTokenUsingClientTokenService();
		if (!accessToken.isEmpty()) {
//			WebResource webResource = client.resource(getEnvVariable("ExtremeScaleServices.endPoint"));
			WebResource webResource = client.resource(readXMLdata.getTestData("Services/ExtremeScale", "endPoint"));
//			String data = "{\"cacheId\":\"" + new Hooks().getUUID() + "\"}";
			String data = "{\"cacheId\":\"" + dataStorage.getUUID() + "\"}";
//			String authorizationToken = 
//					getEnvVariable("ExtremeScaleServices.getUserDetailsService.Headers.Authorization") + accessToken;
//			String timeStamp = getEnvVariable("ExtremeScaleServices.getUserDetailsService.Headers.timestamp");
//			String scope = getEnvVariable("ExtremeScaleServices.getUserDetailsService.Headers.scope");
//			String actor = getEnvVariable("ExtremeScaleServices.getUserDetailsService.Headers.actor");			
//			String path=getEnvVariable("ExtremeScaleServices.getUserDetailsService.path");
			
			String authorizationToken = readXMLdata.getTestData("Services/ExtremeScale/getUserDetailsService/Headers","Authorization")+" "+accessToken;
					
			String timeStamp = readXMLdata.getTestData("Services/ExtremeScale/getUserDetailsService/Headers","timestamp");
			String scope = readXMLdata.getTestData("Services/ExtremeScale/getUserDetailsService/Headers","scope");
			String actor = readXMLdata.getTestData("Services/ExtremeScale/getUserDetailsService/Headers","actor");			
			String path=readXMLdata.getTestData("Services/ExtremeScale/getUserDetailsService","path");
			
			ClientResponse response = webResource.path(path)
					.accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).header("timestamp", timeStamp)
					.header("scope",scope ).header("actor", actor)
					.header("Authorization", authorizationToken)
					.post(ClientResponse.class, data);
			System.out.println(webResource.getProperties());
			int status = response.getStatus();			
			Assert.assertEquals(status+" is not the expected status",200, status);
			String output = response.getEntity(String.class);			
			output = output.replace("[]", "null");
			output = output.replace("[", "");
			output = output.replace("]", "");			

			JSONObject jobj = new JSONObject(output);
			return jobj;
		} else {
			throw new Exception("Access token should not be empty");
		}

	}
}
