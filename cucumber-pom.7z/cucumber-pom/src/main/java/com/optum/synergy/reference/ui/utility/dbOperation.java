package com.optum.synergy.reference.ui.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class dbOperation {

	private static final String ISECDB_USERNAME = "TSUOPWH";
	private static final String MyUHCProvisioningDB_USERNAME = "myu0_own";
	
	public static void deleterecordFromPDB(String FirstName, String LastName) throws SQLException {
		Connection con = getPDBDBConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = '" + FirstName
					+ "' AND MDM_LST_NM = '" + LastName + "'");
			String hsid = null;

			while (rs.next()) {
				hsid = rs.getString(1);
			}

			stmt.executeUpdate("delete  from mbr_prtl where mbr_prtl_fst_nm= '" + FirstName + "' and mbr_prtl_lst_nm= '"
					+ LastName + "'");
			stmt.executeUpdate(
					"delete FROM mbr WHERE MDM_FST_NM = '" + FirstName + "' AND MDM_LST_NM = '" + LastName + "'");
			if (hsid != null) {
				stmt.executeUpdate("delete  from mbr_extrm_scl_dtl where HLTHSF_ID = '" + hsid + "'");
			}
		} finally {
			con.close();
			con = null;
		}
	}

	public static String deleterecordFromMyUHCPDB(String FirstName, String LastName, String DOB) throws SQLException {
		String PersonalID;
		String lstPersonalID = "";
		Connection con = getMyUHCPDBconnection();
		String[] tmpArr = DOB.split("/");
		DOB = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("Select uhcPersonalID from myu001.member_info where myu001.member_info.cn = '"
							+ FirstName.toUpperCase() + " " + LastName.toUpperCase()
							+ "'and myu001.member_info.uhcDateOfBirth='" + DOB + "'");

			while (rs.next()) {
				PersonalID = rs.getString(1);
				if (lstPersonalID.length() > 0) {
					lstPersonalID = lstPersonalID + ",'" + PersonalID + "'";
				} else {
					lstPersonalID = lstPersonalID + "'" + PersonalID + "'";
				}
			}

			stmt.executeUpdate(
					"delete  from myu001.member_info where myu001.member_info.cn = '" + FirstName.toUpperCase() + " "
							+ LastName.toUpperCase() + "'and myu001.member_info.uhcDateOfBirth='" + DOB + "'");
			return lstPersonalID;

		} finally {			
			
			con.close();
			con = null;
		}
	}

	public static void deleterecordFromISEC(String FirstName, String LastName, String DOB) throws SQLException {

		Connection con = getISECDBConnection();
		try {
			String lstPersonalID = deleterecordFromMyUHCPDB(FirstName, LastName, DOB);
			if (lstPersonalID.length()>0){
				
			Statement stmt = con.createStatement();

			stmt.executeUpdate("delete FROM F6330DBB.I_MEMBER_CURRENT where PERSONAL_ID IN (" + lstPersonalID + ")");}

		} finally {
			con.close();
			con = null;
		}
	}

	public static Connection getPDBDBConnection() throws SQLException {

		Connection con;
		// Obtain database username from runtime environment
		String user = System.getenv("NTID");

		String pwd = System.getenv(System.getProperty("ExecutionEnv") + "PDBpw");

		if (user == null) {
			throw new IllegalStateException("Missing value for DB username environment variable [" + "NTID" + "]");
		}
		if (pwd == null) {
			throw new IllegalStateException("Missing value for DB password environment variable ["
					+ System.getProperty("ExecutionEnv") + "PDBpw" + "]");
		}

		String dbcnectionstring = readXMLdata.getTestData("DB/PDB", "DBConnectionString");
		con = DriverManager.getConnection(dbcnectionstring, user, pwd);
		return con;

	}

	public static Connection getISECDBConnection() throws SQLException {

		// ISEC DB2 credentials, password must come from environment variable.
		
		String ISECDB_PWD = System.getenv(System.getProperty("ExecutionEnv") + "IsecDbPw");
		
		if (ISECDB_PWD == null) {
			throw new IllegalStateException("Missing value for ISEC DB password environment variable ["
					+ System.getProperty("ExecutionEnv") + "IsecDbPw" + "] for username [" 
					+ ISECDB_USERNAME + "]");
		}
		
		Connection con;
		String dbcnectionstring = readXMLdata.getTestData("DB/ISEC", "DBConnectionString");
		con = DriverManager.getConnection(dbcnectionstring, ISECDB_USERNAME, ISECDB_PWD);
		return con;

	}

	public static Connection getMyUHCPDBconnection() throws SQLException {

		// MyUhc Provision DB credentials, password must come from environment variable. 
		
		String MyUHCProvisioningDB_PWD =  System.getenv(System.getProperty("ExecutionEnv") + "MyUhcPdbPw"); // "asEFq3a8";

		if (MyUHCProvisioningDB_PWD == null) {
			throw new IllegalStateException("Missing value for MyUHC Provisioning DB password environment variable ["
					+ System.getProperty("ExecutionEnv") + "MyUhcPdbPw" + "] for username [" 
					+ MyUHCProvisioningDB_USERNAME + "]");
		}
		
		Connection con;
		String dbcnectionstring = readXMLdata.getTestData("DB/MyUHCProvisioning", "DBConnectionString");
		con = DriverManager.getConnection(dbcnectionstring, MyUHCProvisioningDB_USERNAME, MyUHCProvisioningDB_PWD);
		return con;

	}

	public static int recordcountFromMmberTable(String frstname, String lstname) throws SQLException {
		Connection con = getPDBDBConnection();
		int rcrdcnt;

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS recordcnt from	 mbr where MDM_FST_NM= '" + frstname
					+ "' and MDM_LST_NM= '" + lstname + "'");
			rs.next();
			rcrdcnt = Integer.parseInt(rs.getString(1));
			return rcrdcnt;

		} catch (Exception e) {
			dataStorage.setCustomErrmsg(
					"There is a exception thrown while communicating with PDB [" + e.getMessage() + "]");
			return -1;
		} finally {
			con.close();
			con = null;
		}

	}

	public static int recordcountFromMmberTablewithSubscriberid(String frstname, String lstname, String Subscriberid)
			throws SQLException {
		Connection con = getPDBDBConnection();
		int rcrdcnt;

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS recordcnt from	 mbr where MDM_FST_NM= '" + frstname
					+ "' and MDM_LST_NM= '" + lstname + "'" + "and MDM_MBR_SBSCR_ID='" + Subscriberid + "'");
			rs.next();
			rcrdcnt = Integer.parseInt(rs.getString(1));
			return rcrdcnt;

		} catch (Exception e) {
			dataStorage.setCustomErrmsg(
					"There is a exception thrown while communicating with PDB [" + e.getMessage() + "]");
			return -1;
		} finally {
			con.close();
			con = null;
		}

	}

	public static int recordcountFromMmberPortalTable(String frstname, String lstname) throws SQLException {
		Connection con = getPDBDBConnection();
		int rcrdcnt;
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS recordcnt from	 mbr_prtl where mbr_prtl_fst_nm= '"
					+ frstname + "' and mbr_prtl_lst_nm= '" + lstname + "'");
			rs.next();
			rcrdcnt = Integer.parseInt(rs.getString(1));
			return rcrdcnt;
		} catch (Exception e) {
			dataStorage.setCustomErrmsg("There is a exception thrown while communicating with PDB" + e.toString());
			return -1;
		} finally {
			con.close();
			con = null;
		}
	}

	public static String getPortalSpecificMemberIDFromPDB(String firstName, String lastName) throws SQLException {
		String specificMemberID = "MEMBER_NOT_FOUND";
		Connection con = getPDBDBConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT MBR_PRTL_SPC_MBR_ID FROM mbr_prtl WHERE mbr_prtl_fst_nm = '"
					+ firstName + "' AND mbr_prtl_lst_nm = '" + lastName + "'");

			rs.last();
			if (rs.getRow() > 0) {
				specificMemberID = rs.getString(1);
			}

			return specificMemberID;

		} finally {
			con.close();
			con = null;
		}
	}

	public static void cleanupMyUHCmember(String FirstName, String LastName, String DOB) throws SQLException {
		deleterecordFromPDB(FirstName, LastName);
		deleterecordFromISEC(FirstName, LastName, DOB);
	}
}
