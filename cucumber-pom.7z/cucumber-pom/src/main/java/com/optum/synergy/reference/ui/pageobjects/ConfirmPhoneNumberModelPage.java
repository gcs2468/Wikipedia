package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ConfirmPhoneNumberModelPage extends PageObjectBase {

	@FindBy(how = How.CLASS_NAME, using = "//div[@class='modal']")
	private WebElement ConfirmPhoneNumberModal;

	// div[@class='modal__content']/h2[contains(.,'Confirm phone number')]

	@FindBy(how = How.ID, using = "code")
	private WebElement confirmationCodeTextBox;

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(ConfirmPhoneNumberModal)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void enterConfirmationCode() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmationCodeTextBox));
		confirmationCodeTextBox.sendKeys(new Hooks().getPhoneConfirmatioCode());
	}

}
