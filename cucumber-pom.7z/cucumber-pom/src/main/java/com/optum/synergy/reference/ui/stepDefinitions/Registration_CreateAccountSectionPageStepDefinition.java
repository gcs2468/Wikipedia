package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.Registration_CreateAccountSectionPage;
import com.optum.synergy.reference.ui.utility.dataStorage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registration_CreateAccountSectionPageStepDefinition {
	private Registration_CreateAccountSectionPage page;
	
	public Registration_CreateAccountSectionPageStepDefinition() {
		page = new Registration_CreateAccountSectionPage();
	}

	/**
	 * --------------------------------------- Givens
	 * -----------------------------------------
	 **/

	/**
	 * --------------------------------------- Whens
	 * -----------------------------------------
	 **/

	/**
	 * --------------------------------------- Thens
	 * -----------------------------------------
	 **/

	@Then("^I should be at Create account section page$")
	public void i_should_be_at_Create_account_section_page() throws Throwable {
		Thread.sleep(2000);
		Assert.assertTrue("Issue while loading the Create account page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should see a Username label with textbox$")
	public void i_should_see_a_Username_label_with_textbox() throws Throwable {
	    Assert.assertTrue("Issue while displaying the Username label with textbox", page.verifyIfUsernameLabelExistWithTextbox());
	}

	@Then("^I enter valid \"([^\"]*)\" into Username field$")
	public void i_enter_valid_into_Username_field(String userName) throws Throwable {
		page.enterUserName(userName);
	}

	@Then("^I enter valid username into Username field for registration$")
	public void i_enter_valid_username_into_Username_field() throws Throwable {
				
		page.enterUserName(dataStorage.getUserName());
		System.out.println(dataStorage.getUserName());
		dataStorage.setCustomErrmsg("username:::"+dataStorage.getUserName());
	}
	
	//Sravan: added for second username in same scenario in feature
	@Then("^I enter valid second username into Username field for registration$")
	public void i_enter_valid_second_username_into_Username_field() throws Throwable {
				
		page.enterUserName(dataStorage.getUserName() + "x");
		System.out.println(dataStorage.getUserName()+ "x");
		dataStorage.setCustomErrmsg("username:::"+dataStorage.getUserName()+ "x");
	}
	
	@Then("^I enter valid username \"([^\"]*)\" into Username field for bulk registration$")
	public void i_enter_valid_username_into_Username_field(String arg1) throws Throwable {
		
		String username=dataStorage.getUserName();		
		username=username+arg1;// adding special symbol 		
        dataStorage.setUserName(username);// setting up new user name				
		page.enterUserName(username);
		dataStorage.setCustomErrmsg("username:::"+dataStorage.getUserName());
	}
	
	@Then("^I enter valid \"([^\"]*)\" into Password field$")
	public void i_enter_valid_into_Password_field(String password) throws Throwable {
		page.enterPassword(password);
	}

	@Then("^I enter valid \"([^\"]*)\" into Confirm password field$")
	public void i_enter_valid_into_Confirm_password_field(String password) throws Throwable {
		page.enterConfirmPassword(password);
	}

	@Then("^I enter valid \"([^\"]*)\" into Email field$")
	public void i_enter_valid_into_Email_field(String email) throws Throwable {
		page.enterEmail(email);
	}
	
	@Then("^I enter valid email into Email field$")
	public void i_enter_valid_email_into_Email_field() throws Throwable {
		page.enterEmail(dataStorage.getEmailId());
	}
	
	@Then("^I enter valid \"([^\"]*)\" into Confirm email field$")
	public void i_enter_valid_into_Confirm_email_field(String email) throws Throwable {
		page.confirmEmail(email);
	}
	
	@Then("^I enter valid email into Confirm email field$")
	public void i_enter_valid_email_into_Confirm_email_field() throws Throwable {
		page.confirmEmail(dataStorage.getEmailId());
	}

	@Then("^I select the security type as \"([^\"]*)\"$")
	public void i_select_the_security_type_as(String securityType) throws Throwable {
		page.selectSecurityType(securityType); 
		Thread.sleep(1000);
	}

	@Then("^I select security question1 as \"([^\"]*)\"$")
	public void i_select_security_question1_as(String questionName1) throws Throwable {
		page.selectSecurityQuestion1(questionName1);
	}

	@Then("^I select security answer1 as \"([^\"]*)\"$")
	public void i_select_security_answer1_as(String securityAnswer1) throws Throwable {
		page.enterSecurityAnswer1(securityAnswer1);
	}

	@Then("^I select security question2 as \"([^\"]*)\"$")
	public void i_select_security_question2_as(String questionName2) throws Throwable {
		page.selectSecurityQuestion2(questionName2);
	}

	@Then("^I select security answer2 as \"([^\"]*)\"$")
	public void i_select_security_answer2_as(String securityAnswer2) throws Throwable {
		page.enterSecurityAnswer2(securityAnswer2);
	}

	@Then("^I select security question3 as \"([^\"]*)\"$")
	public void i_select_security_question3_as(String questionName3) throws Throwable {
		page.selectSecurityQuestion3(questionName3);
	}

	@Then("^I select security answer3 as \"([^\"]*)\"$")
	public void i_select_security_answer3_as(String securityAnswer3) throws Throwable {
		page.enterSecurityAnswer3(securityAnswer3);
	}

	@Then("^I check the Remember this device check box$")
	public void i_check_the_Remember_this_device_check_box() throws Throwable {
		page.clickRememberThisDeviceCheckBox();
	}

	@Then("^I check the Agree to terms of use check box$")
	public void i_check_the_Agree_to_terms_of_use_check_box() throws Throwable {
		page.clicktermsOfUseCheckBox();
	}

	@Then("^I should see \"([^\"]*)\" required message$")
	public void i_should_see_required_message(String message) throws Throwable {
		page.verifyRequiredField(message);
	}

	@Then("^I shuld see the \"([^\"]*)\" rule tip$")
	public void i_shuld_see_the_rule_tip(String message) throws Throwable {
		page.verifyRuleTip(message);
	}

	@Then("^I enter valid \"([^\"]*)\" into confirm email field$")
	public void i_enter_valid_into_confirm_email_field(String email) throws Throwable {
		page.updateEmail(email);
	}

	@Then("^I enter phone number \"([^\"]*)\"$")
	public void iEnterPhoneNumber(String phoneNumber) throws Throwable {
		page.enterPhoneNumber(phoneNumber);
	}
	
	@Then("^I enter Confirm phone number \"([^\"]*)\"$")
	public void iEnterConfirmPhoneNumber(String phoneNumber) throws Throwable {
		page.enterConfirmPhoneNumber(phoneNumber);
	}

	@Then("^I select Phone Type as \"([^\"]*)\"$")
	public void iSelectPhoneTypeAs(String phoneType) throws Throwable {
		page.selectPhoneType(phoneType);
	}

	@Then("^I should select the Confirm your phone number with option \"([^\"]*)\"$")
	public void iShouldSelectTheConfirmYourPhoneNumberWithOption(String optionName) throws Throwable {
		page.clickConfirmYourPhoneNumberWithRadioButton(optionName);
	}

	@When("^I enter Username with \"([^\"]*)\"$")
	public void iEnterUsernameWith(String userName) throws Throwable {
		page.enterUserName(userName);
	}

	@Then("^I should see an error message \"([^\"]*)\" for Username$")
	public void iShouldSeeAnErrorMessageForUsername(String message) throws Throwable {
		Assert.assertTrue("Username error is displaying the error message " + message,
				page.verifyErrorMessageOnUserName(message));
	}
	
	@Then("^I should see an error message \"([^\"]*)\"$")
	public void iShouldSeeAnErrorMessage(String message) throws Throwable {
		Assert.assertTrue("Error is displaying for field validation" + message,
				page.verifyErrorMessageOnConfirmPhoneNumber(message));
	}
	
	@Then("^I should see an error message \"([^\"]*)\" for Code$")
	public void iShouldSeeAnErrorMessageForCode(String message) throws Throwable {
		Assert.assertTrue("Code field is displaying the error message " + message,
				page.verifyErrorMessageOnCode(message));
	}
	
	@Then("^I should see an error message \"([^\"]*)\" for Confirmation Option$")
	public void iShouldSeeAnErrorMessageForConfirmationOption(String message) throws Throwable {
		Assert.assertTrue("Confirmation Option is displaying the error message " + message,
				page.verifyErrorMessageOnConfirmationOption(message));
	}

	@Then("^I should an error alert message \"([^\"]*)\" under Create username and password section$")
	public void iShouldAnErrorAlertMessageUnderCreateUsernameAndPasswordSection(String message) throws Throwable {
		Assert.assertTrue("error in displaying the error message " + message,
				page.verifyErrorMessageInErrorBox(message));
	}

	@Then("^I should see a Remember this device check box in Create Account page$")
	public void i_should_see_a_Remember_this_device_check_box_in_Create_Account_page() throws Throwable {
		Assert.assertTrue("Issue while displaying the Remember this device checkbox",
				page.verifyForRememberThisDeviceCheckBox());
	}

	@Then("^I should see the Create account form header as \"([^\"]*)\"$")
	public void i_should_see_the_Create_account_form_header_as(String header) throws Throwable {
		Assert.assertTrue("\""+header+"\" heading is not displaying on the Create account form", page.verifyFormHeader(header));
	}
	
	@Then("^I should see the Confirm your phone number input field$")
	public void i_should_see_the_Confirm_your_phone_number_input_field() throws Throwable {
		Assert.assertTrue("Confirm your phone number input field not displayed", page.verifyConfirmphoneNo());
	}
	
	@When("^I enter Code \"([^\"]*)\"$")
	public void iEnterCode(String userName) throws Throwable {
		page.enterCode(userName);
	}
	
	@When("^I click on Edit link$")
	public void iClickOnEditLink() throws Throwable {
		page.editlinkClick();
	}
	
	@When("^I click on Save link$")
	public void iClickOnSaveLink() throws Throwable {
		page.savelinkClick();
	}
	
	@Then("^I should see the \"([^\"]*)\" label in recovery section$")
	public void i_should_see_the_label_in_recovery_section(String label) throws Throwable {
		Assert.assertTrue("\""+label+"\" label is not displaying on the Create account recovery_section", page.verifyRecoverySectionlabel(label));
	}
	
	@Then("^I should see the create account heading$")
	public void i_should_see_the_create_account_heading() throws Throwable {
		Thread.sleep(2000);
		Assert.assertTrue("\""+"\" label is not displaying on the Create account recovery_section", page.verifyCreateHeader());
	}
	
	@Then("^I should see that the Consumer Communications Notice link points to \"([^\"]*)\"$")
	public void iShouldSeeThatTheConsumerCommunicationsNoticeLinkPointsTo(String hrefValue) throws Throwable {
	   // Assert.assertEquals(hrefValue, page.getConsumerCommunicationsNoticeLink().getAttribute("href").trim());
		Assert.assertTrue("Incorrect URL " + page.getConsumerCommunicationsNoticeLink().getAttribute("href"),
				page.getConsumerCommunicationsNoticeLink().getAttribute("href").endsWith(hrefValue));
	}

	@Then("^I should see that the Terms of Use link points to \"([^\"]*)\"$")
	public void iShouldSeeThatTheTermsOfUseLinkPointsTo(String hrefValue) throws Throwable {
		//Assert.assertEquals(hrefValue, page.getTermsOfUseLink().getAttribute("href").trim());
		
		Assert.assertTrue("Incorrect URL " + page.getTermsOfUseLink().getAttribute("href"),
		   page.getTermsOfUseLink().getAttribute("href").endsWith(hrefValue));

	}

	@Then("^I should see that the Privacy Policy link points to \"([^\"]*)\"$")
	public void iShouldSeeThatThePrivacyPolicyLinkPointsTo(String hrefValue) throws Throwable {
		//Assert.assertEquals(hrefValue, page.getPrivacyPolicyLink().getAttribute("href").trim());
		Assert.assertTrue("Incorrect URL " + page.getPrivacyPolicyLink().getAttribute("href"),
				page.getPrivacyPolicyLink().getAttribute("href").endsWith(hrefValue));
	}
	
	@Then("^I should see the Phone number label$")
	public void iShouldSeeThePhoneNumberLabel() throws Throwable {
	    Assert.assertTrue(page.getPhoneNumberLabel().isDisplayed());
	}
	

	@Then("^I should see that the Texting Terms and Conditions link points to \"([^\"]*)\"$")
	public void iShouldSeeThatTheTextingTermsAndConditionsLinkPointsTo(String hrefValue) throws Throwable {
		//Assert.assertEquals(hrefValue, page.getTextingTermsAndConditionsLink().getAttribute("href").trim());
		Assert.assertTrue("Incorrect URL " + page.getTextingTermsAndConditionsLink().getAttribute("href"),
			      page.getTextingTermsAndConditionsLink().getAttribute("href").endsWith(hrefValue));

	}
	
	@Then("^I click on create username and password edit link$")
	public void iClickOnCreateUsernameAndPAsswordEditLink() throws Throwable{
		page.clickCredentialsEditLink();
	}
	
	@Then("^I click on setup account recovery edit link$")
	public void iClickOnSetupAccountRecoveryEditLink() throws Throwable{
		page.clickRecoveryEditLink();
	} 
	
	
	@Then("^I should see the \"([^\"]*)\" label for username$")
	public void iShouldSeeTheLabelForUsername(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyusernameLabel(arg1));
	}


	@Then("^I should see the \"([^\"]*)\"  label for existing username$")
	public void i_should_see_the_for_existing_username_label(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyExistingUsernameLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for password$")
	public void i_should_see_the_label_for_password(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyPasswordLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for confirm password$")
	public void i_should_see_the_label_for_confirm_password(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyConfirmpasswordLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for invalid confirm password$")
	public void i_should_see_the_label_for_invalid_confirm_password(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyinvalidConfirmpasswordLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for special confirm password$")
	public void i_should_see_the_label_for_special_confirm_password(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyspecialConfirmpasswordLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for different confirm password$")
	public void i_should_see_the_label_for_different_confirm_password(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyDifferentConfirmpasswordLabel(arg1));
	}
	
	
	 
	@Then("^I should see the \"([^\"]*)\" label for email$")
	public void iShouldSeeTheLabelForEmail(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyEmailLabel(arg1));
	}

	@Then("^I should see the \"([^\"]*)\" label for confirm email$")
	public void iShouldSeeTheLabelForConfirmEmail(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyConfirmEmailLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for security dropdown$")
	public void i_should_see_the_label_for_security_dropdown(String arg1) throws Throwable {
		Assert.assertEquals("\""+arg1+"\" error message is not displaying on the Registration Page", 
				page.getSecurityDropdownError(),
				arg1);
	}
	
	@Then("^I should see the \"([^\"]*)\" label for security phone number$")
	public void i_should_see_the_label_for_security_phone_number(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifySecurityPhoneNumberLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for security phone type$")
	public void i_should_see_the_label_for_security_phone_type(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifySecurityPhoneTypeLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for invalid security phone number$")
	public void iShouldSeeTheLabelForInvalidSecurityPhoneNumber(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyInvalidSecurityPhoneNumberLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for question 1$")
	public void iShouldSeeTheLabelForquestion1(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyquestion1(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for question 2$")
	public void iShouldSeeTheLabelForquestion2(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyquestion2(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for question 3$")
	public void iShouldSeeTheLabelForquestion3(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyquestion3(arg1));
	}  
	
	@Then("^I should see the \"([^\"]*)\" label for answer 1$")
	public void iShouldSeeTheLabelForAnswer1(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyAnswer1(arg1));
	} 
	
	@Then("^I should see the \"([^\"]*)\" label for answer 2$")
	public void iShouldSeeTheLabelForAnswer2(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyAnswer2(arg1));
	} 
	
	@Then("^I should see the \"([^\"]*)\" label for answer 3$")
	public void iShouldSeeTheLabelForAnswer3(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyAnswer3(arg1));
	}  
	
	@Then("^I should see the \"([^\"]*)\" label for agree terms of validation$")
	public void iShouldSeeTheLabelForAgreeTermsOfValidations(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyAgreeTermsOfValidations(arg1));
	}
	
	@Then("^I should see the following content in \"([^\"]*)\" tooltip$")
	public void iShouldSeeTheFollowingContentInTooltip(String arg1, List<String> contentList) throws Throwable {
		for (String content : contentList) {
			content = content.trim();
			//System.out.println("Expected:" + content);
			Assert.assertTrue("\"" + content + "\" content is not displaying on the tooltip",
					page.verifyTooltipContent(arg1, content));
		}
	}
	
	@When("^I mouse hover over on email tooltip$")
	public void iMouseHoverOverOnEmailTooltip() throws Throwable {
		
		page.mouseHoverOnEmailIdToolTip();
	}
	
	@Then("^I should see the page header of HSID Create Account as \"([^\"]*)\"$")
	public void iShouldSeeThePageHeaderOfHSIDCreateAccountAs(String arg1) throws Throwable {
	   Assert.assertTrue("Create HSID header not displayed.", page.verifyCreateHsidHeaderContent(arg1));
	}
	
	@Then("^I should see the field \"([^\"]*)\" with label \"([^\"]*)\"$")
	public void iShouldSeeTheFieldWithLabel(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Assert.assertEquals(arg2, page.verifyLabels(arg1));
	  
	}

	@Then("^I should see a \"([^\"]*)\" error on top of White section$")
	public void iShouldSeeAErrorOnTopOfWhiteSection(String errorMsg) throws Throwable {
		Assert.assertEquals("Incorrect error message for Username field", errorMsg, page.getWhiteSectionErrorText() ) ;
	}

	@Then("^I should see the \"([^\"]*)\" error for myUhc username$")
	public void iShouldSeeErrorForMyUhcUsername(String errorMsg) {
	                Assert.assertEquals("Incorrect error message for Username field", errorMsg, page.getUsernameErrorText() ) ;
	}

	@Then("^I should see the \"([^\"]*)\" message for myUhc existing username$")
	public void iShouldSeeTheMessageForMyUhcExistingUsername(String arg1) throws Throwable {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyMyUhcExistingUsernameMessage(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" error for myUhc password$")
	public void iShouldSeeErrorForMyUhcPassword(String errorMsg) {
	                Assert.assertEquals("Incorrect error message for Password field", errorMsg, page.getPasswordErrorText() ) ;
	}
	
	@Then("^I should see the \"([^\"]*)\" below phone number security option$")
	public void iShouldSeeTheBelowPhoneNumberSecurityOption(String message) throws Throwable {
		Assert.assertEquals("Incorrect phone message displayed on the Create account section page",
				message, page.getPhoneMsg());
	}
	
	@When("^I mouse hover over on Why we need your email toolTip for Email Id$")
    public void iMouseHoverOverOnToolTipForMemberId() throws Throwable {
		 page.mouseHoverOnEmailIdToolTip();
    }
	
	@Then("^I should see \"([^\"]*)\" message in email toolTip$")
    public void i_should_see_message_on_ToolTip(String message) throws Throwable {
     Assert.assertTrue(page.validateEmailToolTipMessage(message));
    } 

	@Then("^I should see the Username field is empty$")
	public void iShouldSeeTheUsernameFieldIsEmpty() throws Throwable {
	    Assert.assertTrue(page.verifyIfUserNameFieldisEmpty());
	}
	
	@Then("^I should see the Password field is empty$")
	public void iShouldSeeThePasswordFieldIsEmpty() throws Throwable {
	    Assert.assertTrue(page.verifyIfPasswordFieldisEmpty());
	}
	
	@Then("^I should see the ReEnter Password field is empty$")
	public void iShouldSeeTheReEnterPasswordFieldIsEmpty() throws Throwable {
	    Assert.assertTrue(page.verifyIfReEnterPasswordFieldisEmpty());
	}
	
	@Then("^I should see the Email field is empty$")
	public void iShouldSeeTheEmailFieldIsEmpty() throws Throwable {
	    Assert.assertTrue(page.verifyIfEmailFieldisEmpty());
	}
	
	@Then("^I should see the ReEnterEmail field is empty$")
	public void iShouldSeeTheReEnterEmailFieldIsEmpty() throws Throwable {
	    Assert.assertTrue(page.verifyIfReEnterEmailFieldisEmpty());
	}
	
	@Then("^I should see the page header of Upgrade to HSID contains \"([^\"]*)\"$")
	public void iShouldSeeThePageHeaderOfUpgradeToHSIDContains(String content) throws Throwable {
		Assert.assertTrue("Content not present in header", page.verifyUpgradeToHsidHeaderContent(content));
	}
	
	@Then("^I should see the username autopopulated into New username field$")
	public void iShouldSeeTheUsernameAutopopulatedIntoNewUsernameField() throws Throwable {
	    Assert.assertTrue(dataStorage.getUserName().trim().equalsIgnoreCase(page.verifyUsernameAutoPopulated().trim()));
	}
	
	@Then("^I should see the following content in HealthSafeIDTM PopUp Window in Simple StepUp Window$")
	public void iShouldSeeTheFollowingContentInTooltip(List<String> contentList) throws Throwable {
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" content is not displaying on the PopUp",
					page.getHealthSafeIdPopUpWindowContent().contains(content));
		}
	}
	
	@When("^I click on 'X' CloseICON in PopUP Window$")
	public void IclickonCloseICONinPopUP() throws Throwable {
		page.CloseICONinPopUPClick();
	}
	
	@Then("^I should see the Answer1 textbox is masked and editable$")
	public void i_should_see_the_Answer1_as_masked_and_editable() throws Throwable {
		page.VerifySecurityAnswerismaskedandeditable();
	}
}

