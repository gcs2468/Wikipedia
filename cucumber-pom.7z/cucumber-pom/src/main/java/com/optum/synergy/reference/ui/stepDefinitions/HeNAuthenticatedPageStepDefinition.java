package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ConfirmYourIdentityPage_securityQuestions;
import com.optum.synergy.reference.ui.pageobjects.HeNAuthenticatedPage;

import cucumber.api.java.en.Then;

public class HeNAuthenticatedPageStepDefinition {
	private HeNAuthenticatedPage page;	
	public HeNAuthenticatedPageStepDefinition() {
		
		page = new HeNAuthenticatedPage();
	}
	
//	@Then("^I should see usermenu dropdown on global nav bar$")
//	public void i_should_see_usermenu_dropdown_on_global_nav_bar() throws Throwable {
//		Assert.assertTrue("Usermenu on Global Nav bar has not displayed", page.verifyIfUserMenuDisplayedOnGlobalNav());
//		
//	}
	@Then("^I should be at HeN Authenticated page$")
	public void i_should_be_at_HeN_Authenticated_page() throws Throwable {
		Thread.sleep(5000);
		Assert.assertTrue("Issue while loading the authenticated page", page.verifyIfUserMenuDisplayedOnGlobalNav());
		
	}
	
	@Then("^I should landed into Authenticated HeN Home Page$")
	public void i_should_landed_into_Authenticated_HeN_Home_Page() throws Throwable {
		//NOTE: copied from LAWWAUthenticatedPage
		
		//TODO: Should eventually remove this step Def and have feature files explicitly handle 
		//  potential landing on security question page.  For now, keep (for backward compatibility 
		//	with existing feature files) with simpler handling
		ConfirmYourIdentityPage_securityQuestions confirmIdentityPage = new ConfirmYourIdentityPage_securityQuestions();
		if ( confirmIdentityPage.verifyIfPageLoadedSQA() ) {
			confirmIdentityPage.handleSecurityQuestionWithAnswer();	// Fill in default security question answer, click continue			
		}

	}
	
	@Then("^I should see the HeN Home Page with header \"([^\"]*)\"$")
	public void iShouldSeeTheHeNHomePageWithHeader(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		  // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals("\""+arg1+"\"" +" heading is not displayed", page.getPageHeader(),arg1);
	
	}
}
