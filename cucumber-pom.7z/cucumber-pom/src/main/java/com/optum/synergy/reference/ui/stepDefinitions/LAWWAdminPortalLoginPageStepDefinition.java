package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalAuthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalLoginPage;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalUserDeleteConfirmationPage;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalUserDeletePage;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalUserSearchPage;
import com.optum.synergy.reference.ui.pageobjects.LAWWAdminPortalUserSearchResultsPage;
import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import com.optum.synergy.reference.ui.utility.readXMLdata;

import cucumber.api.java.en.Given;

public class LAWWAdminPortalLoginPageStepDefinition {
	private LAWWAdminPortalLoginPage page;
	public LAWWAdminPortalLoginPageStepDefinition() {
		page = new LAWWAdminPortalLoginPage();
	}
	
	@Given("^I logged into LAWW Admin portal using valid credentials$")
	public void i_logged_into_LAWW_Admin_portal_using_valid_credentials() throws Throwable {
		page.openPage();
		page.enterUserID(PageObjectBase.getEnvVariable("LAWWAdminDetails.user"));
		page.enterPassword(PageObjectBase.getEnvVariable("LAWWAdminDetails.password"));
		page.clickLoginButton();
		LAWWAdminPortalAuthenticatedHomePage adminPortalLoggedInPage = new LAWWAdminPortalAuthenticatedHomePage();
		Assert.assertTrue(adminPortalLoggedInPage.verifyIfPageLoaded());
	}

	@Given("^member \"([^\"]*)\" doesnt have record exist in LAWW admin portal$")
	public void member_does_not_have_record_exist_in_LAWW_adminportal(String arg1) {
		// This used to be LAWW specific, but after implementing step def to
		// support cleanup of users during
		// scenarios for other portals, we can leave this here for
		// backwards-compatibility,
		// but redirect to new function with "LAWW" as first parameter
		member_does_not_have_record_exist_in_LAWW_adminportal("LAWW", arg1);
	
	}

	// Sravan - implemented this step definition for other portals like hen and
	// wcp
	@Given("^\"([^\"]*)\" member \"([^\"]*)\" doesnt have record exist in LAWW admin portal$")
	public void member_does_not_have_record_exist_in_LAWW_adminportal(String portalName, String userKey) {
	
		String FirstName = readXMLdata.getTestData(portalName + "/Users/" + userKey, "FirstName");
		String LastName = readXMLdata.getTestData(portalName + "/Users/" + userKey, "LastName");
		page.openPage();
		page.enterUserID(readXMLdata.getTestData("LAWW/AdminPortal", "userid"));
		page.enterPassword(readXMLdata.getTestData("LAWW/AdminPortal", "pwd"));
		page.clickLoginButton();
	
		LAWWAdminPortalAuthenticatedHomePage adminPortalAuthenticatedPage = new LAWWAdminPortalAuthenticatedHomePage();
		Assert.assertTrue("Failed to login to LAWW admin portal", adminPortalAuthenticatedPage.verifyIfPageLoaded());
		LAWWAdminPortalUserSearchPage lawwserchpage = new LAWWAdminPortalUserSearchPage();
		adminPortalAuthenticatedPage.clickSearchForAUserLink();
		Assert.assertTrue("Failed to open search page of LAWW admin portal", lawwserchpage.verifyIfPageLoaded());
		lawwserchpage.enterUserFirstName(FirstName);
		lawwserchpage.enterUserLastName(LastName);
		lawwserchpage.clickSearchButton();
		LAWWAdminPortalUserSearchResultsPage lawwadminsrchrsltpage = new LAWWAdminPortalUserSearchResultsPage();
		boolean searchresult = lawwserchpage.verifySearchResults();
	
		// If results were found, execute delete on each user returned
		if (searchresult) {
			List<String> users = lawwadminsrchrsltpage.getListOfSearchedUsers();
			Assert.assertTrue("ERROR: Did not find expected list of users in LAWW Admin search results",
					users.size() > 0);
			LAWWAdminPortalUserDeleteConfirmationPage userDeleteConfirmationPage = new LAWWAdminPortalUserDeleteConfirmationPage();
			userDeleteConfirmationPage.clickHomeLink();
			for (int tmpint = 0; tmpint < users.size(); tmpint++) {
	
				adminPortalAuthenticatedPage.clickDeleteAUserIDLink();
				LAWWAdminPortalUserDeletePage userDeletePage = new LAWWAdminPortalUserDeletePage();
				Assert.assertTrue("Failed to open User Delete page of LAWW Admin portal",
						userDeletePage.verifyIfPageLoaded());
				userDeletePage.enterOptumUserId(users.get(tmpint));
				userDeletePage.clickSearchUserToDeleteButton();
				Assert.assertTrue(
						"Failed to open Delete confirmation page of LAWW Admin portal for " + users.get(tmpint),
						userDeleteConfirmationPage.verifyIfPageLoaded());
				userDeleteConfirmationPage.clickConfirmDeleteButton();
				Assert.assertTrue(
						"Failed to find 'has been deleted sucessfully' message after deleting " + users.get(tmpint),
						userDeleteConfirmationPage.verifyForTheActionMessage("has been deleted sucessfully"));
				userDeleteConfirmationPage.clickDoneButton();
				userDeleteConfirmationPage.clickHomeLink();
	
			}
		}
	
	}
}
