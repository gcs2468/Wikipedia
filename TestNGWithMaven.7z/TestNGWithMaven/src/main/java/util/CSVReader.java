package util;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Chandrashekhar Gomasa
 * @project TestNGWithMavenFramework
 */

public class CSVReader {

    public String path;
    public BufferedReader buffReader;
    PrintWriter pw = null;
    String line = "";
    String cvsSplitBy = ",";
    List<String> elementValue = new ArrayList<>();


    public CSVReader(String path) {
        this.path = path;
        try {
            buffReader = new BufferedReader(new FileReader(path));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<String> readCsvFile() {

        try {
            while ((line = buffReader.readLine()) != null) {
                elementValue.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return elementValue;
    }


    public boolean setCellDataToCsvFile(String data1, String data2) {
        try {
            pw = new PrintWriter(new File(path));
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        StringBuilder sb = new StringBuilder();
        sb.append(data1);
        sb.append('\n');
        sb.append(data2);
        pw.write(sb.toString());
        pw.close();
        return true;
    }
}