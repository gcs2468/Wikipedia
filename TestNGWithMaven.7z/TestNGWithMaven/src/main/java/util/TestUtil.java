package util;

import java.util.Hashtable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Chandrashekhar Gomasa
 * @project TestNGWithMavenFramework
 */

public class TestUtil {

    //private static final Logger logger = LogManager.getLogger(TestUtil.class); // Using Log4j
    private static final Logger logger = LoggerFactory.getLogger(TestUtil.class);// Using slf4j

    public static Object[][] getdata(String testCaseName, ExcelReader xls) {

        // This will read data from excel for respective test case
        // > Find row num on which test is starting
        // > Find total number of rows of data
        // > Find total number of columns of data
        // > Extract data


        // Find row num on which test is starting
        int testStartRowNum = 1;
        while (!xls.getCellData("Data", 0, testStartRowNum).equalsIgnoreCase(testCaseName)) {
            testStartRowNum++;
            // This will iterate over each and every cell in column 0 till it finds the testcaseName
        }

        //logger.debug("TestPage Case " + testCaseName + " starts from row : " + testStartRowNum);


        // Find total number of rows of data
        int dataStartsRowNum = testStartRowNum + 2;
        int rowsOfData = 0;
        while (!xls.getCellData("Data", 0, dataStartsRowNum + rowsOfData).equals("")) {
            rowsOfData++;
        }

        //logger.debug("Total data sets for test case " + testCaseName + " are " + rowsOfData);


        // Find total number of columns of data
        int ColStartRowNum = testStartRowNum + 1;
        int ColsOfData = 0;
        while (!xls.getCellData("Data", ColsOfData, ColStartRowNum).equals("")) {
            ColsOfData++;
        }
        //logger.debug("Total number of Parameters for test case " + testCaseName + " are " + ColsOfData);


        // Extract data into HashTables and put one hash table in one single row of first column
        Object testdata[][] = new Object[rowsOfData][1];
        Hashtable<String, String> table = null;
        int index = 0;

        for (int rNum = dataStartsRowNum; rNum < dataStartsRowNum + rowsOfData; rNum++) {
            table = new Hashtable<String, String>();
            String forloging = "   ";
            for (int cNum = 0; cNum < ColsOfData; cNum++) {
                String ParameterName = xls.getCellData("Data", cNum, ColStartRowNum);
                String ParameterValue = xls.getCellData("Data", cNum, rNum);
                forloging = forloging + " " + ParameterName + " -------- " + ParameterValue + "-------";
                //System.out.print(ParameterValue+" -------- ");
                table.put(ParameterName, ParameterValue);
            }
            //forloging = forloging + " ";
           // logger.debug(forloging);
            testdata[index][0] = table; // putting table in test data array starting from index 0
            index++;
            //to list
			/*List<String> excellist = new ArrayList<String>(table.values());
			System.out.println(excellist);*/
        }

        return testdata;
    }


    public static boolean getRunmode(String testName, ExcelReader xls) {

        // This will Iterate through every row of test cases sheet and check for the testName.
        // If found it will check its runmode and return boolean value or else return false by default.

        for (int rNum = 2; rNum <= xls.getRowCount("TestPage Cases"); rNum++) {
            String testCaseName = xls.getCellData("TestPage Cases", "TCID", rNum);
            if (testCaseName.equalsIgnoreCase(testName)) {
                // check runmode
                if (xls.getCellData("TestPage Cases", "Runmode", rNum).equalsIgnoreCase("Y")) {
                    return true;
                } else {
                    return false;
                }

            }

        }

        return false;
    }


    // update results for a particular data set
    public static void reportDataSetResult(ExcelReader xls, String testCaseName, int rowNum, String result) {
        xls.setCellData(testCaseName, "Results", rowNum, result);
    }


}
