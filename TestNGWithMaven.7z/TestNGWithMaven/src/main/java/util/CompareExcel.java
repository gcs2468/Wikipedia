package util;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * @author Chandrashekhar Gomasa
 * @project TestNGWithMavenFramework
 */

public class CompareExcel {

    public String path1;
    public String path2;
    public FileInputStream fis1 = null;
    public FileInputStream fis2 = null;
    public FileOutputStream fileOut = null;
    private XSSFWorkbook workbook1 = null;
    private XSSFWorkbook workbook2 = null;
    private XSSFSheet sheet1 = null;
    private XSSFSheet sheet2 = null;
    //    private XSSFRow row1 = null;
    //    private XSSFCell cell = null;


    public CompareExcel(String excelFile1Path, String excelFile2Path) {

        this.path1 = excelFile1Path;
        this.path2 = excelFile2Path;
        try {
            fis1 = new FileInputStream(path1);
            fis2 = new FileInputStream(path2);
            workbook1 = new XSSFWorkbook(fis1);
            workbook2 = new XSSFWorkbook(fis2);
            sheet1 = workbook1.getSheetAt(0);
            sheet2 = workbook2.getSheetAt(0);
			/* if(compareTwoSheets(sheet1, sheet2)) {
			   System.out.println("\n\nThe two excel sheets are Equal");
			   } else {
			        System.out.println("\n\nThe two excel sheets are Not Equal");
			   } */
            fis1.close();
            fis2.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean compareTwoSheets() {
        int firstRow = sheet1.getFirstRowNum();
        int lastRow = sheet1.getLastRowNum();
        boolean equalSheets = true;
        for (int i = firstRow; i <= lastRow; i++) {

            System.out.println("\n\nComparing Row " + i);

            XSSFRow rowOfSheet1 = sheet1.getRow(i);
            XSSFRow rowOfSheet2 = sheet2.getRow(i);
            if (!compareTwoRows(rowOfSheet1, rowOfSheet2)) {
                equalSheets = false;
                System.out.println("Row " + i + " - Not Equal");
                // break;
            } else {
                System.out.println("Row " + i + " - Equal");
            }
        }
        return equalSheets;
    }

    public boolean compareTwoRows(XSSFRow rowOfSheet1, XSSFRow rowOfSheet2) {
        if ((rowOfSheet1 == null) && (rowOfSheet2 == null)) {
            return true;
        } else if ((rowOfSheet1 == null) || (rowOfSheet2 == null)) {
            return false;
        }

        int firstCell1 = rowOfSheet1.getFirstCellNum();
        int lastCell1 = rowOfSheet1.getLastCellNum();
        boolean equalRows = true;

        // Compare all cells in a row
        for (int i = firstCell1; i <= lastCell1; i++) {
            XSSFCell cellOfSheet1 = rowOfSheet1.getCell(i);
            XSSFCell cellOfSheet2 = rowOfSheet2.getCell(i);
            if (!compareTwoCells(cellOfSheet1, cellOfSheet2)) {
                equalRows = false;
                System.out.println("Value of cell " + i + " from sheet-1 : " + cellOfSheet1);
                System.out.println("Value of cell " + i + " from sheet-2 : " + cellOfSheet2);
                System.out.println("Cell Values are Not Equal");
                // break;
            } else {
                // System.out.println("Value of cell "+i+  " from sheet-1 : "+  cellOfSheet1);
                // System.out.println("Value of cell "+i+  " from sheet-2 : "+  cellOfSheet2);
                // System.out.println("Cell Values are Equal");
            }
        }
        return equalRows;
    }


    // Compare Two Cells
    public static boolean compareTwoCells(XSSFCell cellOfSheet1, XSSFCell cellOfSheet2) {
        if ((cellOfSheet1 == null) && (cellOfSheet2 == null)) {
            return true;
        } else if ((cellOfSheet1 == null) || (cellOfSheet2 == null)) {
            return false;
        }

        boolean equalCells = false;
        int type1 = cellOfSheet1.getCellType();
        int type2 = cellOfSheet2.getCellType();
        if (type1 == type2) {
            if (cellOfSheet1.getCellStyle().equals(cellOfSheet2.getCellStyle())) {
                // Compare cells based on its type
                switch (cellOfSheet1.getCellType()) {
                    case XSSFCell.CELL_TYPE_FORMULA:
                        if (cellOfSheet1.getCellFormula().equals(cellOfSheet2.getCellFormula())) {
                            equalCells = true;
                        }
                        break;
                    case XSSFCell.CELL_TYPE_NUMERIC:
                        if (cellOfSheet1.getNumericCellValue() == cellOfSheet2
                                .getNumericCellValue()) {
                            equalCells = true;
                        }
                        break;
                    case XSSFCell.CELL_TYPE_STRING:
                        if (cellOfSheet1.getStringCellValue().equalsIgnoreCase(cellOfSheet2
                                .getStringCellValue())) {
                            equalCells = true;
                        }
                        break;
                    case XSSFCell.CELL_TYPE_BLANK:
                        if (cellOfSheet2.getCellType() == HSSFCell.CELL_TYPE_BLANK) {
                            equalCells = true;
                        }
                        break;
                    case XSSFCell.CELL_TYPE_BOOLEAN:
                        if (cellOfSheet1.getBooleanCellValue() == cellOfSheet2
                                .getBooleanCellValue()) {
                            equalCells = true;
                        }
                        break;
                    case XSSFCell.CELL_TYPE_ERROR:
                        if (cellOfSheet1.getErrorCellValue() == cellOfSheet2.getErrorCellValue()) {
                            equalCells = true;
                        }
                        break;
                    default:
                        if (cellOfSheet1.getStringCellValue().equals(
                                cellOfSheet2.getStringCellValue())) {
                            equalCells = true;
                        }
                        break;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
        return equalCells;
    }

}
