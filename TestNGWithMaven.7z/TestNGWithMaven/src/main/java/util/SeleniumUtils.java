package util;

import com.google.common.base.Function;
import base.Constants;
import base.PropertyConstants;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static base.TestBase.driver;

/**
 * @author Chandrashekhar Gomasa
 * @project TestNGWithMavenFramework
 */

public class SeleniumUtils {

    //private static final Logger logger = LogManager.getLogger(SeleniumUtils.class); // Using Log4j
    private static final Logger logger = LoggerFactory.getLogger(SeleniumUtils.class);// Using slf4j

    public int maxRetry;
    public int explicitWait;
    public int pageRefreshWait;
    public int waitInMilliSec;
    public int refreshWaitInMilliSec;
    public int alertWaitInMilliSec;

    public SeleniumUtils(Properties properties) {
        //maxRetry = Integer.parseInt(properties.getProperty(PropertyConstants.MAX_RETRY));
        maxRetry = Integer.parseInt(properties.getProperty("maxRetry"));
        explicitWait = Integer.parseInt(properties.getProperty(PropertyConstants.EXPLICIT_WAIT));
        pageRefreshWait = Integer.parseInt(properties.getProperty(PropertyConstants.PAGE_REFRESH_WAIT));
        waitInMilliSec = Integer.parseInt(properties.getProperty(PropertyConstants.WAIT_IN_MILLI_SEC));
        alertWaitInMilliSec = Integer.parseInt(properties.getProperty(PropertyConstants.ALERT_WAIT_IN_MILLI_SEC));
        refreshWaitInMilliSec = Integer.parseInt(properties.getProperty(PropertyConstants.REFRESH_WAIT_IN_MILLI_SEC));
    }

    /**
     * Navigate to the given url.
     */
    public void getUrl(String url) {
        if (driver == null)
            return;
        //driver.navigate().to(url);
        driver.get(url);
    }

    /**
     * Find element with given parameter.
     */
    public WebElement findElement(WebDriver driver, Identifier identifier, String locator) {
        By by = getByLocator(identifier, locator);
        return driver.findElement(by);
    }

    /**
     * Find all element with given parameter.
     */
    public List<WebElement> findElements(WebDriver driver, Identifier identifier, String locator) {
        By by = getByLocator(identifier, locator);
        return driver.findElements(by);
    }

    public By getByLocator(Identifier identifier, String locator) {
        By by = null;
        switch (identifier) {
            case ID:
                by = By.id(locator);
                break;
            case NAME:
                by = By.name(locator);
                break;
            case CLASS_NAME:
                by = By.className(locator);
                break;
            case CSS:
                by = By.cssSelector(locator);
                break;
            case XPATH:
                by = By.xpath(locator);
                break;
        }
        return by;
    }

    /**
     * Send text key to webelement. Clear the text before sending the key.
     */
    public void sendKeys(WebElement webElement, String text) {
        webElement.clear();
        waitElementValueTextEmpty(webElement, pageRefreshWait, TimeUnit.SECONDS);
        webElement.sendKeys(text);
    }

    public void modifyEnteredText(String textboxId, String inputData) throws InterruptedException {
        WebElement element = explicitWait(driver, textboxId);
        element.clear();
        element.sendKeys(inputData);
        Thread.sleep(50);
    }

    public boolean waitForElementDisplay(WebDriver driver, WebElement webElement) {
        return waitForElementDisplay(driver, webElement, explicitWait);
    }

    /**
     * Waits until given element is displayed.
     */
    public boolean waitForElementDisplay(WebDriver driver, WebElement webElement, int timeOut) {
        try {
            Wait<WebElement> wait = new FluentWait<WebElement>(webElement).withTimeout(timeOut, TimeUnit.SECONDS).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(new Function<WebElement, Boolean>() {
                           @Override
                           public Boolean apply(WebElement element) {
                               return element.isDisplayed();
                           }
                       }
            );
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits until given element is displayed.
     */
    public boolean waitForElementDisplay(WebDriver driver, final Identifier identifier, final String locator) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(explicitWait, TimeUnit.SECONDS).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver driver) {
                    return findElement(driver, identifier, locator).isDisplayed();
                }
            });
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till text in the element is not empty then returns the test.
     */
    public String getElementTextDisplay(WebDriver driver, final Identifier identifier, final String locator) {
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(explicitWait, TimeUnit.SECONDS).
                ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
        wait.until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                String text = findElement(driver, identifier, locator).getText();
                return null != text && !text.isEmpty();
            }
        });
        return findElement(driver, identifier, locator).getText();
    }

    /**
     * Waits till text in the element is not empty then returns the test.
     */
    public boolean waitElementValueTextDisplay(WebElement element) {
        try {
            new FluentWait<WebElement>(element).withTimeout(explicitWait, TimeUnit.SECONDS).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class).
                    until(new Function<WebElement, Boolean>() {
                              @Override
                              public Boolean apply(WebElement element) {
                                  String text = element.getAttribute(Constants.VALUE);
                                  return null != text && !text.isEmpty();
                              }
                          }
                    );
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till text in the element is empty then returns the test.
     */
    public boolean waitElementValueTextEmpty(WebElement element, int timeOut, TimeUnit timeUnit) {
        try {
            new FluentWait<WebElement>(element).withTimeout(timeOut, timeUnit).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class).
                    until(new Function<WebElement, Boolean>() {
                              @Override
                              public Boolean apply(WebElement element) {
                                  String text = element.getAttribute(Constants.VALUE);
                                  return null == text || text.isEmpty();
                              }
                          }
                    );
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }


    /**
     * Waits till given element is clickable.
     */
    public boolean waitForElementClickable(WebDriver driver, WebElement webElement) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(explicitWait, TimeUnit.SECONDS).
                    pollingEvery(2, TimeUnit.SECONDS).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(ExpectedConditions.elementToBeClickable(webElement));
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }


    public boolean waitForElementClickable(WebDriver driver, WebElement webElement, int timeout) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(timeout, TimeUnit.SECONDS).
                    pollingEvery(2, TimeUnit.SECONDS).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(ExpectedConditions.elementToBeClickable(webElement));
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till given element is clickable.
     */
    public boolean waitForElementClickable(WebDriver driver, Identifier identifier, String locator) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(explicitWait, TimeUnit.SECONDS).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(ExpectedConditions.elementToBeClickable(getByLocator(identifier, locator)));
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }


    /**
     * Waits until page is loaded.
     */
    public void waitForPageLoad(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, explicitWait);
        wait.until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript(
                        "return document.readyState"
                ).equals("complete");
            }
        });
    }

    public WebElement explicitWait(WebDriver driver, final String elementLoc) {
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(50, TimeUnit.SECONDS)
                .pollingEvery(1, TimeUnit.SECONDS)
                .ignoring(NoSuchElementException.class);
        if (elementLoc.contains(".//")) {
            WebElement element = wait.until(new Function<WebDriver, WebElement>() {

                public WebElement apply(WebDriver driver) {
                    return driver.findElement(By.xpath(elementLoc));
                }
            });
            return element;
        } else {
            WebElement element = wait.until(new Function<WebDriver, WebElement>() {

                public WebElement apply(WebDriver driver) {
                    return driver.findElement(By.id(elementLoc));
                }
            });
            return element;
        }
    }

    /**
     * Waits until only one element is found for the given locator.
     */
    public boolean waitForSingleElementVisibility(WebDriver driver, final Identifier identifier, final String locator) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(pageRefreshWait, TimeUnit.SECONDS).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver driver) {
                    List<WebElement> results = findElements(driver, identifier, locator);
                    return null != results && !results.isEmpty() && results.size() == 1;
                }
            });
        } catch (Exception e) {
            // TestBase.debug("Exception while waiting for display of element", e);
            return false;
        }
        return true;
    }

    /**
     * Takes screenshot of the applciation.
     *
     * @return screenshot location.
     */
    public String takeScreenshot(WebDriver driver) {

        TakesScreenshot screenshot = (TakesScreenshot) driver;
        File source = screenshot.getScreenshotAs(OutputType.FILE);
        File dest = new File(
                Constants.SCREENSHOT_DIR + "Screenshot_" + Commons.getCurrentTimeStamp() + ".png");
        try {
            org.apache.commons.io.FileUtils.copyFile(source, dest);

        } catch (IOException e) {
            //   TestBase.debug("IOException occurred while saving screenshot", e);
        }
        String path = dest.getAbsolutePath();
        //logger.info("Screen shot path : " + path);
        return dest.getAbsolutePath();
    }

	/*public String takeScreenshot(WebDriver driver) {
        DateFormat df = new SimpleDateFormat("yyyy_MMM_dd HH_mm_ss");
        Date d = new Date();
        String time = df.format(d);
        File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File dest = new File(Constants.SCREENSHOT_DIR + "Screenshot_" + time + ".png");

        try {
            org.apache.commons.io.FileUtils.copyFile(source, dest);

        } catch (IOException e) {
            //   TestBase.debug("IOException occurred while saving screenshot", e);
        }
        logger.info("Screenshot path is :: " + dest.getAbsolutePath());
        return dest.getAbsolutePath();
    }*/

    public boolean waitFor(WebDriver driver, int timeout, TimeUnit timeUnit) {
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(timeout, timeUnit).
                    ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
            wait.until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver driver) {
                    return !((JavascriptExecutor) driver).executeScript(
                            "return document.readyState"
                    ).equals("complete");
                }
            });
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * Waits till page refresh is triggered.
     */
    public void waitForPageRefresh(WebDriver driver) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, pageRefreshWait);
            wait.until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver driver) {
                    return !((JavascriptExecutor) driver).executeScript(
                            "return document.readyState"
                    ).equals("complete");
                }
            });
        } catch (TimeoutException e) {
        }
    }

    /**
     * Clicks on a Button waiting until that it is clickable.
     */
    public boolean waitClickElement(WebDriver driver, final Identifier identifier, final String locator) {
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(explicitWait, TimeUnit.SECONDS).
                ignoring(NoSuchElementException.class).ignoring(WebDriverException.class).ignoring(
                ElementNotVisibleException.class);
        wait.until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                findElement(driver, identifier, locator).click();
                return true;
            }
        });
        return true;
    }

    /**
     * Clicks on a Button waiting until that it is clickable.
     */
    public boolean waitClickElement(WebElement webElement) {
        new FluentWait<WebElement>(webElement).withTimeout(explicitWait, TimeUnit.SECONDS).
                ignoring(NoSuchElementException.class).ignoring(WebDriverException.class).ignoring(
                ElementNotVisibleException.class).ignoring(TimeoutException.class).
                until(new Function<WebElement, Boolean>() {
                          @Override
                          public Boolean apply(WebElement element) {
                              element.click();
                              return true;
                          }
                      }
                );
        return true;
    }

    public void implicitlyWait(int timeOut, TimeUnit timeUnit) {
        driver.manage().timeouts().implicitlyWait(timeOut, timeUnit);
    }

    public void scrollIntoView(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public void scrollUp() {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, -250);");
    }

    public void scrollDown() {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, 250);");
    }

	/*public void moveToElementClick(WebDriver driver,WebElement element) {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).click().perform();
    }*/

    public void moveToElementClick(WebDriver driver, WebElement element) {
        try {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).click().perform();
            while (isAlertPresent(driver)) {
                Alert alert;
                alert = driver.switchTo().alert();
                alert.accept();
            }
        } catch (StaleElementReferenceException | ClassCastException e) {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).click().perform();
            while (isAlertPresent(driver)) {
                Alert alert;
                alert = driver.switchTo().alert();
                alert.accept();
            }
        }
    }

    public void moveToElement(WebDriver driver, WebElement element) {
        try {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).perform();
        } catch (StaleElementReferenceException e) {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).perform();
        }
    }

    public void selectByValueFromDropDown(WebElement element, String value) {
        Select selectFromDropDown = new Select(element);
        selectFromDropDown.selectByValue(value);
    }


    public void selectByVisibleTextFromDropDown(WebElement element, String value) {
        Select selectFromDropDown = new Select(element);
        selectFromDropDown.selectByVisibleText(value);
    }

    public void selectByIndexFromDropDown(WebElement element, int index) {
        Select selectFromDropDown = new Select(element);
        selectFromDropDown.selectByIndex(index);
    }

    public boolean isAlertPresent(WebDriver driver) {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
    }

    public void zoomOut(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.body.style.zoom='80%'");
    }

    public void zoomIn(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.body.style.zoom='100%'");
    }



	/*public static String captureScreenshot(WebDriver driver,String screenshotName ){

        try{
            TakesScreenshot ts = (TakesScreenshot)driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            String dest = "C:\\Automation\\PIM\\oodp_at_orlm\\Screenshots" + screenshotName+".png";
            File destination = new File (dest);
            org.apache.commons.io.FileUtils.copyFile(source,destination);
            System.out.println("Screenshot taken");
            return(dest);
        }
        catch(Exception e){
            System.out.println("Exception while taking screenshot"+e.getMessage());
            return e.getMessage();
        }
    }*/


    public enum Identifier {ID, NAME, CLASS_NAME, CSS, XPATH}


	/* public void waitForPendingToReady(WebDriver driver, WebElement element, int timeOut) {
	        try{
	        FluentWait fluentWait = new FluentWait(element)
	                .withTimeout(timeOut, TimeUnit.SECONDS)
	                .pollingEvery(10,TimeUnit.SECONDS)
	                .ignoring(NoSuchElementException.class)
	                .ignoring(WebDriverException.class);
	            fluentWait.until(new Function<WebElement, Boolean>() {
	                @Override
	                public Boolean apply(WebElement element) {
	                    String countOfReadyAfter = element.getText();
	                    int readyCount_After = Integer.parseInt(countOfReadyAfter);
	                    logger.info("CR count in Ready state After Wait : " + readyCount_After);
	                    if (readyCount_After > readtStateCountBefore) {
	                        return true;
	                    }
	                    return true;

	                }
	            });

	        } */

    public void pageRefreshWait(WebElement element) {
        try {
            FluentWait<WebElement> fluentWait = new FluentWait<WebElement>(element)
                    .withTimeout(400, TimeUnit.SECONDS)
                    .pollingEvery(10, TimeUnit.SECONDS)
                    .ignoring(NoSuchElementException.class)
                    .ignoring(WebDriverException.class);

            fluentWait.until(new Function<WebElement, Boolean>() {
                @Override
                public Boolean apply(WebElement element) {
                    if (element.isDisplayed()) {
                        logger.info("Element displayed");
                        return true;
                    }
                    logger.info("Element not displayed, Still searching for Element");
                    return false;

                }
            });
        } catch (TimeoutException e) {
            logger.info("Element is not yet displayed ::::: Timeout Exception");
        }
    }


    public void waitTillElementDisplayed(WebElement element, int timeout) {
        try {
            FluentWait<WebElement> fluentWait = new FluentWait<WebElement>(element)
                    .withTimeout(timeout, TimeUnit.SECONDS)
                    .pollingEvery(5, TimeUnit.SECONDS)
                    .ignoring(NoSuchElementException.class)
                    .ignoring(WebDriverException.class);

            fluentWait.until(new Function<WebElement, Boolean>() {
                @Override
                public Boolean apply(WebElement element) {
                    if (element.isDisplayed()) {
                        logger.info("Element is DISPLAYED");
                        return true;
                    }
                    logger.info("Returning False value because element is not yet displayed on the page ");
                    return false;

                }
            });
        } catch (TimeoutException e) {
            logger.info("Timeout Exception in waitTillElementPresent method");
        }
    }


    public void waitTillElementEnabled(WebElement element, int timeout) {
        try {
            FluentWait<WebElement> fluentWait = new FluentWait<WebElement>(element)
                    .withTimeout(timeout, TimeUnit.SECONDS)
                    .pollingEvery(5, TimeUnit.SECONDS)
                    .ignoring(NoSuchElementException.class)
                    .ignoring(WebDriverException.class);

            fluentWait.until(new Function<WebElement, Boolean>() {
                @Override
                public Boolean apply(WebElement element) {
                    if (element.isEnabled()) {
                        //                        logger.info("Element is CLICKABLE");
                        return true;
                    }
                    //                    logger.info("Returning False value because element is not yet displayed on the page ");
                    return false;

                }
            });
        } catch (TimeoutException e) {
            logger.info("Timeout Exception in waitTillElementClickable method");
        }
    }

    public void isAlertPresent() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 15);
            implicitlyWait(10, TimeUnit.SECONDS);
            wait.until(ExpectedConditions.alertIsPresent());
            Alert alert = driver.switchTo().alert();
            alert.dismiss();
            System.out.println("Alert is cancelled");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void highLightElement(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('style', 'background: blue;');", element);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
        js.executeScript("arguments[0].setAttribute('style','border: solid 1px white');", element);
    }

    public void zoomOutWidgetPage(int noOfTimesToIncrease) {
        Actions action = new Actions(driver);
        for (int i = 1; i < noOfTimesToIncrease; i++) {
            action.keyDown(Keys.CONTROL).sendKeys(Keys.ADD).keyUp(Keys.CONTROL).perform();
        }
    }

    public void increasingScreenSize(int noOfTimesToIncrease) {
        Actions action = new Actions(driver);
        waitFor(driver, refreshWaitInMilliSec, TimeUnit.MILLISECONDS);
        for (int i = 1; i <= noOfTimesToIncrease; i++) {
            action.keyDown(Keys.CONTROL).sendKeys(Keys.ADD).keyUp(Keys.CONTROL).perform();
            logger.info("Increased size " + i + "times");
        }
    }

    public void decreasingScreenSize(int noOfTimesToIncrease) {
        Actions action = new Actions(driver);
        waitFor(driver, refreshWaitInMilliSec, TimeUnit.MILLISECONDS);
        for (int i = 1; i <= noOfTimesToIncrease; i++) {
            action.keyDown(Keys.CONTROL).sendKeys(Keys.SUBTRACT).keyUp(Keys.CONTROL).perform();
        }
    }


    // code for file upload
    public static void setClipboardData(String string) {
        //StringSelection is a class that can be used for copy and paste operations.
        StringSelection stringSelection = new StringSelection(string);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
    }

    public void uploadFile() throws Exception {

        try {
            //Setting clipboard with file location
            setClipboardData("Path of file");

            //native key strokes for CTRL, V and ENTER keys
            Robot robot = new Robot();

            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    public void explicitlyWaitMethod() {
        By locator = By.xpath("xyz");
        WebDriverWait wait = new WebDriverWait(driver, 5);
        wait.until(ExpectedConditions.presenceOfElementLocated(locator));
        WebElement rightClickElement = driver.findElement(locator);
        rightClickElement.click();

    }

}
