package util;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.*;

import java.io.*;
import java.util.*;
import java.util.Calendar;

/**
 * @author Chandrashekhar Gomasa
 * @project TestNGWithMavenFramework
 */

public class ExcelReader {

    public String path;

    public FileInputStream fis = null;
    public FileOutputStream fileOut = null;
    private XSSFWorkbook workbook = null;
    private XSSFSheet sheet = null;
    private XSSFRow row = null;
    private XSSFCell cell = null;

    private CellStyle styleForPass;
    private CellStyle styleForFail;
    private CellStyle styleForEachEqualCellValue;
    private CellStyle styleForEachNotEqualCellValue;

    private CellStyle styleForSingleCell;
    private CellStyle styleToHighlightMatchedCell;

    public ExcelReader(String path) {

        this.path = path;
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheetAt(0);
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // returns the row count in a sheet
    public int getRowCount(String sheetName) {
        int index = workbook.getSheetIndex(sheetName);
        if (index == -1)
            return 0;
        else {
            sheet = workbook.getSheetAt(index);
            int number = sheet.getLastRowNum() + 1;
            return number;
        }

    }

    // returns the data from a cell
    public String getCellData(String sheetName, String colName, int rowNum) {
        try {
            if (rowNum <= 0)
                return "";

            int index = workbook.getSheetIndex(sheetName);
            int col_Num = -1;
            if (index == -1)
                return "";

            sheet = workbook.getSheetAt(index);
            row = sheet.getRow(0);
            for (int i = 0; i < row.getLastCellNum(); i++) {
                System.out.println(row.getCell(i).getStringCellValue().trim());
                if (row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
                    col_Num = i;
            }
            if (col_Num == -1)
                return "";

            sheet = workbook.getSheetAt(index);
            row = sheet.getRow(rowNum - 1);
            if (row == null)
                return "";
            cell = row.getCell(col_Num);

            if (cell == null)
                return "";

            if (cell.getCellType() == Cell.CELL_TYPE_STRING)
                return cell.getStringCellValue();
            else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC || cell.getCellType() == Cell.CELL_TYPE_FORMULA) {

                String cellText = String.valueOf(cell.getNumericCellValue());
                if (HSSFDateUtil.isCellDateFormatted(cell)) {

                    double d = cell.getNumericCellValue();

                    Calendar cal = Calendar.getInstance();
                    cal.setTime(HSSFDateUtil.getJavaDate(d));
                    cellText =
                            (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
                    cellText = cal.get(Calendar.DAY_OF_MONTH) + "/" +
                            cal.get(Calendar.MONTH) + 1 + "/" +
                            cellText;
                }


                return cellText;
            } else if (cell.getCellType() == Cell.CELL_TYPE_BLANK)
                return "";
            else
                return String.valueOf(cell.getBooleanCellValue());

        } catch (Exception e) {
            e.printStackTrace();
            return "row " + rowNum + " or column " + colName + " does not exist in xls";
        }
    }

    // returns the data from a cell
    public String getCellData(String sheetName, int colNum, int rowNum) {
        try {
            if (rowNum <= 0)
                return "";

            int index = workbook.getSheetIndex(sheetName);

            if (index == -1)
                return "";

            sheet = workbook.getSheetAt(index);
            row = sheet.getRow(rowNum - 1);
            if (row == null)
                return "";
            cell = row.getCell(colNum);
            if (cell == null)
                return "";

            if (cell.getCellType() == Cell.CELL_TYPE_STRING)
                return cell.getStringCellValue();
            else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC || cell.getCellType() == Cell.CELL_TYPE_FORMULA) {

                String cellText = String.valueOf(cell.getNumericCellValue());
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    // format in form of M/D/YY
                    double d = cell.getNumericCellValue();

                    Calendar cal = Calendar.getInstance();
                    cal.setTime(HSSFDateUtil.getJavaDate(d));
                    cellText =
                            (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
                    cellText = cal.get(Calendar.MONTH) + 1 + "/" +
                            cal.get(Calendar.DAY_OF_MONTH) + "/" +
                            cellText;
                }

                return cellText;
            } else if (cell.getCellType() == Cell.CELL_TYPE_BLANK)
                return "";
            else
                return String.valueOf(cell.getBooleanCellValue());
        } catch (Exception e) {

            e.printStackTrace();
            return "row " + rowNum + " or column " + colNum + " does not exist  in xls";
        }
    }

    // returns true if data is set successfully else false
    public boolean setCellData(String sheetName, String colName, int rowNum, String data) {
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);

            if (rowNum <= 0)
                return false;

            int index = workbook.getSheetIndex(sheetName);
            if (index == -1)
                return false;

            sheet = workbook.getSheetAt(index);

            int colNum = -1;
            row = sheet.getRow(0);
            for (int i = 0; i < row.getLastCellNum(); i++) {
                //System.out.println(row.getCell(i).getStringCellValue().trim());
                if (row.getCell(i).getStringCellValue().trim().equals(colName))
                    colNum = i;
            }

            if (colNum == -1)
                return false;

            sheet.autoSizeColumn(colNum);
            row = sheet.getRow(rowNum - 1);
            if (row == null)
                row = sheet.createRow(rowNum - 1);

            cell = row.getCell(colNum);
            if (cell == null)
                cell = row.createCell(colNum);

            cell.setCellValue(data);

            fis.close();

            fileOut = new FileOutputStream(path);

            workbook.write(fileOut);
            fileOut.flush();
            fileOut.close();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    // Insert data in specific cell using row and column number
    public boolean setCellData(String sheetName, int colNum, int rowNum, String data) {
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);

            if (rowNum <= 0)
                return false;

            int index = workbook.getSheetIndex(sheetName);
            if (index == -1)
                return false;

            sheet = workbook.getSheetAt(index);
            row = sheet.getRow(0);

            if (colNum == -1)
                return false;

            sheet.autoSizeColumn(colNum);
            row = sheet.getRow(rowNum - 1);
            if (row == null)
                row = sheet.createRow(rowNum - 1);

            cell = row.getCell(colNum);
            if (cell == null)
                cell = row.createCell(colNum);

            cell.setCellValue(data);

            fis.close();

            fileOut = new FileOutputStream(path);

            workbook.write(fileOut);
            fileOut.flush();
            fileOut.close();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    // returns true if data is set successfully else false
    public boolean setCellData(String sheetName, String colName, int rowNum, String data, String url) {

        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);

            if (rowNum <= 0)
                return false;

            int index = workbook.getSheetIndex(sheetName);
            int colNum = -1;
            if (index == -1)
                return false;

            sheet = workbook.getSheetAt(index);

            row = sheet.getRow(0);
            for (int i = 0; i < row.getLastCellNum(); i++) {

                if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName))
                    colNum = i;
            }

            if (colNum == -1)
                return false;
            sheet.autoSizeColumn(colNum);
            row = sheet.getRow(rowNum - 1);
            if (row == null)
                row = sheet.createRow(rowNum - 1);

            cell = row.getCell(colNum);
            if (cell == null)
                cell = row.createCell(colNum);

            cell.setCellValue(data);
            XSSFCreationHelper createHelper = workbook.getCreationHelper();

            //cell style for hyperlinks

            CellStyle hlink_style = workbook.createCellStyle();
            XSSFFont hlink_font = workbook.createFont();
            hlink_font.setUnderline(XSSFFont.U_SINGLE);
            hlink_font.setColor(IndexedColors.BLUE.getIndex());
            hlink_style.setFont(hlink_font);
            //hlink_style.setWrapText(true);

            XSSFHyperlink link = createHelper.createHyperlink(XSSFHyperlink.LINK_FILE);
            link.setAddress(url);
            cell.setHyperlink(link);
            cell.setCellStyle(hlink_style);

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);

            fileOut.close();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    // returns true if sheet is created successfully else false
    public boolean addSheet(String sheetname) {
        FileOutputStream fileOut;
        try {
            workbook.createSheet(sheetname);
            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    // returns true if sheet is removed successfully else false if sheet does not exist
    public boolean removeSheet(String sheetName) {
        int index = workbook.getSheetIndex(sheetName);
        if (index == -1)
            return false;

        FileOutputStream fileOut;
        try {
            workbook.removeSheetAt(index);
            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    // returns true if column is created successfully
    public boolean addColumn(String sheetName, String colName) {
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            int index = workbook.getSheetIndex(sheetName);
            if (index == -1)
                return false;

            XSSFCellStyle style = workbook.createCellStyle();
            style.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
            style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

            sheet = workbook.getSheetAt(index);

            row = sheet.getRow(0);
            if (row == null)
                row = sheet.createRow(0);


            if (row.getLastCellNum() == -1)
                cell = row.createCell(0);

            if (row.getCell(0) == null)
                cell = row.createCell(0);

            else
                cell = row.createCell(row.getLastCellNum());

            cell.setCellValue(colName);
            cell.setCellStyle(style);

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;

    }

    // returns true if column is created successfully
    public boolean addColumn(String sheetName, String colName, int colNum) {
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            int index = workbook.getSheetIndex(sheetName);
            if (index == -1)
                return false;

            XSSFCellStyle style = workbook.createCellStyle();
            style.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
            style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

            sheet = workbook.getSheetAt(index);

            row = sheet.getRow(0);
            if (row == null)
                row = sheet.createRow(0);


            if (row.getLastCellNum() == -1)
                cell = row.createCell(0);

            else
                cell = row.createCell(colNum);

            cell.setCellValue(colName);
            cell.setCellStyle(style);

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;

    }

    // returns true if column is created successfully
    public boolean addColumn(String sheetName, String colName, int rowNum, int colNum) {
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            int index = workbook.getSheetIndex(sheetName);
            if (index == -1)
                return false;

            XSSFCellStyle style = workbook.createCellStyle();
            style.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
            style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

            sheet = workbook.getSheetAt(index);

            row = sheet.getRow(rowNum);
            if (row == null)
                row = sheet.createRow(rowNum);

            if (row.getLastCellNum() == -1)
                cell = row.createCell(colNum);

            else
                cell = row.createCell(colNum);

            cell.setCellValue(colName);
            cell.setCellStyle(style);

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;

    }

    // removes a column and all the contents
    public boolean removeColumn(String sheetName, int colNum) {
        try {
            if (!isSheetExist(sheetName))
                return false;
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);
            XSSFCellStyle style = workbook.createCellStyle();
            style.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
            XSSFCreationHelper createHelper = workbook.getCreationHelper();
            style.setFillPattern(HSSFCellStyle.NO_FILL);

            for (int i = 0; i < getRowCount(sheetName); i++) {
                row = sheet.getRow(i);
                if (row != null) {
                    cell = row.getCell(colNum);
                    if (cell != null) {
                        cell.setCellStyle(style);
                        row.removeCell(cell);
                    }
                }
            }
            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    // removes a column and all the contents
    public boolean removeColumn(String sheetName, String colName) {
        int colNum = -1;
        try {
            if (!isSheetExist(sheetName))
                return false;
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);

            row = sheet.getRow(0);
            if (row == null)
                return false;

            int lastCell = row.getLastCellNum();
            if (lastCell == 0) {
                return false;
            }
            for (int i = 0; i < row.getLastCellNum(); i++) {
                if (row.getCell(i).getStringCellValue().trim().equals(colName.trim())) {
                    colNum = i;
                }
            }
            XSSFCellStyle style = workbook.createCellStyle();
            style.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
            XSSFCreationHelper createHelper = workbook.getCreationHelper();
            style.setFillPattern(HSSFCellStyle.NO_FILL);
            int row_count = getRowCount(sheetName);
            // System.out.println("column number in sheet : " + colNum);
            if (colNum >= 0) {
                for (int i = 0; i < getRowCount(sheetName); i++) {

                    row = sheet.getRow(i);

                    if (row != null) {
                        //sheet.removeRow(row);
                        cell = row.getCell(colNum);
                        if (cell != null) {
                            cell.setCellStyle(style);
                            row.removeCell(cell);
                        }
                    }
                }
            }
            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    // find whether sheets exists
    public boolean isSheetExist(String sheetName) {
        int index = workbook.getSheetIndex(sheetName);
        if (index == -1) {
            index = workbook.getSheetIndex(sheetName.toUpperCase());
            if (index == -1)
                return false;
            else
                return true;
        } else
            return true;
    }

    // returns number of columns in a sheet
    public int getColumnCount(String sheetName) {
        // check if sheet exists
        if (!isSheetExist(sheetName))
            return -1;

        sheet = workbook.getSheet(sheetName);
        row = sheet.getRow(0);

        if (row == null)
            return -1;

        return row.getLastCellNum();

    }

    //String sheetName, String testCaseName,String keyword ,String URL,String message
    public boolean addHyperLink(String sheetName, String screenShotColName, String testCaseName, int index, String url, String message) {

        url = url.replace('\\', '/');
        if (!isSheetExist(sheetName))
            return false;

        sheet = workbook.getSheet(sheetName);

        for (int i = 2; i <= getRowCount(sheetName); i++) {
            if (getCellData(sheetName, 0, i).equalsIgnoreCase(testCaseName)) {

                setCellData(sheetName, screenShotColName, i + index, message, url);
                break;
            }
        }
        return true;
    }

    public int getCellRowNum(String sheetName, String colName, String cellValue) {

        for (int i = 2; i <= getRowCount(sheetName); i++) {
            if (getCellData(sheetName, colName, i).equalsIgnoreCase(cellValue)) {
                return i;
            }
        }
        return -1;

    }

    public boolean setCellData(String sheetName, String colName, int colRow, int rowNum, String data) {
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);

            if (rowNum <= 0)
                return false;

            int index = workbook.getSheetIndex(sheetName);
            if (index == -1)
                return false;

            sheet = workbook.getSheetAt(index);

            int colNum = -1;
            row = sheet.getRow(colRow - 1);
            for (int i = 0; i < row.getLastCellNum(); i++) {
                //System.out.println(row.getCell(i).getStringCellValue().trim());
                if (row.getCell(i).getStringCellValue().trim().equals(colName))
                    colNum = i;
            }

            if (colNum == -1)
                return false;

            sheet.autoSizeColumn(colNum);
            row = sheet.getRow(rowNum - 1);
            if (row == null)
                row = sheet.createRow(rowNum - 1);

            cell = row.getCell(colNum);
            if (cell == null)
                cell = row.createCell(colNum);

            cell.setCellValue(data);

            fis.close();

            fileOut = new FileOutputStream(path);

            workbook.write(fileOut);
            fileOut.flush();
            fileOut.close();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public List<String> getSheetsNames() {
        List<String> listOfSheets = null;
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            listOfSheets = new LinkedList<>();
            for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                String sheetName = workbook.getSheetName(i);
                listOfSheets.add(sheetName);
            }
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return listOfSheets;
    }

    // Add columns in product id sheet
    public void addRangeIdsSheetInRangeIdsWorkbook(String sheetName) throws Exception {
        if (isSheetExist(sheetName)) {
            //sheet=workbook.getSheet(sheetName);
            removeSheet(sheetName);
            addSheet(sheetName);
        } else {
            addSheet(sheetName);
        }
        addColumn(sheetName, "RangeId", 0, 0);
        addColumn(sheetName, "RangeScope", 0, 1);
        addColumn(sheetName, "Result", 0, 2);

    }

    // Add columns in Range Id Sheet
    public void addProductIdsSheetInRangeIdsAndProductIdsWorkbook(String sheetName) {
        if (isSheetExist(sheetName)) {
            removeSheet(sheetName);
            addSheet(sheetName);
        } else {
            addSheet(sheetName);
        }
        addColumn(sheetName, "Product_Id", 0);
        addColumn(sheetName, "Product_Loc", 1);
        addColumn(sheetName, "Product_Scope", 2);
        addColumn(sheetName, "Result", 3);
    }

    // Add columns in product id sheet
    public void addProductCharsSheetInProductCharsWorkbook(String sheetName) throws Exception {
        if (isSheetExist(sheetName)) {
            removeSheet(sheetName);
            addSheet(sheetName);
        } else {
            addSheet(sheetName);
        }
        addColumn(sheetName, "ExpChar_Name", 0, 0);
        addColumn(sheetName, "ExpChar_Value", 0, 1);
        addColumn(sheetName, "ActualChar_Name", 0, 2);
        addColumn(sheetName, "ActualChar_Value", 0, 3);
        addColumn(sheetName, "MatchStatus", 0, 4);
        addColumn(sheetName, "Result", 0, 5);
        if (isSheetExist("Sheet1")) {
            removeSheet("Sheet1");
        } else {
            //System.out.println("Sheet1 is not available");
        }
    }

    // Add columns in sheet
    public void addNodesSheetInWorkbook(String sheetName) throws Exception {
        if (isSheetExist(sheetName)) {
            removeSheet(sheetName);
            addSheet(sheetName);
        } else {
            addSheet(sheetName);
        }
        addColumn(sheetName, "Expected_Node", 0, 0);
        //addColumn(sheetName, "Actual_Node", 0, 1);
        //addColumn(sheetName, "Match_Status", 0, 2);
        //addColumn(sheetName, "Result", 0, 3);
    }

    public void addSubNodesSheetInWorkbook(String sheetName) throws Exception {
        if (isSheetExist(sheetName)) {
            sheet = workbook.getSheet(sheetName);
        } else {
            addSheet(sheetName);
        }
        addColumn(sheetName, "Expected_Node", 0, 0);
        addColumn(sheetName, "Actual_Node", 0, 1);
        addColumn(sheetName, "Match_Status", 0, 2);
        addColumn(sheetName, "Result", 0, 3);
    }

    public void addRichTextSheetInWorkbook(String sheetName) throws Exception {
        if (isSheetExist(sheetName)) {
            sheet = workbook.getSheet(sheetName);
        } else {
            addSheet(sheetName);
        }
        addColumn(sheetName, "Expected_RT", 0, 0);
        addColumn(sheetName, "Actual_RT", 0, 1);
        addColumn(sheetName, "MatchStatus", 0, 2);
        addColumn(sheetName, "Result", 0, 3);
    }

    // Add columns in product id sheet
    public void addProductIdsSheetProductCharsWorkbook(String sheetName) throws Exception {
        if (isSheetExist(sheetName)) {
            removeSheet(sheetName);
            addSheet(sheetName);
        } else {
            addSheet(sheetName);
        }
        addColumn(sheetName, "Product_Id", 0, 0);
        addColumn(sheetName, "Result", 0, 1);
    }

    public void addColorRowWise(String sheetName) {
        try {
            sheet = workbook.getSheet(sheetName);

            // Green foreground
            CellStyle styleGreen = workbook.createCellStyle();
            styleGreen.setFillForegroundColor(IndexedColors.GREEN.getIndex());
            styleGreen.setFillPattern(CellStyle.SOLID_FOREGROUND);

            // Red foreground
            CellStyle styleRed = workbook.createCellStyle();
            styleRed.setFillForegroundColor(IndexedColors.RED.getIndex());
            styleRed.setFillPattern(CellStyle.SOLID_FOREGROUND);

            // Yellow foreground
            CellStyle styleYellow = workbook.createCellStyle();
            styleYellow.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            styleYellow.setFillPattern(CellStyle.SOLID_FOREGROUND);

            row = sheet.getRow((short) 0);
            for (int row1 = 1; row1 <= sheet.getLastRowNum(); row1++) {
                row = sheet.getRow((short) row1);
                String cellValue = row.getCell(row.getLastCellNum() - 1).toString();
                for (int col = 0; col <= row.getLastCellNum() - 1; col++) {
                    if (cellValue.equalsIgnoreCase("Pass")) {
                        Cell cell = row.getCell((short) col, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                        cell.setCellStyle(styleGreen);
                    } else if (cellValue.equalsIgnoreCase("Fail")) {
                        Cell cell = row.getCell((short) col, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                        cell.setCellStyle(styleRed);
                    } else {
                        Cell cell = row.getCell((short) col, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                        cell.setCellStyle(styleYellow);
                    }
                }
            }
            // Write the output to a file
            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    public boolean addColor_ForCellWithPassVal(String sheetName, int iRowNum, String colName) {
        try {
            if (!isSheetExist(sheetName))
                return false;
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);
            int rowCount = sheet.getLastRowNum();

            for (int i = 1; i <= rowCount; i++) {
                row = sheet.getRow(i);
                XSSFCell cell = row.getCell(row.getLastCellNum() - 6);
                String cellValue = cell.toString();
                if (cellValue.equalsIgnoreCase("Pass")) {
                    styleForPass = workbook.createCellStyle();
                    styleForPass.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
                    styleForPass.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                    cell.setCellStyle(styleForPass);
                }
            }

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    public boolean addColor_ForCellWithFailVal(String sheetName, int iRowNum, String colName) {
        try {
            if (!isSheetExist(sheetName))
                return false;
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);
            int rowCount = sheet.getLastRowNum();

            for (int i = 1; i <= rowCount; i++) {
                row = sheet.getRow(i);
                XSSFCell cell = row.getCell(row.getLastCellNum() - 6);
                String cellValue = cell.toString();
                if (cellValue.equalsIgnoreCase("Fail")) {

                    styleForFail = workbook.createCellStyle();
                    styleForFail.setFillForegroundColor(IndexedColors.RED.getIndex());
                    styleForFail.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                    cell.setCellStyle(styleForFail);
                }
            }

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    public boolean addColorRowWise(String sheetName, int rowNum) {
        try {
            if (!isSheetExist(sheetName))
                return false;
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);

            int rowCount = sheet.getLastRowNum();

            styleForEachEqualCellValue = workbook.createCellStyle();
            styleForEachEqualCellValue.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            styleForEachEqualCellValue.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            for (int i = 1; i <= rowCount; i++) {
                row = sheet.getRow(i);
                XSSFCell cell = row.getCell(row.getLastCellNum() - 6);
                String cellValue = cell.toString();

                for (int y = 0; y <= getColumnCount(sheetName) - 7; y++) {
                    if (cellValue.equalsIgnoreCase("Pass")) {
                        XSSFCell cellRowWise = sheet.getRow(i).getCell(y);
                        cellRowWise.setCellStyle(styleForEachEqualCellValue);
                    } else {
                        /*XSSFCell cellRowWise = sheet.getRow(i).getCell(y);
                        cellRowWise.setCellStyle(styleForEachNotEqualCellValue);*/
                        System.out.println("When test case FAIL");
                    }
                }
            }

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    public boolean addColorToMismatchedCell(String sheetName, String s1, String s2) {
        try {
            System.out.println("In addColorToMismatchedCell method");
            if (!isSheetExist(sheetName))
                return false;

            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);
            int rowCount = sheet.getLastRowNum();

            for (int i = 1; i <= rowCount; i++) {
                row = sheet.getRow(i);

                int colCount = row.getLastCellNum() - 1;
                for (int y = 0; y <= colCount - 4; y++) {
                    XSSFCell cell = row.getCell(y);
                    System.out.println("Cell val ::" + cell);
                    if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
                        //if (cell != null) {
                        String cellValue = cell.getStringCellValue();

                        if (cellValue.equalsIgnoreCase(s1)) {
                            XSSFCell eachCellValue = sheet.getRow(i).getCell(y);
                            styleForSingleCell = workbook.createCellStyle();
                            styleForSingleCell.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
                            styleForSingleCell.setFillPattern(FillPatternType.BIG_SPOTS);
                            XSSFCell eachCell = sheet.getRow(i).getCell(y);
                            eachCell.setCellStyle(styleForSingleCell);


                        } else {
                            System.out.println("Color change not required");
                        }

                        //}
                    }
                }
            }

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    public boolean highlightCellWithRightValues(String sheetName) {
        try {
            if (!isSheetExist(sheetName))
                return false;

            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);

            styleToHighlightMatchedCell = workbook.createCellStyle();
            styleToHighlightMatchedCell.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            styleToHighlightMatchedCell.setFillPattern(FillPatternType.BIG_SPOTS);

            int rowCount = sheet.getLastRowNum();

            for (int z = 1; z <= rowCount; z++) {

                XSSFCell cell0 = sheet.getRow(z).getCell(0);
                String val0 = cell0.toString();
                XSSFCell cell6 = sheet.getRow(z).getCell(6);
                String val6 = cell6.toString();
                if (!val0.equals(val6)) {
                    cell6.setCellStyle(styleToHighlightMatchedCell);
                }

                XSSFCell cell1 = sheet.getRow(z).getCell(1);
                String val1 = cell1.toString();
                XSSFCell cell7 = sheet.getRow(z).getCell(7);
                String val7 = cell7.toString();
                if (!val1.equals(val7)) {
                    cell7.setCellStyle(styleToHighlightMatchedCell);
                }

                XSSFCell cell2 = sheet.getRow(z).getCell(2);
                String val2 = cell2.toString();
                XSSFCell cell8 = sheet.getRow(z).getCell(8);
                String val8 = cell8.toString();
                if (!val2.equals(val8)) {
                    cell8.setCellStyle(styleToHighlightMatchedCell);
                }

                XSSFCell cell3 = sheet.getRow(z).getCell(3);
                String val3 = cell3.toString();
                XSSFCell cell9 = sheet.getRow(z).getCell(9);
                String val9 = cell9.toString();
                if (!val3.equals(val9)) {
                    cell9.setCellStyle(styleToHighlightMatchedCell);
                }

                XSSFCell cell4 = sheet.getRow(z).getCell(4);
                String val4 = cell4.toString();
                XSSFCell cell10 = sheet.getRow(z).getCell(10);
                String val10 = cell10.toString();
                if (!val4.equals(val10)) {
                    cell10.setCellStyle(styleToHighlightMatchedCell);
                }
            }

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    public boolean greenColorForPassVal(String sheetName, int iRowNum, String colName) {
        try {
            if (!isSheetExist(sheetName))
                return false;
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);
            int rowCount = sheet.getLastRowNum();

            for (int i = 1; i <= rowCount; i++) {
                row = sheet.getRow(i);
                XSSFCell cell = row.getCell(row.getLastCellNum() - 1);
                String cellValue = cell.toString();
                if (cellValue.equalsIgnoreCase("Pass")) {
                    styleForPass = workbook.createCellStyle();
                    styleForPass.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
                    styleForPass.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                    cell.setCellStyle(styleForPass);

                }
            }

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    public boolean redColorForFailVal(String sheetName, int iRowNum, String colName) {
        try {
            if (!isSheetExist(sheetName))
                return false;
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);
            int rowCount = sheet.getLastRowNum();

            for (int i = 1; i <= rowCount; i++) {
                row = sheet.getRow(i);
                XSSFCell cell = row.getCell(row.getLastCellNum() - 1);
                String cellValue = cell.toString();
                if (cellValue.equalsIgnoreCase("Fail")) {
                    styleForFail = workbook.createCellStyle();
                    styleForFail.setFillForegroundColor(IndexedColors.RED.getIndex());
                    styleForFail.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                    cell.setCellStyle(styleForFail);
                }
            }

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    public boolean addColorForPassFail(String sheetName, int rowNum) {
        try {
            if (!isSheetExist(sheetName))
                return false;
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);

            int rowCount = sheet.getLastRowNum();

            styleForPass = workbook.createCellStyle();
            styleForPass.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            styleForPass.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            styleForFail = workbook.createCellStyle();
            styleForFail.setFillForegroundColor(IndexedColors.RED.getIndex());
            styleForFail.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            for (int i = 1; i <= rowCount; i++) {
                row = sheet.getRow(i);
                XSSFCell cell = row.getCell(row.getLastCellNum() - 1);
                String cellValue = cell.toString();

                for (int y = 0; y <= getColumnCount(sheetName) - 2; y++) {
                    if (cellValue.equalsIgnoreCase("Pass")) {
                        XSSFCell cellRowWise = sheet.getRow(i).getCell(y);
                        cellRowWise.setCellStyle(styleForPass);
                    } else if (cellValue.equalsIgnoreCase("Fail")) {
                        XSSFCell cellRowWise_FailVal = sheet.getRow(i).getCell(y);
                        System.out.println("Cell row wise ;;" + cellRowWise_FailVal);
                        cellRowWise_FailVal.setCellStyle(styleForFail);

                    }
                }
            }

            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }



    public static  void main(String[] args) throws Exception {

        String path = "E:\\Workspace\\Intellij\\TestNGWithMaven\\src\\main\\resources\\excelfiles\\Test.xlsx";

        ExcelReader obj = new ExcelReader(path);

        obj.addNodesSheetInWorkbook("TestSheetOne");

        for(int rn = 2; rn <= 5; rn++) {
            obj.setCellData("TestSheetOne", "Expected_Node", rn, "TestOne");
        }

        for(int rn = 2; rn <= obj.getRowCount("TestSheetOne"); rn++) {
            System.out.println(obj.getCellData("TestSheetOne", "Expected_Node", rn));
        }



    }


}


