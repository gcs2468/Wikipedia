package base;

/**
 * @author Chandrashekhar Gomasa
 * @project TestNGWithMavenFramework
 */

public interface PropertyConstants {

    //Webdriver configuration properties
    String IMPLICIT_WAIT = "implicitWait";
    String PAGE_LOAD_TIME = "pageLoadTime";
    String EXPLICIT_WAIT = "explicitWait";
    String PAGE_REFRESH_WAIT = "pageRefreshWait";
    String AJAX_TIMEOUT = "ajaxTimeout";
    String MAX_RETRY = "maxRetry";
    String WAIT_IN_MILLI_SEC = "waitInMilliSec";
    String REFRESH_WAIT_IN_MILLI_SEC = "refreshWaitInMilliSec";
    String ALERT_WAIT_IN_MILLI_SEC = "alertWaitInMilliSec";
    String TAKE_SCREENSHOT_ON_FAILURE = "takeScreenshotOnFailure";
    String REPLACE_CHAR = "replaceChar";
    String REPLACE_CHAR2 = "replaceChar2";
    String ENV1 = "env1";
    String ENV2 = "env2";
    String URL = "url";
    String URL1 = "url1";
    String URL2 = "url2";
    String PESV2_URL = "pesv2_url";
    String PESV2_URL2 = "pesv2_url2";

    String USERNAME = "username";
    String PASSWORD = "password";
    String INVALID_USER = "invalid_user";
    String COLM_USER = "colm_user";
    String LOLM_USER = "lolm_user";
    String ODME_USER = "odme_user";
    String BPC_USER = "bpc_user";
    String BDO_USER = "bdo_user";
    String CPC_USER = "cpc_user";
    String CDM_USER = "cdm_user";
    String REFERENCE_ID = "referenceID";
    String PRODUCT_TYPOLOGY= "productTypology";
    String ORIGIN_OF_REQUEST = "originOfRequest";
    String USE_CASE = "usecase";
    String REASON = "reason";
    String GDP = "gdp";
    String RANGE = "range";
    String FORECAST_QUANTITY = "forecastQuantity";
    String EXPECTED_MARGIN = "expectedMargin";
    String LIST_PRICE_PROPOSAL = "listPriceProposal";
    String CURRENCY = "currency";
    String QUANTITY_OF_LIST_PRICE_PROPOSAL = "quantityOfListPriceProposal";
    String HOME_PAGE_TITLE = "HomePageTitle";
    String REPORT_NAME = "ReportName";
    String USER_SUCCESS_MESSAGE = "UserSuccessMessage";
    String ENABLE_STATUS = "EnableStatus";
    String DISABLE_STATUS = "DisableStatus";
    String URL_SQE = "url_sqe";
    String URL_INT = "url_int";
    
    //To fill the Attributes with some value - Added By Devyani
    //String ATTRIBUTE_DESCRIPTION ="Automation Test";

    String PROD_URL = "Prod_Url";
    String PRE_PROD_URL = "PreProd_Url";
    String SQE_URL = "Sqe_Url";
    String PRODPES_URL = "Prodpes_Url";
    String SQEPES_URL = "Sqepes_Url";
    String PREPRDPES_URL = "Preprdpes_Url";
    String OOSQEPES_URL = "Oosqepes_Url";


    String OOSQE_URL24 = "OoSqe_Url24";
    String eCatOneOfferSqeURL ="oneOfferSQE_URL";

    String PROD_URL24 = "Prod_Url24";
    String PRE_PROD_URL24 = "PreProd_Url24";
    String SQE_URL24 = "Sqe_Url24";


    String RT_INTERFACE = "VerifyRichText";

    String ATTRIBUTE_DESCRIPTION ="Automation TestPage";
    String IMAGE_NAME="image_name";
    String RANGE_ID_01 ="range_id_01";
    String RANGE_ID_02 ="range_id_02";
    String RANGE_ID_03 ="range_id_03";
    String RANGE_ID_04 ="range_id_04";
    String CR_REF_ID_01="crRefId_01";
    String CR_REF_ID_02="crRefId_02";
    String CR_REF_ID_03="crRefId_03";
    String ECAT_SEARCH_ID="ecatSearchId";
    String TAXOCLASS_SIMPLE_TECHNICAL_DATA ="TaxoClassName_E_NRT_CR11";
    String IMPORT_CONFIGURATION_VALUE_COMMON = "ImportConfigurationValue_Common";
    String IMPORT_CONFIGURATION_VALUE_S_NRT_CR6 = "ImportConfigurationValue_S_NRT_CR6";
    String IMPORT_CONFIGURATION_VALUE_E_NRT_CR11 = "ImportConfigurationValue_E_NRT_CR11";
    String EXPORT_CONFIGURATION_VALUE_S_NRT_CR6 = "ExportConfigurationValue_S_NRT_CR6";
    String EXPORT_CONFIGURATION_VALUE_E_NRT_CR11 = "ExportConfigurationValue_E_NRT_CR11";
    String MIGRATION_TAXO_E_NRT_CR7 = "Migration_Taxo_E_NRT_CR7";

    /*Added by astha*/
    String RichText = "Automation RichText";
    String DocumentsList ="Automation TestDoc";
    String ConfiguratorText ="Automation TestConfigurator Text";
    String A_CR_REF_ID_01="A_crRefId_01";
    String A_CR_REF_ID_02="A_crRefId_02";
    String A_CR_REF_ID_03="A_crRefId_03";
    String RANGE_ID_ForNode1 = "range_id_fornode1";
    String RANGE_ID_ForNode2 = "range_id_fornode2";

}
